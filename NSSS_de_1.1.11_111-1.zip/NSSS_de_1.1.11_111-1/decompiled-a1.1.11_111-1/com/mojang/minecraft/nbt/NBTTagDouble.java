package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagDouble extends NBTBase
{
    public double doubleValue;
    
    public NBTTagDouble() {
    }
    
    public NBTTagDouble(final double d) {
        this.doubleValue = d;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeDouble(this.doubleValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.doubleValue = datainput.readDouble();
    }
    
    @Override
    public byte getType() {
        return 6;
    }
    
    @Override
    public String toString() {
        return "" + this.doubleValue;
    }
}
