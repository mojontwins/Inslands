package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagLong extends NBTBase
{
    public long longValue;
    
    public NBTTagLong() {
    }
    
    public NBTTagLong(final long l) {
        this.longValue = l;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeLong(this.longValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.longValue = datainput.readLong();
    }
    
    @Override
    public byte getType() {
        return 4;
    }
    
    @Override
    public String toString() {
        return "" + this.longValue;
    }
}
