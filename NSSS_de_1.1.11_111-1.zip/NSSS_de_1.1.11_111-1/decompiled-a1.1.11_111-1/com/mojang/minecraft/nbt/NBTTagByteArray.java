package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagByteArray extends NBTBase
{
    public byte[] byteArray;
    
    public NBTTagByteArray() {
    }
    
    public NBTTagByteArray(final byte[] abyte0) {
        this.byteArray = abyte0;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeInt(this.byteArray.length);
        dataoutput.write(this.byteArray);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        final int i = datainput.readInt();
        datainput.readFully(this.byteArray = new byte[i]);
    }
    
    @Override
    public byte getType() {
        return 7;
    }
    
    @Override
    public String toString() {
        return "[" + this.byteArray.length + " bytes]";
    }
}
