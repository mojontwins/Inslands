package com.mojang.minecraft.nbt;

import java.util.*;
import java.io.*;

public class NBTTagCompound extends NBTBase
{
    private Map<String, NBTBase> tagMap;
    
    public NBTTagCompound() {
        this.tagMap = new HashMap<String, NBTBase>();
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        for (final NBTBase nbtbase : this.tagMap.values()) {
            NBTBase.writeTag(nbtbase, dataoutput);
        }
        dataoutput.writeByte(0);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.tagMap.clear();
        NBTBase nbtbase;
        while ((nbtbase = NBTBase.readTag(datainput)).getType() != 0) {
            this.tagMap.put(nbtbase.getKey(), nbtbase);
        }
    }
    
    @Override
    public byte getType() {
        return 10;
    }
    
    public void func_762_a(final String s, final NBTBase nbtbase) {
        this.tagMap.put(s, nbtbase.setKey(s));
    }
    
    public void setByte(final String s, final byte byte0) {
        this.tagMap.put(s, new NBTTagByte(byte0).setKey(s));
    }
    
    public void setShort(final String s, final short word0) {
        this.tagMap.put(s, new NBTTagShort(word0).setKey(s));
    }
    
    public void setInteger(final String s, final int i) {
        this.tagMap.put(s, new NBTTagInt(i).setKey(s));
    }
    
    public void setLong(final String s, final long l) {
        this.tagMap.put(s, new NBTTagLong(l).setKey(s));
    }
    
    public void setFloat(final String s, final float f) {
        this.tagMap.put(s, new NBTTagFloat(f).setKey(s));
    }
    
    public void setDouble(final String s, final double d) {
        this.tagMap.put(s, new NBTTagDouble(d).setKey(s));
    }
    
    public void setString(final String s, final String s1) {
        this.tagMap.put(s, new NBTTagString(s1).setKey(s));
    }
    
    public void func_747_a(final String s, final byte[] abyte0) {
        this.tagMap.put(s, new NBTTagByteArray(abyte0).setKey(s));
    }
    
    public void func_763_a(final String s, final NBTTagCompound nbttagcompound) {
        this.tagMap.put(s, nbttagcompound.setKey(s));
    }
    
    public void setBool(final String s, final boolean flag) {
        this.setByte(s, (byte)(flag ? 1 : 0));
    }
    
    public boolean hasKey(final String s) {
        return this.tagMap.containsKey(s);
    }
    
    public byte getByte(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0;
        }
        return this.tagMap.get(s).byteValue;
    }
    
    public short getShort(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0;
        }
        return this.tagMap.get(s).shortValue;
    }
    
    public int getInteger(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0;
        }
        return this.tagMap.get(s).intValue;
    }
    
    public long getLong(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0L;
        }
        return this.tagMap.get(s).longValue;
    }
    
    public float getFloat(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0.0f;
        }
        return this.tagMap.get(s).floatValue;
    }
    
    public double getDouble(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return 0.0;
        }
        return this.tagMap.get(s).doubleValue;
    }
    
    public String getString(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return "";
        }
        return this.tagMap.get(s).stringValue;
    }
    
    public byte[] getByteArray(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return new byte[0];
        }
        return this.tagMap.get(s).byteArray;
    }
    
    public NBTTagCompound getCompoundTag(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return new NBTTagCompound();
        }
        return this.tagMap.get(s);
    }
    
    public NBTTagList getTagList(final String s) {
        if (!this.tagMap.containsKey(s)) {
            return new NBTTagList();
        }
        return this.tagMap.get(s);
    }
    
    public boolean getBoolean(final String s) {
        return this.getByte(s) != 0;
    }
    
    @Override
    public String toString() {
        return "" + this.tagMap.size() + " entries";
    }
}
