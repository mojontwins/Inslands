package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagShort extends NBTBase
{
    public short shortValue;
    
    public NBTTagShort() {
    }
    
    public NBTTagShort(final short word0) {
        this.shortValue = word0;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeShort(this.shortValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.shortValue = datainput.readShort();
    }
    
    @Override
    public byte getType() {
        return 2;
    }
    
    @Override
    public String toString() {
        return "" + this.shortValue;
    }
}
