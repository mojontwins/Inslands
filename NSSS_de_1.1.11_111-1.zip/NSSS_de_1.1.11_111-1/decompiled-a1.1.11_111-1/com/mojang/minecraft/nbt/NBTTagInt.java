package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagInt extends NBTBase
{
    public int intValue;
    
    public NBTTagInt() {
    }
    
    public NBTTagInt(final int i) {
        this.intValue = i;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeInt(this.intValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.intValue = datainput.readInt();
    }
    
    @Override
    public byte getType() {
        return 3;
    }
    
    @Override
    public String toString() {
        return "" + this.intValue;
    }
}
