package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagEnd extends NBTBase
{
    @Override
    void readTagContents(final DataInput datainput) {
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) {
    }
    
    @Override
    public byte getType() {
        return 0;
    }
    
    @Override
    public String toString() {
        return "END";
    }
}
