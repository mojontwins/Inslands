package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagByte extends NBTBase
{
    public byte byteValue;
    
    public NBTTagByte() {
    }
    
    public NBTTagByte(final byte byte0) {
        this.byteValue = byte0;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeByte(this.byteValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.byteValue = datainput.readByte();
    }
    
    @Override
    public byte getType() {
        return 1;
    }
    
    @Override
    public String toString() {
        return "" + this.byteValue;
    }
}
