package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagFloat extends NBTBase
{
    public float floatValue;
    
    public NBTTagFloat() {
    }
    
    public NBTTagFloat(final float f) {
        this.floatValue = f;
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeFloat(this.floatValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.floatValue = datainput.readFloat();
    }
    
    @Override
    public byte getType() {
        return 5;
    }
    
    @Override
    public String toString() {
        return "" + this.floatValue;
    }
}
