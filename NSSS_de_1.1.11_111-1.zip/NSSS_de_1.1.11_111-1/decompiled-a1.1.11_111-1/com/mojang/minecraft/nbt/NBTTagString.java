package com.mojang.minecraft.nbt;

import java.io.*;

public class NBTTagString extends NBTBase
{
    public String stringValue;
    
    public NBTTagString() {
    }
    
    public NBTTagString(final String s) {
        this.stringValue = s;
        if (s == null) {
            throw new IllegalArgumentException("Empty string not allowed");
        }
    }
    
    @Override
    void writeTagContents(final DataOutput dataoutput) throws IOException {
        dataoutput.writeUTF(this.stringValue);
    }
    
    @Override
    void readTagContents(final DataInput datainput) throws IOException {
        this.stringValue = datainput.readUTF();
    }
    
    @Override
    public byte getType() {
        return 8;
    }
    
    @Override
    public String toString() {
        return "" + this.stringValue;
    }
}
