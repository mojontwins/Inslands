package com.mojang.minecraft;

import com.mojang.minecraft.util.*;
import java.awt.*;
import com.mojang.minecraft.gui.*;

public class MinecraftAppletImpl extends Minecraft
{
    final MinecraftApplet mainFrame;
    
    public MinecraftAppletImpl(final MinecraftApplet minecraftapplet, final Component component, final Canvas canvas, final MinecraftApplet minecraftapplet1, final int i, final int j, final boolean flag) {
        super(component, canvas, minecraftapplet1, i, j, flag);
        this.mainFrame = minecraftapplet;
    }
    
    @Override
    public void onMinecraftCrash(final UnexpectedThrowable unexpectedthrowable) {
        this.mainFrame.removeAll();
        this.mainFrame.setLayout(new BorderLayout());
        this.mainFrame.add(new GuiCrashReport(unexpectedthrowable), "Center");
        this.mainFrame.validate();
    }
}
