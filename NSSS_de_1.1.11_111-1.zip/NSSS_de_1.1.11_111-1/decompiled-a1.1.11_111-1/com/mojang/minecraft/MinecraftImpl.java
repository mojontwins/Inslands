package com.mojang.minecraft;

import java.awt.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.gui.*;

public final class MinecraftImpl extends Minecraft
{
    final Frame mainFrame;
    
    public MinecraftImpl(final Component component, final Canvas canvas, final MinecraftApplet minecraftapplet, final int i, final int j, final boolean flag, final Frame frame) {
        super(component, canvas, minecraftapplet, i, j, flag);
        this.mainFrame = frame;
    }
    
    @Override
    public void onMinecraftCrash(final UnexpectedThrowable unexpectedthrowable) {
        this.mainFrame.removeAll();
        this.mainFrame.add(new GuiCrashReport(unexpectedthrowable), "Center");
        this.mainFrame.validate();
    }
}
