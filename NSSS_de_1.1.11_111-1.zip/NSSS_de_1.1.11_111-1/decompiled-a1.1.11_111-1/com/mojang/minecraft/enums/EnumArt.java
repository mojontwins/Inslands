package com.mojang.minecraft.enums;

public enum EnumArt
{
    Kebab("Kebab", 0, "Kebab", 16, 16, 0, 0), 
    Aztec("Aztec", 1, "Aztec", 16, 16, 16, 0), 
    Alban("Alban", 2, "Alban", 16, 16, 32, 0), 
    Aztec2("Aztec2", 3, "Aztec2", 16, 16, 48, 0), 
    Bomb("Bomb", 4, "Bomb", 16, 16, 64, 0), 
    Plant("Plant", 5, "Plant", 16, 16, 80, 0), 
    Wasteland("Wasteland", 6, "Wasteland", 16, 16, 96, 0), 
    Pool("Pool", 7, "Pool", 32, 16, 0, 32), 
    Courbet("Courbet", 8, "Courbet", 32, 16, 32, 32), 
    Sea("Sea", 9, "Sea", 32, 16, 64, 32), 
    Sunset("Sunset", 10, "Sunset", 32, 16, 96, 32), 
    Creebet("Creebet", 11, "Creebet", 32, 16, 128, 32), 
    Wanderer("Wanderer", 12, "Wanderer", 16, 32, 0, 64), 
    Graham("Graham", 13, "Graham", 16, 32, 16, 64), 
    Match("Match", 14, "Match", 32, 32, 0, 128), 
    Bust("Bust", 15, "Bust", 32, 32, 32, 128), 
    Stage("Stage", 16, "Stage", 32, 32, 64, 128), 
    Void("Void", 17, "Void", 32, 32, 96, 128), 
    SkullAndRoses("SkullAndRoses", 18, "SkullAndRoses", 32, 32, 128, 128), 
    Fighters("Fighters", 19, "Fighters", 64, 32, 0, 96), 
    PigScene("PigScene", 20, "Pointer", 64, 64, 0, 192), 
    Pointer("Pointer", 21, "Pigscene", 64, 64, 64, 192), 
    Skeleton("Skeleton", 22, "Skeleton", 64, 48, 192, 64), 
    DonkeyKong("DonkeyKong", 23, "DonkeyKong", 64, 48, 192, 112);
    
    public static final int maxArtTitleLength;
    public final String title;
    public final int sizeX;
    public final int sizeY;
    public final int offsetX;
    public final int offsetY;
    
    static {
        maxArtTitleLength = "SkullAndRoses".length();
    }
    
    private EnumArt(final String s2, final int n, final String s1, final int j, final int k, final int l, final int i1) {
        this.title = s1;
        this.sizeX = j;
        this.sizeY = k;
        this.offsetX = l;
        this.offsetY = i1;
    }
}
