package com.mojang.minecraft.enums;

public enum EnumOS1
{
    linux("linux", 0), 
    solaris("solaris", 1), 
    windows("windows", 2), 
    macos("macos", 3), 
    macos9("macos9", 4), 
    irix("irix", 5), 
    unknown("unknown", 6);
    
    private EnumOS1(final String s, final int n) {
    }
}
