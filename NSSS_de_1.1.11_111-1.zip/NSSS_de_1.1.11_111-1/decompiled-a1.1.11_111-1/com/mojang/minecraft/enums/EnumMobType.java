package com.mojang.minecraft.enums;

public enum EnumMobType
{
    everything("everything", 0), 
    mobs("mobs", 1), 
    players("players", 2);
    
    private EnumMobType(final String s, final int n) {
    }
}
