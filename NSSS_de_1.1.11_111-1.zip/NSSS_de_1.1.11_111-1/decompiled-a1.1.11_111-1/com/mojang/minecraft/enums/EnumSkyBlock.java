package com.mojang.minecraft.enums;

public enum EnumSkyBlock
{
    Sky("Sky", 0, 15), 
    Block("Block", 1, 0);
    
    public final int field_1722_c;
    
    private EnumSkyBlock(final String s, final int n, final int j) {
        this.field_1722_c = j;
    }
}
