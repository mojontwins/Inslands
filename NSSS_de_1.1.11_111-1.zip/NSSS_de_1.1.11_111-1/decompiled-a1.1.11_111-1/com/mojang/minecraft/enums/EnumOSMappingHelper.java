package com.mojang.minecraft.enums;

public class EnumOSMappingHelper
{
    public static final int[] osEnums;
    
    static {
        osEnums = new int[EnumOS2.values().length];
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.linux.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.solaris.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.windows.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.macos.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.macos9.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            EnumOSMappingHelper.osEnums[EnumOS2.irix.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
    }
}
