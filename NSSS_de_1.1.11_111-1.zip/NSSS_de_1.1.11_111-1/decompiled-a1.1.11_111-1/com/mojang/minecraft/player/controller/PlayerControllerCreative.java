package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.entity.spawn.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.*;

public class PlayerControllerCreative extends PlayerController
{
    private SpawnerAnimals cspAnimals;
    private SpawnerMonsters cspMonsters;
    
    public PlayerControllerCreative(final Minecraft minecraft) {
        super(minecraft);
        this.isCreative = true;
        this.cspMonsters = new SpawnerMonsters(this, 200, IMobs.class, new Class[] { EntityZombie.class, EntitySkeleton.class, EntityCreeper.class, EntitySpider.class, EntitySlime.class });
        this.cspAnimals = new SpawnerAnimals(15, EntityAnimals.class, new Class[] { EntitySheep.class, EntityPig.class, EntityCow.class, EntityChicken.class });
    }
    
    @Override
    public void initiateInventory(final EntityPlayer entityplayer) {
        entityplayer.isCreative = true;
        for (int i = 0; i < 9; ++i) {
            if (entityplayer.inventory.mainInventory[i] == null) {
                this.mc.thePlayer.inventory.mainInventory[i] = new ItemStack(Session.creativeInventory.get(i).blockID);
                this.mc.thePlayer.inventory.mainInventory[i].stackSize = -1;
            }
            else {
                this.mc.thePlayer.inventory.mainInventory[i].stackSize = -1;
            }
        }
    }
    
    @Override
    public boolean isVulnerable() {
        return false;
    }
    
    @Override
    public void func_717_a(final World world) {
        super.func_717_a(world);
    }
    
    @Override
    public void updateController() {
        this.cspAnimals.func_1150_a(this.mc.mcWorld);
        this.cspMonsters.func_1150_a(this.mc.mcWorld);
    }
}
