package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.*;

public class PlayerController
{
    protected final Minecraft mc;
    public boolean isCreative;
    
    public PlayerController(final Minecraft minecraft) {
        this.isCreative = false;
        this.mc = minecraft;
    }
    
    public void func_717_a(final World world) {
    }
    
    public void clickBlock(final int i, final int j, final int k, final int l) {
        this.doDigBlock(i, j, k, l);
    }
    
    public boolean doDigBlock(final int i, final int j, final int k, final int l) {
        this.mc.effectRenderer.addBlockDestroyEffects(i, j, k);
        final World world = this.mc.mcWorld;
        final Block block = Block.allBlocks[world.getBlockId(i, j, k)];
        final int i2 = world.getBlockMetadata(i, j, k);
        final boolean flag = world.setBlockWithNotify(i, j, k, 0);
        if (block != null && flag) {
            this.mc.soundMGR.playSound(block.stepSound.stepSoundDir(), i + 0.5f, j + 0.5f, k + 0.5f, (block.stepSound.getVolume() + 1.0f) / 2.0f, block.stepSound.getPitch() * 0.8f);
            if (!(world instanceof WorldClient)) {
                block.dropBlockAsItemWithChance(world, i, j, k, i2);
            }
        }
        return flag;
    }
    
    public void sendRemovingBlock(final int i, final int j, final int k, final int l) {
    }
    
    public void resetBlockRemoving() {
    }
    
    public void setPartialTime(final float f) {
    }
    
    public float getBlockReachDistance() {
        return 5.0f;
    }
    
    public boolean sendUseItem(final EntityPlayer entityplayer, final World world, final ItemStack itemstack) {
        if (!entityplayer.worldObj.multiplayerWorld) {
            return true;
        }
        final int i = itemstack.stackSize;
        final ItemStack itemstack2 = itemstack.useItemRightClick(world, entityplayer);
        if (itemstack2 != itemstack || (itemstack2 != null && itemstack2.stackSize != i)) {
            entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = itemstack2;
            if (itemstack2.stackSize == 0) {
                entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = null;
            }
            return true;
        }
        return false;
    }
    
    public void flipPlayer(final EntityPlayer entityplayer) {
    }
    
    public void updateController() {
    }
    
    public boolean isVulnerable() {
        return true;
    }
    
    public void initiateInventory(final EntityPlayer entityplayer) {
    }
    
    public boolean sendPlaceBlock(final EntityPlayer entityplayer, final World world, final ItemStack itemstack, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockId(i, j, k);
        return (!entityplayer.getIsSneaking() && i2 > 0 && Block.allBlocks[i2].blockActivated(world, i, j, k, entityplayer)) || (itemstack != null && itemstack.useItem(entityplayer, world, i, j, k, l));
    }
    
    public EntityPlayer createPlayer(final World world) {
        return new EntityPlayerSP(this.mc, world, this.mc.session);
    }
    
    public ItemStack func_27174_a(final int window, final int slot, final int click, final boolean flag, final EntityPlayer entityplayer) {
        return entityplayer.craftingInventory.func_27280_a(slot, click, flag, entityplayer);
    }
    
    public void func_20086_a(final int i, final EntityPlayer entityplayer) {
        entityplayer.craftingInventory.onCraftGuiClosed(entityplayer);
        entityplayer.craftingInventory = entityplayer.inventorySlots;
    }
    
    public void attackEntity(final EntityPlayer thePlayer, final Entity entityHit) {
    }
    
    public void interactWithEntity(final EntityPlayer thePlayer, final Entity entityHit) {
    }
}
