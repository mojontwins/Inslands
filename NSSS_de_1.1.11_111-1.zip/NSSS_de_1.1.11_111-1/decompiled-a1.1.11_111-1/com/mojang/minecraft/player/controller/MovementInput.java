package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.entity.*;

public class MovementInput
{
    public float movementLeftRight;
    public float movementForwardBack;
    public boolean field_1177_c;
    public boolean movementIsJumping;
    public boolean movementIsSneaking;
    public boolean movementIsRunning;
    
    public MovementInput() {
        this.movementLeftRight = 0.0f;
        this.movementForwardBack = 0.0f;
        this.field_1177_c = false;
        this.movementIsJumping = false;
        this.movementIsSneaking = false;
        this.movementIsRunning = false;
    }
    
    public void func_797_a(final EntityPlayer entityplayer) {
    }
    
    public void func_798_a() {
    }
    
    public void func_796_a(final int i, final boolean flag) {
    }
}
