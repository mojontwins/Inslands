package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.*;
import com.mojang.minecraft.entity.spawn.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.*;

public class PlayerControllerSP extends PlayerController
{
    private int field_1074_c;
    private int field_1073_d;
    private int field_1072_e;
    private float field_1071_f;
    private float field_1070_g;
    private float field_1069_h;
    private int field_1068_i;
    private SpawnerAnimals sspMonsters;
    private SpawnerAnimals sspAnimals;
    
    public PlayerControllerSP(final Minecraft minecraft) {
        super(minecraft);
        this.field_1074_c = -1;
        this.field_1073_d = -1;
        this.field_1072_e = -1;
        this.field_1071_f = 0.0f;
        this.field_1070_g = 0.0f;
        this.field_1069_h = 0.0f;
        this.field_1068_i = 0;
        this.sspMonsters = new SpawnerMonsters(this, 200, IMobs.class, new Class[] { EntityZombie.class, EntitySkeleton.class, EntityCreeper.class, EntitySpider.class, EntitySlime.class });
        this.sspAnimals = new SpawnerAnimals(15, EntityAnimals.class, new Class[] { EntitySheep.class, EntityPig.class, EntityCow.class, EntityChicken.class });
    }
    
    @Override
    public void flipPlayer(final EntityPlayer entityplayer) {
        entityplayer.rotationYaw = -180.0f;
    }
    
    @Override
    public boolean doDigBlock(final int i, final int j, final int k, final int l) {
        final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
        final int j2 = this.mc.mcWorld.getBlockMetadata(i, j, k);
        final boolean flag = super.doDigBlock(i, j, k, l);
        final ItemStack itemstack = this.mc.thePlayer.getCurrentEquippedItem();
        final boolean flag2 = this.mc.thePlayer.checkBreakBlock(Block.allBlocks[i2]);
        final boolean flag3 = this.mc.thePlayer.checkGoldTouch(Block.allBlocks[i2]);
        if (itemstack != null) {
            itemstack.onDestroyBlock(i2, i, j, k);
            if (itemstack.stackSize == 0) {
                itemstack.func_1097_a(this.mc.thePlayer);
                this.mc.thePlayer.destroyCurrentEquippedItem();
            }
        }
        if (flag && flag3) {
            Block.allBlocks[i2].dropBlockGoldTouch(this.mc.mcWorld, i, j, k, j2, 1.0f);
        }
        else if (flag && flag2) {
            Block.allBlocks[i2].harvestBlock(this.mc.mcWorld, i, j, k, j2);
        }
        return flag;
    }
    
    @Override
    public void clickBlock(final int i, final int j, final int k, final int l) {
        final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
        if (i2 > 0 && this.field_1071_f == 0.0f) {
            Block.allBlocks[i2].onBlockClicked(this.mc.mcWorld, i, j, k, this.mc.thePlayer);
        }
        if (i2 > 0 && Block.allBlocks[i2].blockStrength(this.mc.thePlayer) >= 1.0f) {
            this.doDigBlock(i, j, k, l);
        }
    }
    
    @Override
    public void resetBlockRemoving() {
        this.field_1071_f = 0.0f;
        this.field_1068_i = 0;
    }
    
    @Override
    public void sendRemovingBlock(final int i, final int j, final int k, final int l) {
        if (this.field_1068_i > 0) {
            --this.field_1068_i;
            return;
        }
        if (i == this.field_1074_c && j == this.field_1073_d && k == this.field_1072_e) {
            final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
            if (i2 == 0) {
                return;
            }
            final Block block = Block.allBlocks[i2];
            this.field_1071_f += block.blockStrength(this.mc.thePlayer);
            if (this.field_1069_h % 4.0f == 0.0f && block != null) {
                this.mc.soundMGR.playSound(block.stepSound.func_1145_d(), i + 0.5f, j + 0.5f, k + 0.5f, (block.stepSound.getVolume() + 1.0f) / 8.0f, block.stepSound.getPitch() * 0.5f);
            }
            ++this.field_1069_h;
            if (this.field_1071_f >= 1.0f) {
                this.doDigBlock(i, j, k, l);
                this.field_1071_f = 0.0f;
                this.field_1070_g = 0.0f;
                this.field_1069_h = 0.0f;
                this.field_1068_i = 5;
            }
        }
        else {
            this.field_1071_f = 0.0f;
            this.field_1070_g = 0.0f;
            this.field_1069_h = 0.0f;
            this.field_1074_c = i;
            this.field_1073_d = j;
            this.field_1072_e = k;
        }
    }
    
    @Override
    public void setPartialTime(final float f) {
        if (this.field_1071_f <= 0.0f) {
            this.mc.ingameGUI.field_932_b = 0.0f;
            this.mc.renderGlobal.damagePartialTime = 0.0f;
        }
        else {
            final float f2 = this.field_1070_g + (this.field_1071_f - this.field_1070_g) * f;
            this.mc.ingameGUI.field_932_b = f2;
            this.mc.renderGlobal.damagePartialTime = f2;
        }
    }
    
    @Override
    public float getBlockReachDistance() {
        return 4.0f;
    }
    
    @Override
    public void func_717_a(final World world) {
        super.func_717_a(world);
    }
    
    @Override
    public void updateController() {
        this.field_1070_g = this.field_1071_f;
        this.sspMonsters.func_1150_a(this.mc.mcWorld);
        this.sspAnimals.func_1150_a(this.mc.mcWorld);
        this.mc.soundMGR.func_341_c();
    }
}
