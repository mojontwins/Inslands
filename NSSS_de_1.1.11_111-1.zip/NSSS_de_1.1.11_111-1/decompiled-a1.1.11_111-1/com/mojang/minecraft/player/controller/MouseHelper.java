package com.mojang.minecraft.player.controller;

import java.awt.*;
import com.mojang.minecraft.render.*;
import java.nio.*;
import org.lwjgl.input.*;

public class MouseHelper
{
    private Component field_1117_c;
    public int field_1114_a;
    public int field_1113_b;
    
    public MouseHelper(final Component component) {
        this.field_1117_c = component;
        final IntBuffer intbuffer = GLAllocation.createDirectIntBuffer(1);
        intbuffer.put(0);
        intbuffer.flip();
    }
    
    public void grabMouseCursor() {
        Mouse.setGrabbed(true);
        this.field_1114_a = 0;
        this.field_1113_b = 0;
    }
    
    public void ungrabMouseCursor() {
        Mouse.setCursorPosition(this.field_1117_c.getWidth() / 2, this.field_1117_c.getHeight() / 2);
        Mouse.setGrabbed(false);
    }
    
    public void mouseXYChange() {
        this.field_1114_a = Mouse.getDX();
        this.field_1113_b = Mouse.getDY();
    }
}
