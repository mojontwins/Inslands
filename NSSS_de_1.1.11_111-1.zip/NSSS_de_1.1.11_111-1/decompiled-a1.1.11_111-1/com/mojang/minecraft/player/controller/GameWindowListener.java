package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.*;
import java.awt.event.*;

public final class GameWindowListener extends WindowAdapter
{
    final Minecraft field_1587_a;
    final Thread field_1586_b;
    
    public GameWindowListener(final Minecraft minecraft, final Thread thread) {
        this.field_1587_a = minecraft;
        this.field_1586_b = thread;
    }
    
    @Override
    public void windowClosing(final WindowEvent windowevent) {
        this.field_1587_a.shutdown();
        try {
            this.field_1586_b.join();
        }
        catch (InterruptedException interruptedexception) {
            interruptedexception.printStackTrace();
        }
        System.exit(0);
    }
}
