package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.entity.*;

public class MovementInputFromOptions extends MovementInput
{
    private boolean[] currentPlayerMovement;
    private GameSettings currentInput;
    
    public MovementInputFromOptions(final GameSettings gamesettings) {
        this.currentPlayerMovement = new boolean[10];
        this.currentInput = gamesettings;
    }
    
    @Override
    public void func_796_a(final int i, final boolean flag) {
        byte movement = -1;
        if (i == this.currentInput.keyBindForward.keyCode) {
            movement = 0;
        }
        if (i == this.currentInput.keyBindBack.keyCode) {
            movement = 1;
        }
        if (i == this.currentInput.keyBindLeft.keyCode) {
            movement = 2;
        }
        if (i == this.currentInput.keyBindRight.keyCode) {
            movement = 3;
        }
        if (i == this.currentInput.keyBindJump.keyCode) {
            movement = 4;
        }
        if (i == this.currentInput.keyBindSneak.keyCode) {
            movement = 5;
        }
        if (i == this.currentInput.keyBindRun.keyCode) {
            movement = 6;
        }
        if (movement >= 0) {
            this.currentPlayerMovement[movement] = flag;
        }
    }
    
    @Override
    public void func_798_a() {
        for (int i = 0; i < 10; ++i) {
            this.currentPlayerMovement[i] = false;
        }
    }
    
    @Override
    public void func_797_a(final EntityPlayer entityplayer) {
        this.movementLeftRight = 0.0f;
        this.movementForwardBack = 0.0f;
        if (this.currentPlayerMovement[0]) {
            ++this.movementForwardBack;
        }
        if (this.currentPlayerMovement[1]) {
            --this.movementForwardBack;
        }
        if (this.currentPlayerMovement[2]) {
            ++this.movementLeftRight;
        }
        if (this.currentPlayerMovement[3]) {
            --this.movementLeftRight;
        }
        this.movementIsJumping = this.currentPlayerMovement[4];
        this.movementIsSneaking = this.currentPlayerMovement[5];
        this.movementIsRunning = this.currentPlayerMovement[6];
        if (this.movementIsSneaking) {
            this.movementIsRunning = false;
            this.movementLeftRight *= (float)0.3;
            this.movementForwardBack *= (float)0.3;
        }
        if (this.movementIsRunning) {
            this.movementLeftRight *= 1.5;
            this.movementForwardBack *= 1.5;
        }
    }
}
