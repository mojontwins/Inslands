package com.mojang.minecraft.player.controller;

public class KeyBinding
{
    public String keyDescription;
    public int keyCode;
    
    public KeyBinding(final String s, final int i) {
        this.keyDescription = s;
        this.keyCode = i;
    }
}
