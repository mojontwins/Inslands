package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.*;

public class CommandHandler
{
    Minecraft mc;
}
