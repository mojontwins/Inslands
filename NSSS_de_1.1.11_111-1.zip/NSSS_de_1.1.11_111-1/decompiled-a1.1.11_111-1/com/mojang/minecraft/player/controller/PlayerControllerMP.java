package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.networknew.packet.*;
import com.mojang.minecraft.entity.*;

public class PlayerControllerMP extends PlayerController
{
    private int currentBlockX;
    private int currentBlockY;
    private int currentBlockZ;
    private float curBlockDamageMP;
    private float prevBlockDamageMP;
    private float h;
    private int blockHitDelay;
    private boolean isHittingBlock;
    private NetClientHandler netClientHandler;
    private int currentPlayerItem;
    
    public PlayerControllerMP(final Minecraft minecraft, final NetClientHandler netclienthandler) {
        super(minecraft);
        this.currentBlockX = -1;
        this.currentBlockY = -1;
        this.currentBlockZ = -1;
        this.curBlockDamageMP = 0.0f;
        this.prevBlockDamageMP = 0.0f;
        this.h = 0.0f;
        this.blockHitDelay = 0;
        this.isHittingBlock = false;
        this.currentPlayerItem = 0;
        this.netClientHandler = netclienthandler;
    }
    
    @Override
    public void flipPlayer(final EntityPlayer entityplayer) {
        entityplayer.rotationYaw = -180.0f;
    }
    
    @Override
    public boolean doDigBlock(final int i, final int j, final int k, final int l) {
        this.netClientHandler.addToSendQueue(new Packet14BlockDig(2, i, j, k, l));
        final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
        final int j2 = this.mc.mcWorld.getBlockMetadata(i, j, k);
        final boolean flag = super.doDigBlock(i, j, k, l);
        final boolean flag2 = this.mc.thePlayer.checkBreakBlock(Block.allBlocks[i2]);
        final boolean flag3 = this.mc.thePlayer.checkGoldTouch(Block.allBlocks[i2]);
        final ItemStack itemstack = this.mc.thePlayer.getCurrentEquippedItem();
        if (itemstack != null) {
            itemstack.onDestroyBlock(i2, i, j, k);
            if (itemstack.stackSize == 0) {
                itemstack.func_1097_a(this.mc.thePlayer);
                this.mc.thePlayer.destroyCurrentEquippedItem();
            }
        }
        if (flag && flag3) {
            Block.allBlocks[i2].dropBlockGoldTouch(this.mc.mcWorld, i, j, k, j2, 1.0f);
        }
        else if (flag && flag2) {
            Block.allBlocks[i2].harvestBlock(this.mc.mcWorld, i, j, k, j2);
        }
        return flag;
    }
    
    public boolean sendBlockRemoved(final int i, final int j, final int k, final int l) {
        final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
        final boolean flag = super.doDigBlock(i, j, k, l);
        final ItemStack itemstack = this.mc.thePlayer.getCurrentEquippedItem();
        if (itemstack != null) {
            itemstack.onDestroyBlock(i2, i, j, k);
            if (itemstack.stackSize == 0) {
                itemstack.func_1097_a(this.mc.thePlayer);
                this.mc.thePlayer.destroyCurrentEquippedItem();
            }
        }
        return flag;
    }
    
    @Override
    public void clickBlock(final int i, final int j, final int k, final int l) {
        if (!this.isHittingBlock || i != this.currentBlockX || j != this.currentBlockY || k != this.currentBlockZ) {
            this.netClientHandler.addToSendQueue(new Packet14BlockDig(0, i, j, k, l));
            final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
            if (i2 > 0 && this.curBlockDamageMP == 0.0f) {
                Block.allBlocks[i2].onBlockClicked(this.mc.mcWorld, i, j, k, this.mc.thePlayer);
            }
            if (i2 > 0 && Block.allBlocks[i2].blockStrength(this.mc.thePlayer) >= 1.0f) {
                this.sendBlockRemoved(i, j, k, l);
            }
            else {
                this.isHittingBlock = true;
                this.currentBlockX = i;
                this.currentBlockY = j;
                this.currentBlockZ = k;
                this.curBlockDamageMP = 0.0f;
                this.prevBlockDamageMP = 0.0f;
                this.h = 0.0f;
            }
        }
    }
    
    @Override
    public void resetBlockRemoving() {
        this.curBlockDamageMP = 0.0f;
        this.isHittingBlock = false;
    }
    
    @Override
    public void sendRemovingBlock(final int i, final int j, final int k, final int l) {
        if (!this.isHittingBlock) {
            return;
        }
        this.syncCurrentPlayItem();
        if (this.blockHitDelay > 0) {
            --this.blockHitDelay;
            return;
        }
        if (i == this.currentBlockX && j == this.currentBlockY && k == this.currentBlockZ) {
            final int i2 = this.mc.mcWorld.getBlockId(i, j, k);
            if (i2 == 0) {
                this.isHittingBlock = false;
                return;
            }
            final Block block = Block.allBlocks[i2];
            this.curBlockDamageMP += block.blockStrength(this.mc.thePlayer);
            if (this.h % 4.0f == 0.0f && block != null) {
                this.mc.soundMGR.playSound(block.stepSound.func_1145_d(), i + 0.5f, j + 0.5f, k + 0.5f, (block.stepSound.getVolume() + 1.0f) / 8.0f, block.stepSound.getPitch() * 0.5f);
            }
            ++this.h;
            if (this.curBlockDamageMP >= 1.0f) {
                this.isHittingBlock = false;
                this.netClientHandler.addToSendQueue(new Packet14BlockDig(2, i, j, k, l));
                this.sendBlockRemoved(i, j, k, l);
                this.curBlockDamageMP = 0.0f;
                this.prevBlockDamageMP = 0.0f;
                this.h = 0.0f;
                this.blockHitDelay = 5;
            }
        }
        else {
            this.clickBlock(i, j, k, l);
        }
    }
    
    @Override
    public void setPartialTime(final float f) {
        if (this.curBlockDamageMP <= 0.0f) {
            this.mc.ingameGUI.field_932_b = 0.0f;
            this.mc.renderGlobal.damagePartialTime = 0.0f;
        }
        else {
            final float f2 = this.prevBlockDamageMP + (this.curBlockDamageMP - this.prevBlockDamageMP) * f;
            this.mc.ingameGUI.field_932_b = f2;
            this.mc.renderGlobal.damagePartialTime = f2;
        }
    }
    
    @Override
    public float getBlockReachDistance() {
        return 4.0f;
    }
    
    @Override
    public void func_717_a(final World world) {
        super.func_717_a(world);
    }
    
    @Override
    public void updateController() {
        this.syncCurrentPlayItem();
        this.prevBlockDamageMP = this.curBlockDamageMP;
        this.mc.soundMGR.func_341_c();
    }
    
    private void syncCurrentPlayItem() {
        final int i = this.mc.thePlayer.inventory.currentItem;
        if (i != this.currentPlayerItem) {
            this.currentPlayerItem = i;
            this.netClientHandler.addToSendQueue(new Packet16BlockItemSwitch(this.currentPlayerItem));
        }
    }
    
    @Override
    public void attackEntity(final EntityPlayer entityplayer, final Entity entity) {
        this.syncCurrentPlayItem();
        this.netClientHandler.addToSendQueue(new Packet7UseEntity(entityplayer.entityId, entity.entityId, 1));
        entityplayer.attackTargetEntityWithCurrentItem(entity);
    }
    
    @Override
    public void interactWithEntity(final EntityPlayer entityplayer, final Entity entity) {
        this.syncCurrentPlayItem();
        this.netClientHandler.addToSendQueue(new Packet7UseEntity(entityplayer.entityId, entity.entityId, 0));
        entityplayer.useCurrentItemOnEntity(entity);
    }
    
    @Override
    public boolean sendPlaceBlock(final EntityPlayer entityplayer, final World world, final ItemStack itemstack, final int i, final int j, final int k, final int l) {
        this.syncCurrentPlayItem();
        this.netClientHandler.addToSendQueue(new Packet15Place(i, j, k, l, itemstack));
        return super.sendPlaceBlock(entityplayer, world, itemstack, i, j, k, l);
    }
    
    @Override
    public boolean sendUseItem(final EntityPlayer entityplayer, final World world, final ItemStack itemstack) {
        this.syncCurrentPlayItem();
        this.netClientHandler.addToSendQueue(new Packet15Place(-1, -1, -1, 255, entityplayer.inventory.getCurrentItem()));
        final boolean flag = super.sendUseItem(entityplayer, world, itemstack);
        return flag;
    }
    
    @Override
    public ItemStack func_27174_a(final int window, final int slot, final int click, final boolean flag, final EntityPlayer entityplayer) {
        final short act = entityplayer.craftingInventory.func_20111_a(entityplayer.inventory);
        final ItemStack itemstack = super.func_27174_a(window, slot, click, flag, entityplayer);
        this.netClientHandler.addToSendQueue(new Packet102WindowClick(window, slot, click, flag, itemstack, act));
        return itemstack;
    }
    
    @Override
    public EntityPlayer createPlayer(final World world) {
        return new EntityClientPlayerMP(this.mc, world, this.mc.session, this.netClientHandler);
    }
    
    @Override
    public void func_20086_a(final int i, final EntityPlayer entityplayer) {
        if (i == -9999) {
            return;
        }
    }
}
