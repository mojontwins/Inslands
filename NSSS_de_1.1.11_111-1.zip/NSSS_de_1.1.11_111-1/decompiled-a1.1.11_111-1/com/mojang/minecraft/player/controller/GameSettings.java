package com.mojang.minecraft.player.controller;

import com.mojang.minecraft.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.*;
import org.lwjgl.*;
import java.util.*;
import com.mojang.minecraft.util.*;
import java.io.*;

public class GameSettings
{
    private static final String[] RENDER_DISTANCES;
    private static final String[] DIFFICULTY_LEVELS;
    private static final String[] GUI_SCALES;
    private static final String[] CLOUD_LEVELS;
    private static final String[] LEAF_LEVELS;
    public String lastServer;
    public float musicVolume;
    public float soundVolume;
    public float ambienceVolume;
    public float mouseSensitivity;
    public float modemVolume;
    public boolean invertMouse;
    public int renderDistance;
    public boolean viewBobbing;
    public boolean anaglyph;
    public boolean limitFramerate;
    public boolean fancyGraphics;
    public KeyBinding keyBindForward;
    public KeyBinding keyBindLeft;
    public KeyBinding keyBindBack;
    public KeyBinding keyBindRight;
    public KeyBinding keyBindJump;
    public KeyBinding keyBindBuild;
    public KeyBinding keyBindInventory;
    public KeyBinding keyBindDrop;
    public KeyBinding keyBindChat;
    public KeyBinding keyBindToggleFog;
    public KeyBinding keyBindSneak;
    public KeyBinding keyBindRun;
    public KeyBinding keyBindSaveLocation;
    public KeyBinding keyBindLoadLocation;
    public KeyBinding[] keyBindings;
    protected Minecraft mc;
    private File optionsFile;
    public int numberOfOptions;
    public int difficulty;
    public int chunkSavingInterval;
    public int guiScale;
    public int FOV;
    public boolean thirdPersonView;
    public boolean fog;
    public boolean clouds;
    public boolean particles;
    public boolean advancedOpenGL;
    public int displayMode;
    public int cloudLevel;
    public int leafLevel;
    public boolean precipLevel;
    public boolean vignette;
    public boolean mobShadows;
    public boolean vSync;
    public boolean noTextures;
    public int randomTickRate;
    public boolean ignoreJavaWarning;
    ArrayList<DisplayMode> Resolutions;
    ArrayList<String> Modes;
    
    static {
        RENDER_DISTANCES = new String[] { "FURTHEST", "FURTHER", "FAR", "NORMAL", "SHORT", "TINY" };
        DIFFICULTY_LEVELS = new String[] { "Peaceful", "Easy", "Normal", "Hard" };
        GUI_SCALES = new String[] { "Big", "Eyestrain", "Small", "Normal" };
        CLOUD_LEVELS = new String[] { "OFF", "FAST", "FANCY" };
        LEAF_LEVELS = new String[] { "FAST", "QUICK", "PRETTY", "FANCY" };
    }
    
    public GameSettings(final Minecraft minecraft, final File file) {
        this.Resolutions = new ArrayList<DisplayMode>();
        this.Modes = new ArrayList<String>();
        this.musicVolume = 1.0f;
        this.soundVolume = 1.0f;
        this.ambienceVolume = 1.0f;
        this.mouseSensitivity = 0.5f;
        this.modemVolume = 0.0f;
        this.invertMouse = false;
        this.renderDistance = 0;
        this.viewBobbing = true;
        this.fog = true;
        this.clouds = true;
        this.particles = true;
        this.anaglyph = false;
        this.limitFramerate = false;
        this.fancyGraphics = true;
        this.lastServer = "";
        this.chunkSavingInterval = 0;
        this.advancedOpenGL = false;
        this.keyBindForward = new KeyBinding("Forward", 17);
        this.keyBindLeft = new KeyBinding("Left", 30);
        this.keyBindBack = new KeyBinding("Back", 31);
        this.keyBindRight = new KeyBinding("Right", 32);
        this.keyBindJump = new KeyBinding("Jump", 57);
        this.keyBindBuild = new KeyBinding("Build", 48);
        this.keyBindInventory = new KeyBinding("Inventory", 18);
        this.keyBindDrop = new KeyBinding("Drop", 16);
        this.keyBindChat = new KeyBinding("Chat", 20);
        this.keyBindToggleFog = new KeyBinding("Toggle fog", 33);
        this.keyBindSneak = new KeyBinding("Sneak", 42);
        this.keyBindRun = new KeyBinding("Run", 29);
        this.keyBindSaveLocation = new KeyBinding("Save Location", 28);
        this.keyBindLoadLocation = new KeyBinding("Load Location", 19);
        this.keyBindings = new KeyBinding[] { this.keyBindForward, this.keyBindLeft, this.keyBindBack, this.keyBindRight, this.keyBindJump, this.keyBindSneak, this.keyBindDrop, this.keyBindInventory, this.keyBindChat, this.keyBindToggleFog, this.keyBindRun, this.keyBindSaveLocation, this.keyBindLoadLocation };
        this.numberOfOptions = 12;
        this.difficulty = 2;
        this.thirdPersonView = false;
        this.guiScale = 0;
        this.FOV = 0;
        this.mc = minecraft;
        this.ignoreJavaWarning = false;
        this.displayMode = 0;
        this.cloudLevel = 2;
        this.leafLevel = 3;
        this.precipLevel = true;
        this.vignette = true;
        this.mobShadows = true;
        this.vSync = false;
        this.noTextures = false;
        this.randomTickRate = 80;
        this.optionsFile = new File(file, "optionsNSSS.txt");
        this.readOptions();
    }
    
    public GameSettings() {
        this.Resolutions = new ArrayList<DisplayMode>();
        this.Modes = new ArrayList<String>();
        this.musicVolume = 1.0f;
        this.soundVolume = 1.0f;
        this.ambienceVolume = 1.0f;
        this.mouseSensitivity = 0.5f;
        this.modemVolume = 0.0f;
        this.invertMouse = false;
        this.renderDistance = 0;
        this.viewBobbing = true;
        this.fog = true;
        this.clouds = true;
        this.particles = true;
        this.anaglyph = false;
        this.limitFramerate = false;
        this.fancyGraphics = true;
        this.chunkSavingInterval = 0;
        this.advancedOpenGL = false;
        this.keyBindForward = new KeyBinding("Forward", 17);
        this.keyBindLeft = new KeyBinding("Left", 30);
        this.keyBindBack = new KeyBinding("Back", 31);
        this.keyBindRight = new KeyBinding("Right", 32);
        this.keyBindJump = new KeyBinding("Jump", 57);
        this.keyBindInventory = new KeyBinding("Inventory", 18);
        this.keyBindDrop = new KeyBinding("Drop", 16);
        this.keyBindChat = new KeyBinding("Chat", 20);
        this.keyBindToggleFog = new KeyBinding("Toggle fog", 33);
        this.keyBindSneak = new KeyBinding("Sneak", 42);
        this.keyBindRun = new KeyBinding("Run", 29);
        this.keyBindSaveLocation = new KeyBinding("Save Location", 28);
        this.keyBindLoadLocation = new KeyBinding("Load Location", 19);
        this.keyBindings = new KeyBinding[] { this.keyBindForward, this.keyBindLeft, this.keyBindBack, this.keyBindRight, this.keyBindJump, this.keyBindSneak, this.keyBindDrop, this.keyBindInventory, this.keyBindChat, this.keyBindToggleFog, this.keyBindRun, this.keyBindSaveLocation, this.keyBindLoadLocation };
        this.numberOfOptions = 12;
        this.difficulty = 2;
        this.thirdPersonView = false;
        this.guiScale = 0;
        this.FOV = 0;
        this.ignoreJavaWarning = false;
        this.displayMode = 0;
        this.cloudLevel = 2;
        this.leafLevel = 3;
        this.precipLevel = true;
        this.vignette = true;
        this.mobShadows = true;
        this.vSync = false;
        this.noTextures = false;
        this.randomTickRate = 80;
    }
    
    public String func_1043_a(final int i) {
        return this.keyBindings[i].keyDescription + ": " + Keyboard.getKeyName(this.keyBindings[i].keyCode);
    }
    
    public void func_1042_a(final int i, final int j) {
        this.keyBindings[i].keyCode = j;
        this.save();
    }
    
    public ArrayList<String> getDisplayModes() {
        if (this.Modes != null && this.Modes.size() > this.displayMode) {
            return this.Modes;
        }
        this.Resolutions = new ArrayList<DisplayMode>();
        (this.Modes = new ArrayList<String>()).add("Display: DEFAULT");
        try {
            final DisplayMode[] modes = Display.getAvailableDisplayModes();
            for (int i = 0; i < modes.length; ++i) {
                final DisplayMode current = modes[i];
                this.Resolutions.add(current);
            }
        }
        catch (LWJGLException e) {
            e.printStackTrace();
        }
        int j = 0;
        for (final DisplayMode mode : this.Resolutions) {
            this.Modes.add("Display: " + mode.getWidth() + "x" + mode.getHeight() + "x" + mode.getBitsPerPixel() + " " + mode.getFrequency() + "Hz");
            ++j;
        }
        return this.Modes;
    }
    
    public void saveSliderValue(final int i, final float f) {
        if (i == 0) {
            this.musicVolume = f;
            this.mc.soundMGR.updateVolume();
        }
        if (i == 1) {
            this.soundVolume = f;
            this.mc.soundMGR.updateVolume();
        }
        if (i == 2) {
            this.ambienceVolume = f;
            this.mc.soundMGR.updateVolume();
        }
        if (i == 3) {
            this.mouseSensitivity = f;
        }
        if (i == 4) {
            this.renderDistance = 3 - MathHelper.floor_float(f * 6.0f);
            this.save();
        }
        if (i == 12) {
            this.FOV = (int)(f * 60.0f);
        }
        if (i == 566) {
            this.modemVolume = f;
        }
        if (i == 104) {
            this.chunkSavingInterval = MathHelper.floor_float(f * 58.0f);
        }
    }
    
    public void setOptionValue(final int i, final int j) {
        if (i == 10) {
            this.invertMouse = !this.invertMouse;
        }
        if (i == 4) {
            this.renderDistance += j;
            if (this.renderDistance > 3) {
                this.renderDistance = -2;
            }
            else if (this.renderDistance < -2) {
                this.renderDistance = 3;
            }
        }
        if (i == 5) {
            this.viewBobbing = !this.viewBobbing;
        }
        if (i == 6) {
            this.anaglyph = !this.anaglyph;
            this.mc.renderEngine.func_1065_b();
        }
        if (i == 7) {
            this.limitFramerate = false;
        }
        if (i == 8) {
            this.difficulty = (this.difficulty + j & 0x3);
        }
        if (i == 9) {
            this.fancyGraphics = !this.fancyGraphics;
            this.mc.renderGlobal.loadRenderers();
        }
        if (i == 11) {
            this.guiScale += j;
            if (this.guiScale > 3) {
                this.guiScale = 0;
            }
        }
        if (i == 101) {
            this.clouds = !this.clouds;
        }
        if (i == 100) {
            this.fog = !this.fog;
        }
        if (i == 1993) {
            this.advancedOpenGL = !this.advancedOpenGL;
        }
        if (i == 1997) {
            this.cloudLevel += j;
            if (this.cloudLevel > 2) {
                this.cloudLevel = 0;
            }
            else if (this.cloudLevel < 0) {
                this.cloudLevel = 2;
            }
        }
        if (i == 1998) {
            this.leafLevel += j;
            if (this.leafLevel > 3) {
                this.leafLevel = 0;
            }
            else if (this.leafLevel < 0) {
                this.leafLevel = 3;
            }
            this.mc.renderGlobal.loadRenderers();
        }
        if (i == 1999) {
            this.vignette = !this.vignette;
        }
        if (i == 2000) {
            this.precipLevel = !this.precipLevel;
        }
        if (i == 2001) {
            this.mobShadows = !this.mobShadows;
        }
        if (i == 2002) {
            Display.setVSyncEnabled(this.vSync = !this.vSync);
        }
        this.save();
    }
    
    public int func_1046_b(final int i) {
        return (i == 0 || i == 1 || i == 2 || i == 3 || i == 4) ? 1 : 0;
    }
    
    public float sliderType(final int i) {
        if (i == 0) {
            return this.musicVolume;
        }
        if (i == 1) {
            return this.soundVolume;
        }
        if (i == 2) {
            return this.ambienceVolume;
        }
        if (i == 3) {
            return this.mouseSensitivity;
        }
        if (i == 4) {
            return (float)this.renderDistance;
        }
        if (i == 104) {
            return (float)this.chunkSavingInterval;
        }
        if (i == 12) {
            return (float)this.FOV;
        }
        if (i == 566) {
            return this.modemVolume;
        }
        return 0.0f;
    }
    
    public String getOptionValue(final int i) {
        if (i == 0) {
            return "Music: " + ((this.musicVolume <= 0.0f) ? "OFF" : ((int)(this.musicVolume * 100.0f) + "%"));
        }
        if (i == 1) {
            return "Sound: " + ((this.soundVolume <= 0.0f) ? "OFF" : ((int)(this.soundVolume * 100.0f) + "%"));
        }
        if (i == 2) {
            return "Ambience: " + ((this.ambienceVolume <= 0.0f) ? "OFF" : ((int)(this.ambienceVolume * 100.0f) + "%"));
        }
        if (i == 12) {
            if (this.FOV == 0) {
                return "FOV: Normal";
            }
            if (this.FOV == 60) {
                return "FOV: CinemaScope";
            }
            return "FOV: " + (this.FOV + 70) + "�";
        }
        else {
            if (i == 10) {
                return "Invert mouse: " + (this.invertMouse ? "ON" : "OFF");
            }
            if (i == 3) {
                if (this.mouseSensitivity == 0.0f) {
                    return "Sensitivity: *yawn*";
                }
                if (this.mouseSensitivity == 1.0f) {
                    return "Sensitivity: HYPERSPEED!!!";
                }
                return "Sensitivity: " + (int)(this.mouseSensitivity * 200.0f) + "%";
            }
            else if (i == 4) {
                if (this.renderDistance >= -2 && this.renderDistance <= 4) {
                    return "Render distance: " + GameSettings.RENDER_DISTANCES[this.renderDistance + 2];
                }
                return "Render distance: " + GameSettings.RENDER_DISTANCES[this.renderDistance + 3];
            }
            else {
                if (i == 5) {
                    return "View bobbing: " + (this.viewBobbing ? "ON" : "OFF");
                }
                if (i == 6) {
                    return "3d anaglyph: " + (this.anaglyph ? "ON" : "OFF");
                }
                if (i == 7) {
                    return "Credits...";
                }
                if (i == 8) {
                    if (this.mc.mcWorld == null || !this.mc.mcWorld.multiplayerWorld) {
                        return "Difficulty: " + GameSettings.DIFFICULTY_LEVELS[this.difficulty];
                    }
                    return "Server Difficulty: " + GameSettings.DIFFICULTY_LEVELS[this.mc.mcWorld.multiplayerDifficulty];
                }
                else {
                    if (i == 11) {
                        return "Gui Scale: " + GameSettings.GUI_SCALES[this.guiScale];
                    }
                    if (i == 104) {
                        return "Save every " + (this.chunkSavingInterval + 2) + " seconds";
                    }
                    if (i == 100) {
                        return "Fog: " + (this.fog ? "ON" : "OFF");
                    }
                    if (i == 101) {
                        return "Clouds: " + (this.clouds ? "ON" : "OFF");
                    }
                    if (i == 102) {
                        return "Particles: " + (this.particles ? "ON" : "OFF");
                    }
                    if (i == 1993) {
                        return "*Advanced OpenGL: " + (this.advancedOpenGL ? "ON" : "OFF");
                    }
                    if (i == 566) {
                        return "Modem Volume: " + ((this.modemVolume <= 0.0f) ? "OFF" : ((int)(this.modemVolume * 100.0f) + "%"));
                    }
                    if (i == 9) {
                        return "Graphics: " + (this.fancyGraphics ? "FANCY" : "FAST");
                    }
                    if (i == 1996) {
                        if (this.displayMode == -1) {
                            return "Display: DEFAULT";
                        }
                        return "Display: " + this.getDisplayModes().get(this.displayMode);
                    }
                    else {
                        if (i == 1997) {
                            return "Clouds: " + GameSettings.CLOUD_LEVELS[this.cloudLevel];
                        }
                        if (i == 1998) {
                            return "Leaves: " + GameSettings.LEAF_LEVELS[this.leafLevel];
                        }
                        if (i == 1999) {
                            return "Vignette: " + (this.vignette ? "ON" : "OFF");
                        }
                        if (i == 2000) {
                            return "Precipitation: " + (this.precipLevel ? "FANCY" : "FAST");
                        }
                        if (i == 2001) {
                            return "Mob Shadows: " + (this.mobShadows ? "ON" : "OFF");
                        }
                        if (i == 2002) {
                            return "Vsync: " + (this.vSync ? "ON" : "OFF");
                        }
                        return "";
                    }
                }
            }
        }
    }
    
    public void readOptions() {
        try {
            if (!this.optionsFile.exists()) {
                return;
            }
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.optionsFile));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                final String[] as = s.split(":");
                if (as[0].equals("music")) {
                    this.musicVolume = this.func_1050_a(as[1]);
                }
                if (as[0].equals("sound")) {
                    this.soundVolume = this.func_1050_a(as[1]);
                }
                if (as[0].equals("ambience")) {
                    this.ambienceVolume = this.func_1050_a(as[1]);
                }
                if (as[0].equals("FOV")) {
                    this.FOV = Integer.parseInt(as[1]);
                }
                if (as[0].equals("mouseSensitivity")) {
                    this.mouseSensitivity = this.func_1050_a(as[1]);
                }
                if (as[0].equals("modemVolume")) {
                    this.modemVolume = this.func_1050_a(as[1]);
                }
                if (as[0].equals("invertYMouse")) {
                    this.invertMouse = as[1].equals("true");
                }
                if (as[0].equals("viewDistance")) {
                    this.renderDistance = Integer.parseInt(as[1]);
                }
                if (as[0].equals("bobView")) {
                    this.viewBobbing = as[1].equals("true");
                }
                if (as[0].equals("anaglyph3d")) {
                    this.anaglyph = as[1].equals("true");
                }
                if (as[0].equals("limitFramerate")) {
                    this.limitFramerate = as[1].equals("true");
                }
                if (as[0].equals("difficulty")) {
                    this.difficulty = Integer.parseInt(as[1]);
                }
                if (as[0].equals("guiScale")) {
                    this.guiScale = Integer.parseInt(as[1]);
                }
                if (as[0].equals("fancyGraphics")) {
                    this.fancyGraphics = as[1].equals("true");
                }
                if (as[0].equals("lastServer") && as.length > 1) {
                    this.lastServer = String.valueOf(as[1]) + ":" + as[2];
                }
                if (as[0].equals("fog")) {
                    this.fog = as[1].equals("true");
                }
                if (as[0].equals("Clouds")) {
                    this.clouds = as[1].equals("true");
                }
                if (as[0].equals("particles")) {
                    this.particles = as[1].equals("true");
                }
                if (as[0].equals("ignoreJavaWarning")) {
                    this.ignoreJavaWarning = as[1].equals("true");
                }
                if (as[0].equals("saverate")) {
                    this.chunkSavingInterval = Integer.parseInt(as[1]);
                }
                if (as[0].equals("advancedopengl")) {
                    this.advancedOpenGL = as[1].equals("true");
                }
                if (as[0].equals("displayMode")) {
                    this.displayMode = Integer.parseInt(as[1]);
                }
                if (as[0].equals("cloudLevel")) {
                    this.cloudLevel = Integer.parseInt(as[1]);
                }
                if (as[0].equals("leafLevel")) {
                    this.leafLevel = Integer.parseInt(as[1]);
                }
                if (as[0].equals("precipLevel")) {
                    this.precipLevel = as[1].equals("true");
                }
                if (as[0].equals("vignette")) {
                    this.vignette = as[1].equals("true");
                }
                if (as[0].equals("mobShadows")) {
                    this.mobShadows = as[1].equals("true");
                }
                if (as[0].equals("vsync")) {
                    this.vSync = as[1].equals("true");
                }
                if (as[0].equals("notextures")) {
                    this.noTextures = as[1].equals("true");
                }
                if (as[0].equals("rantick")) {
                    this.randomTickRate = Integer.parseInt(as[1]);
                }
                for (int i = 0; i < this.keyBindings.length; ++i) {
                    if (as[0].equals("key_" + this.keyBindings[i].keyDescription)) {
                        this.keyBindings[i].keyCode = Integer.parseInt(as[1]);
                    }
                }
            }
            bufferedreader.close();
        }
        catch (Exception exception) {
            System.out.println("Failed to load options");
            exception.printStackTrace();
        }
    }
    
    private float func_1050_a(final String s) {
        if (s.equals("true")) {
            return 1.0f;
        }
        if (s.equals("false")) {
            return 0.0f;
        }
        return Float.parseFloat(s);
    }
    
    public void save() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.optionsFile));
            printwriter.println("music:" + this.musicVolume);
            printwriter.println("sound:" + this.soundVolume);
            printwriter.println("ambience:" + this.ambienceVolume);
            printwriter.println("FOV:" + this.FOV);
            printwriter.println("invertYMouse:" + this.invertMouse);
            printwriter.println("mouseSensitivity:" + this.mouseSensitivity);
            printwriter.println("modemVolume:" + this.modemVolume);
            printwriter.println("viewDistance:" + this.renderDistance);
            printwriter.println("bobView:" + this.viewBobbing);
            printwriter.println("anaglyph3d:" + this.anaglyph);
            printwriter.println("limitFramerate:" + this.limitFramerate);
            printwriter.println("difficulty:" + this.difficulty);
            printwriter.println("guiScale:" + this.guiScale);
            printwriter.println("fancyGraphics:" + this.fancyGraphics);
            printwriter.println(new StringBuilder().append("lastServer:").append(this.lastServer));
            printwriter.println("fog:" + this.fog);
            printwriter.println("Clouds:" + this.clouds);
            printwriter.println("particles:" + this.particles);
            printwriter.println("ignoreJavaWarning:" + this.ignoreJavaWarning);
            printwriter.println("saverate:" + this.chunkSavingInterval);
            printwriter.println("advancedopengl:" + this.advancedOpenGL);
            printwriter.println("displayMode:" + this.displayMode);
            printwriter.println("cloudLevel:" + this.cloudLevel);
            printwriter.println("leafLevel:" + this.leafLevel);
            printwriter.println("precipLevel:" + this.precipLevel);
            printwriter.println("vignette:" + this.vignette);
            printwriter.println("mobShadows:" + this.mobShadows);
            printwriter.println("vsync:" + this.vSync);
            printwriter.println("notextures:" + this.noTextures);
            printwriter.println("rantick:" + this.randomTickRate);
            for (int i = 0; i < this.keyBindings.length; ++i) {
                printwriter.println("key_" + this.keyBindings[i].keyDescription + ":" + this.keyBindings[i].keyCode);
            }
            printwriter.close();
        }
        catch (Exception exception) {
            System.out.println("Failed to save options");
            exception.printStackTrace();
        }
    }
}
