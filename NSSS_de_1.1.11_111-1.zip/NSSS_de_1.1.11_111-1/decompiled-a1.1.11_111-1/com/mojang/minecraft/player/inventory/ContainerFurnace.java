package com.mojang.minecraft.player.inventory;

import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;

public class ContainerFurnace extends Container
{
    private TileEntityFurnace furnace;
    private int cookTime;
    private int burnTime;
    private int itemBurnTime;
    
    public ContainerFurnace(final InventoryPlayer inventoryplayer, final TileEntityFurnace tileentityfurnace) {
        this.cookTime = 0;
        this.burnTime = 0;
        this.itemBurnTime = 0;
        this.furnace = tileentityfurnace;
        this.addSlot(new Slot(tileentityfurnace, 0, 56, 17));
        this.addSlot(new Slot(tileentityfurnace, 1, 56, 53));
        this.addSlot(new SlotFurnace(inventoryplayer.player, tileentityfurnace, 2, 116, 35));
        for (int i = 0; i < 3; ++i) {
            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(inventoryplayer, k + i * 9 + 9, 8 + k * 18, 84 + i * 18));
            }
        }
        for (int j = 0; j < 9; ++j) {
            this.addSlot(new Slot(inventoryplayer, j, 8 + j * 18, 142));
        }
    }
    
    @Override
    public void updateCraftingResults() {
        super.updateCraftingResults();
        for (int i = 0; i < this.field_20121_g.size(); ++i) {
            final ICrafting icrafting = this.field_20121_g.get(i);
            if (this.cookTime != this.furnace.furnaceCookTime) {
                icrafting.func_20158_a(this, 0, this.furnace.furnaceCookTime);
            }
            if (this.burnTime != this.furnace.furnaceBurnTime) {
                icrafting.func_20158_a(this, 1, this.furnace.furnaceBurnTime);
            }
            if (this.itemBurnTime != this.furnace.currentItemBurnTime) {
                icrafting.func_20158_a(this, 2, this.furnace.currentItemBurnTime);
            }
        }
        this.cookTime = this.furnace.furnaceCookTime;
        this.burnTime = this.furnace.furnaceBurnTime;
        this.itemBurnTime = this.furnace.currentItemBurnTime;
    }
    
    @Override
    public void func_20112_a(final int i, final int j) {
        if (i == 0) {
            this.furnace.furnaceCookTime = j;
        }
        if (i == 1) {
            this.furnace.furnaceBurnTime = j;
        }
        if (i == 2) {
            this.furnace.currentItemBurnTime = j;
        }
    }
    
    @Override
    public boolean isUsableByPlayer(final EntityPlayer entityplayer) {
        return this.furnace.canInteractWith(entityplayer);
    }
    
    @Override
    public ItemStack getStackInSlot(final int i) {
        ItemStack itemstack = null;
        final Slot slot = this.slots.get(i);
        if (slot != null && slot.getHasStack()) {
            final ItemStack itemstack2 = slot.getStack();
            itemstack = itemstack2.copy();
            if (i == 2) {
                this.func_28125_a(itemstack2, 3, 39, true);
            }
            else if (i >= 3 && i < 30) {
                this.func_28125_a(itemstack2, 30, 39, false);
            }
            else if (i >= 30 && i < 39) {
                this.func_28125_a(itemstack2, 3, 30, false);
            }
            else {
                this.func_28125_a(itemstack2, 3, 39, false);
            }
            if (itemstack2.stackSize == 0) {
                slot.putStack(null);
            }
            else {
                slot.onSlotChanged();
            }
            if (itemstack2.stackSize == itemstack.stackSize) {
                return null;
            }
            slot.onPickupFromSlot(itemstack2);
        }
        return itemstack;
    }
}
