package com.mojang.minecraft.player.inventory;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;

public class ContainerChest extends Container
{
    private IInventory field_20125_a;
    private int field_27282_b;
    
    public ContainerChest(final IInventory iinventory, final IInventory iinventory1) {
        this.field_20125_a = iinventory1;
        this.field_27282_b = iinventory1.getSizeInventory() / 9;
        final int i = (this.field_27282_b - 4) * 18;
        for (int j = 0; j < this.field_27282_b; ++j) {
            for (int i2 = 0; i2 < 9; ++i2) {
                this.addSlot(new Slot(iinventory1, i2 + j * 9, 8 + i2 * 18, 18 + j * 18));
            }
        }
        for (int k = 0; k < 3; ++k) {
            for (int j2 = 0; j2 < 9; ++j2) {
                this.addSlot(new Slot(iinventory, j2 + k * 9 + 9, 8 + j2 * 18, 103 + k * 18 + i));
            }
        }
        for (int l = 0; l < 9; ++l) {
            this.addSlot(new Slot(iinventory, l, 8 + l * 18, 161 + i));
        }
    }
    
    @Override
    public boolean isUsableByPlayer(final EntityPlayer entityplayer) {
        return this.field_20125_a.canInteractWith(entityplayer);
    }
    
    @Override
    public ItemStack getStackInSlot(final int i) {
        ItemStack itemstack = null;
        final Slot slot = this.slots.get(i);
        if (slot != null && slot.getHasStack()) {
            final ItemStack itemstack2 = slot.getStack();
            itemstack = itemstack2.copy();
            if (i < this.field_27282_b * 9) {
                this.func_28125_a(itemstack2, this.field_27282_b * 9, this.slots.size(), true);
            }
            else {
                this.func_28125_a(itemstack2, 0, this.field_27282_b * 9, false);
            }
            if (itemstack2.stackSize == 0) {
                slot.putStack(null);
            }
            else {
                slot.onSlotChanged();
            }
        }
        return itemstack;
    }
}
