package com.mojang.minecraft.player.inventory;

import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;

public abstract class Container
{
    public List itemstackList;
    public List slots;
    public int windowId;
    private short field_20917_a;
    protected List field_20121_g;
    private Set field_20918_b;
    
    public Container() {
        this.itemstackList = new ArrayList();
        this.slots = new ArrayList();
        this.windowId = 0;
        this.field_20917_a = 0;
        this.field_20121_g = new ArrayList();
        this.field_20918_b = new HashSet();
    }
    
    protected void addSlot(final Slot slot) {
        slot.slotNumber = this.slots.size();
        this.slots.add(slot);
        this.itemstackList.add(null);
    }
    
    public void updateCraftingResults() {
        for (int i = 0; i < this.slots.size(); ++i) {
            final ItemStack itemstack = this.slots.get(i).getStack();
            ItemStack itemstack2 = this.itemstackList.get(i);
            if (!ItemStack.areItemStacksEqual(itemstack2, itemstack)) {
                itemstack2 = ((itemstack != null) ? itemstack.copy() : null);
                this.itemstackList.set(i, itemstack2);
                for (int j = 0; j < this.field_20121_g.size(); ++j) {
                    this.field_20121_g.get(j).func_20159_a(this, i, itemstack2);
                }
            }
        }
    }
    
    public Slot getSlot(final int i) {
        return this.slots.get(i);
    }
    
    public ItemStack getStackInSlot(final int i) {
        final Slot slot = this.slots.get(i);
        if (slot != null) {
            return slot.getStack();
        }
        return null;
    }
    
    public ItemStack func_27280_a(final int i, final int j, final boolean flag, final EntityPlayer entityplayer) {
        ItemStack itemstack = null;
        if (j == 0 || j == 1) {
            final InventoryPlayer inventoryplayer = entityplayer.inventory;
            if (i == -999) {
                if (inventoryplayer.getItemStack() != null && i == -999) {
                    if (j == 0) {
                        entityplayer.dropPlayerItem(inventoryplayer.getItemStack());
                        inventoryplayer.setItemStack(null);
                    }
                    if (j == 1) {
                        entityplayer.dropPlayerItem(inventoryplayer.getItemStack().splitStack(1));
                        if (inventoryplayer.getItemStack().stackSize == 0) {
                            inventoryplayer.setItemStack(null);
                        }
                    }
                }
            }
            else if (flag) {
                final ItemStack itemstack2 = this.getStackInSlot(i);
                if (itemstack2 != null) {
                    final int k = itemstack2.stackSize;
                    itemstack = itemstack2.copy();
                    final Slot slot1 = this.slots.get(i);
                    if (slot1 != null && slot1.getStack() != null) {
                        final int l = slot1.getStack().stackSize;
                        if (l < k) {
                            this.func_27280_a(i, j, flag, entityplayer);
                        }
                    }
                }
            }
            else {
                final Slot slot2 = this.slots.get(i);
                if (slot2 != null) {
                    slot2.onSlotChanged();
                    final ItemStack itemstack3 = slot2.getStack();
                    final ItemStack itemstack4 = inventoryplayer.getItemStack();
                    if (itemstack3 != null) {
                        itemstack = itemstack3.copy();
                    }
                    if (itemstack3 == null) {
                        if (itemstack4 != null && slot2.isItemValid(itemstack4)) {
                            int i2 = (j != 0) ? 1 : itemstack4.stackSize;
                            if (i2 > slot2.getSlotStackLimit()) {
                                i2 = slot2.getSlotStackLimit();
                            }
                            slot2.putStack(itemstack4.splitStack(i2));
                            if (itemstack4.stackSize == 0) {
                                inventoryplayer.setItemStack(null);
                            }
                        }
                    }
                    else if (itemstack4 == null) {
                        final int j2 = (j != 0) ? ((itemstack3.stackSize + 1) / 2) : itemstack3.stackSize;
                        final ItemStack itemstack5 = slot2.decrStackSize(j2);
                        inventoryplayer.setItemStack(itemstack5);
                        if (itemstack3.stackSize == 0) {
                            slot2.putStack(null);
                        }
                        slot2.onPickupFromSlot(inventoryplayer.getItemStack());
                    }
                    else if (slot2.isItemValid(itemstack4)) {
                        if (itemstack3.itemID != itemstack4.itemID || (itemstack3.getHasSubtypes() && itemstack3.getItemDamage() != itemstack4.getItemDamage())) {
                            if (itemstack4.stackSize <= slot2.getSlotStackLimit()) {
                                final ItemStack itemstack6 = itemstack3;
                                slot2.putStack(itemstack4);
                                inventoryplayer.setItemStack(itemstack6);
                            }
                        }
                        else {
                            int k2 = (j != 0) ? 1 : itemstack4.stackSize;
                            if (k2 > slot2.getSlotStackLimit() - itemstack3.stackSize) {
                                k2 = slot2.getSlotStackLimit() - itemstack3.stackSize;
                            }
                            if (k2 > itemstack4.getMaxStackSize() - itemstack3.stackSize) {
                                k2 = itemstack4.getMaxStackSize() - itemstack3.stackSize;
                            }
                            itemstack4.splitStack(k2);
                            if (itemstack4.stackSize == 0) {
                                inventoryplayer.setItemStack(null);
                            }
                            final ItemStack itemStack = itemstack3;
                            itemStack.stackSize += k2;
                        }
                    }
                    else if (itemstack3.itemID == itemstack4.itemID && itemstack4.getMaxStackSize() > 1 && (!itemstack3.getHasSubtypes() || itemstack3.getItemDamage() == itemstack4.getItemDamage())) {
                        final int l2 = itemstack3.stackSize;
                        if (l2 > 0 && l2 + itemstack4.stackSize <= itemstack4.getMaxStackSize()) {
                            final ItemStack itemStack2 = itemstack4;
                            itemStack2.stackSize += l2;
                            itemstack3.splitStack(l2);
                            if (itemstack3.stackSize == 0) {
                                slot2.putStack(null);
                            }
                            slot2.onPickupFromSlot(inventoryplayer.getItemStack());
                        }
                    }
                }
            }
        }
        return itemstack;
    }
    
    public void onCraftGuiClosed(final EntityPlayer entityplayer) {
        final InventoryPlayer inventoryplayer = entityplayer.inventory;
        if (inventoryplayer.getItemStack() != null) {
            entityplayer.dropPlayerItem(inventoryplayer.getItemStack());
            inventoryplayer.setItemStack(null);
        }
    }
    
    public void onCraftMatrixChanged(final IInventory iinventory) {
        this.updateCraftingResults();
    }
    
    public void putStackInSlot(final int i, final ItemStack itemstack) {
        this.getSlot(i).putStack(itemstack);
    }
    
    public void putStacksInSlots(final ItemStack[] aitemstack) {
        for (int i = 0; i < aitemstack.length; ++i) {
            this.getSlot(i).putStack(aitemstack[i]);
        }
    }
    
    public void func_20112_a(final int i, final int j) {
    }
    
    public short func_20111_a(final InventoryPlayer inventoryplayer) {
        return (short)(++this.field_20917_a);
    }
    
    public void func_20113_a(final short word0) {
    }
    
    public void func_20110_b(final short word0) {
    }
    
    public abstract boolean isUsableByPlayer(final EntityPlayer p0);
    
    protected void func_28125_a(final ItemStack itemstack, final int i, final int j, final boolean flag) {
        int k = i;
        if (flag) {
            k = j - 1;
        }
        if (itemstack.isStackable()) {
            while (itemstack.stackSize > 0 && ((!flag && k < j) || (flag && k >= i))) {
                final Slot slot = this.slots.get(k);
                final ItemStack itemstack2 = slot.getStack();
                if (itemstack2 != null && itemstack2.itemID == itemstack.itemID && (!itemstack.getHasSubtypes() || itemstack.getItemDamage() == itemstack2.getItemDamage())) {
                    final int i2 = itemstack2.stackSize + itemstack.stackSize;
                    if (i2 <= itemstack.getMaxStackSize()) {
                        itemstack.stackSize = 0;
                        itemstack2.stackSize = i2;
                        slot.onSlotChanged();
                    }
                    else if (itemstack2.stackSize < itemstack.getMaxStackSize()) {
                        itemstack.stackSize -= itemstack.getMaxStackSize() - itemstack2.stackSize;
                        itemstack2.stackSize = itemstack.getMaxStackSize();
                        slot.onSlotChanged();
                    }
                }
                if (flag) {
                    --k;
                }
                else {
                    ++k;
                }
            }
        }
        if (itemstack.stackSize > 0) {
            int l;
            if (flag) {
                l = j - 1;
            }
            else {
                l = i;
            }
            while (true) {
                if (flag || l >= j) {
                    if (!flag) {
                        break;
                    }
                    if (l < i) {
                        break;
                    }
                }
                final Slot slot2 = this.slots.get(l);
                final ItemStack itemstack3 = slot2.getStack();
                if (itemstack3 == null) {
                    slot2.putStack(itemstack.copy());
                    slot2.onSlotChanged();
                    itemstack.stackSize = 0;
                    break;
                }
                if (flag) {
                    --l;
                }
                else {
                    ++l;
                }
            }
        }
    }
}
