package com.mojang.minecraft.network;

class NetworkMasterThread extends Thread
{
    final NetworkManager field_1086_a;
    
    NetworkMasterThread(final NetworkManager networkmanager) {
        this.field_1086_a = networkmanager;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(5000L);
            if (NetworkManager.func_969_e(this.field_1086_a).isAlive()) {
                try {
                    NetworkManager.func_969_e(this.field_1086_a).stop();
                }
                catch (Throwable t) {}
            }
            if (NetworkManager.func_963_f(this.field_1086_a).isAlive()) {
                try {
                    NetworkManager.func_963_f(this.field_1086_a).stop();
                }
                catch (Throwable t2) {}
            }
        }
        catch (InterruptedException interruptedexception) {
            interruptedexception.printStackTrace();
        }
    }
}
