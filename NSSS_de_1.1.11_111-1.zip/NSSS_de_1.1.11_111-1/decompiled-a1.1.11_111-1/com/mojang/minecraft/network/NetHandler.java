package com.mojang.minecraft.network;

import com.mojang.minecraft.network.packet.*;

public class NetHandler
{
    public void func_833_a(final Packet51MapChunk packet51mapchunk) {
    }
    
    public void func_836_b(final Packet packet) {
    }
    
    public void func_823_a(final String s) {
    }
    
    public void func_844_a(final Packet255KickDisconnect packet255kickdisconnect) {
        this.func_836_b(packet255kickdisconnect);
    }
    
    public void handleLogin(final Packet1Login packet1login) {
        this.func_836_b(packet1login);
    }
    
    public void func_837_a(final Packet10Flying packet10flying) {
        this.func_836_b(packet10flying);
    }
    
    public void func_824_a(final Packet52MultiBlockChange packet52multiblockchange) {
        this.func_836_b(packet52multiblockchange);
    }
    
    public void func_821_a(final Packet14BlockDig packet14blockdig) {
        this.func_836_b(packet14blockdig);
    }
    
    public void func_822_a(final Packet53BlockChange packet53blockchange) {
        this.func_836_b(packet53blockchange);
    }
    
    public void func_826_a(final Packet50PreChunk packet50prechunk) {
        this.func_836_b(packet50prechunk);
    }
    
    public void func_820_a(final Packet20NamedEntitySpawn packet20namedentityspawn) {
        this.func_836_b(packet20namedentityspawn);
    }
    
    public void func_827_a(final Packet30Entity packet30entity) {
        this.func_836_b(packet30entity);
    }
    
    public void func_829_a(final Packet34EntityTeleport packet34entityteleport) {
        this.func_836_b(packet34entityteleport);
    }
    
    public void func_819_a(final Packet15Place packet15place) {
        this.func_836_b(packet15place);
    }
    
    public void func_841_a(final Packet16BlockItemSwitch packet16blockitemswitch) {
        this.func_836_b(packet16blockitemswitch);
    }
    
    public void func_839_a(final Packet29DestroyEntity packet29destroyentity) {
        this.func_836_b(packet29destroyentity);
    }
    
    public void func_839_a(final Packet60HurtEntity packet60hurtentity) {
        this.func_836_b(packet60hurtentity);
    }
    
    public void func_832_a(final Packet21PickupSpawn packet21pickupspawn) {
        this.func_836_b(packet21pickupspawn);
    }
    
    public void func_834_a(final Packet22Collect packet22collect) {
        this.func_836_b(packet22collect);
    }
    
    public void func_831_a(final Packet3Chat packet3chat) {
        this.func_836_b(packet3chat);
    }
    
    public void func_830_a(final Packet17AddToInventory packet17addtoinventory) {
        this.func_836_b(packet17addtoinventory);
    }
    
    public void func_835_a(final Packet23VehicleSpawn packet23vehiclespawn) {
        this.func_836_b(packet23vehiclespawn);
    }
    
    public void func_825_a(final Packet18ArmAnimation packet18armanimation) {
        this.func_836_b(packet18armanimation);
    }
    
    public void func_838_a(final Packet2Handshake packet2handshake) {
        this.func_836_b(packet2handshake);
    }
    
    public void func_828_a(final Packet24MobSpawn packet24mobspawn) {
        this.func_836_b(packet24mobspawn);
    }
    
    public void func_846_a(final Packet4UpdateTime packet4updatetime) {
        this.func_836_b(packet4updatetime);
    }
    
    public void func_843_a(final Packet5PlayerInventory packet5playerinventory) {
        this.func_836_b(packet5playerinventory);
    }
    
    public void func_842_a(final Packet59ComplexEntity packet59complexentity) {
        this.func_836_b(packet59complexentity);
    }
    
    public void func_845_a(final Packet6SpawnPosition packet6spawnposition) {
        this.func_836_b(packet6spawnposition);
    }
    
    public void setHealth(final Packet61PlayerHealth packet61PlayerHealth) {
        this.func_836_b(packet61PlayerHealth);
    }
    
    public void handleSound(final Packet62PlaySound packet62PlaySound) {
        this.func_836_b(packet62PlaySound);
    }
}
