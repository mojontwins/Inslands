package com.mojang.minecraft.network;

import java.net.*;
import com.mojang.minecraft.network.packet.*;
import java.util.*;
import java.io.*;

public class NetworkManager
{
    public static final Object field_1478_a;
    public static int field_1477_b;
    public static int field_1476_c;
    private Object field_1475_d;
    private Socket field_1474_e;
    private DataInputStream field_1473_f;
    private DataOutputStream field_1472_g;
    private boolean field_1471_h;
    private List<Packet> field_1470_i;
    private List<Packet> field_1469_j;
    private List<Packet> field_1468_k;
    private NetHandler field_1467_l;
    private boolean field_1466_m;
    private Thread field_1465_n;
    private Thread field_1464_o;
    private boolean field_1463_p;
    private String field_1462_q;
    private int field_1461_r;
    private int field_1460_s;
    private int field_1459_t;
    
    static {
        field_1478_a = new Object();
    }
    
    public NetworkManager(final Socket socket, final String s, final NetHandler nethandler) throws IOException {
        this.field_1475_d = new Object();
        this.field_1471_h = true;
        this.field_1470_i = Collections.synchronizedList(new LinkedList<Packet>());
        this.field_1469_j = Collections.synchronizedList(new LinkedList<Packet>());
        this.field_1468_k = Collections.synchronizedList(new LinkedList<Packet>());
        this.field_1466_m = false;
        this.field_1463_p = false;
        this.field_1462_q = "";
        this.field_1461_r = 0;
        this.field_1460_s = 0;
        this.field_1459_t = 0;
        this.field_1474_e = socket;
        this.field_1467_l = nethandler;
        socket.setTrafficClass(24);
        this.field_1473_f = new DataInputStream(socket.getInputStream());
        this.field_1472_g = new DataOutputStream(socket.getOutputStream());
        this.field_1464_o = new NetworkReaderThread(this, s + " read thread");
        this.field_1465_n = new NetworkWriterThread(this, s + " write thread");
        this.field_1464_o.start();
        this.field_1465_n.start();
    }
    
    public void func_972_a(final Packet packet) {
        if (this.field_1466_m) {
            return;
        }
        synchronized (this.field_1475_d) {
            this.field_1460_s += packet.packetFunctionUnknown() + 1;
            if (packet.packetBooleanUnknown) {
                this.field_1468_k.add(packet);
            }
            else {
                this.field_1469_j.add(packet);
            }
        }
        // monitorexit(this.field_1475_d)
    }
    
    private void func_964_b() {
        try {
            boolean flag = true;
            if (!this.field_1469_j.isEmpty()) {
                flag = false;
                final Packet packet;
                synchronized (this.field_1475_d) {
                    packet = this.field_1469_j.remove(0);
                    this.field_1460_s -= packet.packetFunctionUnknown() + 1;
                }
                // monitorexit(this.field_1475_d)
                Packet.sendToOutput(packet, this.field_1472_g);
            }
            if ((flag || this.field_1459_t-- <= 0) && !this.field_1468_k.isEmpty()) {
                flag = false;
                final Packet packet2;
                synchronized (this.field_1475_d) {
                    packet2 = this.field_1468_k.remove(0);
                    this.field_1460_s -= packet2.packetFunctionUnknown() + 1;
                }
                // monitorexit(this.field_1475_d)
                Packet.sendToOutput(packet2, this.field_1472_g);
                this.field_1459_t = 50;
            }
            if (flag) {
                Thread.sleep(10L);
            }
        }
        catch (InterruptedException ex) {}
        catch (Exception exception) {
            if (!this.field_1463_p) {
                this.func_970_a(exception);
            }
        }
    }
    
    private void func_973_c() {
        try {
            final Packet packet = Packet.onBaseIncoming(this.field_1473_f);
            if (packet != null) {
                this.field_1470_i.add(packet);
            }
            else {
                this.func_974_a("End of stream");
            }
        }
        catch (Exception exception) {
            if (!this.field_1463_p) {
                this.func_970_a(exception);
            }
        }
    }
    
    private void func_970_a(final Exception exception) {
        exception.printStackTrace();
        this.func_974_a("Internal exception: " + exception.toString());
    }
    
    public void func_974_a(final String s) {
        if (!this.field_1471_h) {
            return;
        }
        this.field_1463_p = true;
        this.field_1462_q = s;
        new NetworkMasterThread(this).start();
        this.field_1471_h = false;
        try {
            this.field_1473_f.close();
        }
        catch (Throwable t) {}
        try {
            this.field_1472_g.close();
        }
        catch (Throwable t2) {}
        try {
            this.field_1474_e.close();
        }
        catch (Throwable t3) {}
    }
    
    public void func_967_a() {
        if (this.field_1460_s > 1048576) {
            this.func_974_a("Send buffer overflow");
        }
        if (this.field_1470_i.isEmpty()) {
            if (this.field_1461_r++ == 1200) {
                this.func_974_a("Timed out");
            }
        }
        else {
            this.field_1461_r = 0;
        }
        int i = 100;
        while (!this.field_1470_i.isEmpty() && i-- >= 0) {
            final Packet packet = this.field_1470_i.remove(0);
            packet.handlePacket(this.field_1467_l);
        }
        if (this.field_1463_p && this.field_1470_i.isEmpty()) {
            this.field_1467_l.func_823_a(this.field_1462_q);
        }
    }
    
    static boolean func_971_a(final NetworkManager networkmanager) {
        return networkmanager.field_1471_h;
    }
    
    static boolean func_968_b(final NetworkManager networkmanager) {
        return networkmanager.field_1466_m;
    }
    
    static void func_966_c(final NetworkManager networkmanager) {
        networkmanager.func_973_c();
    }
    
    static void func_965_d(final NetworkManager networkmanager) {
        networkmanager.func_964_b();
    }
    
    static Thread func_969_e(final NetworkManager networkmanager) {
        return networkmanager.field_1464_o;
    }
    
    static Thread func_963_f(final NetworkManager networkmanager) {
        return networkmanager.field_1465_n;
    }
}
