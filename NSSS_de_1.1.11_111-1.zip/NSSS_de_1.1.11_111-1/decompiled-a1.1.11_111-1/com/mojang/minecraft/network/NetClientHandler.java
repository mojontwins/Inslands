package com.mojang.minecraft.network;

import com.mojang.minecraft.*;
import java.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.gui.*;
import java.net.*;
import java.io.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.network.packet.*;

public class NetClientHandler extends NetHandler
{
    private boolean initialHealth;
    private boolean disconnected;
    private NetworkManager networkManager;
    public String field_1209_a;
    private Minecraft mc;
    private WorldClient worldClient;
    private boolean field_1210_g;
    Random random;
    
    public NetClientHandler(final Minecraft minecraft, final String s, final int i) throws UnknownHostException, IOException {
        this.initialHealth = true;
        this.disconnected = false;
        this.field_1210_g = false;
        this.random = new Random();
        this.mc = minecraft;
    }
    
    @Override
    public void handleSound(final Packet62PlaySound packet62PlaySound) {
        this.mc.soundMGR.playSound(packet62PlaySound.name, packet62PlaySound.x, packet62PlaySound.y, packet62PlaySound.z, packet62PlaySound.volume, packet62PlaySound.pitch);
    }
    
    public void processReadPackets() {
        if (this.disconnected) {
            return;
        }
        this.networkManager.func_967_a();
    }
    
    @Override
    public void handleLogin(final Packet1Login packet1login) {
        this.worldClient.multiplayerWorld = true;
        this.mc.changeWorld1(this.worldClient);
    }
    
    @Override
    public void func_832_a(final Packet21PickupSpawn packet21pickupspawn) {
        final double d = packet21pickupspawn.field_530_b / 32.0;
        final double d2 = packet21pickupspawn.field_529_c / 32.0;
        final double d3 = packet21pickupspawn.field_528_d / 32.0;
        final EntityItem entityitem = new EntityItem(this.worldClient, d, d2, d3, new ItemStack(packet21pickupspawn.itemid, packet21pickupspawn.stacksize, packet21pickupspawn.damage));
        entityitem.motionX = packet21pickupspawn.field_527_e / 128.0;
        entityitem.motionY = packet21pickupspawn.field_526_f / 128.0;
        entityitem.motionZ = packet21pickupspawn.field_525_g / 128.0;
        entityitem.serverPosX = packet21pickupspawn.field_530_b;
        entityitem.serverPosY = packet21pickupspawn.field_529_c;
        entityitem.serverPosZ = packet21pickupspawn.field_528_d;
        this.worldClient.func_712_a(packet21pickupspawn.entid, entityitem);
    }
    
    @Override
    public void func_835_a(final Packet23VehicleSpawn packet23vehiclespawn) {
        final double d = packet23vehiclespawn.field_499_b / 32.0;
        final double d2 = packet23vehiclespawn.field_503_c / 32.0;
        final double d3 = packet23vehiclespawn.field_502_d / 32.0;
        Entity obj = null;
        if (packet23vehiclespawn.field_501_e == 10) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 0);
        }
        if (packet23vehiclespawn.field_501_e == 11) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 1);
        }
        if (packet23vehiclespawn.field_501_e == 12) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 2);
        }
        if (packet23vehiclespawn.field_501_e == 1) {
            obj = new EntityBoat(this.worldClient, d, d2, d3);
        }
        if (obj != null) {
            obj.serverPosX = packet23vehiclespawn.field_499_b;
            obj.serverPosY = packet23vehiclespawn.field_503_c;
            obj.serverPosZ = packet23vehiclespawn.field_502_d;
            obj.rotationYaw = 0.0f;
            obj.rotationPitch = 0.0f;
            obj.entityId = packet23vehiclespawn.field_500_a;
            this.worldClient.func_712_a(packet23vehiclespawn.field_500_a, obj);
        }
    }
    
    @Override
    public void func_839_a(final Packet60HurtEntity packet60hurtentity) {
        if (packet60hurtentity.damage == -500) {
            final Entity ent = this.worldClient.func_709_b(packet60hurtentity.entityId);
            if (ent instanceof EntityLiving) {
                System.out.println("Entity Died");
                ((EntityLiving)ent).health = -5000;
                ((EntityLiving)ent).isDead = true;
                ((EntityLiving)ent).health = -5000;
            }
        }
    }
    
    @Override
    public void func_820_a(final Packet20NamedEntitySpawn packet20namedentityspawn) {
        final double d = packet20namedentityspawn.field_540_c / 32.0;
        final double d2 = packet20namedentityspawn.field_539_d / 32.0;
        final double d3 = packet20namedentityspawn.field_538_e / 32.0;
        final float f = packet20namedentityspawn.field_537_f * 360 / 256.0f;
        final float f2 = packet20namedentityspawn.field_536_g * 360 / 256.0f;
        final EntityOtherPlayerMP entityotherplayermp = new EntityOtherPlayerMP(this.mc.mcWorld, packet20namedentityspawn.field_533_b);
        entityotherplayermp.serverPosX = packet20namedentityspawn.field_540_c;
        entityotherplayermp.serverPosY = packet20namedentityspawn.field_539_d;
        entityotherplayermp.serverPosZ = packet20namedentityspawn.field_538_e;
        final int i = packet20namedentityspawn.field_535_h;
        if (i == 0) {
            entityotherplayermp.inventory.mainInventory[entityotherplayermp.inventory.currentItem] = null;
        }
        else {
            entityotherplayermp.inventory.mainInventory[entityotherplayermp.inventory.currentItem] = new ItemStack(i);
        }
        entityotherplayermp.setPositionAndRotation(d, d2, d3, f, f2);
        this.worldClient.func_712_a(packet20namedentityspawn.field_534_a, entityotherplayermp);
    }
    
    @Override
    public void func_829_a(final Packet34EntityTeleport packet34entityteleport) {
        final Entity entity = this.worldClient.func_709_b(packet34entityteleport.field_509_a);
        if (entity == null) {
            return;
        }
        entity.serverPosX = packet34entityteleport.field_508_b;
        entity.serverPosY = packet34entityteleport.field_513_c;
        entity.serverPosZ = packet34entityteleport.field_512_d;
        final double d = entity.serverPosX / 32.0;
        final double d2 = entity.serverPosY / 32.0;
        final double d3 = entity.serverPosZ / 32.0;
        final float f = packet34entityteleport.field_511_e * 360 / 256.0f;
        final float f2 = packet34entityteleport.field_510_f * 360 / 256.0f;
        entity.setPositionAndRotation2(d, d2, d3, f, f2, 3);
    }
    
    @Override
    public void func_827_a(final Packet30Entity packet30entity) {
        final Entity entity = this.worldClient.func_709_b(packet30entity.field_485_a);
        if (entity == null) {
            return;
        }
        final Entity entity2 = entity;
        entity2.serverPosX += packet30entity.field_484_b;
        final Entity entity3 = entity;
        entity3.serverPosY += packet30entity.field_490_c;
        final Entity entity4 = entity;
        entity4.serverPosZ += packet30entity.field_489_d;
        final double d = entity.serverPosX / 32.0;
        final double d2 = entity.serverPosY / 32.0;
        final double d3 = entity.serverPosZ / 32.0;
        final float f = packet30entity.field_486_g ? (packet30entity.field_488_e * 360 / 256.0f) : entity.rotationYaw;
        final float f2 = packet30entity.field_486_g ? (packet30entity.field_487_f * 360 / 256.0f) : entity.rotationPitch;
        entity.setPositionAndRotation2(d, d2, d3, f, f2, 3);
    }
    
    @Override
    public void func_839_a(final Packet29DestroyEntity packet29destroyentity) {
        this.worldClient.removeEntityFromWorld(packet29destroyentity.field_507_a);
    }
    
    @Override
    public void func_837_a(final Packet10Flying packet10flying) {
        final EntityPlayerSP entityplayersp = this.mc.thePlayer;
        double d = entityplayersp.posX;
        double d2 = entityplayersp.posY;
        double d3 = entityplayersp.posZ;
        float f = entityplayersp.rotationYaw;
        float f2 = entityplayersp.rotationPitch;
        if (packet10flying.field_554_h) {
            d = packet10flying.field_561_a;
            d2 = packet10flying.field_560_b;
            d3 = packet10flying.field_559_c;
        }
        if (packet10flying.field_553_i) {
            f = packet10flying.field_557_e;
            f2 = packet10flying.field_556_f;
        }
        entityplayersp.ySize = 0.0f;
        final EntityPlayerSP entityPlayerSP = entityplayersp;
        final EntityPlayerSP entityPlayerSP2 = entityplayersp;
        final EntityPlayerSP entityPlayerSP3 = entityplayersp;
        final double motionX = 0.0;
        entityPlayerSP3.motionZ = motionX;
        entityPlayerSP2.motionY = motionX;
        entityPlayerSP.motionX = motionX;
        entityplayersp.setPositionAndRotation(d, d2, d3, f, f2);
        packet10flying.field_561_a = entityplayersp.posX;
        packet10flying.field_560_b = entityplayersp.boundingBox.minY;
        packet10flying.field_559_c = entityplayersp.posZ;
        packet10flying.field_558_d = entityplayersp.posY;
        this.networkManager.func_972_a(packet10flying);
        if (!this.field_1210_g) {
            this.mc.thePlayer.prevPosX = this.mc.thePlayer.posX;
            this.mc.thePlayer.prevPosY = this.mc.thePlayer.posY;
            this.mc.thePlayer.prevPosZ = this.mc.thePlayer.posZ;
            this.field_1210_g = true;
            this.mc.setCurrentScreen(null);
        }
    }
    
    @Override
    public void func_826_a(final Packet50PreChunk packet50prechunk) {
        this.worldClient.doPreChunk(packet50prechunk.field_505_a, packet50prechunk.field_504_b, packet50prechunk.field_506_c);
    }
    
    @Override
    public void func_824_a(final Packet52MultiBlockChange packet52multiblockchange) {
        final Chunk chunk = this.worldClient.getChunkFromChunkCoords(packet52multiblockchange.field_479_a, packet52multiblockchange.field_478_b);
        final int i = packet52multiblockchange.field_479_a * 16;
        final int j = packet52multiblockchange.field_478_b * 16;
        for (int k = 0; k < packet52multiblockchange.field_480_f; ++k) {
            final short word0 = packet52multiblockchange.field_483_c[k];
            final int l = packet52multiblockchange.field_482_d[k] & 0xFF;
            final byte byte0 = packet52multiblockchange.field_481_e[k];
            final int i2 = word0 >> 12 & 0xF;
            final int j2 = word0 >> 8 & 0xF;
            final int k2 = word0 & 0xFF;
            chunk.setBlockIDWithMetadata(i2, k2, j2, l, byte0);
            this.worldClient.markRangeForUpdate(i2 + i, k2, j2 + j, i2 + i, k2, j2 + j);
            this.worldClient.markBlocksDirty(i2 + i, k2, j2 + j, i2 + i, k2, j2 + j);
        }
    }
    
    @Override
    public void func_833_a(final Packet51MapChunk packet51mapchunk) {
        this.worldClient.markRangeForUpdate(packet51mapchunk.field_573_a, packet51mapchunk.field_572_b, packet51mapchunk.field_579_c, packet51mapchunk.field_573_a + packet51mapchunk.field_578_d - 1, packet51mapchunk.field_572_b + packet51mapchunk.field_577_e - 1, packet51mapchunk.field_579_c + packet51mapchunk.field_576_f - 1);
        this.worldClient.setChunkData(packet51mapchunk.field_573_a, packet51mapchunk.field_572_b, packet51mapchunk.field_579_c, packet51mapchunk.field_578_d, packet51mapchunk.field_577_e, packet51mapchunk.field_576_f, packet51mapchunk.field_575_g);
    }
    
    @Override
    public void func_822_a(final Packet53BlockChange packet53blockchange) {
        this.worldClient.func_714_c(packet53blockchange.X, packet53blockchange.Y, packet53blockchange.Z, packet53blockchange.ID, packet53blockchange.Metadata);
    }
    
    @Override
    public void func_844_a(final Packet255KickDisconnect packet255kickdisconnect) {
        this.networkManager.func_974_a("Got kicked");
        this.disconnected = true;
        this.mc.changeWorld1(null);
        this.mc.setCurrentScreen(new GuiConnectFailed("Disconnected by server", packet255kickdisconnect.field_582_a));
    }
    
    @Override
    public void func_823_a(final String s) {
        if (this.disconnected) {
            return;
        }
        this.disconnected = true;
        this.mc.changeWorld1(null);
        this.mc.setCurrentScreen(new GuiConnectFailed("Connection lost", s));
    }
    
    public void addToSendQueue(final Packet packet) {
        if (this.disconnected) {
            return;
        }
        this.networkManager.func_972_a(packet);
    }
    
    @Override
    public void func_834_a(final Packet22Collect packet22collect) {
        final EntityItem entityitem = (EntityItem)this.worldClient.func_709_b(packet22collect.field_581_a);
        Object obj = this.worldClient.func_709_b(packet22collect.field_580_b);
        if (obj == null) {
            obj = this.mc.thePlayer;
        }
        if (entityitem != null) {
            this.worldClient.playSoundAtEntity(entityitem, "random.pop", 0.2f, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            this.mc.effectRenderer.addEffect(new EntityPickupFX(this.mc.mcWorld, entityitem, (Entity)obj, -0.5f));
            this.worldClient.removeEntityFromWorld(packet22collect.field_581_a);
        }
    }
    
    @Override
    public void func_841_a(final Packet16BlockItemSwitch packet16blockitemswitch) {
        final Entity entity = this.worldClient.func_709_b(packet16blockitemswitch.field_563_a);
        if (entity == null) {
            return;
        }
        final EntityPlayer entityplayer = (EntityPlayer)entity;
        final int i = packet16blockitemswitch.field_562_b;
        if (i == 0) {
            entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = null;
        }
        else {
            entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = new ItemStack(i);
        }
    }
    
    @Override
    public void func_831_a(final Packet3Chat packet3chat) {
        this.mc.ingameGUI.addChatMessage(packet3chat.field_517_a);
    }
    
    @Override
    public void func_825_a(final Packet18ArmAnimation packet18armanimation) {
        final Entity entity = this.worldClient.func_709_b(packet18armanimation.field_522_a);
        if (entity == null) {
            return;
        }
        final EntityPlayer entityplayer = (EntityPlayer)entity;
        entityplayer.swingItem();
    }
    
    @Override
    public void func_830_a(final Packet17AddToInventory packet17addtoinventory) {
        this.mc.thePlayer.inventory.addItemStackToInventory(new ItemStack(packet17addtoinventory.field_497_a, packet17addtoinventory.field_496_b, packet17addtoinventory.field_498_c));
    }
    
    @Override
    public void func_838_a(final Packet2Handshake packet2handshake) {
        if (packet2handshake.field_532_a.equals("-")) {
            this.addToSendQueue(new Packet1Login(this.mc.session.username, "Password", 2));
        }
        else {
            try {
                final URL url = new URL("http://www.minecraft.net/game/joinserver.jsp?user=" + this.mc.session.username + "&sessionId=" + this.mc.session.token + "&serverId=" + packet2handshake.field_532_a);
                final BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(url.openStream()));
                final String s = bufferedreader.readLine();
                bufferedreader.close();
                if (s.equalsIgnoreCase("ok")) {
                    this.addToSendQueue(new Packet1Login(this.mc.session.username, "Password", 2));
                }
                else {
                    this.networkManager.func_974_a("Failed to login: " + s);
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.networkManager.func_974_a("Internal client error: " + exception.toString());
            }
        }
    }
    
    public void disconnect() {
        this.disconnected = true;
        this.networkManager.func_974_a("Closed");
    }
    
    @Override
    public void func_828_a(final Packet24MobSpawn packet24mobspawn) {
        final double d = packet24mobspawn.field_552_c / 32.0;
        final double d2 = packet24mobspawn.field_551_d / 32.0;
        final double d3 = packet24mobspawn.field_550_e / 32.0;
        final float f = packet24mobspawn.field_549_f * 360 / 256.0f;
        final float f2 = packet24mobspawn.field_548_g * 360 / 256.0f;
        final EntityLiving entityliving = (EntityLiving)EntityList.createEntity(packet24mobspawn.field_546_b, this.mc.mcWorld);
        entityliving.serverPosX = packet24mobspawn.field_552_c;
        entityliving.serverPosY = packet24mobspawn.field_551_d;
        entityliving.serverPosZ = packet24mobspawn.field_550_e;
        entityliving.setPositionAndRotation(d, d2, d3, f, f2);
        entityliving.isMultiplayerEntity = true;
        entityliving.entityId = packet24mobspawn.field_547_a;
        this.worldClient.func_712_a(packet24mobspawn.field_547_a, entityliving);
    }
    
    @Override
    public void setHealth(final Packet61PlayerHealth packet61PlayerHealth) {
        if (this.mc.thePlayer != null) {
            if (packet61PlayerHealth.health < this.mc.thePlayer.health && !this.initialHealth) {
                this.mc.thePlayer.attackEntityFrom(null, this.mc.thePlayer.health - packet61PlayerHealth.health);
            }
            if (this.initialHealth) {
                this.initialHealth = false;
            }
            this.mc.thePlayer.health = packet61PlayerHealth.health;
        }
    }
    
    @Override
    public void func_846_a(final Packet4UpdateTime packet4updatetime) {
        this.mc.mcWorld.setWorldTime(packet4updatetime.field_564_a);
    }
    
    @Override
    public void func_843_a(final Packet5PlayerInventory packet5playerinventory) {
        final EntityPlayerSP entityplayersp = this.mc.thePlayer;
        if (packet5playerinventory.field_571_a == -1) {
            entityplayersp.inventory.mainInventory = packet5playerinventory.field_570_b;
        }
        if (packet5playerinventory.field_571_a == -2) {
            entityplayersp.inventory.craftingInventory = packet5playerinventory.field_570_b;
        }
        if (packet5playerinventory.field_571_a == -3) {
            entityplayersp.inventory.armorInventory = packet5playerinventory.field_570_b;
        }
    }
    
    @Override
    public void func_842_a(final Packet59ComplexEntity packet59complexentity) {
        final TileEntity tileentity = this.worldClient.getBlockTileEntity(packet59complexentity.field_474_a, packet59complexentity.field_473_b, packet59complexentity.field_477_c);
        if (tileentity != null) {
            tileentity.func_482_a(packet59complexentity.field_475_e);
            this.worldClient.markBlocksDirty(packet59complexentity.field_474_a, packet59complexentity.field_473_b, packet59complexentity.field_477_c, packet59complexentity.field_474_a, packet59complexentity.field_473_b, packet59complexentity.field_477_c);
        }
    }
    
    @Override
    public void func_845_a(final Packet6SpawnPosition packet6spawnposition) {
        this.worldClient.spawnX = packet6spawnposition.field_515_a;
        this.worldClient.spawnY = packet6spawnposition.field_514_b;
        this.worldClient.spawnZ = packet6spawnposition.field_516_c;
    }
}
