package com.mojang.minecraft.network;

class NetworkWriterThread extends Thread
{
    final NetworkManager field_1063_a;
    
    NetworkWriterThread(final NetworkManager networkmanager, final String s) {
        super(s);
        this.field_1063_a = networkmanager;
    }
    
    @Override
    public void run() {
        synchronized (NetworkManager.field_1478_a) {
            ++NetworkManager.field_1476_c;
        }
        // monitorexit(NetworkManager.field_1478_a)
        try {
            do {
                NetworkManager.func_965_d(this.field_1063_a);
            } while (NetworkManager.func_971_a(this.field_1063_a));
        }
        finally {
            synchronized (NetworkManager.field_1478_a) {
                --NetworkManager.field_1476_c;
            }
            // monitorexit(NetworkManager.field_1478_a)
        }
        synchronized (NetworkManager.field_1478_a) {
            --NetworkManager.field_1476_c;
        }
        // monitorexit(NetworkManager.field_1478_a)
    }
}
