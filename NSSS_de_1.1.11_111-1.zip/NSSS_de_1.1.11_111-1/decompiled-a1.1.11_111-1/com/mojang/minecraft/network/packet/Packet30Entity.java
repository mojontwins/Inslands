package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet30Entity extends Packet
{
    public int field_485_a;
    public byte field_484_b;
    public byte field_490_c;
    public byte field_489_d;
    public byte field_488_e;
    public byte field_487_f;
    public boolean field_486_g;
    
    public Packet30Entity() {
        this.field_486_g = false;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_485_a = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_485_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_827_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4;
    }
}
