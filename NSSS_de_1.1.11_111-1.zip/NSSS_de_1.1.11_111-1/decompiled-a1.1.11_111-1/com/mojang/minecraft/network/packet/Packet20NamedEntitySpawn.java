package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.item.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet20NamedEntitySpawn extends Packet
{
    public int field_534_a;
    public String field_533_b;
    public int field_540_c;
    public int field_539_d;
    public int field_538_e;
    public byte field_537_f;
    public byte field_536_g;
    public int field_535_h;
    
    public Packet20NamedEntitySpawn() {
    }
    
    public Packet20NamedEntitySpawn(final EntityPlayer entityplayer) {
        this.field_534_a = entityplayer.entityId;
        this.field_533_b = entityplayer.playerName;
        this.field_540_c = MathHelper.floor_double(entityplayer.posX * 32.0);
        this.field_539_d = MathHelper.floor_double(entityplayer.posY * 32.0);
        this.field_538_e = MathHelper.floor_double(entityplayer.posZ * 32.0);
        this.field_537_f = (byte)(entityplayer.rotationYaw * 256.0f / 360.0f);
        this.field_536_g = (byte)(entityplayer.rotationPitch * 256.0f / 360.0f);
        final ItemStack itemstack = entityplayer.inventory.getCurrentItem();
        this.field_535_h = ((itemstack != null) ? itemstack.itemID : 0);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_534_a = datainputstream.readInt();
        this.field_533_b = datainputstream.readUTF();
        this.field_540_c = datainputstream.readInt();
        this.field_539_d = datainputstream.readInt();
        this.field_538_e = datainputstream.readInt();
        this.field_537_f = datainputstream.readByte();
        this.field_536_g = datainputstream.readByte();
        this.field_535_h = datainputstream.readShort();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_534_a);
        dataoutputstream.writeUTF(this.field_533_b);
        dataoutputstream.writeInt(this.field_540_c);
        dataoutputstream.writeInt(this.field_539_d);
        dataoutputstream.writeInt(this.field_538_e);
        dataoutputstream.writeByte(this.field_537_f);
        dataoutputstream.writeByte(this.field_536_g);
        dataoutputstream.writeShort(this.field_535_h);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_820_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 28;
    }
}
