package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet24MobSpawn extends Packet
{
    public int field_547_a;
    public byte field_546_b;
    public int field_552_c;
    public int field_551_d;
    public int field_550_e;
    public byte field_549_f;
    public byte field_548_g;
    
    public Packet24MobSpawn() {
    }
    
    public Packet24MobSpawn(final EntityLiving entityliving) {
        this.field_547_a = entityliving.entityId;
        this.field_546_b = (byte)EntityList.getEntityID(entityliving);
        this.field_552_c = MathHelper.floor_double(entityliving.posX * 32.0);
        this.field_551_d = MathHelper.floor_double(entityliving.posY * 32.0);
        this.field_550_e = MathHelper.floor_double(entityliving.posZ * 32.0);
        this.field_549_f = (byte)(entityliving.rotationYaw * 256.0f / 360.0f);
        this.field_548_g = (byte)(entityliving.rotationPitch * 256.0f / 360.0f);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_547_a = datainputstream.readInt();
        this.field_546_b = datainputstream.readByte();
        this.field_552_c = datainputstream.readInt();
        this.field_551_d = datainputstream.readInt();
        this.field_550_e = datainputstream.readInt();
        this.field_549_f = datainputstream.readByte();
        this.field_548_g = datainputstream.readByte();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_547_a);
        dataoutputstream.writeByte(this.field_546_b);
        dataoutputstream.writeInt(this.field_552_c);
        dataoutputstream.writeInt(this.field_551_d);
        dataoutputstream.writeInt(this.field_550_e);
        dataoutputstream.writeByte(this.field_549_f);
        dataoutputstream.writeByte(this.field_548_g);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_828_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 19;
    }
}
