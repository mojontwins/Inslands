package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet59ComplexEntity extends Packet
{
    public int field_474_a;
    public int field_473_b;
    public int field_477_c;
    public byte[] field_476_d;
    public NBTTagCompound field_475_e;
    
    public Packet59ComplexEntity() {
        this.packetBooleanUnknown = true;
    }
    
    public Packet59ComplexEntity(final int i, final int j, final int k, final TileEntity tileentity) {
        this.packetBooleanUnknown = true;
        this.field_474_a = i;
        this.field_473_b = j;
        this.field_477_c = k;
        tileentity.func_481_b(this.field_475_e = new NBTTagCompound());
        try {
            this.field_476_d = CompressedStreamTools.func_1142_a(this.field_475_e);
        }
        catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_474_a = datainputstream.readInt();
        this.field_473_b = datainputstream.readShort();
        this.field_477_c = datainputstream.readInt();
        final int i = datainputstream.readShort() & 0xFFFF;
        datainputstream.readFully(this.field_476_d = new byte[i]);
        this.field_475_e = CompressedStreamTools.func_1140_a(this.field_476_d);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_474_a);
        dataoutputstream.writeShort(this.field_473_b);
        dataoutputstream.writeInt(this.field_477_c);
        dataoutputstream.writeShort((short)this.field_476_d.length);
        dataoutputstream.write(this.field_476_d);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_842_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return this.field_476_d.length + 2 + 10;
    }
}
