package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet16BlockItemSwitch extends Packet
{
    public int field_563_a;
    public int field_562_b;
    
    public Packet16BlockItemSwitch() {
    }
    
    public Packet16BlockItemSwitch(final int i, final int j) {
        this.field_563_a = i;
        this.field_562_b = j;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_563_a = datainputstream.readInt();
        this.field_562_b = datainputstream.readShort();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_563_a);
        dataoutputstream.writeShort(this.field_562_b);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_841_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 6;
    }
}
