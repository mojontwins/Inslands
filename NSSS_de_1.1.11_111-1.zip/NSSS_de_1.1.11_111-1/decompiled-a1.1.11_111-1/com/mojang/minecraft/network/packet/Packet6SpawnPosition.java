package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet6SpawnPosition extends Packet
{
    public int field_515_a;
    public int field_514_b;
    public int field_516_c;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_515_a = datainputstream.readInt();
        this.field_514_b = datainputstream.readInt();
        this.field_516_c = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_515_a);
        dataoutputstream.writeInt(this.field_514_b);
        dataoutputstream.writeInt(this.field_516_c);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_845_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 12;
    }
}
