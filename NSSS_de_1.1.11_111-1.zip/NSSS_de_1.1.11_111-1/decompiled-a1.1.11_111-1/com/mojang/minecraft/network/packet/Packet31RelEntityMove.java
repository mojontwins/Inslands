package com.mojang.minecraft.network.packet;

import java.io.*;

public class Packet31RelEntityMove extends Packet30Entity
{
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        super.onIncoming(datainputstream);
        this.field_484_b = datainputstream.readByte();
        this.field_490_c = datainputstream.readByte();
        this.field_489_d = datainputstream.readByte();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        super.onOutgoing(dataoutputstream);
        dataoutputstream.writeByte(this.field_484_b);
        dataoutputstream.writeByte(this.field_490_c);
        dataoutputstream.writeByte(this.field_489_d);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 7;
    }
}
