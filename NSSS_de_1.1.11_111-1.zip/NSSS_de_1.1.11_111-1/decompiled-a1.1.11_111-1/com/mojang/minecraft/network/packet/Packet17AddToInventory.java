package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet17AddToInventory extends Packet
{
    public int field_497_a;
    public int field_496_b;
    public int field_498_c;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_497_a = datainputstream.readShort();
        this.field_496_b = datainputstream.readByte();
        this.field_498_c = datainputstream.readShort();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeShort(this.field_497_a);
        dataoutputstream.writeByte(this.field_496_b);
        dataoutputstream.writeShort(this.field_498_c);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_830_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 5;
    }
}
