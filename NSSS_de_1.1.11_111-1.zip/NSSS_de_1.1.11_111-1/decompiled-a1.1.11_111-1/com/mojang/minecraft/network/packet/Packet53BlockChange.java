package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet53BlockChange extends Packet
{
    public int X;
    public int Y;
    public int Z;
    public int ID;
    public int Metadata;
    
    public Packet53BlockChange() {
        this.packetBooleanUnknown = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.X = datainputstream.readInt();
        this.Y = datainputstream.read();
        this.Z = datainputstream.readInt();
        this.ID = datainputstream.read();
        this.Metadata = datainputstream.read();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.X);
        dataoutputstream.write(this.Y);
        dataoutputstream.writeInt(this.Z);
        dataoutputstream.write(this.ID);
        dataoutputstream.write(this.Metadata);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_822_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 11;
    }
}
