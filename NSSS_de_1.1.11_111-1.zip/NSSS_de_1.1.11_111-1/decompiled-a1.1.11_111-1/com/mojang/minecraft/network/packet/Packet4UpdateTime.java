package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet4UpdateTime extends Packet
{
    public long field_564_a;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_564_a = datainputstream.readLong();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeLong(this.field_564_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_846_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 8;
    }
}
