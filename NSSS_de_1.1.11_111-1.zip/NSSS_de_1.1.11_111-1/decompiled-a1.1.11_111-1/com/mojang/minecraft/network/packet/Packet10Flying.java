package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.network.*;
import java.io.*;

public class Packet10Flying extends Packet
{
    public double field_561_a;
    public double field_560_b;
    public double field_559_c;
    public double field_558_d;
    public float field_557_e;
    public float field_556_f;
    public boolean field_555_g;
    public boolean field_554_h;
    public boolean field_553_i;
    
    public Packet10Flying() {
    }
    
    public Packet10Flying(final boolean flag) {
        this.field_555_g = flag;
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_837_a(this);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_555_g = (datainputstream.read() != 0);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.write(this.field_555_g ? 1 : 0);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 1;
    }
}
