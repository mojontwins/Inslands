package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet3Chat extends Packet
{
    public String field_517_a;
    
    public Packet3Chat() {
    }
    
    public Packet3Chat(final String s) {
        this.field_517_a = s;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_517_a = datainputstream.readUTF();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeUTF(this.field_517_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_831_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return this.field_517_a.length();
    }
}
