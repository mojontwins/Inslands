package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet1Login extends Packet
{
    public int field_519_a;
    public String field_518_b;
    public String field_520_c;
    
    public Packet1Login() {
    }
    
    public Packet1Login(final String s, final String s1, final int i) {
        this.field_518_b = s;
        this.field_520_c = s1;
        this.field_519_a = i;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_519_a = datainputstream.readInt();
        this.field_518_b = datainputstream.readUTF();
        this.field_520_c = datainputstream.readUTF();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_519_a);
        dataoutputstream.writeUTF(this.field_518_b);
        dataoutputstream.writeUTF(this.field_520_c);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.handleLogin(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4 + this.field_518_b.length() + this.field_520_c.length() + 4;
    }
}
