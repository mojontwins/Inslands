package com.mojang.minecraft.network.packet;

import java.io.*;

public class Packet11PlayerPosition extends Packet10Flying
{
    public Packet11PlayerPosition() {
        this.field_554_h = true;
    }
    
    public Packet11PlayerPosition(final double d, final double d1, final double d2, final double d3, final boolean flag) {
        this.field_561_a = d;
        this.field_560_b = d1;
        this.field_558_d = d2;
        this.field_559_c = d3;
        this.field_555_g = flag;
        this.field_554_h = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_561_a = datainputstream.readDouble();
        this.field_560_b = datainputstream.readDouble();
        this.field_558_d = datainputstream.readDouble();
        this.field_559_c = datainputstream.readDouble();
        super.onIncoming(datainputstream);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeDouble(this.field_561_a);
        dataoutputstream.writeDouble(this.field_560_b);
        dataoutputstream.writeDouble(this.field_558_d);
        dataoutputstream.writeDouble(this.field_559_c);
        super.onOutgoing(dataoutputstream);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 33;
    }
}
