package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet14BlockDig extends Packet
{
    public int X;
    public int Y;
    public int Z;
    public int Face;
    public int Status;
    
    public Packet14BlockDig() {
    }
    
    public Packet14BlockDig(final int i, final int j, final int k, final int l, final int i1) {
        this.Status = i;
        this.X = j;
        this.Y = k;
        this.Z = l;
        this.Face = i1;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.Status = datainputstream.read();
        this.X = datainputstream.readInt();
        this.Y = datainputstream.read();
        this.Z = datainputstream.readInt();
        this.Face = datainputstream.read();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.write(this.Status);
        dataoutputstream.writeInt(this.X);
        dataoutputstream.write(this.Y);
        dataoutputstream.writeInt(this.Z);
        dataoutputstream.write(this.Face);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_821_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 11;
    }
}
