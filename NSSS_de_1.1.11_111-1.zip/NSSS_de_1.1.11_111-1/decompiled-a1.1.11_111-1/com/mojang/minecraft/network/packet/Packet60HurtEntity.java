package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet60HurtEntity extends Packet
{
    public int entityId;
    public int damage;
    
    public Packet60HurtEntity() {
    }
    
    public Packet60HurtEntity(final int x, final int damage) {
        this.entityId = x;
        this.damage = damage;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.damage = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeInt(this.damage);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_839_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4;
    }
}
