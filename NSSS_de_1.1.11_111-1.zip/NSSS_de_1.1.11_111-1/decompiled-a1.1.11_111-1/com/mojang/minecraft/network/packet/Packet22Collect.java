package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet22Collect extends Packet
{
    public int field_581_a;
    public int field_580_b;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_581_a = datainputstream.readInt();
        this.field_580_b = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_581_a);
        dataoutputstream.writeInt(this.field_580_b);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_834_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 8;
    }
}
