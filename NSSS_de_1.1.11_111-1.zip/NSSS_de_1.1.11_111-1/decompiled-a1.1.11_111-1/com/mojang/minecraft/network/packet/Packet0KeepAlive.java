package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.network.*;
import java.io.*;

public class Packet0KeepAlive extends Packet
{
    @Override
    public void handlePacket(final NetHandler nethandler) {
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) {
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) {
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 0;
    }
}
