package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet50PreChunk extends Packet
{
    public int field_505_a;
    public int field_504_b;
    public boolean field_506_c;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_505_a = datainputstream.readInt();
        this.field_504_b = datainputstream.readInt();
        this.field_506_c = (datainputstream.read() != 0);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_505_a);
        dataoutputstream.writeInt(this.field_504_b);
        dataoutputstream.write(this.field_506_c ? 1 : 0);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_826_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 9;
    }
}
