package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet52MultiBlockChange extends Packet
{
    public int field_479_a;
    public int field_478_b;
    public short[] field_483_c;
    public byte[] field_482_d;
    public byte[] field_481_e;
    public int field_480_f;
    
    public Packet52MultiBlockChange() {
        this.packetBooleanUnknown = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_479_a = datainputstream.readInt();
        this.field_478_b = datainputstream.readInt();
        this.field_480_f = (datainputstream.readShort() & 0xFFFF);
        this.field_483_c = new short[this.field_480_f];
        this.field_482_d = new byte[this.field_480_f];
        this.field_481_e = new byte[this.field_480_f];
        for (int i = 0; i < this.field_480_f; ++i) {
            this.field_483_c[i] = datainputstream.readShort();
        }
        datainputstream.readFully(this.field_482_d);
        datainputstream.readFully(this.field_481_e);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_479_a);
        dataoutputstream.writeInt(this.field_478_b);
        dataoutputstream.writeShort((short)this.field_480_f);
        for (int i = 0; i < this.field_480_f; ++i) {
            dataoutputstream.writeShort(this.field_483_c[i]);
        }
        dataoutputstream.write(this.field_482_d);
        dataoutputstream.write(this.field_481_e);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_824_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 10 + this.field_480_f * 4;
    }
}
