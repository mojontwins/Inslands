package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet21PickupSpawn extends Packet
{
    public int damage;
    public int entid;
    public int field_530_b;
    public int field_529_c;
    public int field_528_d;
    public byte field_527_e;
    public byte field_526_f;
    public byte field_525_g;
    public int itemid;
    public int stacksize;
    
    public Packet21PickupSpawn() {
    }
    
    public Packet21PickupSpawn(final EntityItem entityitem) {
        this.entid = entityitem.entityId;
        this.itemid = entityitem.item.itemID;
        this.stacksize = entityitem.item.stackSize;
        this.damage = entityitem.item.itemDamage;
        this.field_530_b = MathHelper.floor_double(entityitem.posX * 32.0);
        this.field_529_c = MathHelper.floor_double(entityitem.posY * 32.0);
        this.field_528_d = MathHelper.floor_double(entityitem.posZ * 32.0);
        this.field_527_e = (byte)(entityitem.motionX * 128.0);
        this.field_526_f = (byte)(entityitem.motionY * 128.0);
        this.field_525_g = (byte)(entityitem.motionZ * 128.0);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.entid = datainputstream.readInt();
        this.itemid = datainputstream.readShort();
        this.stacksize = datainputstream.readByte();
        this.damage = datainputstream.readInt();
        this.field_530_b = datainputstream.readInt();
        this.field_529_c = datainputstream.readInt();
        this.field_528_d = datainputstream.readInt();
        this.field_527_e = datainputstream.readByte();
        this.field_526_f = datainputstream.readByte();
        this.field_525_g = datainputstream.readByte();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entid);
        dataoutputstream.writeShort(this.itemid);
        dataoutputstream.writeByte(this.stacksize);
        dataoutputstream.writeInt(this.damage);
        dataoutputstream.writeInt(this.field_530_b);
        dataoutputstream.writeInt(this.field_529_c);
        dataoutputstream.writeInt(this.field_528_d);
        dataoutputstream.writeByte(this.field_527_e);
        dataoutputstream.writeByte(this.field_526_f);
        dataoutputstream.writeByte(this.field_525_g);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_832_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 22;
    }
}
