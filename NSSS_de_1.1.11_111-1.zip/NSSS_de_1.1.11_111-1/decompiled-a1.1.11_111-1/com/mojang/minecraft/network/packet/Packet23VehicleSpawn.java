package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet23VehicleSpawn extends Packet
{
    public int field_500_a;
    public int field_499_b;
    public int field_503_c;
    public int field_502_d;
    public int field_501_e;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_500_a = datainputstream.readInt();
        this.field_501_e = datainputstream.readByte();
        this.field_499_b = datainputstream.readInt();
        this.field_503_c = datainputstream.readInt();
        this.field_502_d = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_500_a);
        dataoutputstream.writeByte(this.field_501_e);
        dataoutputstream.writeInt(this.field_499_b);
        dataoutputstream.writeInt(this.field_503_c);
        dataoutputstream.writeInt(this.field_502_d);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_835_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 17;
    }
}
