package com.mojang.minecraft.network.packet;

import java.util.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public abstract class Packet
{
    private static Map<Integer, Class<?>> packetIdToClassMap;
    private static Map<Class<?>, Integer> packetClassToIdMap;
    public boolean packetBooleanUnknown;
    
    static {
        Packet.packetIdToClassMap = new HashMap<Integer, Class<?>>();
        Packet.packetClassToIdMap = new HashMap<Class<?>, Integer>();
        registerPacket(0, Packet0KeepAlive.class);
        registerPacket(1, Packet1Login.class);
        registerPacket(2, Packet2Handshake.class);
        registerPacket(3, Packet3Chat.class);
        registerPacket(4, Packet4UpdateTime.class);
        registerPacket(5, Packet5PlayerInventory.class);
        registerPacket(6, Packet6SpawnPosition.class);
        registerPacket(10, Packet10Flying.class);
        registerPacket(11, Packet11PlayerPosition.class);
        registerPacket(12, Packet12PlayerLook.class);
        registerPacket(13, Packet13PlayerLookMove.class);
        registerPacket(14, Packet14BlockDig.class);
        registerPacket(15, Packet15Place.class);
        registerPacket(16, Packet16BlockItemSwitch.class);
        registerPacket(17, Packet17AddToInventory.class);
        registerPacket(18, Packet18ArmAnimation.class);
        registerPacket(20, Packet20NamedEntitySpawn.class);
        registerPacket(21, Packet21PickupSpawn.class);
        registerPacket(22, Packet22Collect.class);
        registerPacket(23, Packet23VehicleSpawn.class);
        registerPacket(24, Packet24MobSpawn.class);
        registerPacket(29, Packet29DestroyEntity.class);
        registerPacket(30, Packet30Entity.class);
        registerPacket(31, Packet31RelEntityMove.class);
        registerPacket(32, Packet32EntityLook.class);
        registerPacket(33, Packet33RelEntityMoveLook.class);
        registerPacket(34, Packet34EntityTeleport.class);
        registerPacket(50, Packet50PreChunk.class);
        registerPacket(51, Packet51MapChunk.class);
        registerPacket(52, Packet52MultiBlockChange.class);
        registerPacket(53, Packet53BlockChange.class);
        registerPacket(59, Packet59ComplexEntity.class);
        registerPacket(60, Packet60HurtEntity.class);
        registerPacket(61, Packet61PlayerHealth.class);
        registerPacket(62, Packet62PlaySound.class);
        registerPacket(255, Packet255KickDisconnect.class);
    }
    
    public Packet() {
        this.packetBooleanUnknown = false;
    }
    
    static void registerPacket(final int i, final Class<?> class1) {
        if (Packet.packetIdToClassMap.containsKey(i)) {
            throw new IllegalArgumentException("Duplicate packet id:" + i);
        }
        if (Packet.packetClassToIdMap.containsKey(class1)) {
            throw new IllegalArgumentException("Duplicate packet class:" + class1);
        }
        Packet.packetIdToClassMap.put(i, class1);
        Packet.packetClassToIdMap.put(class1, i);
    }
    
    public static Packet verifyId(final int i) {
        try {
            final Class<?> class1 = Packet.packetIdToClassMap.get(i);
            if (class1 == null) {
                return null;
            }
            return (Packet)class1.newInstance();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            System.out.println("Skipping packet with id " + i);
            return null;
        }
    }
    
    public final int getId() {
        return Packet.packetClassToIdMap.get(this.getClass());
    }
    
    public static Packet onBaseIncoming(final DataInputStream datainputstream) throws IOException {
        final int i = datainputstream.read();
        if (i == -1) {
            return null;
        }
        final Packet packet = verifyId(i);
        if (packet == null) {
            return verifyId(0);
        }
        packet.onIncoming(datainputstream);
        return packet;
    }
    
    public static void sendToOutput(final Packet packet, final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.write(packet.getId());
        packet.onOutgoing(dataoutputstream);
    }
    
    public abstract void onIncoming(final DataInputStream p0) throws IOException;
    
    public abstract void onOutgoing(final DataOutputStream p0) throws IOException;
    
    public abstract void handlePacket(final NetHandler p0);
    
    public abstract int packetFunctionUnknown();
    
    static Class<?> _mthclass$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException classnotfoundexception) {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }
}
