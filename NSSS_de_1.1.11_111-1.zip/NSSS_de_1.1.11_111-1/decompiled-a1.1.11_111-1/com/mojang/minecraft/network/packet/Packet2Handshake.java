package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet2Handshake extends Packet
{
    public String field_532_a;
    
    public Packet2Handshake() {
    }
    
    public Packet2Handshake(final String s) {
        this.field_532_a = s;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_532_a = datainputstream.readUTF();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeUTF(this.field_532_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_838_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4 + this.field_532_a.length() + 4;
    }
}
