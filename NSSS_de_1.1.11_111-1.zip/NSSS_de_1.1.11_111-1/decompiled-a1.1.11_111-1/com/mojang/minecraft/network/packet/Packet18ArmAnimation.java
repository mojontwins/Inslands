package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet18ArmAnimation extends Packet
{
    public int field_522_a;
    public int field_521_b;
    
    public Packet18ArmAnimation() {
    }
    
    public Packet18ArmAnimation(final Entity entity, final int i) {
        this.field_522_a = entity.entityId;
        this.field_521_b = i;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_522_a = datainputstream.readInt();
        this.field_521_b = datainputstream.readByte();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_522_a);
        dataoutputstream.writeByte(this.field_521_b);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_825_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 5;
    }
}
