package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.network.*;
import java.io.*;

public class Packet61PlayerHealth extends Packet
{
    public int health;
    
    public Packet61PlayerHealth() {
    }
    
    public Packet61PlayerHealth(final int x) {
        this.health = x;
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4;
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.health);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.setHealth(this);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.health = datainputstream.readInt();
    }
}
