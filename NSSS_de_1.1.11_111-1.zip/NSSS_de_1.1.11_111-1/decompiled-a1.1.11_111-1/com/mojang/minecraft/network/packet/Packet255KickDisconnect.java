package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet255KickDisconnect extends Packet
{
    public String field_582_a;
    
    public Packet255KickDisconnect() {
    }
    
    public Packet255KickDisconnect(final String s) {
        this.field_582_a = s;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_582_a = datainputstream.readUTF();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeUTF(this.field_582_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_844_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return this.field_582_a.length();
    }
}
