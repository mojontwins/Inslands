package com.mojang.minecraft.network.packet;

import java.util.zip.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet51MapChunk extends Packet
{
    public int field_573_a;
    public int field_572_b;
    public int field_579_c;
    public int field_578_d;
    public int field_577_e;
    public int field_576_f;
    public byte[] field_575_g;
    private int field_574_h;
    
    public Packet51MapChunk() {
        this.packetBooleanUnknown = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_573_a = datainputstream.readInt();
        this.field_572_b = datainputstream.readShort();
        this.field_579_c = datainputstream.readInt();
        this.field_578_d = datainputstream.read() + 1;
        this.field_577_e = datainputstream.read() + 1;
        this.field_576_f = datainputstream.read() + 1;
        final int i = datainputstream.readInt();
        final byte[] abyte0 = new byte[i];
        datainputstream.readFully(abyte0);
        this.field_575_g = new byte[this.field_578_d * this.field_577_e * this.field_576_f * 5 / 2];
        final Inflater inflater = new Inflater();
        inflater.setInput(abyte0);
        try {
            inflater.inflate(this.field_575_g);
        }
        catch (DataFormatException dataformatexception) {
            throw new IOException("Bad compressed data format");
        }
        finally {
            inflater.end();
        }
        inflater.end();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_573_a);
        dataoutputstream.writeShort(this.field_572_b);
        dataoutputstream.writeInt(this.field_579_c);
        dataoutputstream.write(this.field_578_d - 1);
        dataoutputstream.write(this.field_577_e - 1);
        dataoutputstream.write(this.field_576_f - 1);
        dataoutputstream.writeInt(this.field_574_h);
        dataoutputstream.write(this.field_575_g, 0, this.field_574_h);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_833_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 17 + this.field_574_h;
    }
}
