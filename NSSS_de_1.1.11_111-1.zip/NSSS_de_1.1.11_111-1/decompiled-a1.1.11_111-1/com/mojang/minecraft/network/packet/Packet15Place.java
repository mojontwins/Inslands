package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet15Place extends Packet
{
    public int ID;
    public int X;
    public int Y;
    public int Z;
    public int Direction;
    
    public Packet15Place() {
    }
    
    public Packet15Place(final int i, final int j, final int k, final int l, final int i1) {
        this.ID = i;
        this.X = j;
        this.Y = k;
        this.Z = l;
        this.Direction = i1;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.ID = datainputstream.readShort();
        this.X = datainputstream.readInt();
        this.Y = datainputstream.read();
        this.Z = datainputstream.readInt();
        this.Direction = datainputstream.read();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeShort(this.ID);
        dataoutputstream.writeInt(this.X);
        dataoutputstream.write(this.Y);
        dataoutputstream.writeInt(this.Z);
        dataoutputstream.write(this.Direction);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_819_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 12;
    }
}
