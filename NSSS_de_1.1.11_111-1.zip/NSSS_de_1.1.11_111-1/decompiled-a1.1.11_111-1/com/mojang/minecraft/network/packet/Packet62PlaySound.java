package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet62PlaySound extends Packet
{
    public String name;
    public float x;
    public float y;
    public float z;
    public float volume;
    public float pitch;
    
    public Packet62PlaySound() {
    }
    
    public Packet62PlaySound(final String s, final float d, final float d1, final float d2, final float f, final float f1) {
        this.name = s;
        this.x = d;
        this.y = d1;
        this.z = d2;
        this.pitch = f1;
        this.volume = f;
    }
    
    public int func_329_a() {
        return 4;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.name = datainputstream.readUTF();
        this.x = datainputstream.readFloat();
        this.y = datainputstream.readFloat();
        this.z = datainputstream.readFloat();
        this.volume = datainputstream.readFloat();
        this.pitch = datainputstream.readFloat();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeUTF(this.name);
        dataoutputstream.writeFloat(this.x);
        dataoutputstream.writeFloat(this.y);
        dataoutputstream.writeFloat(this.z);
        dataoutputstream.writeFloat(this.volume);
        dataoutputstream.writeFloat(this.pitch);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.handleSound(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 0;
    }
}
