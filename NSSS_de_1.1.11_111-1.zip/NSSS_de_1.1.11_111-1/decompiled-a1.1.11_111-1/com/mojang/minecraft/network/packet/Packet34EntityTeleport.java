package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet34EntityTeleport extends Packet
{
    public int field_509_a;
    public int field_508_b;
    public int field_513_c;
    public int field_512_d;
    public byte field_511_e;
    public byte field_510_f;
    
    public Packet34EntityTeleport() {
    }
    
    public Packet34EntityTeleport(final Entity entity) {
        this.field_509_a = entity.entityId;
        this.field_508_b = MathHelper.floor_double(entity.posX * 32.0);
        this.field_513_c = MathHelper.floor_double(entity.posY * 32.0);
        this.field_512_d = MathHelper.floor_double(entity.posZ * 32.0);
        this.field_511_e = (byte)(entity.rotationYaw * 256.0f / 360.0f);
        this.field_510_f = (byte)(entity.rotationPitch * 256.0f / 360.0f);
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_509_a = datainputstream.readInt();
        this.field_508_b = datainputstream.readInt();
        this.field_513_c = datainputstream.readInt();
        this.field_512_d = datainputstream.readInt();
        this.field_511_e = (byte)datainputstream.read();
        this.field_510_f = (byte)datainputstream.read();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_509_a);
        dataoutputstream.writeInt(this.field_508_b);
        dataoutputstream.writeInt(this.field_513_c);
        dataoutputstream.writeInt(this.field_512_d);
        dataoutputstream.write(this.field_511_e);
        dataoutputstream.write(this.field_510_f);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_829_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 34;
    }
}
