package com.mojang.minecraft.network.packet;

import java.io.*;

public class Packet12PlayerLook extends Packet10Flying
{
    public Packet12PlayerLook() {
        this.field_553_i = true;
    }
    
    public Packet12PlayerLook(final float f, final float f1, final boolean flag) {
        this.field_557_e = f;
        this.field_556_f = f1;
        this.field_555_g = flag;
        this.field_553_i = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_557_e = datainputstream.readFloat();
        this.field_556_f = datainputstream.readFloat();
        super.onIncoming(datainputstream);
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeFloat(this.field_557_e);
        dataoutputstream.writeFloat(this.field_556_f);
        super.onOutgoing(dataoutputstream);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 9;
    }
}
