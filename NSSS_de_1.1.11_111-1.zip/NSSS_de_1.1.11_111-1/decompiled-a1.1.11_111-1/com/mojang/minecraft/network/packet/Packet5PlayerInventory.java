package com.mojang.minecraft.network.packet;

import com.mojang.minecraft.entity.item.*;
import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet5PlayerInventory extends Packet
{
    public int field_571_a;
    public ItemStack[] field_570_b;
    
    public Packet5PlayerInventory() {
    }
    
    public Packet5PlayerInventory(final int i, final ItemStack[] aitemstack) {
        this.field_571_a = i;
        this.field_570_b = new ItemStack[aitemstack.length];
        for (int j = 0; j < this.field_570_b.length; ++j) {
            this.field_570_b[j] = ((aitemstack[j] != null) ? aitemstack[j].copy() : null);
        }
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_571_a = datainputstream.readInt();
        final short word0 = datainputstream.readShort();
        this.field_570_b = new ItemStack[word0];
        for (int i = 0; i < word0; ++i) {
            final short word2 = datainputstream.readShort();
            if (word2 >= 0) {
                final byte byte0 = datainputstream.readByte();
                final short word3 = datainputstream.readShort();
                this.field_570_b[i] = new ItemStack(word2, byte0, word3);
            }
        }
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_571_a);
        dataoutputstream.writeShort(this.field_570_b.length);
        for (int i = 0; i < this.field_570_b.length; ++i) {
            if (this.field_570_b[i] == null) {
                dataoutputstream.writeShort(-1);
            }
            else {
                dataoutputstream.writeShort((short)this.field_570_b[i].itemID);
                dataoutputstream.writeByte((byte)this.field_570_b[i].stackSize);
                dataoutputstream.writeShort((short)this.field_570_b[i].itemDamage);
            }
        }
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_843_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 6 + this.field_570_b.length * 5;
    }
}
