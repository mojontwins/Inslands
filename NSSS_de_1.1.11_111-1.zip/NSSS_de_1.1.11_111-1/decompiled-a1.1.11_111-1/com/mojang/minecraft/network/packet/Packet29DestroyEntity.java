package com.mojang.minecraft.network.packet;

import java.io.*;
import com.mojang.minecraft.network.*;

public class Packet29DestroyEntity extends Packet
{
    public int field_507_a;
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        this.field_507_a = datainputstream.readInt();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_507_a);
    }
    
    @Override
    public void handlePacket(final NetHandler nethandler) {
        nethandler.func_839_a(this);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 4;
    }
}
