package com.mojang.minecraft.network.packet;

import java.io.*;

public class Packet33RelEntityMoveLook extends Packet30Entity
{
    public Packet33RelEntityMoveLook() {
        this.field_486_g = true;
    }
    
    @Override
    public void onIncoming(final DataInputStream datainputstream) throws IOException {
        super.onIncoming(datainputstream);
        this.field_484_b = datainputstream.readByte();
        this.field_490_c = datainputstream.readByte();
        this.field_489_d = datainputstream.readByte();
        this.field_488_e = datainputstream.readByte();
        this.field_487_f = datainputstream.readByte();
    }
    
    @Override
    public void onOutgoing(final DataOutputStream dataoutputstream) throws IOException {
        super.onOutgoing(dataoutputstream);
        dataoutputstream.writeByte(this.field_484_b);
        dataoutputstream.writeByte(this.field_490_c);
        dataoutputstream.writeByte(this.field_489_d);
        dataoutputstream.writeByte(this.field_488_e);
        dataoutputstream.writeByte(this.field_487_f);
    }
    
    @Override
    public int packetFunctionUnknown() {
        return 9;
    }
}
