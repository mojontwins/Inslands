package com.mojang.minecraft.network;

class NetworkReaderThread extends Thread
{
    final NetworkManager field_1085_a;
    
    NetworkReaderThread(final NetworkManager networkmanager, final String s) {
        super(s);
        this.field_1085_a = networkmanager;
    }
    
    @Override
    public void run() {
        Label_0029: {
            synchronized (NetworkManager.field_1478_a) {
                ++NetworkManager.field_1477_b;
                // monitorexit(NetworkManager.field_1478_a)
                break Label_0029;
            }
            try {
                do {
                    NetworkManager.func_966_c(this.field_1085_a);
                    if (NetworkManager.func_971_a(this.field_1085_a)) {
                        continue;
                    }
                    break;
                } while (!NetworkManager.func_968_b(this.field_1085_a));
            }
            finally {
                synchronized (NetworkManager.field_1478_a) {
                    --NetworkManager.field_1477_b;
                }
                // monitorexit(NetworkManager.field_1478_a)
            }
        }
        synchronized (NetworkManager.field_1478_a) {
            --NetworkManager.field_1477_b;
        }
        // monitorexit(NetworkManager.field_1478_a)
    }
}
