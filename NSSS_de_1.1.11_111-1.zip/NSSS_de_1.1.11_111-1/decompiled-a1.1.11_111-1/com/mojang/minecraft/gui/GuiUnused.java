package com.mojang.minecraft.gui;

public class GuiUnused extends GuiScreen
{
    private String lineOne;
    private String lineTwo;
    
    @Override
    public void initGui() {
    }
    
    public void func_573_b(final int i, final int j, final float f) {
        this.drawGradientRect(0, 0, this.width, this.height, -12574688, -11530224);
        this.drawCenteredString(this.fontRenderer, this.lineOne, this.width / 2, 90, 16777215);
        this.drawCenteredString(this.fontRenderer, this.lineTwo, this.width / 2, 110, 16777215);
        super.drawScreen(i, j, f);
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
}
