package com.mojang.minecraft.gui;

import com.mojang.minecraft.player.controller.*;

public class GuiControls extends GuiScreen
{
    private GuiScreen parentScreen;
    protected String screenTitle;
    private GameSettings options;
    private int buttonId;
    
    public GuiControls(final GuiScreen guiscreen, final GameSettings gamesettings) {
        this.screenTitle = "Controls";
        this.buttonId = -1;
        this.parentScreen = guiscreen;
        this.options = gamesettings;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        for (int i = 0; i < this.options.keyBindings.length; ++i) {
            this.controlList.add(new GuiSmallButton(i, this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), this.options.func_1043_a(i)));
        }
        this.controlList.add(new GuiButton(200, this.width / 2 - 100, this.height / 6 + 168, "Done"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        for (int i = 0; i < this.options.keyBindings.length; ++i) {
            this.controlList.get(i).displayString = this.options.func_1043_a(i);
        }
        if (guibutton.id == 200) {
            this.mc.setCurrentScreen(this.parentScreen);
        }
        else {
            this.buttonId = guibutton.id;
            guibutton.displayString = "> " + this.options.func_1043_a(guibutton.id) + " <";
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (this.buttonId >= 0) {
            this.options.func_1042_a(this.buttonId, i);
            this.controlList.get(this.buttonId).displayString = this.options.func_1043_a(this.buttonId);
            this.buttonId = -1;
        }
        else {
            super.keyTyped(c, i);
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 20, 16777215);
        super.drawScreen(i, j, f);
    }
}
