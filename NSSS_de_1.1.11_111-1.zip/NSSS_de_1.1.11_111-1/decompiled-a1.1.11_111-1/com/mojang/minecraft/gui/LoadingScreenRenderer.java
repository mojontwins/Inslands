package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import com.mojang.minecraft.render.*;
import org.lwjgl.opengl.*;

public class LoadingScreenRenderer implements IProgressUpdate
{
    private String field_1004_a;
    private Minecraft field_1003_b;
    private String field_1007_c;
    private long field_1006_d;
    private boolean field_1005_e;
    
    public LoadingScreenRenderer(final Minecraft minecraft) {
        this.field_1004_a = "";
        this.field_1007_c = "";
        this.field_1006_d = System.currentTimeMillis();
        this.field_1005_e = false;
        this.field_1003_b = minecraft;
    }
    
    public void func_596_a(final String s) {
        this.field_1005_e = false;
        this.func_597_c(s);
    }
    
    public void func_594_b(final String s) {
        this.field_1005_e = true;
        this.func_597_c(this.field_1007_c);
    }
    
    public void func_597_c(final String s) {
        if (this.field_1003_b.running) {
            this.field_1007_c = s;
            final ScaledResolution scaledresolution = new ScaledResolution(this.field_1003_b.displayWidth, this.field_1003_b.displayHeight, this.field_1003_b);
            final int i = scaledresolution.getScaledWidth();
            final int j = scaledresolution.getScaledHeight();
            GL11.glClear(256);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)i, (double)j, 0.0, 100.0, 300.0);
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, 0.0f, -200.0f);
            return;
        }
        if (this.field_1005_e) {
            return;
        }
        throw new MinecraftError();
    }
    
    public void func_595_d(final String s) {
        if (this.field_1003_b.running) {
            this.field_1006_d = 0L;
            this.field_1004_a = s;
            this.setProgess(-1);
            this.field_1006_d = 0L;
            return;
        }
        if (this.field_1005_e) {
            return;
        }
        throw new MinecraftError();
    }
    
    public void setProgess(final int i) {
        if (!this.field_1003_b.running) {
            if (this.field_1005_e) {
                return;
            }
            throw new MinecraftError();
        }
        else {
            final long l = System.currentTimeMillis();
            if (l - this.field_1006_d < 20L) {
                return;
            }
            this.field_1006_d = l;
            final ScaledResolution scaledresolution = new ScaledResolution(this.field_1003_b.displayWidth, this.field_1003_b.displayHeight, this.field_1003_b);
            final int j = scaledresolution.getScaledWidth();
            final int k = scaledresolution.getScaledHeight();
            GL11.glClear(256);
            GL11.glMatrixMode(5889);
            GL11.glLoadIdentity();
            GL11.glOrtho(0.0, (double)j, (double)k, 0.0, 100.0, 300.0);
            GL11.glMatrixMode(5888);
            GL11.glLoadIdentity();
            GL11.glTranslatef(0.0f, 0.0f, -200.0f);
            GL11.glClear(16640);
            final Tessellator tessellator = Tessellator.instance;
            final int i2 = this.field_1003_b.renderEngine.getTex("/dirt.png");
            GL11.glBindTexture(3553, i2);
            final float f = 32.0f;
            tessellator.startDrawingQuads();
            tessellator.setColorOpaque_I(4210752);
            tessellator.addVertexWithUV(0.0, k, 0.0, 0.0, k / f);
            tessellator.addVertexWithUV(j, k, 0.0, j / f, k / f);
            tessellator.addVertexWithUV(j, 0.0, 0.0, j / f, 0.0);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0, 0.0, 0.0);
            tessellator.draw();
            if (i >= 0) {
                final byte byte0 = 100;
                final byte byte2 = 2;
                final int j2 = j / 2 - byte0 / 2;
                final int k2 = k / 2 + 16;
                GL11.glDisable(3553);
                tessellator.startDrawingQuads();
                tessellator.setColorOpaque_I(8421504);
                tessellator.addVertex(j2, k2, 0.0);
                tessellator.addVertex(j2, k2 + byte2, 0.0);
                tessellator.addVertex(j2 + byte0, k2 + byte2, 0.0);
                tessellator.addVertex(j2 + byte0, k2, 0.0);
                tessellator.setColorOpaque_I(8454016);
                tessellator.addVertex(j2, k2, 0.0);
                tessellator.addVertex(j2, k2 + byte2, 0.0);
                tessellator.addVertex(j2 + i, k2 + byte2, 0.0);
                tessellator.addVertex(j2 + i, k2, 0.0);
                tessellator.draw();
                GL11.glEnable(3553);
            }
            this.field_1003_b.fontRender.drawStringWithShadow(this.field_1007_c, (j - this.field_1003_b.fontRender.getStringWidth(this.field_1007_c)) / 2, k / 2 - 4 - 16, 16777215);
            this.field_1003_b.fontRender.drawStringWithShadow(this.field_1004_a, (j - this.field_1003_b.fontRender.getStringWidth(this.field_1004_a)) / 2, k / 2 - 4 + 8, 16777215);
            Display.update();
            try {
                Thread.yield();
            }
            catch (Exception ex) {}
        }
    }
}
