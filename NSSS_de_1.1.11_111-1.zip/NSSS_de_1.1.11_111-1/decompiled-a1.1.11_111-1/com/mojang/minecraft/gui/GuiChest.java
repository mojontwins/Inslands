package com.mojang.minecraft.gui;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.player.inventory.*;
import org.lwjgl.opengl.*;

public class GuiChest extends GuiContainer
{
    private IInventory upperChestInventory;
    private IInventory lowerChestInventory;
    private int inventoryRows;
    
    public GuiChest(final IInventory iinventory, final IInventory iinventory1) {
        super(new ContainerChest(iinventory, iinventory1));
        this.inventoryRows = 0;
        this.upperChestInventory = iinventory;
        this.lowerChestInventory = iinventory1;
        this.field_948_f = false;
        final char c = '\u00de';
        final int i = c - 'l';
        this.inventoryRows = iinventory1.getSizeInventory() / 9;
        this.ySize = i + this.inventoryRows * 18;
    }
    
    @Override
    protected void drawGuiContainerForegroundLayer() {
        this.fontRenderer.drawString(this.lowerChestInventory.getInvName(), 8, 6, 4210752);
        this.fontRenderer.drawString(this.upperChestInventory.getInvName(), 8, this.ySize - 96 + 2, 4210752);
    }
    
    @Override
    protected void drawGuiContainerBackgroundLayer(final float f) {
        final int i = this.mc.renderEngine.getTex("/gui/container.png");
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.renderEngine.bindTex(i);
        final int j = (this.width - this.xSize) / 2;
        final int k = (this.height - this.ySize) / 2;
        if (this.inventoryRows > 12) {
            this.drawTexturedModalRect(j, k, 0, 0, this.xSize, 132);
            this.drawTexturedModalRect(j, k + 108, 0, 54, this.xSize, 72);
            this.drawTexturedModalRect(j, k + 132, 0, 24, this.xSize, 102);
            this.drawTexturedModalRect(j, k + 168, 0, 24, this.xSize, 112);
            this.drawTexturedModalRect(j, k + 260, 0, 26, this.xSize, 27);
            this.drawTexturedModalRect(j, k + 287, 0, 126, this.xSize, 130);
        }
        else if (this.inventoryRows > 9) {
            this.drawTexturedModalRect(j, k, 0, 0, this.xSize, 132);
            this.drawTexturedModalRect(j, k + 108, 0, 54, this.xSize, 72);
            this.drawTexturedModalRect(j, k + 132, 0, 24, this.xSize, 102);
            this.drawTexturedModalRect(j, k + 234, 0, 127, this.xSize, 108);
        }
        else if (this.inventoryRows > 6) {
            this.drawTexturedModalRect(j, k, 0, 0, this.xSize, 108);
            this.drawTexturedModalRect(j, k + 108, 0, 54, this.xSize, 72);
            this.drawTexturedModalRect(j, k + 180, 0, 127, this.xSize, 96);
        }
        else {
            this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.inventoryRows * 18 + 17);
            this.drawTexturedModalRect(j, k + this.inventoryRows * 18 + 17, 0, 126, this.xSize, 96);
        }
    }
}
