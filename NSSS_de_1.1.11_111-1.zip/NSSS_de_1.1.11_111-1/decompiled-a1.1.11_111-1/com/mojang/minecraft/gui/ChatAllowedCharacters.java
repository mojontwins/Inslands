package com.mojang.minecraft.gui;

import java.io.*;

public class ChatAllowedCharacters
{
    public static final String allowedCharacters;
    public static final char[] allowedCharactersArray;
    
    static {
        allowedCharacters = getAllowedCharacters();
        allowedCharactersArray = new char[] { '/', '\n', '\r', '\t', '\0', '\f', '`', '?', '*', '\\', '<', '>', '|', '\"', ':' };
    }
    
    private static String getAllowedCharacters() {
        String s = "";
        try {
            final BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(ChatAllowedCharacters.class.getResourceAsStream("/font.txt"), "UTF-8"));
            final String s2 = "";
            String s3;
            while ((s3 = bufferedreader.readLine()) != null) {
                if (!s3.startsWith("#")) {
                    s += s3;
                }
            }
            bufferedreader.close();
        }
        catch (Exception ex) {}
        return s;
    }
}
