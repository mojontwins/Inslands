package com.mojang.minecraft.gui;

import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.render.*;

public class GuiOptions extends GuiScreen
{
    private GuiScreen parentScreen;
    protected String screenTitle;
    private GameSettings options;
    
    public GuiOptions(final GuiScreen guiscreen, final GameSettings gamesettings) {
        this.screenTitle = "Options";
        this.parentScreen = guiscreen;
        this.options = gamesettings;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        for (int i = 0; i < this.options.numberOfOptions; ++i) {
            final int j = this.options.func_1046_b(i);
            if (j == 0) {
                this.controlList.add(new GuiSmallButton(i, this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), this.options.getOptionValue(i)));
            }
            else if (i != 4) {
                this.controlList.add(new GuiSlider(i, this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), i, this.options.getOptionValue(i), this.options.sliderType(i)));
            }
            else {
                this.controlList.add(new GuiSlider(i, this.width / 2 - 155 + i % 2 * 160, this.height / 6 + 24 * (i >> 1), i, this.options.getOptionValue(i), 1.0f - (this.options.sliderType(i) + 3.0f) / 6.0f));
            }
        }
        this.controlList.add(new GuiButton(100, this.width / 2 - 100, this.height / 6 + 145, 98, 20, "Controls..."));
        this.controlList.add(new GuiButton(300, this.width / 2 + 2, this.height / 6 + 145, 98, 20, "Extra Settings..."));
        this.controlList.add(new GuiButton(200, this.width / 2 - 100, this.height / 6 + 168, "Done"));
        if (this.mc.mcWorld != null && this.mc.mcWorld.multiplayerWorld) {
            this.controlList.get(8).enabled = false;
        }
        this.controlList.get(9).enabled = false;
        this.controlList.get(9).displayString = "Mods & Texture Packs...";
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 7) {
            this.mc.setCurrentScreen(new GuiCredits(this));
        }
        if (guibutton.id < 100) {
            if (guibutton.id != 4 && guibutton.id != 7) {
                this.options.setOptionValue(guibutton.id, 1);
            }
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
        }
        if (guibutton.id == 11) {
            this.mc.setIngameNotInFocus();
            final ScaledResolution scaledresolution = new ScaledResolution(this.mc.displayWidth, this.mc.displayHeight, this.mc);
            final int i = scaledresolution.getScaledWidth();
            final int j = scaledresolution.getScaledHeight();
            this.setResolution(this.mc, i, j);
            this.mc.skipRenderWorld = false;
        }
        if (guibutton.id == 100) {
            this.mc.setCurrentScreen(new GuiControls(this, this.options));
        }
        if (guibutton.id == 200) {
            this.mc.setCurrentScreen(this.parentScreen);
        }
        if (guibutton.id == 300) {
            this.mc.setCurrentScreen(new GuiExtraVideoSettings(this, this.options));
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 20, 16777215);
        super.drawScreen(i, j, f);
    }
}
