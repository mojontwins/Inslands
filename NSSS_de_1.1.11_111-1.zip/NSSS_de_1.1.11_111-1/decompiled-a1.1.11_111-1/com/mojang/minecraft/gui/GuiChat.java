package com.mojang.minecraft.gui;

import org.lwjgl.input.*;
import java.io.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.player.controller.*;

public class GuiChat extends GuiScreen
{
    static String[] PLAYER_COLORS;
    private String message;
    private int updateCounter;
    
    static {
        GuiChat.PLAYER_COLORS = new String[] { "c", "b", "a", "5", "6", "e", "d", "7" };
    }
    
    public GuiChat() {
        this.message = "";
        this.updateCounter = 0;
    }
    
    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
    }
    
    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    public void updateScreen() {
        ++this.updateCounter;
    }
    
    public void sendText(final String s) {
        this.mc.ingameGUI.addChatMessage(s);
    }
    
    public static String computePlayerColor(final String name) {
        byte[] pName = null;
        try {
            pName = name.getBytes("US-ASCII");
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        final int length = pName.length;
        final int oddShift = 1 - length % 2;
        int value = 0;
        for (int i = 0; i < length; ++i) {
            final byte by = pName[i];
            final int rev = length - (i + 1) + oddShift;
            if (rev % 4 >= 2) {
                value -= by;
            }
            else {
                value += by;
            }
        }
        value %= 8;
        if (value < 0) {
            value += GuiChat.PLAYER_COLORS.length;
        }
        System.out.println(value);
        return GuiChat.PLAYER_COLORS[value];
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (i == 1) {
            this.mc.setCurrentScreen(null);
            return;
        }
        if (c == '\u0016') {
            String s = GuiScreen.getClipboardString();
            if (s == null) {
                s = "";
            }
            int j = 256 - this.message.length();
            if (j > s.length()) {
                j = s.length();
            }
            if (j > 0) {
                this.message = String.valueOf(this.message) + s.substring(0, j);
            }
        }
        if (i == 28) {
            final String s = this.message.trim();
            if (s.length() > 0) {
                this.mc.thePlayer.sendChatMessage(this.message.trim());
            }
            this.mc.setCurrentScreen(null);
            if (!this.mc.isServer()) {
                if (this.message.startsWith("/") && !this.mc.thePlayer.worldObj.cheatsDisabled) {
                    this.handleCommand(this.message.replaceFirst("/", ""));
                }
                else if (!this.message.startsWith("/")) {
                    System.out.println(this.mc.thePlayer.chatColor);
                    this.sendText("<�" + this.mc.thePlayer.chatColor + this.mc.session.username + "�f> " + this.message);
                }
            }
            return;
        }
        if (i == 14 && this.message.length() > 0) {
            this.message = this.message.substring(0, this.message.length() - 1);
        }
        if (ChatAllowedCharacters.allowedCharacters.indexOf(c) >= 0 && this.message.length() < 256) {
            this.message = String.valueOf(this.message) + c;
        }
    }
    
    private Block getBlockIfExist(final int id) {
        for (int i = 0; i < Block.allBlocks.length; ++i) {
            if (Block.allBlocks[i] != null && Block.allBlocks[i].blockID == id) {
                return Block.allBlocks[i];
            }
        }
        return null;
    }
    
    private Item getItemIfExist(final int id) {
        for (int i = 0; i < Item.itemsList.length; ++i) {
            if (Item.itemsList[i] != null && Item.itemsList[i].shiftedIndex == id) {
                return Item.itemsList[i];
            }
        }
        return null;
    }
    
    private void handleCommand(final String command) {
        final String[] commandArgs = command.split(" ");
        if (commandArgs[0].equalsIgnoreCase("give") || commandArgs[0].equalsIgnoreCase("i")) {
            if (commandArgs.length <= 3 && commandArgs.length >= 2) {
                try {
                    int id = 0;
                    try {
                        id = Integer.parseInt(commandArgs[1]);
                    }
                    catch (Exception ex2) {
                        id = IdMap.getItem(commandArgs[1]);
                        if (id == -1) {
                            this.sendText("Invalid item: " + commandArgs[1]);
                            if (commandArgs[1].equals("null")) {
                                this.mc.changeWorld(null, "");
                            }
                            return;
                        }
                    }
                    final Block blk = this.getBlockIfExist(id);
                    Item itm = null;
                    int size = 64;
                    if (commandArgs.length == 3) {
                        size = Integer.parseInt(commandArgs[2]);
                    }
                    if (blk == null) {
                        itm = this.getItemIfExist(id);
                        if (itm != null) {
                            if (commandArgs.length < 3) {
                                size = itm.maxStackSize;
                            }
                            this.sendText("Giving " + size + " of item " + id);
                            final EntityItem entityitem = new EntityItem(this.mc.thePlayer.worldObj, this.mc.thePlayer.posX, this.mc.thePlayer.posY, this.mc.thePlayer.posZ, new ItemStack(itm, size));
                            entityitem.delayBeforeCanPickup = 10;
                            this.mc.thePlayer.worldObj.entityJoinedWorld(entityitem);
                        }
                        else {
                            this.sendText("�cInvalid item: " + id);
                        }
                    }
                    else {
                        this.sendText("Giving " + size + " of item " + id);
                        final EntityItem entityitem = new EntityItem(this.mc.thePlayer.worldObj, this.mc.thePlayer.posX, this.mc.thePlayer.posY, this.mc.thePlayer.posZ, new ItemStack(blk, size));
                        entityitem.delayBeforeCanPickup = 10;
                        this.mc.thePlayer.worldObj.entityJoinedWorld(entityitem);
                    }
                }
                catch (Exception ex) {
                    this.sendText("�cInvalid syntax for command: " + command);
                    ex.printStackTrace();
                }
            }
            else if (commandArgs.length < 2) {
                this.sendText("�cThis requires 2 or more arguments!");
            }
            else {
                this.sendText("�cThis command cannot accept more than 3 arguments!");
            }
            return;
        }
        Label_3005: {
            if (commandArgs.length == 2) {
                if (commandArgs[0].equalsIgnoreCase("setwinter")) {
                    try {
                        commandArgs[1] = commandArgs[1].toLowerCase();
                        if (commandArgs[1].equalsIgnoreCase("true") || commandArgs[1].equalsIgnoreCase("false")) {
                            this.mc.thePlayer.worldObj.snowCovered = Boolean.parseBoolean(commandArgs[1]);
                        }
                        else {
                            this.sendText("�cYou cannot set winter to " + commandArgs[1] + "!");
                        }
                    }
                    catch (Exception ex) {
                        this.sendText("�cInvalid syntax for command: " + command);
                        ex.printStackTrace();
                    }
                    return;
                }
                if (commandArgs[0].equalsIgnoreCase("summon")) {
                    final Random rand = new Random();
                    Entity entitysummon = null;
                    if (commandArgs[1].equalsIgnoreCase("slime")) {
                        entitysummon = new EntitySlime(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("mob")) {
                        entitysummon = new EntityMob(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("monster")) {
                        entitysummon = new EntityMobs(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("zombie")) {
                        entitysummon = new EntityZombie(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("creeper")) {
                        entitysummon = new EntityCreeper(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("skeleton")) {
                        entitysummon = new EntitySkeleton(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("sheep")) {
                        entitysummon = new EntitySheep(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("pig")) {
                        entitysummon = new EntityPig(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("cow")) {
                        entitysummon = new EntityCow(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("chicken")) {
                        entitysummon = new EntityChicken(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("giant")) {
                        entitysummon = new EntityGiant(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("spider")) {
                        entitysummon = new EntitySpider(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("player")) {
                        entitysummon = new EntityPlayer(this.mc.thePlayer.worldObj);
                    }
                    else if (commandArgs[1].equalsIgnoreCase("lightning")) {
                        entitysummon = new EntityLightningBolt(this.mc.thePlayer.worldObj, this.mc.thePlayer.posX, this.mc.thePlayer.posY - 2.0, this.mc.thePlayer.posZ);
                    }
                    if (entitysummon != null) {
                        if (this.mc.objectMouseOver != null && this.mc.thePlayer.worldObj.getBlockId(this.mc.objectMouseOver.blockX, this.mc.objectMouseOver.blockY, this.mc.objectMouseOver.blockZ) == Block.mobSpawner.blockID) {
                            final TileEntityMobSpawner tile = (TileEntityMobSpawner)this.mc.thePlayer.worldObj.getBlockTileEntity(this.mc.objectMouseOver.blockX, this.mc.objectMouseOver.blockY, this.mc.objectMouseOver.blockZ);
                            tile.entityID = commandArgs[1];
                        }
                        else {
                            entitysummon.setLocationAndAngles(this.mc.thePlayer.posX, this.mc.thePlayer.posY + 0.5, this.mc.thePlayer.posZ, rand.nextFloat() * 360.0f, 0.0f);
                            this.mc.thePlayer.worldObj.entityJoinedWorld(entitysummon);
                            if (entitysummon instanceof EntityPlayer) {
                                final int chance = rand.nextInt(10);
                                switch (chance) {
                                    case 0: {
                                        ((EntityPlayer)entitysummon).playerName = "Noptch";
                                        break;
                                    }
                                    case 1: {
                                        ((EntityPlayer)entitysummon).playerName = "DirtPiper";
                                        break;
                                    }
                                    case 2: {
                                        ((EntityPlayer)entitysummon).playerName = "Vulpovile";
                                        break;
                                    }
                                    case 3: {
                                        ((EntityPlayer)entitysummon).playerName = "LO6AN_";
                                        break;
                                    }
                                    case 4: {
                                        ((EntityPlayer)entitysummon).playerName = "deadmau5";
                                        break;
                                    }
                                    case 5: {
                                        ((EntityPlayer)entitysummon).playerName = "Herobrine";
                                        break;
                                    }
                                    case 6: {
                                        ((EntityPlayer)entitysummon).playerName = "GenericPnPMonior";
                                        break;
                                    }
                                    case 7: {
                                        ((EntityPlayer)entitysummon).playerName = "Steve";
                                        break;
                                    }
                                    case 8: {
                                        ((EntityPlayer)entitysummon).playerName = "Rene";
                                        ((EntityPlayer)entitysummon).modelRene = true;
                                        break;
                                    }
                                    case 9: {
                                        ((EntityPlayer)entitysummon).playerName = "jom";
                                        break;
                                    }
                                }
                                if (!((EntityPlayer)entitysummon).playerName.equals("Rene") && !((EntityPlayer)entitysummon).playerName.equals("Steve") && !((EntityPlayer)entitysummon).playerName.equals("Herobrine")) {
                                    SkinManager.getSkinFromName(((EntityPlayer)entitysummon).playerName, (EntityPlayer)entitysummon);
                                }
                                ((EntityPlayer)entitysummon).yOffset = 0.0f;
                                this.mc.mcWorld.obtainEntitySkin(entitysummon);
                            }
                        }
                    }
                    else {
                        this.sendText("�cA " + commandArgs[1] + " is not a valid entity!");
                    }
                    return;
                }
                if (commandArgs[0].equalsIgnoreCase("gamemode")) {
                    if (commandArgs[1].equalsIgnoreCase("survival") || commandArgs[1].equalsIgnoreCase("s") || commandArgs[1].equalsIgnoreCase("0")) {
                        this.mc.playerController = new PlayerControllerSP(this.mc);
                        this.mc.thePlayer.isCreative = false;
                        this.sendText("Your game mode has been set to survival.");
                    }
                    else if (commandArgs[1].equalsIgnoreCase("creative") || commandArgs[1].equalsIgnoreCase("c") || commandArgs[1].equalsIgnoreCase("1")) {
                        this.mc.playerController = new PlayerControllerCreative(this.mc);
                        this.mc.thePlayer.isCreative = true;
                        this.sendText("Your game mode has been set to creative.");
                    }
                    else {
                        this.sendText("�c" + commandArgs[1] + " is not a valid game mode!");
                    }
                    return;
                }
            }
            else if (commandArgs.length == 3) {
                if (commandArgs[0].equalsIgnoreCase("summon") && commandArgs[1].equalsIgnoreCase("player")) {
                    final Random rand = new Random();
                    final EntityPlayer entitysummon2 = new EntityPlayer(this.mc.thePlayer.worldObj);
                    entitysummon2.setLocationAndAngles(this.mc.thePlayer.posX, this.mc.thePlayer.posY + 0.5, this.mc.thePlayer.posZ, rand.nextFloat() * 360.0f, 0.0f);
                    this.mc.thePlayer.worldObj.entityJoinedWorld(entitysummon2);
                    SkinManager.getSkinFromName(entitysummon2.playerName = commandArgs[2], entitysummon2);
                    entitysummon2.yOffset = 0.0f;
                    this.mc.mcWorld.obtainEntitySkin(entitysummon2);
                    return;
                }
                if (commandArgs[0].equalsIgnoreCase("time")) {
                    try {
                        if (commandArgs[1].equalsIgnoreCase("add")) {
                            final int ticks = Integer.parseInt(commandArgs[2]);
                            final World worldObj = this.mc.thePlayer.worldObj;
                            worldObj.worldTime += ticks;
                        }
                        else if (commandArgs[1].equalsIgnoreCase("set")) {
                            if (commandArgs[2].equalsIgnoreCase("day")) {
                                this.mc.thePlayer.worldObj.worldTime = 0L;
                            }
                            else if (commandArgs[2].equalsIgnoreCase("night")) {
                                this.mc.thePlayer.worldObj.worldTime = 13000L;
                            }
                            else {
                                final int ticks = Integer.parseInt(commandArgs[2]);
                                this.mc.thePlayer.worldObj.worldTime = ticks;
                            }
                        }
                        else {
                            this.sendText("�cInvalid parameter for time command: " + commandArgs[1] + ". Use 'add' or 'set'");
                        }
                    }
                    catch (Exception ex) {
                        this.sendText("�cInvalid syntax for command: " + command);
                        ex.printStackTrace();
                    }
                    return;
                }
            }
            else {
                if (commandArgs.length == 4) {
                    if (!commandArgs[0].equalsIgnoreCase("give")) {
                        if (!commandArgs[0].equalsIgnoreCase("i")) {
                            if (!commandArgs[0].equalsIgnoreCase("teleport")) {
                                if (!commandArgs[0].equalsIgnoreCase("tp")) {
                                    break Label_3005;
                                }
                            }
                            try {
                                final int x = Integer.parseInt(commandArgs[1]);
                                int y = Integer.parseInt(commandArgs[2]);
                                final int z = Integer.parseInt(commandArgs[3]);
                                if (this.mc.thePlayer.worldObj.getBlockId(x, y, z) != 0) {}
                                y = this.getHighestBlock(this.mc.thePlayer.worldObj, x, y, z);
                                this.mc.thePlayer.setPosition(x, y, z);
                            }
                            catch (Exception ex) {
                                this.sendText("�cInvalid syntax for command: " + command);
                                ex.printStackTrace();
                            }
                            return;
                        }
                    }
                    try {
                        final int id = Integer.parseInt(commandArgs[1]);
                        final int size2 = Integer.parseInt(commandArgs[2]);
                        final int damage = Integer.parseInt(commandArgs[3]);
                        final Block blk2 = this.getBlockIfExist(id);
                        Item itm2 = null;
                        if (blk2 == null) {
                            itm2 = this.getItemIfExist(id);
                            if (itm2 != null) {
                                this.sendText("Giving " + size2 + " of item " + id + " with damage " + damage);
                                final EntityItem entityitem2 = new EntityItem(this.mc.thePlayer.worldObj, this.mc.thePlayer.posX, this.mc.thePlayer.posY, this.mc.thePlayer.posZ, new ItemStack(itm2.shiftedIndex, size2, damage));
                                entityitem2.delayBeforeCanPickup = 10;
                                this.mc.thePlayer.worldObj.entityJoinedWorld(entityitem2);
                            }
                            else {
                                this.sendText("�cInvalid item: " + id);
                            }
                        }
                        else {
                            this.sendText("Giving " + size2 + " of item " + id + " with damage " + damage);
                            this.sendText("Damage invalid for block, ignoring");
                            final EntityItem entityitem2 = new EntityItem(this.mc.thePlayer.worldObj, this.mc.thePlayer.posX, this.mc.thePlayer.posY, this.mc.thePlayer.posZ, new ItemStack(blk2, size2));
                            entityitem2.delayBeforeCanPickup = 10;
                            this.mc.thePlayer.worldObj.entityJoinedWorld(entityitem2);
                        }
                    }
                    catch (Exception ex) {
                        this.sendText("�cInvalid syntax for command: " + command);
                        ex.printStackTrace();
                    }
                    return;
                }
                if (commandArgs.length == 1) {
                    if (commandArgs[0].equalsIgnoreCase("spawn")) {
                        try {
                            final int x = this.mc.thePlayer.worldObj.spawnX;
                            int y = this.mc.thePlayer.worldObj.spawnY;
                            final int z = this.mc.thePlayer.worldObj.spawnZ;
                            if (this.mc.thePlayer.worldObj.getBlockId(x, y, z) != 0) {}
                            y = this.getHighestBlock(this.mc.thePlayer.worldObj, x, y, z);
                            this.mc.thePlayer.setPosition(x, y, z);
                        }
                        catch (Exception ex) {
                            this.sendText("�cInvalid syntax for command: " + command);
                            ex.printStackTrace();
                        }
                        return;
                    }
                    if (commandArgs[0].equalsIgnoreCase("help")) {
                        this.sendText("�b---------------Command help (Page 1 of 1)---------------");
                        this.sendText("�e/teleport/tp <x> <y> <z> - teleport to a location");
                        this.sendText("�e/give <item> [quantity] - gives requested item");
                        this.sendText("�e/i <item> [quantity] - alias to give");
                        this.sendText("�e/time <set/add> <ticks> - changes the time");
                        this.sendText("�e/setwinter <true/false> - sets the world's climate");
                        this.sendText("�e/summon <entity> - spawns the requested entity");
                        this.sendText("�e/spawn - sends you to the spawn location");
                        this.sendText("�e/gamemode <survival/creative> - sets your current gamemode");
                        this.sendText("�b-----------------------------------------------------");
                        return;
                    }
                }
            }
        }
        this.sendText("�cInvalid command: " + command);
    }
    
    private int getHighestBlock(final World world, final int x, final int y, final int z) {
        for (int i = 128; i > 0; --i) {
            if (world.getBlockId(x, i, z) != 0) {
                return i + 2;
            }
        }
        return 0;
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawRect(2, this.height - 14, this.width - 2, this.height - 2, Integer.MIN_VALUE);
        this.drawString(this.fontRenderer, "> " + this.message + ((this.updateCounter / 6 % 2 != 0) ? "" : "_"), 4, this.height - 12, 14737632);
    }
    
    @Override
    public void handleMouseInput() {
        super.handleMouseInput();
        if (this.scrollAmount < 0) {
            this.scrollAmount = 0;
        }
        if (this.scrollAmount > 512) {
            this.scrollAmount = 512;
        }
    }
    
    @Override
    public void sendScroll(int j) {
        if (j > 0) {
            j = 1;
        }
        if (j < 0) {
            j = -1;
        }
        this.scrollAmount += j;
    }
    
    @Override
    protected void mouseClicked(final int i, final int j, final int k) {
        System.out.println(this.message);
        if (k != 0 || this.mc.ingameGUI.hoveredPlayer == null) {
            return;
        }
        if (this.message.length() > 0 && !this.message.endsWith(" ")) {
            this.message = String.valueOf(this.message) + " ";
        }
        this.message = String.valueOf(this.message) + this.mc.ingameGUI.hoveredPlayer;
        final int byte0 = 256;
        if (this.message.length() > byte0) {
            this.message = this.message.substring(0, byte0);
        }
    }
}
