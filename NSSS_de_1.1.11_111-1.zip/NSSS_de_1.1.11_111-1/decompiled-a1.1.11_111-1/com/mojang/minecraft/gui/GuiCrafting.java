package com.mojang.minecraft.gui;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.*;
import org.lwjgl.opengl.*;

public class GuiCrafting extends GuiContainer
{
    public GuiCrafting(final InventoryPlayer inventoryplayer, final World world, final int i, final int j, final int k) {
        super(new ContainerWorkbench(inventoryplayer, world, i, j, k));
    }
    
    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        this.inventorySlots.onCraftGuiClosed(this.mc.thePlayer);
    }
    
    @Override
    protected void drawGuiContainerForegroundLayer() {
        this.fontRenderer.drawString("Crafting", 28, 6, 4210752);
        this.fontRenderer.drawString("Inventory", 8, this.ySize - 96 + 2, 4210752);
    }
    
    @Override
    protected void drawGuiContainerBackgroundLayer(final float f) {
        final int i = this.mc.renderEngine.getTex("/gui/crafting.png");
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.renderEngine.bindTex(i);
        final int j = (this.width - this.xSize) / 2;
        final int k = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
    }
}
