package com.mojang.minecraft.gui;

public class GuiSmallButton extends GuiButton
{
    public GuiSmallButton(final int i, final int j, final int k, final String s) {
        super(i, j, k, 150, 20, s);
    }
}
