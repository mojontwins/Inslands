package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import java.io.*;
import com.mojang.minecraft.level.*;

public class GuiSelectServer extends GuiScreen
{
    int list;
    long timeSinceClick;
    protected GuiScreen field_958_a;
    protected String field_960_h;
    private boolean field_959_i;
    
    public GuiSelectServer(final GuiScreen guiscreen) {
        this.list = 0;
        this.timeSinceClick = System.currentTimeMillis();
        this.field_960_h = "Select Server";
        this.field_959_i = false;
        this.field_958_a = guiscreen;
    }
    
    @Override
    public void initGui() {
        this.setButtons(this.list);
    }
    
    public void setButtons(final int next) {
        this.controlList.clear();
        this.list = next;
        String name = "Select server";
        if (this instanceof GuiDeleteServer) {
            name = "Delete server";
        }
        this.field_960_h = String.valueOf(name) + " (" + (this.list + 1) + " - " + (this.list + 5) + ")";
        final File file = Minecraft.getMinecraftDir();
        for (int i = this.list; i < this.list + 5; ++i) {
            final File serverName = new File(file, "NSSSservers/Server" + (i + 1));
            if (!serverName.exists()) {
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), "- empty -\u0000"));
            }
            else {
                String s = "Server " + (i + 1);
                final File f = new File(file, "NSSSservers/Server" + (i + 1) + "/name.data");
                if (f.exists()) {
                    try {
                        final BufferedReader br = new BufferedReader(new FileReader(f));
                        s = br.readLine().replace("\u0000", "");
                        br.close();
                    }
                    catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), s));
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), s));
            }
        }
        this.func_585_j();
    }
    
    protected String func_586_d(final int i) {
        final File file = Minecraft.getMinecraftDir();
        return (World.func_629_a(file, "Server" + i) == null) ? null : ("Server" + i);
    }
    
    public void func_585_j() {
        final GuiButton gbnext = new GuiButton(-3, this.width / 2 + 6, this.height / 6 + 128, ">");
        gbnext.width = 95;
        this.controlList.add(gbnext);
        final GuiButton gbprev = new GuiButton(-4, this.width / 2 - 100, this.height / 6 + 128, "<");
        gbprev.width = 95;
        if (this.list <= 0) {
            gbprev.enabled = false;
        }
        else {
            gbprev.enabled = true;
        }
        this.controlList.add(gbprev);
        this.controlList.add(new GuiButton(-1, this.width / 2 - 100, this.height / 6 + 120 + 32 + 2, "Delete server..."));
        this.controlList.add(new GuiButton(-2, this.width / 2 - 100, this.height / 6 + 168 + 10, "Cancel"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (this.timeSinceClick < System.currentTimeMillis() - 50L) {
            this.timeSinceClick = System.currentTimeMillis();
            if (!guibutton.enabled) {
                return;
            }
            if (guibutton.id == -3) {
                this.controlList.clear();
                this.setButtons(this.list + 5);
            }
            if (guibutton.id == -4) {
                this.controlList.clear();
                if (this.list - 5 < 0) {
                    this.list = 5;
                }
                this.setButtons(this.list - 5);
            }
            if (guibutton.id > -1) {
                if (this instanceof GuiDeleteServer || !guibutton.displayString.contains("\u0000")) {
                    this.func_584_c(guibutton.id + 1);
                }
                else {
                    this.mc.setCurrentScreen(new GuiNameServer(this, guibutton.id + 1));
                }
            }
            else if (guibutton.id == -1) {
                this.mc.setCurrentScreen(new GuiDeleteServer(this));
            }
            else if (guibutton.id == -2) {
                this.mc.setCurrentScreen(this.field_958_a);
            }
        }
    }
    
    public void func_584_c(final int i) {
        String s = "";
        final File file = Minecraft.getMinecraftDir();
        final File f = new File(file, "NSSSservers/Server" + i + "/ip.data");
        if (f.exists()) {
            try {
                final BufferedReader br = new BufferedReader(new FileReader(f));
                s = br.readLine().replace("\u0000", "");
                br.close();
            }
            catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        System.out.println(s);
        final String[] as = s.split(":");
        this.func_584_c(i, as);
    }
    
    public void func_584_c(final int i, final String[] as) {
        this.mc.setCurrentScreen(null);
        if (this.field_959_i) {
            return;
        }
        this.field_959_i = true;
        this.mc.setCurrentScreen(new GuiConnecting(this.mc, as[0], (as.length <= 1) ? 25565 : this.parseIntWithDefault(as[1], 25565)));
    }
    
    private int parseIntWithDefault(final String s, final int i) {
        try {
            return Integer.parseInt(s.trim());
        }
        catch (Exception exception) {
            return i;
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.field_960_h, this.width / 2, 20, 16777215);
        super.drawScreen(i, j, f);
    }
}
