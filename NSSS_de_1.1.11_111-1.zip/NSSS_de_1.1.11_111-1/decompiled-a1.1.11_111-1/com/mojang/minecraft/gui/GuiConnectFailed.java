package com.mojang.minecraft.gui;

public class GuiConnectFailed extends GuiScreen
{
    private String field_992_a;
    private String field_993_h;
    
    public GuiConnectFailed(final String s, final String s1) {
        this.field_992_a = s;
        this.field_993_h = s1;
    }
    
    @Override
    public void updateScreen() {
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, "Back to title screen"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton.id == 0) {
            this.mc.setCurrentScreen(new GuiMainMenu());
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.field_992_a, this.width / 2, this.height / 2 - 50, 16777215);
        this.drawCenteredString(this.fontRenderer, this.field_993_h, this.width / 2, this.height / 2 - 10, 16777215);
        super.drawScreen(i, j, f);
    }
}
