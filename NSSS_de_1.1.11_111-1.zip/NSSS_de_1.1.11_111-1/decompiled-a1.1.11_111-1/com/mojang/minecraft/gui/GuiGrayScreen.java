package com.mojang.minecraft.gui;

public class GuiGrayScreen extends GuiScreen
{
    private String lineOne;
    private String lineTwo;
    private long counter;
    private long startTime;
    
    public GuiGrayScreen() {
        this.startTime = 1337L;
    }
    
    @Override
    public void initGui() {
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        if (this.startTime == 1337L) {
            this.startTime = System.currentTimeMillis();
            this.counter = this.startTime;
        }
        this.drawGradientRect(0, 0, this.width, this.height, -7829368, -7829368);
        if (this.counter < this.startTime + 6000L) {
            this.counter = System.currentTimeMillis();
        }
        if (this.counter > this.startTime + 2000L) {
            this.lineOne = "Minecraft Alpha 1.1.1 - Seecret Saturday Update #1";
        }
        if (this.counter > this.startTime + 3000L) {
            this.lineTwo = "Minecraft Alpha 1.1.11 - Seecret Saturday Update #11";
        }
        if (this.counter > this.startTime + 4000L) {
            this.lineTwo = "11 years of Seecret Saturdays! (plus or minus 8)";
            this.lineOne = "\u263a";
        }
        if (this.counter > this.startTime + 5000L) {
            this.mc.setCurrentScreen(new GuiMainMenu());
        }
        this.drawCenteredString(this.fontRenderer, this.lineOne, this.width / 2, 90, 16777215);
        this.drawCenteredString(this.fontRenderer, this.lineTwo, this.width / 2, 110, 16777215);
        super.drawScreen(i, j, f);
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        this.mc.setCurrentScreen(new GuiMainMenu());
    }
}
