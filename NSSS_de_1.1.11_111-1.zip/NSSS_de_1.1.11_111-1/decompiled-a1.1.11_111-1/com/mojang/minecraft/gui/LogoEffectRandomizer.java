package com.mojang.minecraft.gui;

class LogoEffectRandomizer
{
    public double field_1312_a;
    public double field_1311_b;
    public double field_1314_c;
    final GuiMainMenu field_1313_d;
    
    public LogoEffectRandomizer(final GuiMainMenu guimainmenu, final int i, final int j) {
        this.field_1313_d = guimainmenu;
        final double n = 10 + j + GuiMainMenu.func_592_j().nextDouble() * 32.0 + i;
        this.field_1311_b = n;
        this.field_1312_a = n;
    }
    
    public void func_875_a() {
        this.field_1311_b = this.field_1312_a;
        if (this.field_1312_a > 0.0) {
            this.field_1314_c -= 0.6;
        }
        this.field_1312_a += this.field_1314_c;
        this.field_1314_c *= 0.9;
        if (this.field_1312_a < 0.0) {
            this.field_1312_a = 0.0;
            this.field_1314_c = 0.0;
        }
    }
}
