package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import java.util.*;
import java.awt.*;
import java.awt.datatransfer.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class GuiScreen extends Gui
{
    protected Minecraft mc;
    public int width;
    public int height;
    protected List<Object> controlList;
    public boolean field_948_f;
    protected FontRenderer fontRenderer;
    private GuiButton field_946_a;
    public int scrollAmount;
    
    public GuiScreen() {
        this.scrollAmount = 0;
        this.controlList = new ArrayList<Object>();
        this.field_948_f = false;
        this.field_946_a = null;
    }
    
    public void drawScreen(final int i, final int j, final float f) {
        for (int k = 0; k < this.controlList.size(); ++k) {
            final GuiButton guibutton = this.controlList.get(k);
            guibutton.func_561_a(this.mc, i, j);
        }
    }
    
    protected void keyTyped(final char c, final int i) {
        if (i == 1) {
            this.mc.setCurrentScreen(null);
            this.mc.setIngameFocus();
        }
    }
    
    public static String getClipboardString() {
        try {
            final Transferable transferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
            if (transferable != null && transferable.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                final String s = (String)transferable.getTransferData(DataFlavor.stringFlavor);
                return s;
            }
        }
        catch (Exception ex) {}
        return null;
    }
    
    protected void mouseClicked(final int i, final int j, final int k) {
        if (k == 0) {
            for (int l = this.controlList.size() - 1; l >= 0; --l) {
                final GuiButton guibutton = this.controlList.get(l);
                if (guibutton.func_562_c(this.mc, i, j)) {
                    this.field_946_a = guibutton;
                    this.mc.soundMGR.playSoundFX("random.click", 1.0f, 1.0f);
                    this.actionPerformed(guibutton);
                    break;
                }
            }
        }
    }
    
    protected void mouseMovedOrUp(final int i, final int j, final int k) {
        if (this.field_946_a != null && k == 0) {
            this.field_946_a.func_559_a(i, j);
            this.field_946_a = null;
        }
    }
    
    protected void actionPerformed(final GuiButton guibutton) {
    }
    
    public void setResolution(final Minecraft minecraft, final int i, final int j) {
        this.mc = minecraft;
        this.fontRenderer = minecraft.fontRender;
        this.width = i;
        this.height = j;
        this.initGui();
    }
    
    public void initGui() {
    }
    
    public void handleInput() {
        while (Mouse.next()) {
            this.handleMouseInput();
        }
        while (Keyboard.next()) {
            this.handleKeyboardInput();
        }
    }
    
    public void handleMouseInput() {
        final int wheel = Mouse.getEventDWheel();
        if (wheel != 0) {
            this.sendScroll(wheel);
        }
        if (Mouse.getEventButtonState()) {
            final int i = Mouse.getEventX() * this.width / this.mc.displayWidth;
            final int k = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
            this.mouseClicked(i, k, Mouse.getEventButton());
        }
        else {
            final int j = Mouse.getEventX() * this.width / this.mc.displayWidth;
            final int l = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
            this.mouseMovedOrUp(j, l, Mouse.getEventButton());
        }
    }
    
    public void handleKeyboardInput() {
        if (Keyboard.getEventKeyState()) {
            if (Keyboard.getEventKey() == 87) {
                this.mc.toggleFullscreen();
                return;
            }
            this.keyTyped(Keyboard.getEventCharacter(), Keyboard.getEventKey());
        }
    }
    
    public void updateScreen() {
    }
    
    public void onGuiClosed() {
    }
    
    public void drawDefaultBackground() {
        this.func_567_a(0);
    }
    
    public void func_567_a(final int i) {
        if (this.mc.mcWorld != null) {
            this.drawGradientRect(0, 0, this.width, this.height, -1072689136, -804253680);
        }
        else {
            this.func_579_b(i);
        }
    }
    
    public void func_579_b(final int i) {
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        final Tessellator tessellator = Tessellator.instance;
        GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/dirt.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final float f = 32.0f;
        tessellator.startDrawingQuads();
        tessellator.setColorOpaque_I(4210752);
        tessellator.addVertexWithUV(0.0, this.height, 0.0, 0.0, this.height / f + i);
        tessellator.addVertexWithUV(this.width, this.height, 0.0, this.width / f, this.height / f + i);
        tessellator.addVertexWithUV(this.width, 0.0, 0.0, this.width / f, 0 + i);
        tessellator.addVertexWithUV(0.0, 0.0, 0.0, 0.0, 0 + i);
        tessellator.draw();
    }
    
    public boolean doesGuiPauseGame() {
        return true;
    }
    
    public void func_568_a(final boolean flag, final int i) {
    }
    
    public void selectNextField() {
    }
    
    public void sendScroll(int j) {
        if (j > 0) {
            j = 1;
        }
        if (j < 0) {
            j = -1;
        }
        this.scrollAmount -= j;
    }
}
