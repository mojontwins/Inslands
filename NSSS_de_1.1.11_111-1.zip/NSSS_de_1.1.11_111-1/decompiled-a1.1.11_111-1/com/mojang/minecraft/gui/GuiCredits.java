package com.mojang.minecraft.gui;

public class GuiCredits extends GuiScreen
{
    private GuiScreen prevScreen;
    private int updateCounter;
    
    public GuiCredits(final GuiScreen prev) {
        this.prevScreen = prev;
        this.updateCounter = 0;
    }
    
    @Override
    public void updateScreen() {
        ++this.updateCounter;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, "Ok"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 0) {
            this.mc.setCurrentScreen(this.prevScreen);
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, "Credits", this.width / 2, this.height / 4 - 60 + 20, 16777215);
        this.drawCenteredString(this.fontRenderer, "The people who made NSSS", this.width / 2, this.height / 4 - 40 + 12, 16777215);
        this.drawCenteredString(this.fontRenderer, "Developers:", this.width / 2, this.height / 4 - 60 + 60 - 12, 10526880);
        this.drawCenteredString(this.fontRenderer, "DirtPiper - Lead Developer", this.width / 2, this.height / 4 - 60 + 60, 10526880);
        this.drawCenteredString(this.fontRenderer, "Vulpovile - Codeveloper", this.width / 2, this.height / 4 - 60 + 60 + 12, 10526880);
        this.drawCenteredString(this.fontRenderer, "L06AN_ - Codeveloper", this.width / 2, this.height / 4 - 60 + 60 + 24, 10526880);
        this.drawCenteredString(this.fontRenderer, "Artsicle - Former Codeveloper", this.width / 2, this.height / 4 - 60 + 60 + 36, 10526880);
        this.drawCenteredString(this.fontRenderer, "Patrons:", this.width / 2, this.height / 4 - 60 + 60 + 60, 10526880);
        this.drawCenteredString(this.fontRenderer, "Gutine", this.width / 2, this.height / 4 - 60 + 60 + 72, 10526880);
        this.drawCenteredString(this.fontRenderer, "Playtesters:", this.width / 2, this.height / 4 - 60 + 60 + 96, 10526880);
        this.drawCenteredString(this.fontRenderer, "GenericPNPMonior  Jyration   MrLordSith   Nitpick  MiniGram  Tubeheader", this.width / 2, this.height / 4 - 60 + 60 + 108, 10526880);
        this.drawCenteredString(this.fontRenderer, "MapleTheOne  Fie_Guy  TolerableDruid  Vista_Ultimate  MaggAndGeez  Tami", this.width / 2, this.height / 4 - 60 + 60 + 120, 10526880);
        super.drawScreen(i, j, f);
    }
}
