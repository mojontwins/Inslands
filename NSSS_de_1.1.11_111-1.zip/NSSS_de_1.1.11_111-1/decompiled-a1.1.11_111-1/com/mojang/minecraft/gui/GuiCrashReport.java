package com.mojang.minecraft.gui;

import com.mojang.minecraft.util.*;
import java.io.*;
import java.text.*;
import java.util.*;
import com.mojang.minecraft.*;
import org.lwjgl.*;
import org.lwjgl.opengl.*;
import java.awt.*;

public class GuiCrashReport extends Panel
{
    private static final long serialVersionUID = 1L;
    
    public GuiCrashReport(final UnexpectedThrowable unexpectedthrowable) {
        this.setBackground(new Color(3028036));
        this.setLayout(new BorderLayout());
        final StringWriter stringwriter = new StringWriter();
        unexpectedthrowable.exception.printStackTrace(new PrintWriter(stringwriter));
        final String s = stringwriter.toString();
        String s2 = "";
        String s3 = "";
        try {
            s3 = s3 + "Generated " + new SimpleDateFormat().format(new Date()) + "\n";
            s3 += "\n";
            s3 += "Minecraft: Minecraft Alpha " + Minecraft.versionNumber + "\n";
            s3 = s3 + "OS: " + System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ") version " + System.getProperty("os.version") + "\n";
            s3 = s3 + "Java: " + System.getProperty("java.version") + ", " + System.getProperty("java.vendor") + "\n";
            s3 = s3 + "VM: " + System.getProperty("java.vm.name") + " (" + System.getProperty("java.vm.info") + "), " + System.getProperty("java.vm.vendor") + "\n";
            s3 = s3 + "LWJGL: " + Sys.getVersion() + "\n";
            s2 = GL11.glGetString(7936);
            s3 = s3 + "OpenGL: " + GL11.glGetString(7937) + " version " + GL11.glGetString(7938) + ", " + GL11.glGetString(7936) + "\n";
        }
        catch (Throwable throwable) {
            s3 = s3 + "[failed to get system properties (" + throwable + ")]\n";
        }
        s3 += "\n";
        s3 += s;
        String s4 = "";
        s4 += "\n";
        s4 += "\n";
        if (s.contains("Pixel format not accelerated")) {
            s4 += "      Bad video card drivers!      \n";
            s4 += "      -----------------------      \n";
            s4 += "\n";
            s4 += "Minecraft was unable to start because it failed to find an accelerated OpenGL mode.\n";
            s4 += "This can usually be fixed by updating the video card drivers.\n";
            if (s2.toLowerCase().contains("nvidia")) {
                s4 += "\n";
                s4 += "You might be able to find drivers for your video card here:\n";
                s4 += "  http://www.nvidia.com/\n";
            }
            else if (s2.toLowerCase().contains("ati")) {
                s4 += "\n";
                s4 += "You might be able to find drivers for your video card here:\n";
                s4 += "  http://www.amd.com/\n";
            }
        }
        else {
            s4 += "      Minecraft has crashed!      \n";
            s4 += "      ----------------------      \n";
            s4 += "\n";
            s4 += "Minecraft has stopped running because it encountered a problem.\n";
            s4 += "\n";
            s4 += "If you wish to report this, please copy this entire text and email it to support@mojang.com.\n";
            s4 += "Please include a description of what you did when the error occured.\n";
        }
        s4 += "\n";
        s4 += "\n";
        s4 += "\n";
        s4 = s4 + "--- BEGIN ERROR REPORT " + Integer.toHexString(s4.hashCode()) + " --------\n";
        s4 += s3;
        s4 = s4 + "--- END ERROR REPORT " + Integer.toHexString(s4.hashCode()) + " ----------\n";
        s4 += "\n";
        s4 += "\n";
        final TextArea textarea = new TextArea(s4, 0, 0, 1);
        textarea.setFont(new Font("Monospaced", 0, 12));
        this.add(new MajongLogoCanvas(), "North");
        this.add(new CrashCanvas(80), "East");
        this.add(new CrashCanvas(80), "West");
        this.add(new CrashCanvas(100), "South");
        this.add(textarea, "Center");
    }
}
