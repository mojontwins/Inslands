package com.mojang.minecraft.gui;

import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;

public class GuiConnecting extends GuiScreen
{
    ThreadDial dial;
    private NetClientHandler netClientHandler;
    private boolean field_953_h;
    
    public GuiConnecting(final Minecraft minecraft, final String s, final int i) {
        this.field_953_h = false;
        minecraft.changeWorld1(null);
        if (minecraft.options.modemVolume > 0.0f) {
            try {
                (this.dial = new ThreadDial(this, minecraft, s, i)).start();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        else {
            new ThreadConnectToServer(this, minecraft, s, i).start();
        }
    }
    
    @Override
    public void updateScreen() {
        if (this.netClientHandler != null) {
            this.netClientHandler.processReadPackets();
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, "Cancel"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton.id == 0) {
            this.field_953_h = true;
            if (this.netClientHandler != null) {
                this.netClientHandler.disconnect();
                if (this.dial != null) {
                    this.dial.interrupt();
                }
            }
            this.mc.setCurrentScreen(new GuiMainMenu());
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        if (this.netClientHandler == null) {
            this.drawCenteredString(this.fontRenderer, "Connecting to the server...", this.width / 2, this.height / 2 - 50, 16777215);
            this.drawCenteredString(this.fontRenderer, "", this.width / 2, this.height / 2 - 10, 16777215);
        }
        else {
            this.drawCenteredString(this.fontRenderer, "Logging in...", this.width / 2, this.height / 2 - 50, 16777215);
            this.drawCenteredString(this.fontRenderer, this.netClientHandler.field_1209_a, this.width / 2, this.height / 2 - 10, 16777215);
        }
        super.drawScreen(i, j, f);
    }
    
    public static NetClientHandler setNetClientHandler(final GuiConnecting guiconnecting, final NetClientHandler netclienthandler) {
        return guiconnecting.netClientHandler = netclienthandler;
    }
    
    public static boolean isCancelled(final GuiConnecting guiconnecting) {
        return guiconnecting.field_953_h;
    }
    
    public static NetClientHandler func_583_b(final GuiConnecting guiconnecting) {
        return guiconnecting.netClientHandler;
    }
}
