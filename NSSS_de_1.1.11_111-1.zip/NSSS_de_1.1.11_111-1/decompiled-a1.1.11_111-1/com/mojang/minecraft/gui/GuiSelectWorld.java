package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import com.mojang.minecraft.level.*;
import java.io.*;
import com.mojang.minecraft.nbt.*;
import java.util.*;
import com.mojang.minecraft.player.controller.*;

public class GuiSelectWorld extends GuiScreen
{
    int list;
    long timeSinceClick;
    protected GuiScreen field_958_a;
    protected String field_960_h;
    private boolean field_959_i;
    
    public GuiSelectWorld(final GuiScreen guiscreen) {
        this.list = 0;
        this.timeSinceClick = System.currentTimeMillis();
        this.field_960_h = "Select world";
        this.field_959_i = false;
        this.field_958_a = guiscreen;
    }
    
    @Override
    public void initGui() {
        this.setButtons(this.list);
    }
    
    public void setButtons(final int next) {
        this.controlList.clear();
        this.list = next;
        String name = "Select world";
        if (this instanceof GuiDeleteWorld) {
            name = "Delete World";
        }
        this.field_960_h = String.valueOf(name) + " (" + (this.list + 1) + " - " + (this.list + 5) + ")";
        final File file = Minecraft.getMinecraftDir();
        for (int i = this.list; i < this.list + 5; ++i) {
            final NBTTagCompound nbttagcompound = World.func_629_a(file, "World" + (i + 1));
            if (nbttagcompound == null) {
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), "- empty -\u0000"));
            }
            else {
                String s = "World " + (i + 1);
                final File f = new File(file, "NSSSsaves/World" + (i + 1) + "/name.data");
                if (f.exists()) {
                    try {
                        final BufferedReader br = new BufferedReader(new FileReader(f));
                        s = br.readLine().replace("\u0000", "");
                        br.close();
                    }
                    catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
                final long l = nbttagcompound.getLong("SizeOnDisk");
                s = s + " (" + l / 1024L * 100L / 1024L / 100.0f + " MB)";
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), s));
                this.controlList.add(new GuiButton(i, this.width / 2 - 100, this.height / 6 + 24 * (i - this.list), s));
            }
        }
        this.func_585_j();
    }
    
    protected String func_586_d(final int i) {
        final File file = Minecraft.getMinecraftDir();
        return (World.func_629_a(file, "World" + i) == null) ? null : ("World" + i);
    }
    
    public void func_585_j() {
        final GuiButton gbnext = new GuiButton(-3, this.width / 2 + 6, this.height / 6 + 128, ">");
        gbnext.width = 95;
        this.controlList.add(gbnext);
        final GuiButton gbprev = new GuiButton(-4, this.width / 2 - 100, this.height / 6 + 128, "<");
        gbprev.width = 95;
        if (this.list <= 0) {
            gbprev.enabled = false;
        }
        else {
            gbprev.enabled = true;
        }
        this.controlList.add(gbprev);
        this.controlList.add(new GuiButton(-1, this.width / 2 - 100, this.height / 6 + 120 + 32 + 2, "Delete world..."));
        this.controlList.add(new GuiButton(-2, this.width / 2 - 100, this.height / 6 + 168 + 10, "Cancel"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (this.timeSinceClick < System.currentTimeMillis() - 50L) {
            this.timeSinceClick = System.currentTimeMillis();
            if (!guibutton.enabled) {
                return;
            }
            if (guibutton.id == -3) {
                this.controlList.clear();
                this.setButtons(this.list + 5);
            }
            if (guibutton.id == -4) {
                this.controlList.clear();
                if (this.list - 5 < 0) {
                    this.list = 5;
                }
                this.setButtons(this.list - 5);
            }
            if (guibutton.id > -1) {
                if (this instanceof GuiDeleteWorld || !guibutton.displayString.contains("\u0000")) {
                    this.func_584_c(guibutton.id + 1);
                }
                else {
                    this.mc.setCurrentScreen(new GuiNameWorld(this, guibutton.id + 1));
                }
            }
            else if (guibutton.id == -1) {
                this.mc.setCurrentScreen(new GuiDeleteWorld(this));
            }
            else if (guibutton.id == -2) {
                this.mc.setCurrentScreen(this.field_958_a);
            }
        }
    }
    
    public void func_584_c(final int i) {
        this.func_584_c(i, new Random().nextInt(4) == 0, true, 0);
    }
    
    public void func_584_c(final int i, final boolean snowCovered, final boolean cheatsEnabled, final int worldType) {
        this.mc.setCurrentScreen(null);
        if (this.field_959_i) {
            return;
        }
        this.field_959_i = true;
        this.mc.playerController = new PlayerControllerSP(this.mc);
        this.mc.startWorld("World" + i, snowCovered, !cheatsEnabled, worldType);
        this.mc.setCurrentScreen(null);
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.field_960_h, this.width / 2, 20, 16777215);
        super.drawScreen(i, j, f);
    }
}
