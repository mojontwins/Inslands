package com.mojang.minecraft.gui;

import com.mojang.minecraft.entity.render.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.render.*;
import org.lwjgl.input.*;

public final class GuiBuild extends GuiScreen
{
    private int buildMenuTier;
    private static RenderItem itemRenderer;
    private Minecraft mc;
    
    static {
        GuiBuild.itemRenderer = new RenderItem();
    }
    
    public GuiBuild(final Minecraft minecraft, final int tier) {
        this.buildMenuTier = 0;
        this.buildMenuTier = tier;
        this.mc = minecraft;
    }
    
    private int getBlockOnScreen(final int var1, final int var2) {
        if (this.mc.playerController instanceof PlayerControllerMP) {
            return -1;
        }
        int maxInvSize = (this.buildMenuTier + 1) * 45;
        if (maxInvSize >= Session.creativeInventory.size() + Session.creativeInventoryItems.size()) {
            maxInvSize -= 45 - (Session.creativeInventory.size() + Session.creativeInventoryItems.size()) % 45;
        }
        for (int var3 = this.buildMenuTier * 45; var3 < maxInvSize; ++var3) {
            final int normalizedPos = var3 - this.buildMenuTier * 45;
            final int var4 = this.width / 2 + normalizedPos % 9 * 24 - 108 - 3;
            final int var5 = this.height / 2 + normalizedPos / 9 * 24 - 60 + 3;
            if (var1 >= var4 && var1 <= var4 + 24 && var2 >= var5 - 12 && var2 <= var5 + 12) {
                return var3;
            }
        }
        return -1;
    }
    
    @Override
    public final void drawScreen(int var1, int var2, final float f) {
        var1 = this.getBlockOnScreen(var1, var2);
        this.drawGradientRect(this.width / 2 - 120, this.height / 2 - 90, this.width / 2 + 120, this.height / 2 + 80, -1878719232, -1070583712);
        if (var1 >= 0) {
            final int normalizedPos = var1 - this.buildMenuTier * 45;
            var2 = this.width / 2 + normalizedPos % 9 * 24 - 108;
            final int var3 = this.height / 2 + normalizedPos / 9 * 24 - 60;
            this.drawGradientRect(var2 - 3, var3 - 8, var2 + 23, var3 + 24 - 6, -1862270977, -1056964609);
        }
        if (this.buildMenuTier == 0) {
            this.drawCenteredString(this.fontRenderer, "Select block", this.width / 2, this.height / 2 - 80, 16777215);
        }
        else if (this.buildMenuTier == 1) {
            this.drawCenteredString(this.fontRenderer, "Select block/item", this.width / 2, this.height / 2 - 80, 16777215);
        }
        else {
            this.drawCenteredString(this.fontRenderer, "Select item", this.width / 2, this.height / 2 - 80, 16777215);
        }
        final RenderEngine renderEngine = this.mc.renderEngine;
        int maxInvSize = (this.buildMenuTier + 1) * 45;
        if (maxInvSize >= Session.creativeInventory.size() + Session.creativeInventoryItems.size()) {
            maxInvSize -= 45 - (Session.creativeInventory.size() + Session.creativeInventoryItems.size()) % 45;
        }
        Block var4;
        Item var5;
        int normalizedPos2;
        int slotX;
        int slotY;
        for (var2 = this.buildMenuTier * 45; var2 < maxInvSize; ++var2) {
            var4 = null;
            var5 = null;
            if (var2 < Session.creativeInventory.size()) {
                var4 = Session.creativeInventory.get(var2);
            }
            else if (var2 > Session.creativeInventory.size() - 1 && var2 < Session.creativeInventory.size() + Session.creativeInventoryItems.size()) {
                var5 = Session.creativeInventoryItems.get(var2 - Session.creativeInventory.size());
            }
            normalizedPos2 = var2 - this.buildMenuTier * 45;
            slotX = this.width / 2 + normalizedPos2 % 9 * 24 - 108;
            slotY = this.height / 2 + normalizedPos2 / 9 * 24 - 60;
            GL11.glPushMatrix();
            GL11.glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
            RenderHelper.enableStandardItemLighting();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glEnable(32826);
            if (var4 != null) {
                GL11.glTranslatef(0.0f, 0.0f, 32.0f);
                GuiBuild.itemRenderer.renderItemBlock(this.fontRenderer, this.mc.renderEngine, new ItemStack(var4), slotX, slotY);
                GuiBuild.itemRenderer.renderTextDmg(this.fontRenderer, this.mc.renderEngine, new ItemStack(var4), slotX, slotY);
            }
            if (var5 != null) {
                GL11.glTranslatef(0.0f, 0.0f, 32.0f);
                GuiBuild.itemRenderer.renderItemBlock(this.fontRenderer, this.mc.renderEngine, new ItemStack(var5), slotX, slotY);
                GuiBuild.itemRenderer.renderTextDmg(this.fontRenderer, this.mc.renderEngine, new ItemStack(var5), slotX, slotY);
            }
            GL11.glDisable(32826);
            RenderHelper.disableStandardItemLighting();
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glEnable(2929);
            GL11.glPopMatrix();
        }
    }
    
    @Override
    protected final void mouseClicked(final int var1, final int var2, final int var3) {
        if (var3 == 0) {
            if (this.getBlockOnScreen(var1, var2) >= 0 && this.getBlockOnScreen(var1, var2) < 82) {
                if (Keyboard.isKeyDown(42)) {
                    this.mc.thePlayer.inventory.setCurrentItem(Session.creativeInventory.get(this.getBlockOnScreen(var1, var2)).blockID, new ItemStack(Session.creativeInventory.get(this.getBlockOnScreen(var1, var2))).getMaxStackSize(), true);
                }
                else {
                    this.mc.thePlayer.inventory.setCurrentItem(Session.creativeInventory.get(this.getBlockOnScreen(var1, var2)).blockID, 1, true);
                }
            }
            if (this.getBlockOnScreen(var1, var2) >= 82) {
                if (Keyboard.isKeyDown(42)) {
                    this.mc.thePlayer.inventory.setCurrentItem(Session.creativeInventoryItems.get(this.getBlockOnScreen(var1, var2) - Session.creativeInventory.size()).shiftedIndex, new ItemStack(Session.creativeInventoryItems.get(this.getBlockOnScreen(var1, var2) - 81)).getMaxStackSize(), true);
                }
                else {
                    this.mc.thePlayer.inventory.setCurrentItem(Session.creativeInventoryItems.get(this.getBlockOnScreen(var1, var2) - Session.creativeInventory.size()).shiftedIndex, 1, true);
                }
            }
            this.mc.setCurrentScreen(null);
            System.out.println("Block selected: " + this.getBlockOnScreen(var1, var2));
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (i == this.mc.options.keyBindBuild.keyCode && this.buildMenuTier < 4) {
            this.mc.setCurrentScreen(new GuiBuild(this.mc, this.buildMenuTier + 1));
        }
        else if (i == 1 || i == this.mc.options.keyBindInventory.keyCode) {
            this.mc.setCurrentScreen(null);
        }
        else if (i >= 1 && i < 7) {
            this.mc.setCurrentScreen(new GuiBuild(this.mc, i - 2));
        }
        else if (this.buildMenuTier >= 4 && i == this.mc.options.keyBindBuild.keyCode) {
            this.mc.setCurrentScreen(new GuiBuild(this.mc, 0));
        }
    }
}
