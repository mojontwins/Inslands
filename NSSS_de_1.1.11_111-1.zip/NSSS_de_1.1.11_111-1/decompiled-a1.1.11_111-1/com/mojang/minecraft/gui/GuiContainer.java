package com.mojang.minecraft.gui;

import com.mojang.minecraft.entity.render.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.item.*;
import org.lwjgl.input.*;
import com.mojang.minecraft.entity.*;

public abstract class GuiContainer extends GuiScreen
{
    private static RenderItem itemRenderer;
    public int xSize;
    public int ySize;
    protected Container inventorySlots;
    
    static {
        GuiContainer.itemRenderer = new RenderItem();
    }
    
    public GuiContainer(final Container container) {
        this.xSize = 176;
        this.ySize = 166;
        this.inventorySlots = container;
    }
    
    @Override
    public void initGui() {
        super.initGui();
        this.mc.thePlayer.craftingInventory = this.inventorySlots;
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        final int k = (this.width - this.xSize) / 2;
        final int l = (this.height - this.ySize) / 2;
        this.drawGuiContainerBackgroundLayer(f);
        GL11.glPushMatrix();
        GL11.glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)k, (float)l, 0.0f);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glEnable(32826);
        for (int i2 = 0; i2 < this.inventorySlots.slots.size(); ++i2) {
            final Slot slot1 = this.inventorySlots.slots.get(i2);
            this.drawSlotInventory(slot1);
            if (this.getIsMouseOverSlot(slot1, i, j)) {
                GL11.glDisable(2896);
                GL11.glDisable(2929);
                final int j2 = slot1.xDisplayPosition;
                final int k2 = slot1.yDisplayPosition;
                this.drawGradientRect(j2, k2, j2 + 16, k2 + 16, -2130706433, -2130706433);
                GL11.glEnable(2896);
                GL11.glEnable(2929);
            }
        }
        final InventoryPlayer inventoryplayer = this.mc.thePlayer.inventory;
        if (inventoryplayer.itemStack != null) {
            GL11.glTranslatef(0.0f, 0.0f, 32.0f);
            GuiContainer.itemRenderer.renderItemBlock(this.fontRenderer, this.mc.renderEngine, inventoryplayer.itemStack, i - k - 8, j - l - 8);
            GuiContainer.itemRenderer.renderTextDmg(this.fontRenderer, this.mc.renderEngine, inventoryplayer.itemStack, i - k - 8, j - l - 8);
        }
        GL11.glDisable(32826);
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(2896);
        GL11.glDisable(2929);
        this.drawGuiContainerForegroundLayer();
        GL11.glEnable(2929);
        GL11.glPopMatrix();
    }
    
    protected void drawGuiContainerForegroundLayer() {
    }
    
    protected abstract void drawGuiContainerBackgroundLayer(final float p0);
    
    private void drawSlotInventory(final Slot slot) {
        final int i = slot.xDisplayPosition;
        final int j = slot.yDisplayPosition;
        final ItemStack itemstack = slot.getStack();
        if (itemstack == null) {
            final int k = slot.getBackgroundIconIndex();
            if (k >= 0) {
                GL11.glDisable(2896);
                this.mc.renderEngine.bindTex(this.mc.renderEngine.getTex("/gui/items.png"));
                this.drawTexturedModalRect(i, j, k % 16 * 16, k / 16 * 16, 16, 16);
                GL11.glEnable(2896);
                return;
            }
        }
        GuiContainer.itemRenderer.renderItemBlock(this.fontRenderer, this.mc.renderEngine, itemstack, i, j);
        GuiContainer.itemRenderer.renderTextDmg(this.fontRenderer, this.mc.renderEngine, itemstack, i, j);
    }
    
    private Slot getSlotAtPosition(final int i, final int j) {
        for (int k = 0; k < this.inventorySlots.slots.size(); ++k) {
            final Slot slot = this.inventorySlots.slots.get(k);
            if (this.getIsMouseOverSlot(slot, i, j)) {
                return slot;
            }
        }
        return null;
    }
    
    private boolean getIsMouseOverSlot(final Slot slot, int i, int j) {
        final int k = (this.width - this.xSize) / 2;
        final int l = (this.height - this.ySize) / 2;
        i -= k;
        j -= l;
        return i >= slot.xDisplayPosition - 1 && i < slot.xDisplayPosition + 16 + 1 && j >= slot.yDisplayPosition - 1 && j < slot.yDisplayPosition + 16 + 1;
    }
    
    @Override
    protected void mouseClicked(final int i, final int j, final int k) {
        super.mouseClicked(i, j, k);
        if (k == 0 || k == 1) {
            final Slot slot = this.getSlotAtPosition(i, j);
            final int l = (this.width - this.xSize) / 2;
            final int i2 = (this.height - this.ySize) / 2;
            final boolean flag = i < l || j < i2 || i >= l + this.xSize || j >= i2 + this.ySize;
            int j2 = -1;
            if (slot != null) {
                j2 = slot.slotNumber;
            }
            if (flag) {
                j2 = -999;
            }
            if (j2 != -1) {
                final boolean flag2 = j2 != -999 && (Keyboard.isKeyDown(42) || Keyboard.isKeyDown(54));
                this.mc.playerController.func_27174_a(this.inventorySlots.windowId, j2, k, flag2, this.mc.thePlayer);
            }
        }
    }
    
    @Override
    protected void mouseMovedOrUp(final int i, final int j, final int k) {
        if (k != 0) {}
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (i == 1 || i == this.mc.options.keyBindInventory.keyCode) {
            this.mc.thePlayer.closeScreen();
        }
    }
    
    @Override
    public void onGuiClosed() {
        if (this.mc.thePlayer == null) {
            return;
        }
        this.mc.playerController.func_20086_a(this.inventorySlots.windowId, this.mc.thePlayer);
    }
    
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
