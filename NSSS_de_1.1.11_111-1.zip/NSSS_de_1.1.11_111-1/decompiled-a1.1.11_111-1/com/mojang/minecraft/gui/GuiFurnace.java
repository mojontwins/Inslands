package com.mojang.minecraft.gui;

import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.player.inventory.*;
import org.lwjgl.opengl.*;

public class GuiFurnace extends GuiContainer
{
    private TileEntityFurnace furnaceInventory;
    
    public GuiFurnace(final InventoryPlayer inventoryplayer, final TileEntityFurnace tileentityfurnace) {
        super(new ContainerFurnace(inventoryplayer, tileentityfurnace));
        this.furnaceInventory = tileentityfurnace;
    }
    
    @Override
    protected void drawGuiContainerForegroundLayer() {
        this.fontRenderer.drawString("Furnace", 60, 6, 4210752);
        this.fontRenderer.drawString("Inventory", 8, this.ySize - 96 + 2, 4210752);
    }
    
    @Override
    protected void drawGuiContainerBackgroundLayer(final float f) {
        final int i = this.mc.renderEngine.getTex("/gui/furnace.png");
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.renderEngine.bindTex(i);
        final int j = (this.width - this.xSize) / 2;
        final int k = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
        if (this.furnaceInventory.isBurning()) {
            final int l = this.furnaceInventory.getBurnTimeRemainingScaled(12);
            this.drawTexturedModalRect(j + 56, k + 36 + 12 - l, 176, 12 - l, 14, l + 2);
        }
        final int i2 = this.furnaceInventory.getCookProgressScaled(24);
        this.drawTexturedModalRect(j + 79, k + 34, 176, 14, i2 + 1, 16);
    }
}
