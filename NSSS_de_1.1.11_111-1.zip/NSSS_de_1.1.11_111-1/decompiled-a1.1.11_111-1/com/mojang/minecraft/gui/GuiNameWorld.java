package com.mojang.minecraft.gui;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.*;
import java.io.*;

public class GuiNameWorld extends GuiScreen
{
    int gameid;
    int worldType;
    boolean cheatsEnabled;
    private GuiScreen field_968_a;
    private int field_970_h;
    private String worldName;
    
    public GuiNameWorld(final GuiSelectWorld guiscreen, final int gameid) {
        this.worldType = 0;
        this.cheatsEnabled = false;
        this.field_970_h = 0;
        this.worldName = "";
        this.field_968_a = guiscreen;
        this.gameid = gameid;
    }
    
    @Override
    public void updateScreen() {
        ++this.field_970_h;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        final GuiButton button = new GuiButton(3, this.width / 2 - 100, this.height / 4 + 90, "Season: Summer");
        button.width = 99;
        this.controlList.add(button);
        final GuiButton button2 = new GuiButton(4, this.width / 2 + 2, this.height / 4 + 90, "Commands: " + this.cheatsEnabled);
        button2.width = 99;
        this.controlList.add(button2);
        final GuiButton button3 = new GuiButton(2, this.width / 2 - 100, this.height / 4 + 90 + 22, "World Type: " + World.TYPENAMES.get(this.worldType));
        button2.width = 99;
        this.controlList.add(button3);
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 96 + 44, "Create"));
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 120 + 44, "Cancel"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 4) {
            this.cheatsEnabled = !this.cheatsEnabled;
            guibutton.displayString = "Commands: " + this.cheatsEnabled;
        }
        if (guibutton.id == 3) {
            if (guibutton.displayString.equalsIgnoreCase("Season: Summer")) {
                guibutton.displayString = "Season: Winter";
            }
            else {
                guibutton.displayString = "Season: Summer";
            }
        }
        if (guibutton.id == 5) {
            guibutton.displayString = "BigTree Percentage: ";
        }
        if (guibutton.id == 2) {
            ++this.worldType;
            if (this.worldType > World.TYPENAMES.size() - 1) {
                this.worldType = 0;
            }
            guibutton.displayString = "World Type: " + World.TYPENAMES.get(this.worldType);
        }
        if (guibutton.id == 1) {
            this.mc.setCurrentScreen(this.field_968_a);
        }
        else if (guibutton.id == 0) {
            ((GuiSelectWorld)this.field_968_a).func_584_c(this.gameid, this.controlList.get(0).displayString.equalsIgnoreCase("Season: Winter"), this.cheatsEnabled, this.worldType);
            final String as = this.worldName;
            if (as.trim().length() > 0) {
                final File file = Minecraft.getMinecraftDir();
                final File f = new File(file, "NSSSsaves/World" + this.gameid + "/name.data");
                try {
                    f.createNewFile();
                    final BufferedWriter writer = new BufferedWriter(new FileWriter(f));
                    writer.write(as);
                    writer.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (c == '\u0016') {
            String s = GuiScreen.getClipboardString();
            if (s == null) {
                s = "";
            }
            int j = 32 - this.worldName.length();
            if (j > s.length()) {
                j = s.length();
            }
            if (j > 0) {
                this.worldName = String.valueOf(this.worldName) + s.substring(0, j);
            }
        }
        if (c == '\r') {
            this.actionPerformed(this.controlList.get(3));
        }
        if (i == 14 && this.worldName.length() > 0) {
            this.worldName = this.worldName.substring(0, this.worldName.length() - 1);
        }
        if (ChatAllowedCharacters.allowedCharacters.indexOf(c) >= 0 && this.worldName.length() < 20) {
            this.worldName = String.valueOf(this.worldName) + c;
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, "Setup World", this.width / 2, this.height / 4 - 60 + 20, 16777215);
        this.drawString(this.fontRenderer, "Enter the name of your world and choose a mode.", this.width / 2 - 140, this.height / 4 - 60 + 60 + 0, 10526880);
        this.drawString(this.fontRenderer, "Leaving name empty will set a default name.", this.width / 2 - 140, this.height / 4 - 60 + 60 + 9, 10526880);
        this.drawString(this.fontRenderer, "<In Development!>", this.width / 2 - 140, this.height / 4 - 60 + 60 + 36, 10526880);
        final int k = this.width / 2 - 100;
        final int l = this.height / 4 - 10 + 50 + 18;
        final char c = '\u00c8';
        final byte byte0 = 20;
        this.drawRect(k - 1, l - 1, k + c + 1, l + byte0 + 1, -6250336);
        this.drawRect(k, l, k + c, l + byte0, -16777216);
        this.drawString(this.fontRenderer, this.worldName + ((this.field_970_h / 6 % 2 != 0) ? "" : "_"), k + 4, l + (byte0 - 8) / 2, 14737632);
        super.drawScreen(i, j, f);
    }
}
