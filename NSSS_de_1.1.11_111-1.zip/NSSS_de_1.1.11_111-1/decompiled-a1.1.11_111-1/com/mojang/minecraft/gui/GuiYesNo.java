package com.mojang.minecraft.gui;

public class GuiYesNo extends GuiScreen
{
    private GuiScreen field_961_a;
    private String field_964_h;
    private String field_963_i;
    private int field_962_j;
    
    public GuiYesNo(final GuiScreen guiscreen, final String s, final String s1, final int i) {
        this.field_961_a = guiscreen;
        this.field_964_h = s;
        this.field_963_i = s1;
        this.field_962_j = i;
    }
    
    @Override
    public void initGui() {
        this.controlList.add(new GuiSmallButton(0, this.width / 2 - 155 + 0, this.height / 6 + 96, "Yes"));
        this.controlList.add(new GuiSmallButton(1, this.width / 2 - 155 + 160, this.height / 6 + 96, "No"));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        this.field_961_a.func_568_a(guibutton.id == 0, this.field_962_j);
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.field_964_h, this.width / 2, 70, 16777215);
        this.drawCenteredString(this.fontRenderer, this.field_963_i, this.width / 2, 90, 16777215);
        super.drawScreen(i, j, f);
    }
}
