package com.mojang.minecraft.gui;

import org.lwjgl.input.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.networknew.*;

public class GuiIngameMenu extends GuiScreen
{
    private int field_966_a;
    private int field_967_h;
    
    public GuiIngameMenu() {
        this.field_966_a = 0;
        this.field_967_h = 0;
    }
    
    @Override
    public void initGui() {
        this.field_966_a = 0;
        this.controlList.clear();
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 48, "Save and quit to title"));
        if (this.mc.isServer()) {
            this.controlList.get(0).displayString = "Disconnect";
        }
        this.controlList.add(new GuiButton(4, this.width / 2 - 100, this.height / 4 + 24, "Back to game"));
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 96, "Options..."));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton instanceof GuiListBox) {
            final int i = Mouse.getEventX() * this.width / this.mc.displayWidth;
            final int j = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
            final int index = ((GuiListBox)guibutton).getOption(i, j);
            System.out.print(index);
            ((GuiListBox)guibutton).index = index;
            ((GuiListBox)guibutton).shrink();
        }
        if (guibutton.id == 0) {
            this.mc.setCurrentScreen(new GuiOptions(this, this.mc.options));
        }
        if (guibutton.id == 1) {
            if (this.mc.isServer()) {
                this.mc.mcWorld.sendQuittingDisconnectingPacket();
            }
            this.mc.changeWorld1(null);
            this.mc.setCurrentScreen(new GuiMainMenu());
        }
        if (guibutton.id == 4) {
            this.mc.setCurrentScreen(null);
            this.mc.setIngameFocus();
        }
    }
    
    @Override
    public void updateScreen() {
        super.updateScreen();
        ++this.field_967_h;
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        final boolean flag = !this.mc.mcWorld.func_650_a(this.field_966_a++);
        if (flag || this.field_967_h < 20) {
            float f2 = (this.field_967_h % 10 + f) / 10.0f;
            f2 = MathHelper.sin(f2 * 3.141593f * 2.0f) * 0.2f + 0.8f;
            final int k = (int)(255.0f * f2);
            this.drawString(this.fontRenderer, "Saving level..", 8, this.height - 16, k << 16 | k << 8 | k);
        }
        this.drawCenteredString(this.fontRenderer, "Game menu", this.width / 2, 40, 16777215);
        if (!this.mc.mcWorld.multiplayerWorld) {
            this.drawCenteredString(this.fontRenderer, "Score: �e" + this.mc.thePlayer.getScore(), this.width / 2, 60, 16777215);
        }
        else {
            this.drawCenteredString(this.fontRenderer, "Score: �e" + this.mc.getSendQueue().players.get(this.mc.getSendQueue().getIndexInPlayerList(this.mc.thePlayer.playerName)).playerScore, this.width / 2, 60, 16777215);
        }
        super.drawScreen(i, j, f);
    }
}
