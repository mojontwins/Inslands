package com.mojang.minecraft.gui;

import java.io.*;
import com.mojang.minecraft.*;
import java.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.util.*;
import org.lwjgl.util.glu.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.tile.*;

public class GuiMainMenu extends GuiScreen
{
    private static final Random rand;
    String[] logo;
    String[] minceraft;
    private LogoEffectRandomizer[][] field_990_i;
    private String splashString;
    public static boolean warningShown;
    
    static {
        rand = new Random();
        GuiMainMenu.warningShown = false;
    }
    
    public GuiMainMenu() {
        this.logo = new String[] { " *   * * *   * *** *** *** *** *** ***", " ** ** * **  * *   *   * * * * *    * ", " * * * * * * * **  *   **  *** **   * ", " *   * * *  ** *   *   * * * * *    * ", " *   * * *   * *** *** * * * * *    * " };
        this.minceraft = new String[] { " *   * * *   * *** *** *** *** *** ***", " ** ** * **  * *   *   * * * * *    * ", " * * * * * * * *   **  **  *** **   * ", " *   * * *  ** *   *   * * * * *    * ", " *   * * *   * *** *** * * * * *    * " };
        this.splashString = "missingno";
        try {
            final ArrayList<String> arraylist = new ArrayList<String>();
            final BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(GuiMainMenu.class.getResourceAsStream("/title/splashes.txt")));
            String s1;
            while ((s1 = bufferedreader.readLine()) != null) {
                s1 = s1.trim();
                if (s1.length() > 0) {
                    arraylist.add(s1);
                }
            }
            this.splashString = arraylist.get(GuiMainMenu.rand.nextInt(arraylist.size()));
        }
        catch (Exception ex) {}
    }
    
    @Override
    public void updateScreen() {
        if (this.field_990_i != null) {
            for (int i = 0; i < this.field_990_i.length; ++i) {
                for (int j = 0; j < this.field_990_i[i].length; ++j) {
                    this.field_990_i[i][j].func_875_a();
                }
            }
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
    
    public static int getVersion() {
        String version = System.getProperty("java.version");
        if (version.startsWith("1.")) {
            version = version.substring(2, 3);
        }
        else {
            final int dot = version.indexOf(".");
            if (dot != -1) {
                version = version.substring(0, dot);
            }
        }
        return Integer.parseInt(version);
    }
    
    @Override
    public void initGui() {
        if (!this.mc.hasChimed) {
            this.mc.soundMGR.playSoundFX(Minecraft.chime, 1.0f, 1.0f);
            this.mc.hasChimed = true;
        }
        if (!this.mc.options.ignoreJavaWarning && getVersion() > 8 && !GuiMainMenu.warningShown) {
            this.mc.setCurrentScreen(new GuiWrongJava(this));
        }
        GuiMainMenu.warningShown = true;
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        if (calendar.get(2) + 1 == 11 && calendar.get(5) == 9) {
            this.splashString = "Happy birthday, ez!";
        }
        else if (calendar.get(2) + 1 == 6 && calendar.get(5) == 1) {
            this.splashString = "Happy birthday, Noptch!";
        }
        else if (calendar.get(2) + 1 == 12 && calendar.get(5) == 24) {
            this.splashString = "Merry X-mas!";
        }
        else if (calendar.get(2) + 1 == 1 && calendar.get(5) == 1) {
            this.splashString = "Happy new year!";
        }
        this.controlList.clear();
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 48, "Singleplayer"));
        this.controlList.add(new GuiButton(2, this.width / 2 - 100, this.height / 4 + 72, "Multiplayer"));
        this.controlList.add(new GuiButton(3, this.width / 2 - 100, this.height / 4 + 96, "Play tutorial level"));
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, "Options..."));
        this.controlList.get(2).enabled = false;
        if (this.mc.session == null) {
            this.controlList.get(1).enabled = false;
        }
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton.id == 0) {
            this.mc.setCurrentScreen(new GuiOptions(this, this.mc.options));
        }
        if (guibutton.id == 1) {
            this.mc.setCurrentScreen(new GuiSelectWorld(this));
        }
        if (guibutton.id == 2) {
            this.mc.setCurrentScreen(new GuiSelectServer(this));
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        final Tessellator tessellator = Tessellator.instance;
        this.func_591_a(f);
        GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/gui/logo.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        tessellator.setColorOpaque_I(16777215);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(this.width / 2 + 90), 70.0f, 0.0f);
        GL11.glRotatef(-20.0f, 0.0f, 0.0f, 1.0f);
        float f2 = 1.8f - MathHelper.func_1112_e(MathHelper.sin(System.currentTimeMillis() % 1000L / 1000.0f * 3.141593f * 2.0f) * 0.1f);
        f2 = f2 * 100.0f / (this.fontRenderer.getStringWidth(this.splashString) + 32);
        GL11.glScalef(f2, f2, f2);
        this.drawCenteredString(this.fontRenderer, this.splashString, 0, -8, 16776960);
        GL11.glPopMatrix();
        String s = "Copyright Mojang Specifications. Do not distribute.";
        this.drawString(this.fontRenderer, s, this.width - this.fontRenderer.getStringWidth(s) - 2, this.height - 10, 16777215);
        final long l = Runtime.getRuntime().maxMemory();
        final long l2 = Runtime.getRuntime().totalMemory();
        final long l3 = Runtime.getRuntime().freeMemory();
        final long l4 = l - l3;
        s = "Free memory: " + l4 * 100L / l + "% of " + l / 1024L / 1024L + "MB";
        this.drawString(this.fontRenderer, s, this.width - this.fontRenderer.getStringWidth(s) - 2, 2, 8421504);
        s = "Allocated memory: " + l2 * 100L / l + "% (" + l2 / 1024L / 1024L + "MB)";
        this.drawString(this.fontRenderer, s, this.width - this.fontRenderer.getStringWidth(s) - 2, 12, 8421504);
        super.drawScreen(i, j, f);
    }
    
    private void func_591_a(final float f) {
        if (this.field_990_i == null) {
            this.field_990_i = new LogoEffectRandomizer[this.logo[0].length()][this.logo.length];
            for (int i = 0; i < this.field_990_i.length; ++i) {
                for (int j = 0; j < this.field_990_i[i].length; ++j) {
                    this.field_990_i[i][j] = new LogoEffectRandomizer(this, i, j);
                }
            }
        }
        GL11.glMatrixMode(5889);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        final ScaledResolution scaledresolution = new ScaledResolution(this.mc.displayWidth, this.mc.displayHeight, this.mc);
        final int k = 120 * scaledresolution.scaleFactor;
        GLU.gluPerspective(70.0f, this.mc.displayWidth / (float)k, 0.05f, 100.0f);
        GL11.glViewport(0, this.mc.displayHeight - k, this.mc.displayWidth, k);
        GL11.glMatrixMode(5888);
        GL11.glPushMatrix();
        GL11.glLoadIdentity();
        GL11.glDisable(2884);
        GL11.glCullFace(1029);
        GL11.glDepthMask(true);
        for (int l = 0; l < 3; ++l) {
            GL11.glPushMatrix();
            GL11.glTranslatef(0.4f, 0.6f, -12.0f);
            if (l == 0) {
                GL11.glClear(256);
                GL11.glTranslatef(0.0f, -0.4f, 0.0f);
                GL11.glScalef(0.98f, 1.0f, 1.0f);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
            }
            if (l == 1) {
                GL11.glDisable(3042);
                GL11.glClear(256);
            }
            if (l == 2) {
                GL11.glEnable(3042);
                GL11.glBlendFunc(768, 1);
            }
            GL11.glScalef(1.0f, -1.0f, 1.0f);
            GL11.glRotatef(15.0f, 1.0f, 0.0f, 0.0f);
            GL11.glScalef(0.89f, 1.0f, 0.4f);
            GL11.glTranslatef(-this.logo[0].length() * 0.5f, -this.logo.length * 0.5f, 0.0f);
            GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/terrain.png"));
            if (l == 0) {
                GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/title/black.png"));
            }
            final RenderBlocks renderblocks = new RenderBlocks();
            for (int i2 = 0; i2 < this.logo.length; ++i2) {
                for (int j2 = 0; j2 < this.logo[i2].length(); ++j2) {
                    final char c = this.logo[i2].charAt(j2);
                    if (c != ' ') {
                        GL11.glPushMatrix();
                        final LogoEffectRandomizer logoeffectrandomizer = this.field_990_i[j2][i2];
                        float f2 = (float)(logoeffectrandomizer.field_1311_b + (logoeffectrandomizer.field_1312_a - logoeffectrandomizer.field_1311_b) * f);
                        float f3 = 1.0f;
                        float f4 = 1.0f;
                        final float f5 = 0.0f;
                        if (l == 0) {
                            f3 = f2 * 0.04f + 1.0f;
                            f4 = 1.0f / f3;
                            f2 = 0.0f;
                        }
                        GL11.glTranslatef((float)j2, (float)i2, f2);
                        GL11.glScalef(f3, f3, f3);
                        GL11.glRotatef(f5, 0.0f, 1.0f, 0.0f);
                        renderblocks.renderMenuItems(Block.ice, f4);
                        GL11.glPopMatrix();
                    }
                }
            }
            GL11.glPopMatrix();
        }
        GL11.glDisable(3042);
        GL11.glMatrixMode(5889);
        GL11.glPopMatrix();
        GL11.glMatrixMode(5888);
        GL11.glPopMatrix();
        GL11.glViewport(0, 0, this.mc.displayWidth, this.mc.displayHeight);
        GL11.glEnable(2884);
    }
    
    static Random func_592_j() {
        return GuiMainMenu.rand;
    }
}
