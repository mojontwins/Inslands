package com.mojang.minecraft.gui;

import javax.imageio.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;

class MajongLogoCanvas extends Canvas
{
    private static final long serialVersionUID = 1L;
    private BufferedImage splashImage;
    
    public MajongLogoCanvas() {
        try {
            this.splashImage = ImageIO.read(GuiCrashReport.class.getResource("/gui/logo.png"));
        }
        catch (IOException ex) {}
        final byte byte0 = 100;
        this.setPreferredSize(new Dimension(byte0, byte0));
        this.setMinimumSize(new Dimension(byte0, byte0));
    }
    
    @Override
    public void paint(final Graphics g) {
        super.paint(g);
        g.drawImage(this.splashImage, this.getWidth() / 2 - this.splashImage.getWidth() / 2, 32, null);
    }
}
