package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import org.lwjgl.opengl.*;

public class GuiSlider extends GuiButton
{
    public float value;
    public boolean dragging;
    private int idFloat;
    
    public GuiSlider(final int id, final int x, final int y, final int sliderID, final String string, final float setValue) {
        super(id, x, y, 150, 20, string);
        this.value = 1.0f;
        this.dragging = false;
        this.idFloat = 0;
        this.idFloat = sliderID;
        this.value = setValue;
    }
    
    @Override
    protected int func_558_a(final boolean flag) {
        return 0;
    }
    
    @Override
    protected void func_560_b(final Minecraft minecraft, final int i, final int j) {
        if (!this.enabled2) {
            return;
        }
        if (this.dragging) {
            this.value = (i - (this.xPosition + 4)) / (float)(this.width - 8);
            if (this.value < 0.0f) {
                this.value = 0.0f;
            }
            if (this.value > 1.0f) {
                this.value = 1.0f;
            }
            minecraft.options.saveSliderValue(this.idFloat, this.value);
            this.displayString = minecraft.options.getOptionValue(this.idFloat);
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.drawTexturedModalRect(this.xPosition + (int)(this.value * (this.width - 8)), this.yPosition, 0, 66, 4, 20);
        this.drawTexturedModalRect(this.xPosition + (int)(this.value * (this.width - 8)) + 4, this.yPosition, 196, 66, 4, 20);
    }
    
    @Override
    public boolean func_562_c(final Minecraft minecraft, final int i, final int j) {
        if (super.func_562_c(minecraft, i, j)) {
            this.value = (i - (this.xPosition + 4)) / (float)(this.width - 8);
            if (this.value < 0.0f) {
                this.value = 0.0f;
            }
            if (this.value > 1.0f) {
                this.value = 1.0f;
            }
            minecraft.options.saveSliderValue(this.idFloat, this.value);
            this.displayString = minecraft.options.getOptionValue(this.idFloat);
            return this.dragging = true;
        }
        return false;
    }
    
    @Override
    public void func_559_a(final int i, final int j) {
        this.dragging = false;
    }
}
