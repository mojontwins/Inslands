package com.mojang.minecraft.gui;

public class GuiWrongJava extends GuiScreen
{
    private GuiScreen prevScreen;
    private int updateCounter;
    
    public GuiWrongJava(final GuiScreen prev) {
        this.prevScreen = prev;
        this.updateCounter = 0;
    }
    
    @Override
    public void updateScreen() {
        ++this.updateCounter;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120 + 12, "Ok"));
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 100 + 12, 20, 20, ""));
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 0) {
            this.mc.setCurrentScreen(this.prevScreen);
        }
        if (guibutton.id == 1) {
            this.mc.options.ignoreJavaWarning = !this.mc.options.ignoreJavaWarning;
            guibutton.displayString = (this.mc.options.ignoreJavaWarning ? "�aX" : "");
            this.mc.options.save();
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, "Unsupported Java version detected!", this.width / 2, this.height / 4 - 60 + 20, 16777215);
        this.drawCenteredString(this.fontRenderer, "Don't show me this again", this.width / 2, this.height / 4 + 105 + 12, 16777215);
        this.drawCenteredString(this.fontRenderer, "The version of Java you are using is not supported.", this.width / 2, this.height / 4 - 60 + 60 + 12, 10526880);
        this.drawCenteredString(this.fontRenderer, "NSSS is only supported up to Java 8, you are running Java " + GuiMainMenu.getVersion() + ".", this.width / 2, this.height / 4 - 60 + 60 + 24, 10526880);
        this.drawCenteredString(this.fontRenderer, "You may experience bugs. Keep in mind bug reports under ", this.width / 2, this.height / 4 - 60 + 60 + 36, 10526880);
        this.drawCenteredString(this.fontRenderer, "unsupported Java versions may be dismissed!", this.width / 2, this.height / 4 - 60 + 60 + 48, 10526880);
        super.drawScreen(i, j, f);
    }
}
