package com.mojang.minecraft.gui;

import java.awt.*;

public class CrashCanvas extends Canvas
{
    private static final long serialVersionUID = 1L;
    
    public CrashCanvas(final int i) {
        this.setPreferredSize(new Dimension(i, i));
        this.setMinimumSize(new Dimension(i, i));
    }
}
