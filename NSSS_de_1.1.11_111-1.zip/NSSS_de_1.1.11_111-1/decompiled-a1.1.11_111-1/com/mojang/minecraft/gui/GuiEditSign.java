package com.mojang.minecraft.gui;

import org.lwjgl.input.*;
import com.mojang.minecraft.networknew.packet.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.tile.*;

public class GuiEditSign extends GuiScreen
{
    protected String field_999_a;
    private TileEntitySign entitySign;
    private int updateCounter;
    private int editLine;
    
    public GuiEditSign(final TileEntitySign tileentitysign) {
        this.field_999_a = "Edit sign message:";
        this.editLine = 0;
        this.entitySign = tileentitysign;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        Keyboard.enableRepeatEvents(true);
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 2 + 60, "Done"));
    }
    
    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        if (this.mc.mcWorld.multiplayerWorld) {
            this.mc.getSendQueue().addToSendQueue(new Packet130UpdateSign(this.entitySign.x, this.entitySign.y, this.entitySign.z, this.entitySign.signText));
        }
    }
    
    @Override
    public void updateScreen() {
        ++this.updateCounter;
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 0) {
            this.entitySign.onInventoryChanged();
            this.mc.setCurrentScreen(null);
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        if (i == 200) {
            this.editLine = (this.editLine - 1 & 0x3);
        }
        if (i == 208 || i == 28) {
            this.editLine = (this.editLine + 1 & 0x3);
        }
        if (c == '\u0016') {
            String s = GuiScreen.getClipboardString();
            if (s == null) {
                s = "";
            }
            int j = 15 - this.entitySign.signText[this.editLine].length();
            if (j > s.length()) {
                j = s.length();
            }
            if (j > 0) {
                final String[] signText = this.entitySign.signText;
                final int editLine = this.editLine;
                signText[editLine] = String.valueOf(signText[editLine]) + s.substring(0, j);
                for (int line = this.editLine + 1; line < 4; ++line) {
                    if (s.length() - 1 > j && s.substring(j).length() >= 15) {
                        final String[] signText2 = this.entitySign.signText;
                        final int n = line;
                        signText2[n] = String.valueOf(signText2[n]) + s.substring(j, j + 15);
                        this.editLine = line;
                    }
                    else if (s.length() - 1 > j && s.substring(j).length() - 1 < 15) {
                        final String[] signText3 = this.entitySign.signText;
                        final int n2 = line;
                        signText3[n2] = String.valueOf(signText3[n2]) + s.substring(j);
                        this.editLine = line;
                    }
                    j += 15;
                }
            }
        }
        if (i == 14 && this.entitySign.signText[this.editLine].length() > 0) {
            this.entitySign.signText[this.editLine] = this.entitySign.signText[this.editLine].substring(0, this.entitySign.signText[this.editLine].length() - 1);
        }
        if (ChatAllowedCharacters.allowedCharacters.indexOf(c) >= 0 && this.entitySign.signText[this.editLine].length() < 15) {
            final String[] signText4 = this.entitySign.signText;
            final int editLine2 = this.editLine;
            signText4[editLine2] = String.valueOf(signText4[editLine2]) + c;
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        try {
            this.drawDefaultBackground();
            this.drawCenteredString(this.fontRenderer, this.field_999_a, this.width / 2, this.height / 2 - 75, 16777215);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(this.width / 2), (float)(this.height / 2), 50.0f);
            final float f2 = 93.75f;
            GL11.glScalef(-f2, -f2, -f2);
            GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
            final Block block = this.entitySign.func_478_g();
            if (block == Block.signPost) {
                final float f3 = this.entitySign.func_479_f() * 360 / 16.0f;
                GL11.glRotatef(f3, 0.0f, 1.0f, 0.0f);
            }
            else {
                final int k = this.entitySign.func_479_f();
                float f4 = 0.0f;
                if (k == 2) {
                    f4 = 180.0f;
                }
                if (k == 4) {
                    f4 = 90.0f;
                }
                if (k == 5) {
                    f4 = -90.0f;
                }
                GL11.glRotatef(f4, 0.0f, 1.0f, 0.0f);
                GL11.glTranslatef(0.0f, 0.3125f, 0.0f);
            }
            if (this.updateCounter / 6 % 2 == 0) {
                this.entitySign.lineBeingEdited = this.editLine;
            }
            TileEntityRenderer.instance.renderTileEntityAt(this.entitySign, -0.5, -0.75, -0.5, 0.0f);
            this.entitySign.lineBeingEdited = -1;
            GL11.glPopMatrix();
            super.drawScreen(i, j, f);
        }
        catch (NullPointerException ex) {
            this.mc.setCurrentScreen(null);
        }
    }
}
