package com.mojang.minecraft.gui;

import com.mojang.minecraft.player.inventory.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class GuiInventoryBad extends GuiContainer
{
    private CraftingInventoryPlayerCB field_977_j;
    private float xSize_lo;
    private float ySize_lo;
    public boolean walking;
    
    public GuiInventoryBad(final EntityPlayer entityplayer) {
        super(entityplayer.inventorySlots);
        this.walking = true;
        this.field_948_f = true;
    }
    
    @Override
    protected void drawGuiContainerForegroundLayer() {
        this.fontRenderer.drawString("Crafting", 86, 16, 4210752);
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        super.drawScreen(i, j, f);
        this.xSize_lo = (float)i;
        this.ySize_lo = (float)j;
    }
    
    @Override
    protected void drawGuiContainerBackgroundLayer(final float f) {
        final int i = this.mc.renderEngine.getTex("/gui/inventory.png");
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.mc.renderEngine.bindTex(i);
        final int j = (this.width - this.xSize) / 2;
        final int k = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(j, k, 0, 0, this.xSize, this.ySize);
        GL11.glEnable(32826);
        GL11.glEnable(2903);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(j + 51), (float)(k + 75), 50.0f);
        final float f2 = 30.0f;
        GL11.glScalef(-f2, f2, f2);
        GL11.glRotatef(180.0f, 0.0f, 0.0f, 1.0f);
        final float f3 = this.mc.thePlayer.renderYawOffset;
        final float f4 = this.mc.thePlayer.rotationYaw;
        final float f5 = this.mc.thePlayer.rotationPitch;
        final float f6 = j + 51 - this.xSize_lo;
        final float f7 = k + 75 - 50 - this.ySize_lo;
        GL11.glRotatef(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GL11.glRotatef(-135.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-(float)Math.atan(f7 / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        this.mc.thePlayer.renderYawOffset = (float)Math.atan(f6 / 40.0f) * 20.0f;
        this.mc.thePlayer.rotationYaw = (float)Math.atan(f6 / 40.0f) * 40.0f;
        this.mc.thePlayer.rotationPitch = -(float)Math.atan(f7 / 40.0f) * 20.0f;
        GL11.glTranslatef(0.0f, this.mc.thePlayer.yOffset, 0.0f);
        RenderManager.subManager.renderEntityWithPosYaw(this.mc.thePlayer, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        this.mc.thePlayer.renderYawOffset = f3;
        this.mc.thePlayer.rotationYaw = f4;
        this.mc.thePlayer.rotationPitch = f5;
        GL11.glPopMatrix();
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(32826);
    }
    
    @Override
    public void handleKeyboardInput() {
        super.handleKeyboardInput();
    }
}
