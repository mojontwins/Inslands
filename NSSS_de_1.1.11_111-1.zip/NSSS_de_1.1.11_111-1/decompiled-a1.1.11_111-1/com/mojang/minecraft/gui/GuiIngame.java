package com.mojang.minecraft.gui;

import com.mojang.minecraft.entity.render.*;
import com.mojang.minecraft.*;
import java.text.*;
import java.util.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.material.*;
import java.awt.*;
import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.item.*;

public class GuiIngame extends Gui
{
    NumberFormat format;
    private static RenderItem itemRenderer;
    private List<ChatLine> chatList;
    private Random shakinessRandom;
    private Minecraft mc;
    public String hoveredPlayer;
    private int field_926_h;
    private String field_925_i;
    private int field_924_j;
    public float field_932_b;
    float prevVignetteBrightness;
    int prevStarIntensity;
    public static boolean debugOpen;
    public boolean showHud;
    int debugWait;
    int hudWait;
    
    static {
        GuiIngame.itemRenderer = new RenderItem();
        GuiIngame.debugOpen = false;
    }
    
    public GuiIngame(final Minecraft minecraft) {
        this.format = new DecimalFormat("#0.000");
        this.showHud = true;
        this.debugWait = 0;
        this.hudWait = 0;
        this.chatList = new ArrayList<ChatLine>();
        this.shakinessRandom = new Random();
        this.hoveredPlayer = null;
        this.field_926_h = 0;
        this.field_925_i = "";
        this.field_924_j = 0;
        this.prevVignetteBrightness = 1.0f;
        this.prevStarIntensity = 0;
        this.mc = minecraft;
    }
    
    public void renderGameOverlay(final float f, final boolean flag, final int u, final int v) {
        if (Keyboard.isKeyDown(61)) {
            if (this.debugWait >= 2) {
                GuiIngame.debugOpen = !GuiIngame.debugOpen;
                this.debugWait = 0;
            }
        }
        else if (this.debugWait <= 2) {
            ++this.debugWait;
        }
        if (Keyboard.isKeyDown(59)) {
            if (this.hudWait >= 2) {
                this.showHud = !this.showHud;
                this.hudWait = 0;
            }
        }
        else if (this.hudWait <= 2) {
            ++this.hudWait;
        }
        if (!this.showHud && this.mc.currentScreen == null) {
            return;
        }
        final ScaledResolution scaledresolution = new ScaledResolution(this.mc.displayWidth, this.mc.displayHeight, this.mc);
        final int scaledWidth = scaledresolution.getScaledWidth();
        final int scaledHeight = scaledresolution.getScaledHeight();
        final FontRenderer fontrenderer = this.mc.fontRender;
        this.mc.entityRenderer.func_905_b();
        GL11.glEnable(3042);
        if (this.mc.options.vignette) {
            this.renderVignette((float)(this.mc.thePlayer.getEntityBrightness(f) - this.mc.thePlayer.getExhaustion()), scaledWidth, scaledHeight);
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        if (Minecraft.isIRIX) {
            GL11.glColor4f(1.0f, 0.65f, 0.65f, 1.0f);
        }
        GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/gui/gui.png"));
        final InventoryPlayer inventoryplayer = this.mc.thePlayer.inventory;
        this.zLevel = -90.0f;
        this.drawTexturedModalRect(scaledWidth / 2 - 91, scaledHeight - 22, 0, 0, 182, 22);
        this.drawTexturedModalRect(scaledWidth / 2 - 91 - 1 + inventoryplayer.currentItem * 20, scaledHeight - 22 - 1, 0, 22, 24, 22);
        GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/gui/icons.png"));
        GL11.glEnable(3042);
        if (!Minecraft.isIRIX) {
            GL11.glBlendFunc(775, 769);
        }
        this.drawTexturedModalRect(scaledWidth / 2 - 7, scaledHeight / 2 - 7, 0, 0, 16, 16);
        GL11.glDisable(3042);
        boolean isHalfHeart = this.mc.thePlayer.heartsLife / 3 % 2 == 1;
        if (this.mc.thePlayer.heartsLife < 10) {
            isHalfHeart = false;
        }
        final int health = this.mc.thePlayer.health;
        final int prevhealth = this.mc.thePlayer.prevHealth;
        final double exhaustion = this.mc.thePlayer.getExhaustion();
        this.shakinessRandom.setSeed(this.field_926_h * 312871);
        if (this.mc.playerController.isVulnerable()) {
            final int armorValue = this.mc.thePlayer.getPlayerArmorValue();
            for (int armorIterator = 0; armorIterator < 10; ++armorIterator) {
                int armorHeight = scaledHeight - 32;
                if (armorValue > 0) {
                    final int armorWidth = scaledWidth / 2 + 91 - armorIterator * 8 - 9;
                    if (armorIterator * 2 + 1 < armorValue) {
                        this.drawTexturedModalRect(armorWidth, armorHeight, 34, 9, 9, 9);
                    }
                    if (armorIterator * 2 + 1 == armorValue) {
                        this.drawTexturedModalRect(armorWidth, armorHeight, 25, 9, 9, 9);
                    }
                    if (armorIterator * 2 + 1 > armorValue) {
                        this.drawTexturedModalRect(armorWidth, armorHeight, 16, 9, 9, 9);
                    }
                }
                int heartHalver = 0;
                if (isHalfHeart) {
                    heartHalver = 1;
                }
                final int exhaustionWidth;
                final int heartWidth = exhaustionWidth = scaledWidth / 2 - 91 + armorIterator * 8;
                final int blexaustion = (int)(exhaustion * 20.0);
                if (health <= 4 || exhaustion > 0.8 || this.mc.thePlayer.getIsExhausted()) {
                    armorHeight += this.shakinessRandom.nextInt(2);
                }
                this.drawTexturedModalRect(heartWidth, armorHeight, 16 + heartHalver * 9, 0, 9, 9);
                if (isHalfHeart) {
                    if (armorIterator * 2 + 1 < prevhealth) {
                        this.drawTexturedModalRect(heartWidth, armorHeight, 70, 0, 9, 9);
                    }
                    if (armorIterator * 2 + 1 == prevhealth) {
                        this.drawTexturedModalRect(heartWidth, armorHeight, 79, 0, 9, 9);
                    }
                }
                if (armorIterator * 2 + 1 < health) {
                    this.drawTexturedModalRect(heartWidth, armorHeight, 52, 0, 9, 9);
                }
                if (armorIterator * 2 + 1 == health) {
                    this.drawTexturedModalRect(heartWidth, armorHeight, 61, 0, 9, 9);
                }
                if (armorIterator * 2 + 1 > 20 - blexaustion) {
                    if (armorIterator * 2 + 1 < health) {
                        this.drawTexturedModalRect(heartWidth, armorHeight, 97, 0, 9, 9);
                    }
                    else if (armorIterator * 2 + 1 <= health) {
                        this.drawTexturedModalRect(heartWidth, armorHeight, 106, 0, 9, 9);
                    }
                }
                if (armorIterator * 2 + 1 == 20 - blexaustion && armorIterator * 2 + 1 < health) {
                    this.drawTexturedModalRect(heartWidth, armorHeight, 88, 0, 9, 9);
                }
            }
            if (this.mc.thePlayer.isInsideOfMaterial(Material.water)) {
                for (int maxAirBubbles = (int)Math.ceil((this.mc.thePlayer.air - 2) * 10.0 / 300.0), poppingBubble = (int)Math.ceil(this.mc.thePlayer.air * 10.0 / 300.0) - maxAirBubbles, airIterator = 0; airIterator < maxAirBubbles + poppingBubble; ++airIterator) {
                    if (airIterator < maxAirBubbles) {
                        this.drawTexturedModalRect(scaledWidth / 2 - 91 + airIterator * 8, scaledHeight - 32 - 9, 16, 18, 9, 9);
                    }
                    else {
                        this.drawTexturedModalRect(scaledWidth / 2 - 91 + airIterator * 8, scaledHeight - 32 - 9, 25, 18, 9, 9);
                    }
                }
            }
        }
        GL11.glDisable(3042);
        GL11.glEnable(32826);
        GL11.glPushMatrix();
        GL11.glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GL11.glPopMatrix();
        for (int l1 = 0; l1 < 9; ++l1) {
            final int k2 = scaledWidth / 2 - 90 + l1 * 20 + 2;
            final int l2 = scaledHeight - 16 - 3;
            this.func_554_a(l1, k2, l2, f);
        }
        RenderHelper.disableStandardItemLighting();
        GL11.glDisable(32826);
        if (GuiIngame.debugOpen) {
            fontrenderer.drawStringWithShadow(Minecraft.version + " (" + this.mc.debug + ")", 2, 2, 16777215);
            fontrenderer.drawStringWithShadow("Level seed: " + this.mc.thePlayer.worldObj.randomSeed, 2, 52, 16777215);
            fontrenderer.drawStringWithShadow("X: " + this.format.format(this.mc.thePlayer.posX), 2, 62, 16777215);
            fontrenderer.drawStringWithShadow("Y: " + this.format.format(this.mc.thePlayer.posY), 2, 72, 16777215);
            fontrenderer.drawStringWithShadow("Z: " + this.format.format(this.mc.thePlayer.posZ), 2, 82, 16777215);
            fontrenderer.drawStringWithShadow("Birds: " + this.format.format(this.mc.thePlayer.loopHandler.leaves / 5000.0f), 2, 92, 16777215);
            fontrenderer.drawStringWithShadow("Ocean: " + this.format.format((this.mc.thePlayer.loopHandler.waterSurface - 200) / 1000.0f), 2, 102, 16777215);
            fontrenderer.drawStringWithShadow("Cave: " + this.format.format((this.mc.thePlayer.loopHandler.exposedOre - 20) / 50.0f), 2, 112, 16777215);
            fontrenderer.drawStringWithShadow(this.mc.getDebugInfoRenders(), 2, 12, 16777215);
            fontrenderer.drawStringWithShadow(this.mc.getDebugInfoEntities(), 2, 22, 16777215);
            fontrenderer.drawStringWithShadow(this.mc.getDebugInfoParticlesAndGfx(), 2, 32, 16777215);
            fontrenderer.drawStringWithShadow("OS: " + System.getProperty("os.name") + ", Architecture: " + System.getProperty("os.arch"), 2, 42, 16777215);
            final long l3 = Runtime.getRuntime().maxMemory();
            final long l4 = Runtime.getRuntime().totalMemory();
            final long l5 = Runtime.getRuntime().freeMemory();
            final long l6 = l4 - l5;
            String s = "Used memory: " + l6 * 100L / l3 + "% (" + l6 / 1024L / 1024L + "MB) of " + l3 / 1024L / 1024L + "MB";
            this.drawString(fontrenderer, s, scaledWidth - fontrenderer.getStringWidth(s) - 2, 62, 14737632);
            s = "Allocated memory: " + l4 * 100L / l3 + "% (" + l4 / 1024L / 1024L + "MB)";
            this.drawString(fontrenderer, s, scaledWidth - fontrenderer.getStringWidth(s) - 2, 72, 14737632);
        }
        else {
            fontrenderer.drawStringWithShadow(Minecraft.version, 2, 2, 16777215);
        }
        if (this.field_924_j > 0) {
            final float f2 = this.field_924_j - f;
            int i3 = (int)(f2 * 256.0f / 20.0f);
            if (i3 > 255) {
                i3 = 255;
            }
            if (i3 > 0) {
                GL11.glPushMatrix();
                GL11.glTranslatef((float)(scaledWidth / 2), (float)(scaledHeight - 48), 0.0f);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                final int i4 = Color.HSBtoRGB(f2 / 50.0f, 0.7f, 0.6f) & 0xFFFFFF;
                fontrenderer.drawString(this.field_925_i, -fontrenderer.getStringWidth(this.field_925_i) / 2, -4, i4 + (i3 << 24));
                GL11.glDisable(3042);
                GL11.glPopMatrix();
            }
        }
        int maxShownMessages = 10;
        boolean chatOpen = false;
        int start = 0;
        if (this.mc.currentScreen instanceof GuiChat) {
            maxShownMessages = 20 + this.mc.currentScreen.scrollAmount;
            start = this.mc.currentScreen.scrollAmount;
            if (start >= this.chatList.size()) {
                start = this.chatList.size();
                this.mc.currentScreen.scrollAmount = start;
            }
            chatOpen = true;
        }
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3008);
        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, (float)(scaledHeight - 48), 0.0f);
        for (int chatMessage = start; chatMessage < this.chatList.size() && chatMessage < maxShownMessages; ++chatMessage) {
            if (this.chatList.get(chatMessage).age < 200 || chatOpen) {
                double messageAge = this.chatList.get(chatMessage).age / 200.0;
                messageAge = 1.0 - messageAge;
                messageAge *= 10.0;
                if (messageAge < 0.0) {
                    messageAge = 0.0;
                }
                if (messageAge > 1.0) {
                    messageAge = 1.0;
                }
                messageAge *= messageAge;
                int minAge = (int)(255.0 * messageAge);
                if (chatOpen) {
                    minAge = 255;
                }
                if (minAge > 0) {
                    final byte byte1 = 2;
                    final int messagePos = (-chatMessage + start) * 9;
                    final String s2 = this.chatList.get(chatMessage).content;
                    this.drawRect(byte1, messagePos - 1, byte1 + 320, messagePos + 8, minAge / 2 << 24);
                    GL11.glEnable(3042);
                    fontrenderer.drawStringWithShadow(s2, byte1, messagePos, 16777215 + (minAge << 24));
                }
            }
        }
        GL11.glPopMatrix();
        GL11.glEnable(3008);
        GL11.glDisable(3042);
        final int var14 = scaledWidth / 2;
        final int var15 = scaledHeight / 2;
        if (Keyboard.isKeyDown(15) && this.mc.mcWorld.multiplayerWorld && this.mc.getSendQueue() != null) {
            final List<PlayerScore> playerList = this.mc.getSendQueue().players;
            this.drawGradientRect(var14 - 120, var15 - 80, var14 + 120, var15 + 80, -1878719232, 1146443093);
            final String var16 = "Connected players:";
            fontrenderer.drawString(var16, var14 - fontrenderer.getStringWidth(var16) / 2, var15 - 64 - 12, 16777215);
            for (int var17 = 0; var17 < playerList.size(); ++var17) {
                final int var18 = var14 + var17 % 2 * 120 - 120;
                final int var19 = var15 - 64 + (var17 / 2 << 3);
                if (flag && u >= var18 && v >= var19 && u < var18 + 120 && v < var19 + 8) {
                    this.hoveredPlayer = playerList.get(var17).playerName;
                    fontrenderer.drawString(String.valueOf(playerList.get(var17).playerName) + " : " + playerList.get(var17).playerScore + " pts", var18 + 2, var19, 16777215);
                }
                else {
                    fontrenderer.drawString(String.valueOf(playerList.get(var17).playerName) + " : " + playerList.get(var17).playerScore + " pts", var18, var19, 15658734);
                }
            }
        }
    }
    
    private void renderSeeingStars(final float intensity, final int u, final int v) {
    }
    
    private void renderVignette(float brightness, final int u, final int v) {
        this.renderSeeingStars(brightness, u, v);
        brightness = 1.0f - brightness;
        if (brightness < 0.0f) {
            brightness = 0.0f;
        }
        if (brightness > 1.0f) {
            brightness = 1.0f;
        }
        this.prevVignetteBrightness += (float)((brightness - this.prevVignetteBrightness) * 0.01);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(0, 769);
        GL11.glColor4f(this.prevVignetteBrightness, this.prevVignetteBrightness, this.prevVignetteBrightness, 1.0f);
        GL11.glBindTexture(3553, this.mc.renderEngine.getTex("/misc/vignette.png"));
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(0.0, v, -90.0, 0.0, 1.0);
        tessellator.addVertexWithUV(u, v, -90.0, 1.0, 1.0);
        tessellator.addVertexWithUV(u, 0.0, -90.0, 1.0, 0.0);
        tessellator.addVertexWithUV(0.0, 0.0, -90.0, 0.0, 0.0);
        tessellator.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glBlendFunc(770, 771);
    }
    
    private void func_554_a(final int i, final int j, final int k, final float f) {
        final ItemStack itemstack = this.mc.thePlayer.inventory.mainInventory[i];
        if (itemstack == null) {
            return;
        }
        final float f2 = itemstack.animationsToGo - f;
        if (f2 > 0.0f) {
            GL11.glPushMatrix();
            final float f3 = 1.0f + f2 / 5.0f;
            GL11.glTranslatef((float)(j + 8), (float)(k + 12), 0.0f);
            GL11.glScalef(1.0f / f3, (f3 + 1.0f) / 2.0f, 1.0f);
            GL11.glTranslatef((float)(-(j + 8)), (float)(-(k + 12)), 0.0f);
        }
        GuiIngame.itemRenderer.renderItemBlock(this.mc.fontRender, this.mc.renderEngine, itemstack, j, k);
        if (f2 > 0.0f) {
            GL11.glPopMatrix();
        }
        GuiIngame.itemRenderer.renderTextDmg(this.mc.fontRender, this.mc.renderEngine, itemstack, j, k);
    }
    
    public void updateTick() {
        if (this.field_924_j > 0) {
            --this.field_924_j;
        }
        ++this.field_926_h;
        for (int i = 0; i < this.chatList.size(); ++i) {
            final ChatLine chatLine = this.chatList.get(i);
            ++chatLine.age;
        }
    }
    
    public void addChatMessage(String s) {
        while (this.mc.fontRender.getStringWidth(s) > 320) {
            int i;
            for (i = 1; i < s.length() && this.mc.fontRender.getStringWidth(s.substring(0, i + 1)) <= 320; ++i) {}
            this.addChatMessage(s.substring(0, i));
            s = s.substring(i);
        }
        this.chatList.add(0, new ChatLine(s));
        while (this.chatList.size() > 50) {
            this.chatList.remove(this.chatList.size() - 1);
        }
    }
    
    public void func_553_b(final String s) {
        this.field_925_i = "Now playing: " + s;
        this.field_924_j = 60;
    }
    
    public void showInfo(final String s) {
        this.field_925_i = s;
        this.field_924_j = 60;
    }
}
