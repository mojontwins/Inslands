package com.mojang.minecraft.gui;

import com.mojang.minecraft.render.*;

public class GuiTextField extends Gui
{
    private final FontRenderer fontRenderer;
    private final int xPos;
    private final int yPos;
    private final int width;
    private final int height;
    private String text;
    private int maxStringLength;
    private int cursorCounter;
    public boolean isFocused;
    public boolean isEnabled;
    private GuiScreen parentGuiScreen;
    
    public GuiTextField(final GuiScreen guiscreen, final FontRenderer fontrenderer, final int i, final int j, final int k, final int l, final String s) {
        this.isFocused = false;
        this.isEnabled = true;
        this.parentGuiScreen = guiscreen;
        this.fontRenderer = fontrenderer;
        this.xPos = i;
        this.yPos = j;
        this.width = k;
        this.height = l;
        this.setText(s);
    }
    
    public void setText(final String s) {
        this.text = s;
    }
    
    public String getText() {
        return this.text;
    }
    
    public void updateCursorCounter() {
        ++this.cursorCounter;
    }
    
    public void textboxKeyTyped(final char c, final int i) {
        if (!this.isEnabled || !this.isFocused) {
            return;
        }
        if (c == '\t') {
            this.parentGuiScreen.selectNextField();
        }
        if (c == '\u0016') {
            String s = GuiScreen.getClipboardString();
            if (s == null) {
                s = "";
            }
            int j = 32 - this.text.length();
            if (j > s.length()) {
                j = s.length();
            }
            if (j > 0) {
                this.text = String.valueOf(this.text) + s.substring(0, j);
            }
        }
        if (i == 14 && this.text.length() > 0) {
            this.text = this.text.substring(0, this.text.length() - 1);
        }
        if (ChatAllowedCharacters.allowedCharacters.indexOf(c) >= 0 && (this.text.length() < this.maxStringLength || this.maxStringLength == 0)) {
            this.text = String.valueOf(this.text) + c;
        }
    }
    
    public void mouseClicked(final int i, final int j, final int k) {
        final boolean flag = this.isEnabled && i >= this.xPos && i < this.xPos + this.width && j >= this.yPos && j < this.yPos + this.height;
        this.setFocused(flag);
    }
    
    public void setFocused(final boolean flag) {
        if (flag && !this.isFocused) {
            this.cursorCounter = 0;
        }
        this.isFocused = flag;
    }
    
    public void drawTextBox() {
        this.drawRect(this.xPos - 1, this.yPos - 1, this.xPos + this.width + 1, this.yPos + this.height + 1, -6250336);
        this.drawRect(this.xPos, this.yPos, this.xPos + this.width, this.yPos + this.height, -16777216);
        if (this.isEnabled) {
            final boolean flag = this.isFocused && this.cursorCounter / 6 % 2 == 0;
            this.drawString(this.fontRenderer, this.text + (flag ? "_" : ""), this.xPos + 4, this.yPos + (this.height - 8) / 2, 14737632);
        }
        else {
            this.drawString(this.fontRenderer, this.text, this.xPos + 4, this.yPos + (this.height - 8) / 2, 7368816);
        }
    }
    
    public void setMaxStringLength(final int i) {
        this.maxStringLength = i;
    }
}
