package com.mojang.minecraft.gui;

public class ChatLine
{
    public String content;
    public int age;
    
    public ChatLine(final String s) {
        this.content = s;
        this.age = 0;
    }
}
