package com.mojang.minecraft.gui;

import com.mojang.minecraft.player.controller.*;
import org.lwjgl.input.*;

public class GuiExtraVideoSettings extends GuiScreen
{
    private GuiScreen parent;
    private GameSettings options;
    private String name;
    private int maxDisplays;
    
    public GuiExtraVideoSettings(final GuiScreen parent, final GameSettings options) {
        this.name = "* denotes that a restart is necessary for option to take effect";
        this.maxDisplays = 0;
        this.parent = parent;
        this.options = options;
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
        int i = 1;
        this.maxDisplays = this.options.getDisplayModes().size();
        this.controlList.add(new GuiSmallButton(100, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(100)));
        ++i;
        this.controlList.add(new GuiSmallButton(1997, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(1997)));
        ++i;
        this.controlList.add(new GuiSmallButton(1998, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(1998)));
        ++i;
        this.controlList.add(new GuiSmallButton(1999, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(1999)));
        ++i;
        this.controlList.add(new GuiSmallButton(2000, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(2000)));
        ++i;
        this.controlList.add(new GuiSmallButton(2001, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(2001)));
        ++i;
        this.controlList.add(new GuiSmallButton(102, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(102)));
        ++i;
        this.controlList.add(new GuiSlider(12, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), 12, this.options.getOptionValue(12), this.options.FOV / 60.0f));
        ++i;
        this.controlList.add(new GuiSlider(566, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), 566, this.options.getOptionValue(566), this.options.modemVolume));
        ++i;
        this.controlList.add(new GuiSlider(104, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), 104, this.options.getOptionValue(104), this.options.chunkSavingInterval / 58.0f));
        ++i;
        this.controlList.add(new GuiSmallButton(1993, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(1993)));
        ++i;
        this.controlList.add(new GuiSmallButton(2002, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), this.options.getOptionValue(2002)));
        ++i;
        i += 3;
        this.controlList.add(new GuiSmallButton(200, this.width / 2 - 75 - 6, this.height / 10 + 24 * (i >> 1), "Back"));
        i = 0;
        this.controlList.add(new GuiListBox(1996, this.width / 2 - 155 + i % 2 * 160, this.height / 10 + 24 * (i >> 1), 150, 20, this.options.getDisplayModes(), this.options.displayMode).setDefaultString("Display: DEFAULT"));
    }
    
    @Override
    public void handleMouseInput() {
        super.handleMouseInput();
        if (this.scrollAmount < 0) {
            this.scrollAmount = 0;
        }
        if (this.scrollAmount > this.maxDisplays) {
            this.scrollAmount = this.maxDisplays;
        }
        this.controlList.get(13).scrolledValue = this.scrollAmount;
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton.id == 100) {
            this.mc.options.fog = !this.mc.options.fog;
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.mc.options.save();
        }
        if (guibutton.id == 101) {
            this.mc.options.clouds = !this.mc.options.clouds;
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.mc.options.save();
        }
        if (guibutton.id == 102) {
            this.mc.options.particles = !this.mc.options.particles;
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.mc.options.save();
        }
        if (guibutton.id == 1993) {
            this.mc.options.advancedOpenGL = !this.mc.options.advancedOpenGL;
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.mc.options.save();
        }
        if (guibutton.id == 1996) {
            final int i = Mouse.getEventX() * this.width / this.mc.displayWidth;
            final int j = this.height - Mouse.getEventY() * this.height / this.mc.displayHeight - 1;
            final int index = ((GuiListBox)guibutton).getOption(i, j);
            System.out.print(index);
            ((GuiListBox)guibutton).index = index;
            ((GuiListBox)guibutton).shrink();
            this.mc.options.displayMode = index;
            System.out.println(this.mc.options.displayMode);
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.mc.options.save();
        }
        if (guibutton.id >= 1997 && guibutton.id <= 2002) {
            this.options.setOptionValue(guibutton.id, 1);
            guibutton.displayString = this.options.getOptionValue(guibutton.id);
            this.options.save();
        }
        if (guibutton.id == 104) {
            this.mc.options.save();
        }
        if (guibutton.id == 12) {
            this.mc.options.save();
        }
        if (guibutton.id == 200) {
            this.mc.options.save();
            this.mc.setCurrentScreen(this.parent);
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, this.name, this.width / 2, this.height / 10 + 168, 11513775);
        super.drawScreen(i, j, f);
    }
}
