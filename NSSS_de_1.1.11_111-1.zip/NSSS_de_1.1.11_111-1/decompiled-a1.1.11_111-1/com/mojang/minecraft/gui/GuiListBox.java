package com.mojang.minecraft.gui;

import java.util.*;
import com.mojang.minecraft.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class GuiListBox extends GuiButton
{
    int defheight;
    protected int width;
    protected int height;
    public int xPosition;
    public int yPosition;
    public ArrayList<String> displayString;
    public String defaultString;
    public int index;
    public int id;
    public boolean enabled;
    public boolean enabled2;
    public boolean shrink;
    public int scrolledValue;
    
    public GuiListBox(final int i, final int j, final int k, final ArrayList<String> s, final int index) {
        this(i, j, k, 200, 20, s, index);
    }
    
    protected GuiListBox(final int i, final int j, final int k, final int l, final int i1, final ArrayList<String> s, final int index) {
        super(i, j, k, l, i1, "Listbox");
        this.scrolledValue = 0;
        this.width = 200;
        this.height = 20;
        this.enabled = true;
        this.enabled2 = true;
        this.id = i;
        this.xPosition = j;
        this.yPosition = k;
        this.width = l;
        this.height = i1;
        this.defheight = i1;
        this.displayString = s;
        this.index = index;
    }
    
    protected GuiListBox setDefaultString(final String s) {
        this.defaultString = s;
        return this;
    }
    
    @Override
    protected int func_558_a(final boolean flag) {
        byte byte0 = 1;
        if (!this.enabled) {
            byte0 = 0;
        }
        else if (flag) {
            byte0 = 2;
        }
        return byte0;
    }
    
    @Override
    public void func_561_a(final Minecraft minecraft, final int i, final int j) {
        if (!this.enabled2) {
            return;
        }
        final FontRenderer fontrenderer = minecraft.fontRender;
        GL11.glBindTexture(3553, minecraft.renderEngine.getTex("/gui/gui.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        boolean flag = i >= this.xPosition && j >= this.yPosition && i < this.xPosition + this.width && j < this.yPosition + this.height;
        if (this.shrink) {
            flag = false;
            this.shrink = false;
        }
        final int k = this.func_558_a(flag);
        this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + k * 20, this.width / 2, this.defheight);
        this.drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + k * 20, this.width / 2, this.defheight);
        this.func_560_b(minecraft, i, j);
        if (!this.enabled) {
            this.height = this.defheight;
            if (this.index != -1) {
                this.drawCenteredString(fontrenderer, this.displayString.get(this.index), this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, -6250336);
            }
            else {
                this.drawCenteredString(fontrenderer, this.defaultString, this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, -6250336);
            }
        }
        else if (flag) {
            this.height = this.defheight * this.displayString.size();
            if (this.index != -1) {
                this.drawCenteredString(fontrenderer, this.displayString.get(this.index), this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, 16777120);
            }
            else {
                this.drawCenteredString(fontrenderer, this.defaultString, this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, 16777120);
            }
            for (int idx = this.scrolledValue; idx < this.displayString.size(); ++idx) {
                final boolean flag2 = i >= this.xPosition && j >= this.yPosition + (idx - this.scrolledValue) * this.defheight && i < this.xPosition + this.width && j < this.yPosition + this.defheight + (idx - this.scrolledValue) * this.defheight;
                final int k2 = this.func_558_a(flag2);
                GL11.glBindTexture(3553, minecraft.renderEngine.getTex("/gui/gui.png"));
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                this.drawTexturedModalRect(this.xPosition, this.yPosition + (idx - this.scrolledValue) * this.defheight, 0, 46 + k2 * 20, this.width / 2, this.defheight);
                this.drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition + (idx - this.scrolledValue) * this.defheight, 200 - this.width / 2, 46 + k2 * 20, this.width / 2, this.defheight);
                this.func_560_b(minecraft, i, j + (idx - this.scrolledValue) * this.defheight);
                if (idx - this.scrolledValue != -1) {
                    this.drawCenteredString(fontrenderer, this.displayString.get(idx), this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2 + this.defheight * (idx - this.scrolledValue), 16777120);
                }
                else {
                    this.drawCenteredString(fontrenderer, this.defaultString, this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2 + this.defheight * (idx - this.scrolledValue), 16777120);
                }
            }
        }
        else {
            this.height = this.defheight;
            if (this.index != -1) {
                this.drawCenteredString(fontrenderer, this.displayString.get(this.index), this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, 14737632);
            }
            else {
                this.drawCenteredString(fontrenderer, this.defaultString, this.xPosition + this.width / 2, this.yPosition + (this.defheight - 8) / 2, 14737632);
            }
        }
    }
    
    public int getOption(final int i, final int j) {
        final boolean flag = i >= this.xPosition && j >= this.yPosition && i < this.xPosition + this.width && j < this.yPosition + this.height;
        if (flag) {
            for (int idx = this.scrolledValue; idx < this.displayString.size(); ++idx) {
                final boolean flag2 = i >= this.xPosition && j >= this.yPosition + (idx - this.scrolledValue) * this.defheight && i < this.xPosition + this.width && j < this.yPosition + this.defheight + (idx - this.scrolledValue) * this.defheight;
                if (flag2) {
                    return idx;
                }
            }
        }
        return -1;
    }
    
    @Override
    protected void func_560_b(final Minecraft minecraft, final int i, final int j) {
    }
    
    @Override
    public void func_559_a(final int i, final int j) {
    }
    
    @Override
    public boolean func_562_c(final Minecraft minecraft, final int i, final int j) {
        return this.enabled && i >= this.xPosition && j >= this.yPosition && i < this.xPosition + this.width && j < this.yPosition + this.height;
    }
    
    public void shrink() {
        this.shrink = true;
    }
}
