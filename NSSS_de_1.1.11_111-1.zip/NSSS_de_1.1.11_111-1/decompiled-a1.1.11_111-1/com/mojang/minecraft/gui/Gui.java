package com.mojang.minecraft.gui;

import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class Gui
{
    protected float zLevel;
    
    public Gui() {
        this.zLevel = 0.0f;
    }
    
    protected void drawRect(final int i, final int j, final int k, final int l, final int i1) {
        final float f = (i1 >> 24 & 0xFF) / 255.0f;
        final float f2 = (i1 >> 16 & 0xFF) / 255.0f;
        final float f3 = (i1 >> 8 & 0xFF) / 255.0f;
        final float f4 = (i1 & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.instance;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(f2, f3, f4, f);
        tessellator.startDrawingQuads();
        tessellator.addVertex(i, l, 0.0);
        tessellator.addVertex(k, l, 0.0);
        tessellator.addVertex(k, j, 0.0);
        tessellator.addVertex(i, j, 0.0);
        tessellator.draw();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
    }
    
    protected void drawGradientRect(final int i, final int j, final int k, final int l, final int i1, final int j1) {
        final float f = (i1 >> 24 & 0xFF) / 255.0f;
        final float f2 = (i1 >> 16 & 0xFF) / 255.0f;
        final float f3 = (i1 >> 8 & 0xFF) / 255.0f;
        final float f4 = (i1 & 0xFF) / 255.0f;
        final float f5 = (j1 >> 24 & 0xFF) / 255.0f;
        final float f6 = (j1 >> 16 & 0xFF) / 255.0f;
        final float f7 = (j1 >> 8 & 0xFF) / 255.0f;
        final float f8 = (j1 & 0xFF) / 255.0f;
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glDisable(3008);
        GL11.glBlendFunc(770, 771);
        GL11.glShadeModel(7425);
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.setColorRGBA_F(f2, f3, f4, f);
        tessellator.addVertex(k, j, 0.0);
        tessellator.addVertex(i, j, 0.0);
        tessellator.setColorRGBA_F(f6, f7, f8, f5);
        tessellator.addVertex(i, l, 0.0);
        tessellator.addVertex(k, l, 0.0);
        tessellator.draw();
        GL11.glShadeModel(7424);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glEnable(3553);
    }
    
    public void drawCenteredString(final FontRenderer fontrenderer, final String s, final int i, final int j, final int k) {
        fontrenderer.drawStringWithShadow(s, i - fontrenderer.getStringWidth(s) / 2, j, k);
    }
    
    public void drawString(final FontRenderer fontrenderer, final String s, final int i, final int j, final int k) {
        fontrenderer.drawStringWithShadow(s, i, j, k);
    }
    
    public void drawTexturedModalRect(final int x, final int y, final int u, final int v, final int u2, final int v2) {
        final float f = 0.00390625f;
        final float f2 = 0.00390625f;
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(x + 0, y + v2, this.zLevel, (u + 0) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + v2, this.zLevel, (u + u2) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + 0, this.zLevel, (u + u2) * f, (v + 0) * f2);
        tessellator.addVertexWithUV(x + 0, y + 0, this.zLevel, (u + 0) * f, (v + 0) * f2);
        tessellator.draw();
    }
}
