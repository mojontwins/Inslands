package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class GuiButton extends Gui
{
    protected int width;
    protected int height;
    public int xPosition;
    public int yPosition;
    public String displayString;
    public int id;
    public boolean enabled;
    public boolean enabled2;
    
    public GuiButton(final int id, final int xPos, final int yPos, final String string) {
        this(id, xPos, yPos, 200, 20, string);
    }
    
    protected GuiButton(final int buttonId, final int xPos, final int yPos, final int wide, final int high, final String string) {
        this.width = 200;
        this.height = 20;
        this.enabled = true;
        this.enabled2 = true;
        this.id = buttonId;
        this.xPosition = xPos;
        this.yPosition = yPos;
        this.width = wide;
        this.height = high;
        this.displayString = string;
    }
    
    protected int func_558_a(final boolean flag) {
        byte byte0 = 1;
        if (!this.enabled) {
            byte0 = 0;
        }
        else if (flag) {
            byte0 = 2;
        }
        return byte0;
    }
    
    public void func_561_a(final Minecraft minecraft, final int i, final int j) {
        if (!this.enabled2) {
            return;
        }
        final FontRenderer fontrenderer = minecraft.fontRender;
        GL11.glBindTexture(3553, minecraft.renderEngine.getTex("/gui/gui.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        final boolean flag = i >= this.xPosition && j >= this.yPosition && i < this.xPosition + this.width && j < this.yPosition + this.height;
        int k = this.func_558_a(flag);
        if (k == 2 && Minecraft.isIRIX) {
            k = 3;
        }
        this.drawTexturedModalRect(this.xPosition, this.yPosition, 0, 46 + k * 20, this.width / 2, this.height);
        this.drawTexturedModalRect(this.xPosition + this.width / 2, this.yPosition, 200 - this.width / 2, 46 + k * 20, this.width / 2, this.height);
        this.func_560_b(minecraft, i, j);
        if (!this.enabled) {
            this.drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, -6250336);
        }
        else if (flag) {
            this.drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, 16777120);
        }
        else {
            this.drawCenteredString(fontrenderer, this.displayString, this.xPosition + this.width / 2, this.yPosition + (this.height - 8) / 2, 14737632);
        }
    }
    
    protected void func_560_b(final Minecraft minecraft, final int i, final int j) {
    }
    
    public void func_559_a(final int i, final int j) {
    }
    
    public boolean func_562_c(final Minecraft minecraft, final int i, final int j) {
        return this.enabled && i >= this.xPosition && j >= this.yPosition && i < this.xPosition + this.width && j < this.yPosition + this.height;
    }
}
