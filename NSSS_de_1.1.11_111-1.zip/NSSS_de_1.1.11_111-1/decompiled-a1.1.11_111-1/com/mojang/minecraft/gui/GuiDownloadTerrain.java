package com.mojang.minecraft.gui;

import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.networknew.packet.*;

public class GuiDownloadTerrain extends GuiScreen
{
    private NetClientHandler netHandler;
    private int updateCounter;
    
    public GuiDownloadTerrain(final NetClientHandler netclienthandler) {
        this.updateCounter = 0;
        this.netHandler = netclienthandler;
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
    
    @Override
    public void initGui() {
        this.controlList.clear();
    }
    
    @Override
    public void updateScreen() {
        ++this.updateCounter;
        if (this.updateCounter % 20 == 0) {
            this.netHandler.addToSendQueue(new Packet0KeepAlive());
        }
        if (this.netHandler != null) {
            this.netHandler.processReadPackets();
        }
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.func_579_b(0);
        this.drawCenteredString(this.fontRenderer, "Downloading terrain", this.width / 2, this.height / 2 - 50, 16777215);
        super.drawScreen(i, j, f);
    }
}
