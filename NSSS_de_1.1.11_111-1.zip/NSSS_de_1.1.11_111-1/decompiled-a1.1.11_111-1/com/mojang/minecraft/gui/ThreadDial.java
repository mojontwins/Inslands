package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import com.mojang.minecraft.util.*;

class ThreadDial extends Thread
{
    String ip;
    int port;
    Minecraft minecraft;
    GuiConnecting guiconnecting;
    public boolean cancel;
    
    ThreadDial(final GuiConnecting gc, final Minecraft mc, final String internetProtocol, final int toport) {
        this.cancel = false;
        this.guiconnecting = gc;
        this.minecraft = mc;
        this.ip = internetProtocol;
        this.port = toport;
    }
    
    @Override
    public void interrupt() {
        this.cancel = true;
        super.interrupt();
    }
    
    @Override
    public void run() {
        this.minecraft.soundMGR.playSoundFX("dial.line", this.minecraft.options.modemVolume, 1.0f);
        if (this.cancel) {
            return;
        }
        try {
            Thread.sleep(1000L);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < this.ip.length(); ++i) {
            if (this.cancel) {
                return;
            }
            String digit = "";
            final int digint = this.getMatchingDigit(this.ip.toLowerCase().charAt(i));
            switch (digint) {
                case 0: {
                    digit = "dial.zero";
                    break;
                }
                case 1: {
                    digit = "dial.one";
                    break;
                }
                case 2: {
                    digit = "dial.two";
                    break;
                }
                case 3: {
                    digit = "dial.three";
                    break;
                }
                case 4: {
                    digit = "dial.four";
                    break;
                }
                case 5: {
                    digit = "dial.five";
                    break;
                }
                case 6: {
                    digit = "dial.six";
                    break;
                }
                case 7: {
                    digit = "dial.seven";
                    break;
                }
                case 8: {
                    digit = "dial.eight";
                    break;
                }
                case 9: {
                    digit = "dial.nine";
                    break;
                }
                case -1: {
                    digit = "";
                    break;
                }
                default: {
                    digit = "";
                    break;
                }
            }
            if (!digit.equals("")) {
                this.minecraft.soundMGR.playSoundFX(digit, this.minecraft.options.modemVolume * 0.25f, 1.0f);
                try {
                    Thread.sleep(150L);
                }
                catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            }
        }
        if (this.cancel) {
            return;
        }
        this.minecraft.soundMGR.playSoundFX("dial.modem", this.minecraft.options.modemVolume, 1.0f);
        try {
            Thread.sleep(15000L);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        new ThreadConnectToServer(this.guiconnecting, this.minecraft, this.ip, this.port).start();
    }
    
    public int getMatchingDigit(final char c) {
        final String[] digits = { "0", "1", "2abc", "3def", "4ghi", "5jkl", "6mno", "7pqrs", "8tuv", "9wxyz" };
        for (int i = 0; i < digits.length; ++i) {
            if (digits[i].contains(new StringBuilder().append(c).toString())) {
                return i;
            }
        }
        return -1;
    }
}
