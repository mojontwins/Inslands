package com.mojang.minecraft.gui;

import com.mojang.minecraft.level.*;
import org.lwjgl.opengl.*;

public class GuiGameOver extends GuiScreen
{
    @Override
    public void initGui() {
        this.controlList.clear();
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 72, "Respawn"));
        this.controlList.add(new GuiButton(2, this.width / 2 - 100, this.height / 4 + 96, "Title menu"));
        if (this.mc.session == null) {
            this.controlList.get(1).enabled = false;
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (guibutton.id != 0) {}
        if (guibutton.id == 1) {
            this.mc.thePlayer.respawnPlayer();
            this.mc.setCurrentScreen(null);
        }
        if (guibutton.id == 2) {
            this.mc.changeWorld1(null);
            this.mc.setCurrentScreen(new GuiMainMenu());
        }
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawGradientRect(0, 0, this.width, this.height, 1615855616, -1602211792);
        GL11.glPushMatrix();
        GL11.glScalef(2.0f, 2.0f, 2.0f);
        this.drawCenteredString(this.fontRenderer, "Game over!", this.width / 2 / 2, 30, 16777215);
        GL11.glPopMatrix();
        this.drawCenteredString(this.fontRenderer, "Score: �e" + this.mc.thePlayer.getScore(), this.width / 2, 100, 16777215);
        super.drawScreen(i, j, f);
    }
    
    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
