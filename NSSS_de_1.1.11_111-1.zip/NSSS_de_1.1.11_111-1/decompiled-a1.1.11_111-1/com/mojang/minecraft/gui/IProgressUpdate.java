package com.mojang.minecraft.gui;

public interface IProgressUpdate
{
    void func_594_b(final String p0);
    
    void func_595_d(final String p0);
    
    void setProgess(final int p0);
}
