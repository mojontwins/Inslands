package com.mojang.minecraft.gui;

import com.mojang.minecraft.*;
import java.io.*;
import com.mojang.minecraft.level.*;

public class GuiDeleteWorld extends GuiSelectWorld
{
    GuiScreen parent;
    
    public GuiDeleteWorld(final GuiScreen guiscreen) {
        super(guiscreen);
        this.parent = guiscreen;
        this.field_960_h = "Delete world";
    }
    
    @Override
    public void func_585_j() {
        final GuiButton gbnext = new GuiButton(-3, this.width / 2 + 6, this.height / 6 + 128, ">");
        gbnext.width = 95;
        this.controlList.add(gbnext);
        final GuiButton gbprev = new GuiButton(-4, this.width / 2 - 100, this.height / 6 + 128, "<");
        gbprev.width = 95;
        if (this.list <= 0) {
            gbprev.enabled = false;
        }
        else {
            gbprev.enabled = true;
        }
        this.controlList.add(gbprev);
        this.controlList.add(new GuiButton(-2, this.width / 2 - 100, this.height / 6 + 168 + 10, "Cancel"));
    }
    
    @Override
    public void func_584_c(final int i) {
        String s = this.func_586_d(i);
        final File file = Minecraft.getMinecraftDir();
        final File f = new File(file, "NSSSsaves/World" + i + "/name.data");
        if (f.exists()) {
            try {
                final BufferedReader br = new BufferedReader(new FileReader(f));
                s = br.readLine();
                br.close();
            }
            catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        if (s != null) {
            this.mc.setCurrentScreen(new GuiYesNo(this, "Are you sure you want to delete this world?", "'" + s + "' will be lost forever!", i));
        }
    }
    
    @Override
    public void func_568_a(final boolean flag, final int i) {
        if (flag) {
            final File file = Minecraft.getMinecraftDir();
            World.func_615_b(file, this.func_586_d(i));
            ((GuiSelectWorld)this.parent).setButtons(((GuiSelectWorld)this.parent).list);
        }
        this.mc.setCurrentScreen(this.field_958_a);
    }
}
