package com.mojang.minecraft.gui;

import com.mojang.minecraft.player.controller.*;
import org.lwjgl.input.*;

public class GuiMultiplayer extends GuiScreen
{
    GameSettings gamesettings;
    private GuiScreen parentScreen;
    private GuiTextField field_22111_h;
    private int field_970_h;
    private String cachedServer;
    
    public GuiMultiplayer(final GuiScreen guiscreen, final GameSettings gamesettings) {
        this.field_970_h = 0;
        this.gamesettings = gamesettings;
        this.cachedServer = gamesettings.lastServer;
        this.parentScreen = guiscreen;
    }
    
    @Override
    public void updateScreen() {
        ++this.field_970_h;
    }
    
    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        this.controlList.clear();
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 96 + 12, "Connect"));
        this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 120 + 12, "Cancel"));
        final String s = this.mc.options.lastServer;
        this.controlList.get(0).enabled = (s.length() > 0);
        this.field_22111_h = new GuiTextField(this, this.fontRenderer, this.width / 2 - 100, this.height / 4 - 10 + 50 + 18, 200, 20, s);
        this.field_22111_h.isFocused = true;
        this.field_22111_h.setMaxStringLength(128);
    }
    
    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }
    
    @Override
    protected void actionPerformed(final GuiButton guibutton) {
        if (!guibutton.enabled) {
            return;
        }
        if (guibutton.id == 1) {
            this.mc.setCurrentScreen(this.parentScreen);
        }
        else if (guibutton.id == 0) {
            final String s = this.field_22111_h.getText().trim();
            this.mc.options.lastServer = s;
            this.mc.options.save();
            String[] as = s.split(":");
            if (s.startsWith("[")) {
                final int i = s.indexOf("]");
                if (i > 0) {
                    final String s2 = s.substring(1, i);
                    String s3 = s.substring(i + 1).trim();
                    if (s3.startsWith(":") && s3.length() > 0) {
                        s3 = s3.substring(1);
                        as = new String[] { s2, s3 };
                    }
                    else {
                        as = new String[] { s2 };
                    }
                }
            }
            if (as.length > 2) {
                as = new String[] { s };
            }
            this.mc.setCurrentScreen(new GuiConnecting(this.mc, as[0], (as.length <= 1) ? 25565 : this.parseIntWithDefault(as[1], 25565)));
        }
    }
    
    private int parseIntWithDefault(final String s, final int i) {
        try {
            return Integer.parseInt(s.trim());
        }
        catch (Exception exception) {
            return i;
        }
    }
    
    @Override
    protected void keyTyped(final char c, final int i) {
        this.field_22111_h.textboxKeyTyped(c, i);
        if (c == '\r') {
            this.actionPerformed(this.controlList.get(0));
        }
        this.controlList.get(0).enabled = (this.field_22111_h.getText().length() > 0);
    }
    
    @Override
    protected void mouseClicked(final int i, final int j, final int k) {
        super.mouseClicked(i, j, k);
        this.field_22111_h.mouseClicked(i, j, k);
    }
    
    @Override
    public void drawScreen(final int i, final int j, final float f) {
        this.drawDefaultBackground();
        this.drawCenteredString(this.fontRenderer, "Play Multiplayer", this.width / 2, this.height / 4 - 60 + 20, 16777215);
        this.drawString(this.fontRenderer, "NSSS Multiplayer is currently not finished, but there", this.width / 2 - 140, this.height / 4 - 60 + 60 + 0, 10526880);
        this.drawString(this.fontRenderer, "is some buggy early testing going on.", this.width / 2 - 140, this.height / 4 - 60 + 60 + 9, 10526880);
        this.drawString(this.fontRenderer, "Enter the IP of a server to connect to it:", this.width / 2 - 140, this.height / 4 - 60 + 60 + 36, 10526880);
        this.field_22111_h.drawTextBox();
        super.drawScreen(i, j, f);
    }
}
