package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.render.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;

public class EntityMinecart extends Entity implements IInventory
{
    private ItemStack[] cargoItems;
    public int minecartCurrentDamage;
    public int minecartTimeSinceHit;
    public int minecartRockDirection;
    private boolean field_856_i;
    public int minecartType;
    public int fuel;
    public double pushX;
    public double pushZ;
    private static final int[][][] field_855_j;
    private int field_854_k;
    private double field_853_l;
    private double field_852_m;
    private double field_851_n;
    private double field_850_o;
    private double field_849_p;
    
    static {
        field_855_j = new int[][][] { { { 0, 0, -1 }, { 0, 0, 1 } }, { { -1, 0, 0 }, { 1, 0, 0 } }, { { -1, -1, 0 }, { 1, 0, 0 } }, { { -1, 0, 0 }, { 1, -1, 0 } }, { { 0, 0, -1 }, { 0, -1, 1 } }, { { 0, -1, -1 }, { 0, 0, 1 } }, { { 0, 0, 1 }, { 1, 0, 0 } }, { { 0, 0, 1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { 1, 0, 0 } } };
    }
    
    public EntityMinecart(final World world) {
        super(world);
        this.cargoItems = new ItemStack[36];
        this.minecartCurrentDamage = 0;
        this.minecartTimeSinceHit = 0;
        this.minecartRockDirection = 1;
        this.field_856_i = false;
        this.preventEntitySpawning = true;
        this.setSize(0.98f, 0.7f);
        this.yOffset = this.height / 2.0f;
        this.field_640_aG = false;
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public AxisAlignedBB getCollisionBox(final Entity entity) {
        return entity.boundingBox;
    }
    
    @Override
    public AxisAlignedBB func_372_f_() {
        return this.boundingBox;
    }
    
    @Override
    public boolean canBePushed() {
        return true;
    }
    
    public EntityMinecart(final World world, final double d, final double d1, final double d2, final int i) {
        this(world);
        this.setPosition(d, d1 + this.yOffset, d2);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = d;
        this.prevPosY = d1;
        this.prevPosZ = d2;
        this.minecartType = i;
    }
    
    @Override
    public double getMountedYOffset() {
        return this.height * 0.0 - 0.30000001192092896;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        if (this.worldObj.multiplayerWorld || this.isDead) {
            this.minecartRockDirection = -this.minecartRockDirection;
            this.minecartTimeSinceHit = 10;
            this.minecartCurrentDamage += i * 10;
            return true;
        }
        this.minecartRockDirection = -this.minecartRockDirection;
        this.minecartTimeSinceHit = 10;
        this.minecartCurrentDamage += i * 10;
        if (this.minecartCurrentDamage > 40) {
            if (!this.worldObj.multiplayerWorld) {
                this.dropItemWithOffset(Item.minecartEmpty.shiftedIndex, 1, 0.0f);
                if (this.minecartType == 1) {
                    this.dropItemWithOffset(Block.crate.blockID, 1, 0.0f);
                }
                else if (this.minecartType == 2) {
                    this.dropItemWithOffset(Block.stoneOvenIdle.blockID, 1, 0.0f);
                }
            }
            this.setEntityDead();
        }
        return true;
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }
    
    @Override
    public void setEntityDead() {
        for (int i = 0; i < this.getSizeInventory(); ++i) {
            final ItemStack itemstack = this.getStackInSlot(i);
            if (itemstack != null) {
                final float f = this.rand.nextFloat() * 0.8f + 0.1f;
                final float f2 = this.rand.nextFloat() * 0.8f + 0.1f;
                final float f3 = this.rand.nextFloat() * 0.8f + 0.1f;
                while (itemstack.stackSize > 0) {
                    int j = this.rand.nextInt(21) + 10;
                    if (j > itemstack.stackSize) {
                        j = itemstack.stackSize;
                    }
                    final ItemStack itemStack = itemstack;
                    itemStack.stackSize -= j;
                    if (this.worldObj.multiplayerWorld) {
                        return;
                    }
                    final EntityItem entityitem = new EntityItem(this.worldObj, this.posX + f, this.posY + f2, this.posZ + f3, new ItemStack(itemstack.itemID, j, itemstack.itemDamage));
                    final float f4 = 0.05f;
                    entityitem.motionX = (float)this.rand.nextGaussian() * f4;
                    entityitem.motionY = (float)this.rand.nextGaussian() * f4 + 0.2f;
                    entityitem.motionZ = (float)this.rand.nextGaussian() * f4;
                    this.worldObj.entityJoinedWorld(entityitem);
                }
            }
        }
        super.setEntityDead();
    }
    
    @Override
    public void onUpdate() {
        if (this.minecartTimeSinceHit > 0) {
            --this.minecartTimeSinceHit;
        }
        if (this.minecartCurrentDamage > 0) {
            --this.minecartCurrentDamage;
        }
        if (this.worldObj.multiplayerWorld && this.riddenByEntity == null) {
            if (this.field_854_k > 0) {
                final double d = this.posX + (this.field_853_l - this.posX) / this.field_854_k;
                final double d2 = this.posY + (this.field_852_m - this.posY) / this.field_854_k;
                final double d3 = this.posZ + (this.field_851_n - this.posZ) / this.field_854_k;
                double d4;
                for (d4 = this.field_850_o - this.rotationYaw; d4 < -180.0; d4 += 360.0) {}
                while (d4 >= 180.0) {
                    d4 -= 360.0;
                }
                this.rotationYaw += (float)(d4 / this.field_854_k);
                this.rotationPitch += (float)((this.field_849_p - this.rotationPitch) / this.field_854_k);
                --this.field_854_k;
                this.setPosition(d, d2, d3);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
            else {
                this.setPosition(this.posX, this.posY, this.posZ);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
            return;
        }
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.03999999910593033;
        final int i = MathHelper.floor_double(this.posX);
        int j = MathHelper.floor_double(this.posY);
        final int k = MathHelper.floor_double(this.posZ);
        if (this.worldObj.getBlockId(i, j - 1, k) == Block.minecartTrack.blockID) {
            --j;
        }
        final double d5 = 0.4;
        boolean flag = false;
        final double d6 = 0.0078125;
        if (this.worldObj.getBlockId(i, j, k) == Block.minecartTrack.blockID) {
            final Vec3D vec3d = this.func_514_g(this.posX, this.posY, this.posZ);
            final int l = this.worldObj.getBlockMetadata(i, j, k);
            this.posY = j;
            if (l >= 2 && l <= 5) {
                this.posY = j + 1;
            }
            if (l == 2) {
                this.motionX -= d6;
            }
            if (l == 3) {
                this.motionX += d6;
            }
            if (l == 4) {
                this.motionZ += d6;
            }
            if (l == 5) {
                this.motionZ -= d6;
            }
            final int[][] ai = EntityMinecart.field_855_j[l];
            double d7 = ai[1][0] - ai[0][0];
            double d8 = ai[1][2] - ai[0][2];
            final double d9 = Math.sqrt(d7 * d7 + d8 * d8);
            final double d10 = this.motionX * d7 + this.motionZ * d8;
            if (d10 < 0.0) {
                d7 = -d7;
                d8 = -d8;
            }
            final double d11 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
            this.motionX = d11 * d7 / d9;
            this.motionZ = d11 * d8 / d9;
            double d12 = 0.0;
            final double d13 = i + 0.5 + ai[0][0] * 0.5;
            final double d14 = k + 0.5 + ai[0][2] * 0.5;
            final double d15 = i + 0.5 + ai[1][0] * 0.5;
            final double d16 = k + 0.5 + ai[1][2] * 0.5;
            d7 = d15 - d13;
            d8 = d16 - d14;
            if (d7 == 0.0) {
                this.posX = i + 0.5;
                d12 = this.posZ - k;
            }
            else if (d8 == 0.0) {
                this.posZ = k + 0.5;
                d12 = this.posX - i;
            }
            else {
                final double d17 = this.posX - d13;
                final double d18 = this.posZ - d14;
                final double d19 = d12 = (d17 * d7 + d18 * d8) * 2.0;
            }
            this.posX = d13 + d7 * d12;
            this.posZ = d14 + d8 * d12;
            this.setPosition(this.posX, this.posY + this.yOffset, this.posZ);
            double d20 = this.motionX;
            double d21 = this.motionZ;
            if (this.riddenByEntity != null) {
                d20 *= 0.75;
                d21 *= 0.75;
            }
            if (d20 < -d5) {
                d20 = -d5;
            }
            if (d20 > d5) {
                d20 = d5;
            }
            if (d21 < -d5) {
                d21 = -d5;
            }
            if (d21 > d5) {
                d21 = d5;
            }
            this.moveEntity(d20, 0.0, d21);
            if (ai[0][1] != 0 && MathHelper.floor_double(this.posX) - i == ai[0][0] && MathHelper.floor_double(this.posZ) - k == ai[0][2]) {
                this.setPosition(this.posX, this.posY + ai[0][1], this.posZ);
            }
            else if (ai[1][1] != 0 && MathHelper.floor_double(this.posX) - i == ai[1][0] && MathHelper.floor_double(this.posZ) - k == ai[1][2]) {
                this.setPosition(this.posX, this.posY + ai[1][1], this.posZ);
            }
            if (this.riddenByEntity != null) {
                this.motionX *= 0.996999979019165;
                this.motionY *= 0.0;
                this.motionZ *= 0.996999979019165;
            }
            else {
                if (this.minecartType == 2) {
                    final double d22 = MathHelper.sqrt_double(this.pushX * this.pushX + this.pushZ * this.pushZ);
                    if (d22 > 0.01) {
                        flag = true;
                        this.pushX /= d22;
                        this.pushZ /= d22;
                        final double d23 = 0.08;
                        this.motionX *= 0.8;
                        this.motionY *= 0.0;
                        this.motionZ *= 0.8;
                        this.motionX += this.pushX * d23;
                        this.motionZ += this.pushZ * d23;
                    }
                    else {
                        this.motionX *= 0.9;
                        this.motionY *= 0.0;
                        this.motionZ *= 0.9;
                    }
                }
                this.motionX *= 0.95;
                this.motionY *= 0.0;
                this.motionZ *= 0.95;
            }
            final Vec3D vec3d2 = this.func_514_g(this.posX, this.posY, this.posZ);
            if (vec3d2 != null && vec3d != null) {
                final double d24 = (vec3d.yCoord - vec3d2.yCoord) * 0.05;
                final double d25 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
                if (d25 > 0.0) {
                    this.motionX = this.motionX / d25 * (d25 + d24);
                    this.motionZ = this.motionZ / d25 * (d25 + d24);
                }
                this.setPosition(this.posX, vec3d2.yCoord, this.posZ);
            }
            final int j2 = MathHelper.floor_double(this.posX);
            final int k2 = MathHelper.floor_double(this.posZ);
            if (j2 != i || k2 != k) {
                final double d26 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
                this.motionX = d26 * (j2 - i);
                this.motionZ = d26 * (k2 - k);
            }
            if (this.minecartType == 2) {
                final double d27 = MathHelper.sqrt_double(this.pushX * this.pushX + this.pushZ * this.pushZ);
                if (d27 > 0.01 && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.001) {
                    this.pushX /= d27;
                    this.pushZ /= d27;
                    if (this.pushX * this.motionX + this.pushZ * this.motionZ < 0.0) {
                        this.pushX = 0.0;
                        this.pushZ = 0.0;
                    }
                    else {
                        this.pushX = this.motionX;
                        this.pushZ = this.motionZ;
                    }
                }
            }
        }
        else {
            if (this.motionX < -d5) {
                this.motionX = -d5;
            }
            if (this.motionX > d5) {
                this.motionX = d5;
            }
            if (this.motionZ < -d5) {
                this.motionZ = -d5;
            }
            if (this.motionZ > d5) {
                this.motionZ = d5;
            }
            if (this.onGround) {
                this.motionX *= 0.5;
                this.motionY *= 0.5;
                this.motionZ *= 0.5;
            }
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            if (!this.onGround) {
                this.motionX *= 0.949999988079071;
                this.motionY *= 0.949999988079071;
                this.motionZ *= 0.949999988079071;
            }
        }
        this.rotationPitch = 0.0f;
        final double d28 = this.prevPosX - this.posX;
        final double d29 = this.prevPosZ - this.posZ;
        if (d28 * d28 + d29 * d29 > 0.001) {
            this.rotationYaw = (float)(Math.atan2(d29, d28) * 180.0 / 3.141592653589793);
            if (this.field_856_i) {
                this.rotationYaw += 180.0f;
            }
        }
        double d30;
        for (d30 = this.rotationYaw - this.prevRotationYaw; d30 >= 180.0; d30 -= 360.0) {}
        while (d30 < -180.0) {
            d30 += 360.0;
        }
        if (d30 < -170.0 || d30 >= 170.0) {
            this.rotationYaw += 180.0f;
            this.field_856_i = !this.field_856_i;
        }
        this.setRotation(this.rotationYaw, this.rotationPitch);
        final List<?> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.20000000298023224, 0.0, 0.20000000298023224));
        if (list != null && list.size() > 0) {
            for (int i2 = 0; i2 < list.size(); ++i2) {
                final Entity entity = (Entity)list.get(i2);
                if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityMinecart) {
                    entity.applyEntityCollision(this);
                }
            }
        }
        if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
            this.riddenByEntity = null;
        }
        if (flag && this.rand.nextInt(4) == 0) {
            --this.fuel;
            if (this.fuel < 0) {
                final double n = 0.0;
                this.pushZ = n;
                this.pushX = n;
            }
            this.worldObj.spawnParticle("largesmoke", this.posX, this.posY + 0.8, this.posZ, 0.0, 0.0, 0.0);
        }
    }
    
    @Override
    public void performHurtAnimation() {
        System.out.println("Animating hurt");
        this.minecartRockDirection = -this.minecartRockDirection;
        this.minecartTimeSinceHit = 10;
        this.minecartCurrentDamage += this.minecartCurrentDamage * 10;
    }
    
    public Vec3D func_515_a(double d, double d1, double d2, final double d3) {
        final int i = MathHelper.floor_double(d);
        int j = MathHelper.floor_double(d1);
        final int k = MathHelper.floor_double(d2);
        if (this.worldObj.getBlockId(i, j - 1, k) == Block.minecartTrack.blockID) {
            --j;
        }
        if (this.worldObj.getBlockId(i, j, k) == Block.minecartTrack.blockID) {
            final int l = this.worldObj.getBlockMetadata(i, j, k);
            d1 = j;
            if (l >= 2 && l <= 5) {
                d1 = j + 1;
            }
            final int[][] ai = EntityMinecart.field_855_j[l];
            double d4 = ai[1][0] - ai[0][0];
            double d5 = ai[1][2] - ai[0][2];
            final double d6 = Math.sqrt(d4 * d4 + d5 * d5);
            d4 /= d6;
            d5 /= d6;
            d += d4 * d3;
            d2 += d5 * d3;
            if (ai[0][1] != 0 && MathHelper.floor_double(d) - i == ai[0][0] && MathHelper.floor_double(d2) - k == ai[0][2]) {
                d1 += ai[0][1];
            }
            else if (ai[1][1] != 0 && MathHelper.floor_double(d) - i == ai[1][0] && MathHelper.floor_double(d2) - k == ai[1][2]) {
                d1 += ai[1][1];
            }
            return this.func_514_g(d, d1, d2);
        }
        return null;
    }
    
    public Vec3D func_514_g(double d, double d1, double d2) {
        final int i = MathHelper.floor_double(d);
        int j = MathHelper.floor_double(d1);
        final int k = MathHelper.floor_double(d2);
        if (this.worldObj.getBlockId(i, j - 1, k) == Block.minecartTrack.blockID) {
            --j;
        }
        if (this.worldObj.getBlockId(i, j, k) == Block.minecartTrack.blockID) {
            final int l = this.worldObj.getBlockMetadata(i, j, k);
            d1 = j;
            if (l >= 2 && l <= 5) {
                d1 = j + 1;
            }
            final int[][] ai = EntityMinecart.field_855_j[l];
            double d3 = 0.0;
            final double d4 = i + 0.5 + ai[0][0] * 0.5;
            final double d5 = j + 0.5 + ai[0][1] * 0.5;
            final double d6 = k + 0.5 + ai[0][2] * 0.5;
            final double d7 = i + 0.5 + ai[1][0] * 0.5;
            final double d8 = j + 0.5 + ai[1][1] * 0.5;
            final double d9 = k + 0.5 + ai[1][2] * 0.5;
            final double d10 = d7 - d4;
            final double d11 = (d8 - d5) * 2.0;
            final double d12 = d9 - d6;
            if (d10 == 0.0) {
                d = i + 0.5;
                d3 = d2 - k;
            }
            else if (d12 == 0.0) {
                d2 = k + 0.5;
                d3 = d - i;
            }
            else {
                final double d13 = d - d4;
                final double d14 = d2 - d6;
                final double d15 = d3 = (d13 * d10 + d14 * d12) * 2.0;
            }
            d = d4 + d10 * d3;
            d1 = d5 + d11 * d3;
            d2 = d6 + d12 * d3;
            if (d11 < 0.0) {
                ++d1;
            }
            if (d11 > 0.0) {
                d1 += 0.5;
            }
            return Vec3D.createVector(d, d1, d2);
        }
        return null;
    }
    
    @Override
    protected void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setInteger("Type", this.minecartType);
        if (this.minecartType == 2) {
            nbttagcompound.setDouble("PushX", this.pushX);
            nbttagcompound.setDouble("PushZ", this.pushZ);
            nbttagcompound.setShort("Fuel", (short)this.fuel);
        }
        else if (this.minecartType == 1) {
            final NBTTagList nbttaglist = new NBTTagList();
            for (int i = 0; i < this.cargoItems.length; ++i) {
                if (this.cargoItems[i] != null) {
                    final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                    nbttagcompound2.setByte("Slot", (byte)i);
                    this.cargoItems[i].writeToNBT(nbttagcompound2);
                    nbttaglist.setTag(nbttagcompound2);
                }
            }
            nbttagcompound.func_762_a("Items", nbttaglist);
        }
    }
    
    @Override
    protected void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.minecartType = nbttagcompound.getInteger("Type");
        if (this.minecartType == 2) {
            this.pushX = nbttagcompound.getDouble("PushX");
            this.pushZ = nbttagcompound.getDouble("PushZ");
            this.fuel = nbttagcompound.getShort("Fuel");
        }
        else if (this.minecartType == 1) {
            final NBTTagList nbttaglist = nbttagcompound.getTagList("Items");
            this.cargoItems = new ItemStack[this.getSizeInventory()];
            for (int i = 0; i < nbttaglist.tagCount(); ++i) {
                final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.tagAt(i);
                final int j = nbttagcompound2.getByte("Slot") & 0xFF;
                if (j >= 0 && j < this.cargoItems.length) {
                    this.cargoItems[j] = new ItemStack(nbttagcompound2);
                }
            }
        }
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
    
    @Override
    public void applyEntityCollision(final Entity entity) {
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        if (entity == this.riddenByEntity) {
            return;
        }
        if (entity instanceof EntityLiving && !(entity instanceof EntityPlayer) && this.minecartType == 0 && this.motionX * this.motionX + this.motionZ * this.motionZ > 0.01 && this.riddenByEntity == null && entity.entityBeingRidden == null) {
            entity.mountEntity(this);
        }
        double d = entity.posX - this.posX;
        double d2 = entity.posZ - this.posZ;
        double d3 = d * d + d2 * d2;
        if (d3 >= 9.999999747378752E-5) {
            d3 = MathHelper.sqrt_double(d3);
            d /= d3;
            d2 /= d3;
            double d4 = 1.0 / d3;
            if (d4 > 1.0) {
                d4 = 1.0;
            }
            d *= d4;
            d2 *= d4;
            d *= 0.10000000149011612;
            d2 *= 0.10000000149011612;
            d *= 1.0f - this.entityCollisionReduction;
            d2 *= 1.0f - this.entityCollisionReduction;
            d *= 0.5;
            d2 *= 0.5;
            if (entity instanceof EntityMinecart) {
                double d5 = entity.motionX + this.motionX;
                double d6 = entity.motionZ + this.motionZ;
                if (((EntityMinecart)entity).minecartType == 2 && this.minecartType != 2) {
                    this.motionX *= 0.20000000298023224;
                    this.motionZ *= 0.20000000298023224;
                    this.addVelocity(entity.motionX - d, 0.0, entity.motionZ - d2);
                    entity.motionX *= 0.699999988079071;
                    entity.motionZ *= 0.699999988079071;
                }
                else if (((EntityMinecart)entity).minecartType != 2 && this.minecartType == 2) {
                    entity.motionX *= 0.20000000298023224;
                    entity.motionZ *= 0.20000000298023224;
                    entity.addVelocity(this.motionX + d, 0.0, this.motionZ + d2);
                    this.motionX *= 0.699999988079071;
                    this.motionZ *= 0.699999988079071;
                }
                else {
                    d5 /= 2.0;
                    d6 /= 2.0;
                    this.motionX *= 0.20000000298023224;
                    this.motionZ *= 0.20000000298023224;
                    this.addVelocity(d5 - d, 0.0, d6 - d2);
                    entity.motionX *= 0.20000000298023224;
                    entity.motionZ *= 0.20000000298023224;
                    entity.addVelocity(d5 + d, 0.0, d6 + d2);
                }
            }
            else {
                this.addVelocity(-d, 0.0, -d2);
                entity.addVelocity(d / 4.0, 0.0, d2 / 4.0);
            }
        }
    }
    
    public int getSizeInventory() {
        return 27;
    }
    
    public ItemStack getStackInSlot(final int i) {
        return this.cargoItems[i];
    }
    
    public ItemStack decrStackSize(final int i, final int j) {
        if (this.cargoItems[i] == null) {
            return null;
        }
        if (this.cargoItems[i].stackSize <= j) {
            final ItemStack itemstack = this.cargoItems[i];
            this.cargoItems[i] = null;
            return itemstack;
        }
        final ItemStack itemstack2 = this.cargoItems[i].splitStack(j);
        if (this.cargoItems[i].stackSize == 0) {
            this.cargoItems[i] = null;
        }
        return itemstack2;
    }
    
    public void setInventorySlotContents(final int i, final ItemStack itemstack) {
        this.cargoItems[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
    }
    
    public String getInvName() {
        return "Minecart";
    }
    
    public int getInventoryStackLimit() {
        return 64;
    }
    
    public void onInventoryChanged() {
    }
    
    @Override
    public boolean interact(final EntityPlayer entityplayer) {
        if (this.minecartType == 0) {
            if (!this.worldObj.multiplayerWorld) {
                entityplayer.mountEntity(this);
            }
        }
        else if (this.minecartType == 1) {
            if (!this.worldObj.multiplayerWorld) {
                entityplayer.displayGUIChest(this);
            }
        }
        else if (this.minecartType == 2) {
            final ItemStack itemstack = entityplayer.inventory.getCurrentItem();
            if (itemstack != null && itemstack.itemID == Item.coal.shiftedIndex) {
                final ItemStack itemStack = itemstack;
                if (--itemStack.stackSize == 0) {
                    entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, null);
                }
                this.fuel += 1200;
            }
            this.pushX = this.posX - entityplayer.posX;
            this.pushZ = this.posZ - entityplayer.posZ;
        }
        return true;
    }
    
    @Override
    public void setPositionAndRotation2(final double d, final double d1, final double d2, final float f, final float f1, final int i) {
        this.field_853_l = d;
        this.field_852_m = d1;
        this.field_851_n = d2;
        this.field_850_o = f;
        this.field_849_p = f1;
        this.field_854_k = i;
    }
    
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return true;
    }
}
