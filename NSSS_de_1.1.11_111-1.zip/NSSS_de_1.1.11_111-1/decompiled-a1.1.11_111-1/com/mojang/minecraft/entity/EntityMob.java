package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;

public class EntityMob extends EntityAnimals
{
    public EntityMob(final World world) {
        super(world);
        this.texture = "/char.png";
        this.setSize(0.5f, 2.0f);
        this.isRunning = true;
    }
    
    @Override
    public double getRealMoveSpeed() {
        return 1.0;
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected String idleSound() {
        return "";
    }
    
    @Override
    protected String hurtSound() {
        return "random.hurt";
    }
    
    @Override
    protected String deathSound() {
        return "random.hurt";
    }
    
    @Override
    public boolean interact(final EntityPlayer entityplayer) {
        return false;
    }
    
    @Override
    protected int deathDropItem() {
        return 0;
    }
}
