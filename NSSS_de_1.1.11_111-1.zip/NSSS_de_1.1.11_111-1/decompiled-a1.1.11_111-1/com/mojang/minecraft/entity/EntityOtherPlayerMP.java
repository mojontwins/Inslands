package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.item.*;

public class EntityOtherPlayerMP extends EntityPlayer
{
    private int field_785_bg;
    private double field_784_bh;
    private double field_783_bi;
    private double field_782_bj;
    private double field_780_bk;
    private double field_786_bl;
    float field_781_a;
    
    public EntityOtherPlayerMP(final World world, final String s) {
        super(world);
        this.field_781_a = 0.0f;
        this.playerName = s;
        this.yOffset = 0.0f;
        this.stepHeight = 0.0f;
        if (s != null && s.length() > 0) {
            SkinManager.getSkinFromName(this.playerName, this);
        }
        this.noClip = true;
        this.renderDistanceWeight = 10.0;
    }
    
    @Override
    public void setPositionAndRotation2(final double d, final double d1, final double d2, final float f, final float f1, final int i) {
        this.yOffset = 0.0f;
        this.field_784_bh = d;
        this.field_783_bi = d1;
        this.field_782_bj = d2;
        this.field_780_bk = f;
        this.field_786_bl = f1;
        this.field_785_bg = i;
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        this.field_705_Q = this.limbSwingAmount;
        final double d = this.posX - this.prevPosX;
        final double d2 = this.posZ - this.prevPosZ;
        float f = MathHelper.sqrt_double(d * d + d2 * d2) * 4.0f;
        if (f > 1.0f) {
            f = 1.0f;
        }
        this.limbSwingAmount += (f - this.limbSwingAmount) * 0.4f;
        this.limbSwing += this.limbSwingAmount;
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
    
    @Override
    public void onLivingUpdate() {
        super.updateEntityActionState();
        if (this.field_785_bg > 0) {
            final double d = this.posX + (this.field_784_bh - this.posX) / this.field_785_bg;
            final double d2 = this.posY + (this.field_783_bi - this.posY) / this.field_785_bg;
            final double d3 = this.posZ + (this.field_782_bj - this.posZ) / this.field_785_bg;
            double d4;
            for (d4 = this.field_780_bk - this.rotationYaw; d4 < -180.0; d4 += 360.0) {}
            while (d4 >= 180.0) {
                d4 -= 360.0;
            }
            this.rotationYaw += (float)(d4 / this.field_785_bg);
            this.rotationPitch += (float)((this.field_786_bl - this.rotationPitch) / this.field_785_bg);
            --this.field_785_bg;
            this.setPosition(d, d2, d3);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }
        this.field_775_e = this.field_774_f;
        float f = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        float f2 = (float)Math.atan(-this.motionY * 0.20000000298023224) * 15.0f;
        if (f > 0.1f) {
            f = 0.1f;
        }
        if (!this.onGround || this.health <= 0) {
            f = 0.0f;
        }
        if (this.onGround || this.health <= 0) {
            f2 = 0.0f;
        }
        this.field_774_f += (f - this.field_774_f) * 0.4f;
        this.field_709_M += (f2 - this.field_709_M) * 0.8f;
    }
    
    @Override
    public void outfitWithItem(final int i, final int j, final int k) {
        ItemStack itemstack = null;
        if (j >= 0) {
            itemstack = new ItemStack(j, 1, k);
        }
        if (i == 0) {
            this.inventory.mainInventory[this.inventory.currentItem] = itemstack;
        }
        else {
            this.inventory.armorInventory[i - 1] = itemstack;
        }
    }
}
