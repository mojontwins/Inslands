package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntityCow extends EntityAnimals
{
    public boolean field_761_a;
    
    public EntityCow(final World world) {
        super(world);
        this.field_761_a = false;
        this.scoreYield = 10;
        this.texture = "/mob/cow.png";
        this.setSize(0.9f, 1.3f);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected String idleSound() {
        return "mob.cow";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.cowhurt";
    }
    
    @Override
    protected String deathSound() {
        return "mob.cowhurt";
    }
    
    @Override
    protected float func_413_f() {
        return 0.4f;
    }
    
    @Override
    protected int deathDropItem() {
        return Item.leather.shiftedIndex;
    }
    
    @Override
    public boolean interact(final EntityPlayer entityplayer) {
        final ItemStack itemstack = entityplayer.inventory.getCurrentItem();
        if (itemstack != null && itemstack.itemID == Item.bucketEmpty.shiftedIndex) {
            entityplayer.inventory.setInventorySlotContents(entityplayer.inventory.currentItem, new ItemStack(Item.bucketMilk));
            return true;
        }
        return false;
    }
}
