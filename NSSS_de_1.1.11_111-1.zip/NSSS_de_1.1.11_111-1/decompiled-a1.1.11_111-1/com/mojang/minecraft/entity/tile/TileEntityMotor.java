package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.level.*;

public class TileEntityMotor extends TileEntityGear
{
    public int getGearPower(final World world, final int x, final int y, final int z) {
        return this.gearPower;
    }
}
