package com.mojang.minecraft.entity.tile;

import java.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;

public class TileEntityMobSpawnerRenderer extends TileEntitySpecialRenderer
{
    private Map<String, Entity> entityStringMap;
    
    public TileEntityMobSpawnerRenderer() {
        this.entityStringMap = new HashMap<String, Entity>();
    }
    
    public void renderMob(final TileEntityMobSpawner tileentitymobspawner, final double posX, final double posY, final double posZ, final float yaw) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)posX + 0.5f, (float)posY, (float)posZ + 0.5f);
        final TileEntity tileEntity = tileentitymobspawner;
        Entity entity = this.entityStringMap.get(tileentitymobspawner.getEntityID());
        if (entity == null) {
            entity = EntityList.createEntityByIdFromName(tileentitymobspawner.getEntityID(), null);
            this.entityStringMap.put(tileentitymobspawner.getEntityID(), entity);
        }
        if (entity != null) {
            entity.setWorld(tileentitymobspawner.world);
            final float entityPreviewScale = 0.4375f;
            GL11.glTranslatef(0.0f, 0.4f, 0.0f);
            GL11.glRotatef((float)(tileentitymobspawner.field_830_d + (tileentitymobspawner.field_831_c - tileentitymobspawner.field_830_d) * yaw) * 10.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
            GL11.glTranslatef(0.0f, -0.4f, 0.0f);
            GL11.glScalef(entityPreviewScale, entityPreviewScale, entityPreviewScale);
            entity.setLocationAndAngles(posX, posY, posZ, 0.0f, 0.0f);
            RenderManager.subManager.renderEntityWithPosYaw(entity, 0.0, 0.0, 0.0, 0.0f, yaw);
        }
        GL11.glPopMatrix();
    }
    
    @Override
    public void renderTileEntityAt(final TileEntity tileentity, final double d, final double d1, final double d2, final float f) {
        this.renderMob((TileEntityMobSpawner)tileentity, d, d1, d2, f);
    }
}
