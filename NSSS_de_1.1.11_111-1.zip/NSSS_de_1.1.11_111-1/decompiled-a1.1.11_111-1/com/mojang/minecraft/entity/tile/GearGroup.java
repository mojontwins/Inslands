package com.mojang.minecraft.entity.tile;

import java.util.*;
import com.mojang.minecraft.level.*;

public class GearGroup
{
    private ArrayList<TileEntityGear> gearCache;
    private World mcWorld;
    private int limit;
    private boolean isPowered;
    
    public GearGroup(final World world) {
        this.mcWorld = world;
        this.gearCache = new ArrayList<TileEntityGear>();
        this.limit = 0;
    }
    
    public void setLimit(final int lim) {
        this.limit = lim;
    }
    
    public int getLimit() {
        return this.limit;
    }
    
    public void addToLimit(final int lim) {
        this.limit += lim;
    }
    
    public void subFromLimit(final int lim) {
        this.limit -= lim;
    }
    
    public void addToGearGroup(final TileEntityGear gearEntity) {
        System.out.println("Adding " + gearEntity);
        this.gearCache.add(gearEntity);
    }
    
    public void removeFromGearGroup(final TileEntityGear gearEntity) {
        System.out.println("Removing " + gearEntity);
        this.gearCache.remove(gearEntity);
    }
    
    public void mergeGroup(final GearGroup newgroup) {
        for (int i = 0; i < newgroup.getGearGroupSize(); ++i) {
            this.addToGearGroup(newgroup.getGear(0));
            newgroup.removeFromGearGroup(newgroup.getGear(0));
        }
    }
    
    public TileEntityGear getGear(final int index) {
        return this.gearCache.get(index);
    }
    
    public boolean hasGear(final TileEntityGear gearEntity) {
        return this.gearCache.contains(gearEntity);
    }
    
    public int getGearGroupSize() {
        return this.gearCache.size();
    }
    
    public boolean isBelowThreshold(final int threshold) {
        return this.gearCache.size() < threshold;
    }
    
    public boolean powerGearCache() {
        System.out.println("Being powered!");
        if (this.gearCache.size() < this.limit) {
            for (int i = 0; i < this.gearCache.size(); ++i) {
                this.gearCache.get(i).setGearActive(this.mcWorld, 1);
            }
            return this.isPowered = true;
        }
        for (int i = 0; i < this.gearCache.size(); ++i) {
            this.gearCache.get(i).setGearActive(this.mcWorld, 0);
        }
        return this.isPowered = false;
    }
    
    public boolean unPowerGearCache() {
        for (int i = 0; i < this.gearCache.size() - 1; ++i) {
            this.gearCache.get(i).setGearActive(this.mcWorld, 0);
        }
        this.isPowered = false;
        return true;
    }
    
    public boolean checkPowered() {
        return this.isPowered;
    }
}
