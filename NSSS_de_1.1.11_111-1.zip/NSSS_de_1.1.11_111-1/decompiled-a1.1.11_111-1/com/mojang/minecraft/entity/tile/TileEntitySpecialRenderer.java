package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.render.*;

public abstract class TileEntitySpecialRenderer
{
    protected TileEntityRenderer field_1411_a;
    
    public abstract void renderTileEntityAt(final TileEntity p0, final double p1, final double p2, final double p3, final float p4);
    
    protected void func_927_a(final String s) {
        final RenderEngine renderengine = this.field_1411_a.field_1550_e;
        renderengine.bindTex(renderengine.getTex(s));
    }
    
    public void func_928_a(final TileEntityRenderer tileentityrenderer) {
        this.field_1411_a = tileentityrenderer;
    }
    
    public FontRenderer func_929_a() {
        return this.field_1411_a.getFontRenderer();
    }
}
