package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.*;

public class TileEntityChest extends TileEntity implements IInventory
{
    private ItemStack[] field_827_a;
    
    public TileEntityChest() {
        this.field_827_a = new ItemStack[36];
    }
    
    public int getSizeInventory() {
        return 27;
    }
    
    public ItemStack getStackInSlot(final int i) {
        return this.field_827_a[i];
    }
    
    public ItemStack decrStackSize(final int i, final int j) {
        if (this.field_827_a[i] == null) {
            return null;
        }
        if (this.field_827_a[i].stackSize <= j) {
            final ItemStack itemstack = this.field_827_a[i];
            this.field_827_a[i] = null;
            this.onInventoryChanged();
            return itemstack;
        }
        final ItemStack itemstack2 = this.field_827_a[i].splitStack(j);
        if (this.field_827_a[i].stackSize == 0) {
            this.field_827_a[i] = null;
        }
        this.onInventoryChanged();
        return itemstack2;
    }
    
    public void setInventorySlotContents(final int i, final ItemStack itemstack) {
        this.field_827_a[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
        this.onInventoryChanged();
    }
    
    public String getInvName() {
        return "Chest";
    }
    
    @Override
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        super.func_482_a(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Items");
        this.field_827_a = new ItemStack[this.getSizeInventory()];
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.tagAt(i);
            final int j = nbttagcompound2.getByte("Slot") & 0xFF;
            if (j >= 0 && j < this.field_827_a.length) {
                this.field_827_a[j] = new ItemStack(nbttagcompound2);
            }
        }
    }
    
    @Override
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        super.func_481_b(nbttagcompound);
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.field_827_a.length; ++i) {
            if (this.field_827_a[i] != null) {
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                nbttagcompound2.setByte("Slot", (byte)i);
                this.field_827_a[i].writeToNBT(nbttagcompound2);
                nbttaglist.setTag(nbttagcompound2);
            }
        }
        nbttagcompound.func_762_a("Items", nbttaglist);
    }
    
    public int getInventoryStackLimit() {
        return 64;
    }
    
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return this.world.getBlockTileEntity(this.x, this.y, this.z) == this && entityplayer.getDistanceSq(this.x + 0.5, this.y + 0.5, this.z + 0.5) <= 64.0;
    }
}
