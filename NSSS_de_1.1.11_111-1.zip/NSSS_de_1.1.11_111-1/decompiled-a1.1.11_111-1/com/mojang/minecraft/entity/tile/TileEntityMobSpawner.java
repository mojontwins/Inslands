package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.nbt.*;

public class TileEntityMobSpawner extends TileEntity
{
    public int delay;
    public String entityID;
    public double field_831_c;
    public double field_830_d;
    
    public TileEntityMobSpawner() {
        this.delay = -1;
        this.field_830_d = 0.0;
        this.entityID = "Pig";
        this.delay = 20;
    }
    
    public boolean func_484_a() {
        return this.world.getClosestPlayer(this.x + 0.5, this.y + 0.5, this.z + 0.5, 16.0) != null;
    }
    
    @Override
    public void func_475_b() {
        this.field_830_d = this.field_831_c;
        if (!this.func_484_a()) {
            return;
        }
        final double d = this.x + this.world.rand.nextFloat();
        final double d2 = this.y + this.world.rand.nextFloat();
        final double d3 = this.z + this.world.rand.nextFloat();
        this.world.spawnParticle("smoke", d, d2, d3, 0.0, 0.0, 0.0);
        this.world.spawnParticle("flame", d, d2, d3, 0.0, 0.0, 0.0);
        this.field_831_c += 1000.0f / (this.delay + 200.0f);
        while (this.field_831_c > 360.0) {
            this.field_831_c -= 360.0;
            this.field_830_d -= 360.0;
        }
        if (this.delay == -1) {
            this.func_483_c();
        }
        if (this.delay > 0) {
            --this.delay;
            return;
        }
        final byte byte0 = 4;
        for (int i = 0; i < byte0; ++i) {
            final EntityLiving entityliving = (EntityLiving)EntityList.createEntityByIdFromName(this.entityID, this.world);
            if (entityliving == null || this.world.multiplayerWorld) {
                return;
            }
            final int j = this.world.getEntitiesWithinAABB(entityliving.getClass(), AxisAlignedBB.getBoundingBoxFromPool(this.x, this.y, this.z, this.x + 1, this.y + 1, this.z + 1).expand(8.0, 4.0, 8.0)).size();
            if (j >= 6) {
                this.func_483_c();
                return;
            }
            final double d4 = this.x + (this.world.rand.nextDouble() - this.world.rand.nextDouble()) * 4.0;
            final double d5 = this.y + this.world.rand.nextInt(3) - 1;
            final double d6 = this.z + (this.world.rand.nextDouble() - this.world.rand.nextDouble()) * 4.0;
            entityliving.setLocationAndAngles(d4, d5, d6, this.world.rand.nextFloat() * 360.0f, 0.0f);
            if (entityliving.shouldSpawnOnTile()) {
                this.world.entityJoinedWorld(entityliving);
                this.world.playSoundEffect(this.x, this.y, this.z, "random.breath", 1.0f, 1.0f);
                for (int k = 0; k < 20; ++k) {
                    final double d7 = this.x + 0.5 + (this.world.rand.nextFloat() - 0.5) * 2.0;
                    final double d8 = this.y + 0.5 + (this.world.rand.nextFloat() - 0.5) * 2.0;
                    final double d9 = this.z + 0.5 + (this.world.rand.nextFloat() - 0.5) * 2.0;
                    this.world.spawnParticle("smoke", d7, d8, d9, 0.0, 0.0, 0.0);
                    this.world.spawnParticle("flame", d7, d8, d9, 0.0, 0.0, 0.0);
                }
                entityliving.func_415_z();
                this.func_483_c();
            }
        }
        super.func_475_b();
    }
    
    private void func_483_c() {
        this.delay = 200 + this.world.rand.nextInt(600);
    }
    
    @Override
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        super.func_482_a(nbttagcompound);
        this.entityID = nbttagcompound.getString("EntityId");
        this.delay = nbttagcompound.getShort("Delay");
    }
    
    @Override
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        super.func_481_b(nbttagcompound);
        nbttagcompound.setString("EntityId", this.entityID);
        nbttagcompound.setShort("Delay", (short)this.delay);
    }
    
    public String getEntityID() {
        return this.entityID;
    }
}
