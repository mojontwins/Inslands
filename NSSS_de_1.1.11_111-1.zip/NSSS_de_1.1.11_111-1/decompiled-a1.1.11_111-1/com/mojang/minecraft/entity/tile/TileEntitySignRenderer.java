package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.render.*;

public class TileEntitySignRenderer extends TileEntitySpecialRenderer
{
    private SignModel field_1413_b;
    
    public TileEntitySignRenderer() {
        this.field_1413_b = new SignModel();
    }
    
    public void func_932_a(final TileEntitySign tileentitysign, final double d, final double d1, final double d2, final float f) {
        final Block block = tileentitysign.func_478_g();
        GL11.glPushMatrix();
        final float f2 = 0.6666667f;
        if (block == Block.signPost) {
            GL11.glTranslatef((float)d + 0.5f, (float)d1 + 0.75f * f2, (float)d2 + 0.5f);
            final float f3 = tileentitysign.func_479_f() * 360 / 16.0f;
            GL11.glRotatef(-f3, 0.0f, 1.0f, 0.0f);
            this.field_1413_b.field_1345_b.showModel = true;
        }
        else {
            final int i = tileentitysign.func_479_f();
            float f4 = 0.0f;
            if (i == 2) {
                f4 = 180.0f;
            }
            if (i == 4) {
                f4 = 90.0f;
            }
            if (i == 5) {
                f4 = -90.0f;
            }
            GL11.glTranslatef((float)d + 0.5f, (float)d1 + 0.75f * f2, (float)d2 + 0.5f);
            GL11.glRotatef(-f4, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(0.0f, -0.3125f, -0.4375f);
            this.field_1413_b.field_1345_b.showModel = false;
        }
        this.func_927_a("/item/sign.png");
        GL11.glPushMatrix();
        GL11.glScalef(f2, -f2, -f2);
        this.field_1413_b.func_887_a();
        GL11.glPopMatrix();
        final FontRenderer fontrenderer = this.func_929_a();
        final float f5 = 0.01666667f * f2;
        GL11.glTranslatef(0.0f, 0.5f * f2, 0.07f * f2);
        GL11.glScalef(f5, -f5, f5);
        GL11.glNormal3f(0.0f, 0.0f, -1.0f * f5);
        GL11.glDepthMask(false);
        final int j = 0;
        for (int k = 0; k < tileentitysign.signText.length; ++k) {
            String s = tileentitysign.signText[k];
            if (k == tileentitysign.lineBeingEdited) {
                s = "> " + s + " <";
                fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, k * 10 - tileentitysign.signText.length * 5, j);
            }
            else {
                fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, k * 10 - tileentitysign.signText.length * 5, j);
            }
        }
        GL11.glDepthMask(true);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void renderTileEntityAt(final TileEntity tileentity, final double d, final double d1, final double d2, final float f) {
        this.func_932_a((TileEntitySign)tileentity, d, d1, d2, f);
    }
}
