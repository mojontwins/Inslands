package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.level.tile.*;

public class TileEntity
{
    private static Map<String, Class<?>> nameToClassMap;
    private static Map<Class<?>, String> classToNameMap;
    public World world;
    public int x;
    public int y;
    public int z;
    
    static {
        TileEntity.nameToClassMap = new HashMap<String, Class<?>>();
        TileEntity.classToNameMap = new HashMap<Class<?>, String>();
        func_476_a(TileEntityFurnace.class, "Furnace");
        func_476_a(TileEntityChest.class, "Chest");
        func_476_a(TileEntitySign.class, "Sign");
        func_476_a(TileEntityMobSpawner.class, "MobSpawner");
        func_476_a(TileEntityGear.class, "Gear");
        func_476_a(TileEntityMotor.class, "Motor");
    }
    
    private static void func_476_a(final Class<?> class1, final String s) {
        if (TileEntity.classToNameMap.containsKey(s)) {
            throw new IllegalArgumentException("Duplicate id: " + s);
        }
        TileEntity.nameToClassMap.put(s, class1);
        TileEntity.classToNameMap.put(class1, s);
    }
    
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        this.x = nbttagcompound.getInteger("x");
        this.y = nbttagcompound.getInteger("y");
        this.z = nbttagcompound.getInteger("z");
    }
    
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        final String s = TileEntity.classToNameMap.get(this.getClass());
        if (s == null) {
            throw new RuntimeException(this.getClass() + " is missing a mapping! This is a bug!");
        }
        nbttagcompound.setString("id", s);
        nbttagcompound.setInteger("x", this.x);
        nbttagcompound.setInteger("y", this.y);
        nbttagcompound.setInteger("z", this.z);
    }
    
    public void func_475_b() {
    }
    
    public static TileEntity createAndLoadEntity(final NBTTagCompound nbttagcompound) {
        TileEntity tileentity = null;
        try {
            final Class<?> class1 = TileEntity.nameToClassMap.get(nbttagcompound.getString("id"));
            if (class1 != null) {
                tileentity = (TileEntity)class1.newInstance();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (tileentity != null) {
            tileentity.func_482_a(nbttagcompound);
        }
        else {
            System.out.println("Skipping TileEntity with id " + nbttagcompound.getString("id"));
        }
        return tileentity;
    }
    
    public int func_479_f() {
        return this.world.getBlockMetadata(this.x, this.y, this.z);
    }
    
    public void onInventoryChanged() {
        if (this.world != null) {
            this.world.cacheTileEntity(this.x, this.y, this.z, this);
        }
    }
    
    public double func_480_a(final double d, final double d1, final double d2) {
        final double d3 = this.x + 0.5 - d;
        final double d4 = this.y + 0.5 - d1;
        final double d5 = this.z + 0.5 - d2;
        return d3 * d3 + d4 * d4 + d5 * d5;
    }
    
    public Block func_478_g() {
        return Block.allBlocks[this.world.getBlockId(this.x, this.y, this.z)];
    }
    
    static Class<?> _mthclass$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException classnotfoundexception) {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }
}
