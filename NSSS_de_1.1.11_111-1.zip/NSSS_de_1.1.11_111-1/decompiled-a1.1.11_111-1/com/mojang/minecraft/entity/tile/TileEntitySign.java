package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.nbt.*;

public class TileEntitySign extends TileEntity
{
    public String[] signText;
    public int lineBeingEdited;
    
    public TileEntitySign() {
        this.signText = new String[] { "", "", "", "" };
        this.lineBeingEdited = -1;
    }
    
    @Override
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        super.func_481_b(nbttagcompound);
        nbttagcompound.setString("Text1", this.signText[0]);
        nbttagcompound.setString("Text2", this.signText[1]);
        nbttagcompound.setString("Text3", this.signText[2]);
        nbttagcompound.setString("Text4", this.signText[3]);
    }
    
    @Override
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        super.func_482_a(nbttagcompound);
        for (int i = 0; i < 4; ++i) {
            this.signText[i] = nbttagcompound.getString("Text" + (i + 1));
            if (this.signText[i].length() > 15) {
                this.signText[i] = this.signText[i].substring(0, 15);
            }
        }
    }
}
