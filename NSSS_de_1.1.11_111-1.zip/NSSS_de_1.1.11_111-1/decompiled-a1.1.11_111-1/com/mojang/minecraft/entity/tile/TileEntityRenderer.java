package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;
import java.util.*;
import org.lwjgl.opengl.*;

public class TileEntityRenderer
{
    private Map<Class<?>, TileEntitySpecialRenderer> field_1542_m;
    public static TileEntityRenderer instance;
    private FontRenderer field_1541_n;
    public static double field_1553_b;
    public static double field_1552_c;
    public static double field_1551_d;
    public RenderEngine field_1550_e;
    public World field_1549_f;
    public EntityPlayer field_1548_g;
    public float field_1547_h;
    public float field_1546_i;
    public double field_1545_j;
    public double field_1544_k;
    public double field_1543_l;
    
    static {
        TileEntityRenderer.instance = new TileEntityRenderer();
    }
    
    private TileEntityRenderer() {
        (this.field_1542_m = new HashMap<Class<?>, TileEntitySpecialRenderer>()).put(TileEntitySign.class, new TileEntitySignRenderer());
        this.field_1542_m.put(TileEntityMobSpawner.class, new TileEntityMobSpawnerRenderer());
        for (final TileEntitySpecialRenderer tileentityspecialrenderer : this.field_1542_m.values()) {
            tileentityspecialrenderer.func_928_a(this);
        }
    }
    
    public TileEntitySpecialRenderer getSpecialRendererForClass(final Class<?> class1) {
        TileEntitySpecialRenderer tileentityspecialrenderer = this.field_1542_m.get(class1);
        if (tileentityspecialrenderer == null && class1 != TileEntity.class) {
            tileentityspecialrenderer = this.getSpecialRendererForClass(class1.getSuperclass());
            this.field_1542_m.put(class1, tileentityspecialrenderer);
        }
        return tileentityspecialrenderer;
    }
    
    public boolean checkIfTileEntity(final TileEntity tileentity) {
        return tileentity != null && this.getSpecialRendererForEntity(tileentity) != null;
    }
    
    public TileEntitySpecialRenderer getSpecialRendererForEntity(final TileEntity tileentity) {
        return this.getSpecialRendererForClass(tileentity.getClass());
    }
    
    public void cacheActiveRenderInfo(final World world, final RenderEngine renderengine, final FontRenderer fontrenderer, final EntityPlayer entityplayer, final float f) {
        this.field_1549_f = world;
        this.field_1550_e = renderengine;
        this.field_1548_g = entityplayer;
        this.field_1541_n = fontrenderer;
        this.field_1547_h = entityplayer.prevRotationYaw + (entityplayer.rotationYaw - entityplayer.prevRotationYaw) * f;
        this.field_1546_i = entityplayer.prevRotationPitch + (entityplayer.rotationPitch - entityplayer.prevRotationPitch) * f;
        this.field_1545_j = entityplayer.lastTickPosX + (entityplayer.posX - entityplayer.lastTickPosX) * f;
        this.field_1544_k = entityplayer.lastTickPosY + (entityplayer.posY - entityplayer.lastTickPosY) * f;
        this.field_1543_l = entityplayer.lastTickPosZ + (entityplayer.posZ - entityplayer.lastTickPosZ) * f;
    }
    
    public void renderTileEntity(final TileEntity tileentity, final float f) {
        if (tileentity.func_480_a(this.field_1545_j, this.field_1544_k, this.field_1543_l) < 4096.0) {
            final float f2 = this.field_1549_f.getBrightness(tileentity.x, tileentity.y, tileentity.z);
            GL11.glColor3f(f2, f2, f2);
            this.renderTileEntityAt(tileentity, tileentity.x - TileEntityRenderer.field_1553_b, tileentity.y - TileEntityRenderer.field_1552_c, tileentity.z - TileEntityRenderer.field_1551_d, f);
        }
    }
    
    public void renderTileEntityAt(final TileEntity tileentity, final double d, final double d1, final double d2, final float f) {
        final TileEntitySpecialRenderer tileentityspecialrenderer = this.getSpecialRendererForEntity(tileentity);
        if (tileentityspecialrenderer != null) {
            tileentityspecialrenderer.renderTileEntityAt(tileentity, d, d1, d2, f);
        }
    }
    
    public FontRenderer getFontRenderer() {
        return this.field_1541_n;
    }
}
