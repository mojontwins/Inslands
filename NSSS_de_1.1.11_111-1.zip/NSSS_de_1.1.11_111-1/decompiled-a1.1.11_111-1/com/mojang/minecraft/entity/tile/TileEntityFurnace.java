package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.*;

public class TileEntityFurnace extends TileEntity implements IInventory
{
    private ItemStack[] furnaceItemStacks;
    public int furnaceBurnTime;
    public int currentItemBurnTime;
    public int furnaceCookTime;
    
    public TileEntityFurnace() {
        this.furnaceItemStacks = new ItemStack[3];
        this.furnaceBurnTime = 0;
        this.currentItemBurnTime = 0;
        this.furnaceCookTime = 0;
    }
    
    public int getSizeInventory() {
        return this.furnaceItemStacks.length;
    }
    
    public ItemStack getStackInSlot(final int i) {
        return this.furnaceItemStacks[i];
    }
    
    public ItemStack decrStackSize(final int i, final int j) {
        if (this.furnaceItemStacks[i] == null) {
            return null;
        }
        if (this.furnaceItemStacks[i].stackSize <= j) {
            final ItemStack itemstack = this.furnaceItemStacks[i];
            this.furnaceItemStacks[i] = null;
            return itemstack;
        }
        final ItemStack itemstack2 = this.furnaceItemStacks[i].splitStack(j);
        if (this.furnaceItemStacks[i].stackSize == 0) {
            this.furnaceItemStacks[i] = null;
        }
        return itemstack2;
    }
    
    public void setInventorySlotContents(final int i, final ItemStack itemstack) {
        this.furnaceItemStacks[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
    }
    
    public String getInvName() {
        return "Chest";
    }
    
    @Override
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        super.func_482_a(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Items");
        this.furnaceItemStacks = new ItemStack[this.getSizeInventory()];
        for (int i = 0; i < nbttaglist.tagCount(); ++i) {
            final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.tagAt(i);
            final byte byte0 = nbttagcompound2.getByte("Slot");
            if (byte0 >= 0 && byte0 < this.furnaceItemStacks.length) {
                this.furnaceItemStacks[byte0] = new ItemStack(nbttagcompound2);
            }
        }
        this.furnaceBurnTime = nbttagcompound.getShort("BurnTime");
        this.furnaceCookTime = nbttagcompound.getShort("CookTime");
        this.currentItemBurnTime = this.func_488_a(this.furnaceItemStacks[1]);
    }
    
    @Override
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        super.func_481_b(nbttagcompound);
        nbttagcompound.setShort("BurnTime", (short)this.furnaceBurnTime);
        nbttagcompound.setShort("CookTime", (short)this.furnaceCookTime);
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.furnaceItemStacks.length; ++i) {
            if (this.furnaceItemStacks[i] != null) {
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                nbttagcompound2.setByte("Slot", (byte)i);
                this.furnaceItemStacks[i].writeToNBT(nbttagcompound2);
                nbttaglist.setTag(nbttagcompound2);
            }
        }
        nbttagcompound.func_762_a("Items", nbttaglist);
    }
    
    public int getInventoryStackLimit() {
        return 64;
    }
    
    public int getCookProgressScaled(final int i) {
        return this.furnaceCookTime * i / 200;
    }
    
    public int getBurnTimeRemainingScaled(final int i) {
        if (this.currentItemBurnTime == 0) {
            this.currentItemBurnTime = 200;
        }
        return this.furnaceBurnTime * i / this.currentItemBurnTime;
    }
    
    public boolean isBurning() {
        return this.furnaceBurnTime > 0;
    }
    
    @Override
    public void func_475_b() {
        final boolean flag = this.furnaceBurnTime > 0;
        boolean flag2 = false;
        if (this.furnaceBurnTime > 0) {
            --this.furnaceBurnTime;
        }
        if (!this.world.multiplayerWorld) {
            if (this.furnaceBurnTime == 0 && this.func_491_j()) {
                final int func_488_a = this.func_488_a(this.furnaceItemStacks[1]);
                this.furnaceBurnTime = func_488_a;
                this.currentItemBurnTime = func_488_a;
                if (this.furnaceBurnTime > 0) {
                    flag2 = true;
                    if (this.furnaceItemStacks[1] != null) {
                        final ItemStack itemStack = this.furnaceItemStacks[1];
                        --itemStack.stackSize;
                        if (this.furnaceItemStacks[1].stackSize == 0) {
                            this.furnaceItemStacks[1] = null;
                        }
                    }
                }
            }
            if (this.isBurning() && this.func_491_j()) {
                ++this.furnaceCookTime;
                if (this.furnaceCookTime == 200) {
                    this.furnaceCookTime = 0;
                    this.func_487_i();
                    flag2 = true;
                }
            }
            else {
                this.furnaceCookTime = 0;
            }
            if (flag != this.furnaceBurnTime > 0) {
                flag2 = true;
                BlockFurnace.func_285_a(this.furnaceBurnTime > 0, this.world, this.x, this.y, this.z);
            }
        }
        if (flag2) {
            this.onInventoryChanged();
        }
    }
    
    private boolean func_491_j() {
        if (this.furnaceItemStacks[0] == null) {
            return false;
        }
        final int i = this.func_486_d(this.furnaceItemStacks[0].getItem().shiftedIndex);
        return i >= 0 && (this.furnaceItemStacks[2] == null || (this.furnaceItemStacks[2].itemID == i && ((this.furnaceItemStacks[2].stackSize < this.getInventoryStackLimit() && this.furnaceItemStacks[2].stackSize < this.furnaceItemStacks[2].getMaxStackSize()) || this.furnaceItemStacks[2].stackSize < Item.itemsList[i].func_200_b())));
    }
    
    public void func_487_i() {
        if (!this.func_491_j()) {
            return;
        }
        final int i = this.func_486_d(this.furnaceItemStacks[0].getItem().shiftedIndex);
        if (this.furnaceItemStacks[2] == null) {
            this.furnaceItemStacks[2] = new ItemStack(i, 1);
        }
        else if (this.furnaceItemStacks[2].itemID == i) {
            final ItemStack itemStack = this.furnaceItemStacks[2];
            ++itemStack.stackSize;
        }
        final ItemStack itemStack2 = this.furnaceItemStacks[0];
        --itemStack2.stackSize;
        if (this.furnaceItemStacks[0].stackSize <= 0) {
            this.furnaceItemStacks[0] = null;
        }
    }
    
    private int func_486_d(final int i) {
        if (i == Block.oreIron.blockID) {
            return Item.ingotIron.shiftedIndex;
        }
        if (i == Block.oreGold.blockID) {
            return Item.ingotGold.shiftedIndex;
        }
        if (i == Block.oreDiamond.blockID) {
            return Item.diamond.shiftedIndex;
        }
        if (i == Block.oreCopper.blockID) {
            return Item.ingotCopper.shiftedIndex;
        }
        if (i == Block.sand.blockID) {
            return Block.glass.blockID;
        }
        if (i == Item.porkRaw.shiftedIndex) {
            return Item.porkCooked.shiftedIndex;
        }
        if (i == Block.cobblestone.blockID) {
            return Block.stone.blockID;
        }
        if (i == Item.clay.shiftedIndex) {
            return Item.brick.shiftedIndex;
        }
        if (i == Block.wood.blockID) {
            return Item.coal.shiftedIndex;
        }
        if (i == Block.cactus.blockID) {
            return Item.dyeGreen.shiftedIndex;
        }
        if (i == Item.egg.shiftedIndex) {
            return Item.eggCooked.shiftedIndex;
        }
        if (i == Item.fishRaw.shiftedIndex) {
            return Item.fishCooked.shiftedIndex;
        }
        if (i == Item.silk.shiftedIndex) {
            return Item.carbonFilament.shiftedIndex;
        }
        return -1;
    }
    
    private int func_488_a(final ItemStack itemstack) {
        if (itemstack == null) {
            return 0;
        }
        final int i = itemstack.getItem().shiftedIndex;
        if (i < 256 && Block.allBlocks[i].blockMaterial == Material.wood) {
            return 300;
        }
        if (i == Item.stick.shiftedIndex) {
            return 100;
        }
        if (i == Block.cactus.blockID) {
            return 200;
        }
        if (i == Item.coal.shiftedIndex) {
            return 1600;
        }
        return (i != Item.bucketLava.shiftedIndex) ? 0 : 20000;
    }
    
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return true;
    }
}
