package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;

public class TileEntityGear extends TileEntity
{
    protected int gearPower;
    public int powerLevel;
    public boolean isInGroup;
    
    public TileEntityGear() {
        this.isInGroup = false;
    }
    
    public void setGearPower(final int i) {
        this.gearPower = i;
    }
    
    public int getGearPower() {
        return this.gearPower;
    }
    
    public void updatePos(final int i, final int j, final int k) {
        this.x = i;
        this.y = j;
        this.z = k;
    }
    
    public void printPos() {
    }
    
    public void setGearActive(final World world, final int state) {
    }
    
    boolean checkIfSameFaces(final World world, final int newx, final int newy, final int newz, final int x2, final int y2, final int z2, final int xd, final int zd) {
        return world.isSolidBlockTowardDirection(this.x, this.y, this.z, xd, zd) && world.isSolidBlockTowardDirection(x2, y2, z2, xd, zd) && (this.x != x2 || this.y != y2 || this.z != z2);
    }
    
    public void onPlaced(final World world) {
    }
    
    public void onUpdated(final World world) {
    }
    
    public void onRemoved(final World world) {
        this.x = -1;
        this.y = -1;
        this.z = -1;
    }
    
    @Override
    public void func_482_a(final NBTTagCompound nbttagcompound) {
        super.func_482_a(nbttagcompound);
        this.gearPower = nbttagcompound.getInteger("gearPower");
    }
    
    @Override
    public void func_481_b(final NBTTagCompound nbttagcompound) {
        super.func_481_b(nbttagcompound);
        nbttagcompound.setInteger("gearPower", this.gearPower);
    }
}
