package com.mojang.minecraft.entity.tile;

import com.mojang.minecraft.level.tile.material.*;

public interface IBlockAccess
{
    int getBlockId(final int p0, final int p1, final int p2);
    
    boolean isTouchingAir(final int p0, final int p1, final int p2);
    
    TileEntity getBlockTileEntity(final int p0, final int p1, final int p2);
    
    float getBrightness(final int p0, final int p1, final int p2);
    
    int getBlockMetadata(final int p0, final int p1, final int p2);
    
    Material getMaterialXYZ(final int p0, final int p1, final int p2);
    
    boolean isBlockNormalCube(final int p0, final int p1, final int p2);
}
