package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.util.*;
import java.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public abstract class Entity
{
    private static int nextEntityId;
    public int entityId;
    public double renderDistanceWeight;
    public boolean preventEntitySpawning;
    public Entity riddenByEntity;
    public Entity entityBeingRidden;
    public World worldObj;
    public double prevPosX;
    public double prevPosY;
    public double prevPosZ;
    public double posX;
    public double posY;
    public double posZ;
    public double motionX;
    public double motionY;
    public double motionZ;
    public float rotationYaw;
    public float rotationPitch;
    public float prevRotationYaw;
    public float prevRotationPitch;
    public final AxisAlignedBB boundingBox;
    public boolean onGround;
    public boolean isCollidedHorizionally;
    public boolean isCollidedVertically;
    public boolean isCollided;
    public boolean beenAttacked;
    public boolean isInWeb;
    public boolean isDead;
    public float yOffset;
    public float width;
    public float height;
    public float prevDistanceWalkedModified;
    public float distanceWalkedModified;
    protected boolean field_640_aG;
    protected float fallDistance;
    private int nextStepDistance;
    public double lastTickPosX;
    public double lastTickPosY;
    public double lastTickPosZ;
    public float ySize;
    public float stepHeight;
    public boolean noClip;
    public float entityCollisionReduction;
    public boolean field_631_aP;
    protected Random rand;
    public int ticksExisted;
    public int fireResistance;
    public int fire;
    protected int maxAir;
    protected boolean inWater;
    protected boolean inLava;
    public int heartsLife;
    public int air;
    private boolean isFirstUpdate;
    public String skinURL;
    public String cloakURL;
    protected DataWatcher dataWatcher;
    private double entityRiderPitchDelta;
    private double entityRiderYawDelta;
    public boolean addedToChunk;
    public int chunkCoordX;
    public int chunkCoordY;
    public int chunkCoordZ;
    public int serverPosX;
    public int serverPosY;
    public int serverPosZ;
    boolean flipflop;
    int leatherArmor;
    public int steelArmor;
    public int diamondArmor;
    public int chainArmor;
    public int goldArmor;
    
    static {
        Entity.nextEntityId = 0;
    }
    
    public Entity(final World world) {
        this.boundingBox = AxisAlignedBB.getBoundingBox(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        this.flipflop = false;
        this.entityId = Entity.nextEntityId++;
        this.renderDistanceWeight = 1.0;
        this.preventEntitySpawning = false;
        this.onGround = false;
        this.isCollided = false;
        this.beenAttacked = true;
        this.isDead = false;
        this.yOffset = 0.0f;
        this.width = 0.6f;
        this.height = 1.8f;
        this.prevDistanceWalkedModified = 0.0f;
        this.distanceWalkedModified = 0.0f;
        this.field_640_aG = true;
        this.fallDistance = 0.0f;
        this.nextStepDistance = 1;
        this.ySize = 0.0f;
        this.stepHeight = 0.0f;
        this.noClip = false;
        this.entityCollisionReduction = 0.0f;
        this.field_631_aP = false;
        this.rand = new Random();
        this.ticksExisted = 0;
        this.fireResistance = 1;
        this.fire = 0;
        this.maxAir = 300;
        this.inWater = false;
        this.heartsLife = 0;
        this.air = 300;
        this.isFirstUpdate = true;
        this.dataWatcher = new DataWatcher();
        this.addedToChunk = false;
        this.worldObj = world;
        this.setPosition(0.0, 0.0, 0.0);
        this.dataWatcher.addObject(0, 0);
        this.leatherArmor = 0;
        this.entityInit();
    }
    
    protected abstract void entityInit();
    
    public DataWatcher getDataWatcher() {
        return this.dataWatcher;
    }
    
    @Override
    public boolean equals(final Object obj) {
        return obj instanceof Entity && ((Entity)obj).entityId == this.entityId;
    }
    
    @Override
    public int hashCode() {
        return this.entityId;
    }
    
    protected void preparePlayerToSpawn() {
        if (this.worldObj == null) {
            return;
        }
        while (true) {
            while (this.posY > 0.0) {
                this.setPosition(this.posX, this.posY, this.posZ);
                if (this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0) {
                    final double motionX = 0.0;
                    this.motionZ = motionX;
                    this.motionY = motionX;
                    this.motionX = motionX;
                    this.rotationPitch = 0.0f;
                    return;
                }
                ++this.posY;
            }
            continue;
        }
    }
    
    public void setEntityDead() {
        this.isDead = true;
    }
    
    protected void setSize(final float f, final float f1) {
        this.width = f;
        this.height = f1;
    }
    
    protected void setRotation(final float f, final float f1) {
        this.rotationYaw = f;
        this.rotationPitch = f1;
    }
    
    public void setPosition(final double d, final double d1, final double d2) {
        this.posX = d;
        this.posY = d1;
        this.posZ = d2;
        final float f = this.width / 2.0f;
        final float f2 = this.height;
        this.boundingBox.setBounds(d - f, d1 - this.yOffset + this.ySize, d2 - f, d + f, d1 - this.yOffset + this.ySize + f2, d2 + f);
    }
    
    public void func_346_d(final float f, final float f1) {
        final float f2 = this.rotationPitch;
        final float f3 = this.rotationYaw;
        this.rotationYaw += (float)(f * 0.15);
        this.rotationPitch -= (float)(f1 * 0.15);
        if (this.rotationPitch < -90.0f) {
            this.rotationPitch = -90.0f;
        }
        if (this.rotationPitch > 90.0f) {
            this.rotationPitch = 90.0f;
        }
        this.prevRotationPitch += this.rotationPitch - f2;
        this.prevRotationYaw += this.rotationYaw - f3;
    }
    
    public void onUpdate() {
        this.onEntityUpdate();
    }
    
    public void onEntityUpdate() {
        if (this.entityBeingRidden != null && this.entityBeingRidden.isDead) {
            this.entityBeingRidden = null;
        }
        ++this.ticksExisted;
        this.prevDistanceWalkedModified = this.distanceWalkedModified;
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.prevRotationPitch = this.rotationPitch;
        this.prevRotationYaw = this.rotationYaw;
        if (this.handleWaterMovement()) {
            if (!this.inWater && !this.isFirstUpdate) {
                float f = MathHelper.sqrt_double(this.motionX * this.motionX * 0.20000000298023224 + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.20000000298023224) * 0.2f;
                if (f > 1.0f) {
                    f = 1.0f;
                }
                this.worldObj.playSoundAtEntity(this, "random.splash", f, 1.0f + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4f);
                final float f2 = (float)MathHelper.floor_double(this.boundingBox.minY);
                for (int i = 0; i < 1.0f + this.width * 20.0f; ++i) {
                    final float f3 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    final float f4 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    this.worldObj.spawnParticle("bubble", this.posX + f3, f2 + 1.0f, this.posZ + f4, this.motionX, this.motionY - this.rand.nextFloat() * 0.2f, this.motionZ);
                }
                for (int j = 0; j < 1.0f + this.width * 20.0f; ++j) {
                    final float f5 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    final float f6 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    this.worldObj.spawnParticle("splash", this.posX + f5, f2 + 1.0f, this.posZ + f6, this.motionX, this.motionY, this.motionZ);
                }
            }
            this.fallDistance = 0.0f;
            this.inWater = true;
            this.fire = 0;
        }
        else if (!this.handleLeavesMovement()) {
            this.inWater = false;
        }
        if (this.worldObj.multiplayerWorld) {
            this.fire = 0;
        }
        else if (this.fire > 0) {
            if (this.leatherArmor == 0) {
                if (this.fire % 20 == 0) {
                    this.dealFireDamage(1);
                }
            }
            else if (this.leatherArmor == 1) {
                if (this.fire % 30 == 0) {
                    this.dealFireDamage(1);
                }
            }
            else if (this.leatherArmor == 2) {
                if (this.fire % 40 == 0) {
                    this.dealFireDamage(1);
                }
            }
            else if (this.leatherArmor == 3) {
                if (this.fire % 50 == 0) {
                    this.dealFireDamage(1);
                }
            }
            else if (this.leatherArmor == 4 && this.fire % 60 == 0) {
                this.dealFireDamage(1);
            }
            --this.fire;
        }
        if (this.handleLavaMovement()) {
            this.attackEntityFrom(null, 10 - this.leatherArmor * 2);
            this.fire = 600;
            if (!this.inLava && !this.isFirstUpdate) {
                final float f7 = (float)MathHelper.floor_double(this.boundingBox.minY);
                for (int k = 0; k < 1.0f + this.width * 20.0f; ++k) {
                    final float f8 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    final float f9 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    this.worldObj.spawnParticle("lava", this.posX + f8, f7 + 1.0f, this.posZ + f9, this.motionX, this.motionY, this.motionZ);
                }
                for (int k = 0; k < 1.0f + this.width * 20.0f; ++k) {
                    final float f8 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    final float f9 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                    this.worldObj.spawnParticle("flame", this.posX + f8, f7 + 1.0f, this.posZ + f9, this.motionX, this.motionY + this.rand.nextFloat() * 0.2f, this.motionZ);
                }
                this.inLava = true;
            }
        }
        else {
            this.inLava = false;
        }
        if (this.posY < -64.0) {
            this.kill();
        }
        if (!this.worldObj.multiplayerWorld) {
            this.setEntityFlag(0, this.fire > 0);
            this.setEntityFlag(2, this.entityBeingRidden != null);
        }
        this.isFirstUpdate = false;
    }
    
    protected void kill() {
        this.setEntityDead();
    }
    
    public boolean isOffsetPositionInLiquid(final double d, final double d1, final double d2) {
        final AxisAlignedBB axisalignedbb = this.boundingBox.getOffsetBoundingBox(d, d1, d2);
        final List<?> list = this.worldObj.getCollidingBoundingBoxes(this, axisalignedbb);
        return list.size() <= 0 && !this.worldObj.getIsAnyLiquid(axisalignedbb);
    }
    
    public void moveEntity(double d, double d1, double d2) {
        if (this.noClip) {
            this.boundingBox.offset(d, d1, d2);
            this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0;
            this.posY = this.boundingBox.minY + this.yOffset - this.ySize;
            this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0;
            return;
        }
        final double d3 = this.posX;
        final double d4 = this.posZ;
        if (this.isInWeb) {
            this.isInWeb = false;
            d *= 0.25;
            d1 *= 0.05000000074505806;
            d2 *= 0.25;
            this.motionX = 0.0;
            this.motionY = 0.0;
            this.motionZ = 0.0;
        }
        double d5 = d;
        final double d6 = d1;
        double d7 = d2;
        final AxisAlignedBB axisalignedbb = this.boundingBox.copy();
        final boolean flag = this.onGround && this.getIsSneaking();
        if (flag) {
            final double d8 = 0.05;
            while (d != 0.0) {
                if (this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(d, -1.0, 0.0)).size() != 0) {
                    break;
                }
                if (d < d8 && d >= -d8) {
                    d = 0.0;
                }
                else if (d > 0.0) {
                    d -= d8;
                }
                else {
                    d += d8;
                }
                d5 = d;
            }
            while (d2 != 0.0 && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(0.0, -1.0, d2)).size() == 0) {
                if (d2 < d8 && d2 >= -d8) {
                    d2 = 0.0;
                }
                else if (d2 > 0.0) {
                    d2 -= d8;
                }
                else {
                    d2 += d8;
                }
                d7 = d2;
            }
        }
        final List<?> list = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(d, d1, d2));
        for (int i = 0; i < list.size(); ++i) {
            d1 = ((AxisAlignedBB)list.get(i)).calculateYOffset(this.boundingBox, d1);
        }
        this.boundingBox.offset(0.0, d1, 0.0);
        if (!this.beenAttacked && d6 != d1) {
            d1 = (d = (d2 = 0.0));
        }
        final boolean flag2 = this.onGround || (d6 != d1 && d6 < 0.0);
        for (int j = 0; j < list.size(); ++j) {
            d = ((AxisAlignedBB)list.get(j)).calculateXOffset(this.boundingBox, d);
        }
        this.boundingBox.offset(d, 0.0, 0.0);
        if (!this.beenAttacked && d5 != d) {
            d1 = (d = (d2 = 0.0));
        }
        for (int k = 0; k < list.size(); ++k) {
            d2 = ((AxisAlignedBB)list.get(k)).calculateZOffset(this.boundingBox, d2);
        }
        this.boundingBox.offset(0.0, 0.0, d2);
        if (!this.beenAttacked && d7 != d2) {
            d1 = (d = (d2 = 0.0));
        }
        if (this.stepHeight > 0.0f && flag2 && this.ySize < 0.05f && (d5 != d || d7 != d2)) {
            final double d9 = d;
            final double d10 = d1;
            final double d11 = d2;
            d = d5;
            d1 = this.stepHeight;
            d2 = d7;
            final AxisAlignedBB axisalignedbb2 = this.boundingBox.copy();
            this.boundingBox.setBB(axisalignedbb);
            final List<?> list2 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(d, d1, d2));
            for (int j2 = 0; j2 < list2.size(); ++j2) {
                d1 = ((AxisAlignedBB)list2.get(j2)).calculateYOffset(this.boundingBox, d1);
            }
            this.boundingBox.offset(0.0, d1, 0.0);
            if (!this.beenAttacked && d6 != d1) {
                d1 = (d = (d2 = 0.0));
            }
            for (int k2 = 0; k2 < list2.size(); ++k2) {
                d = ((AxisAlignedBB)list2.get(k2)).calculateXOffset(this.boundingBox, d);
            }
            this.boundingBox.offset(d, 0.0, 0.0);
            if (!this.beenAttacked && d5 != d) {
                d1 = (d = (d2 = 0.0));
            }
            for (int l2 = 0; l2 < list2.size(); ++l2) {
                d2 = ((AxisAlignedBB)list2.get(l2)).calculateZOffset(this.boundingBox, d2);
            }
            this.boundingBox.offset(0.0, 0.0, d2);
            if (!this.beenAttacked && d7 != d2) {
                d1 = (d = (d2 = 0.0));
            }
            if (d9 * d9 + d11 * d11 >= d * d + d2 * d2) {
                d = d9;
                d1 = d10;
                d2 = d11;
                this.boundingBox.setBB(axisalignedbb2);
            }
            else {
                this.ySize += 0.5;
            }
        }
        if (!this.worldObj.multiplayerWorld || this instanceof EntityPlayer || !(this instanceof EntityLiving)) {
            this.posX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0;
            this.posY = this.boundingBox.minY + this.yOffset - this.ySize;
            this.posZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0;
        }
        this.isCollidedHorizionally = (d5 != d || d7 != d2);
        this.isCollidedVertically = (d6 != d1);
        this.onGround = (d6 != d1 && d6 < 0.0);
        this.isCollided = (this.isCollidedHorizionally || this.isCollidedVertically);
        if (this.onGround) {
            if (this.fallDistance > 0.0f) {
                this.fall(this.fallDistance);
                this.fallDistance = 0.0f;
            }
        }
        else if (d1 < 0.0) {
            this.fallDistance -= (float)d1;
        }
        if (d5 != d) {
            this.motionX = 0.0;
        }
        if (d6 != d1) {
            this.motionY = 0.0;
        }
        if (d7 != d2) {
            this.motionZ = 0.0;
        }
        final double d12 = this.posX - d3;
        final double d13 = this.posZ - d4;
        this.distanceWalkedModified += (float)(MathHelper.sqrt_double(d12 * d12 + d13 * d13) * 0.6);
        if (this.field_640_aG && !flag) {
            final int m = MathHelper.floor_double(this.posX);
            final int j3 = MathHelper.floor_double(this.posY - 0.20000000298023224 - this.yOffset);
            final int l3 = MathHelper.floor_double(this.posZ);
            final int i2 = this.worldObj.getBlockId(m, j3, l3);
            float vol = 0.15f;
            float pit = 1.0f;
            if (this instanceof EntityGiant) {
                vol = 0.5f;
                pit = 0.25f;
            }
            if (this.distanceWalkedModified > this.nextStepDistance && i2 > 0) {
                ++this.nextStepDistance;
                StepSound stepsound = Block.allBlocks[i2].stepSound;
                if (this instanceof EntityPlayer && ((EntityPlayer)this).inventory.armorInventory[0] != null && ((EntityPlayer)this).inventory.armorInventory[0].itemID == Item.bootsSponge.shiftedIndex) {
                    if (this.flipflop) {
                        this.worldObj.playSoundAtEntity(this, "step.spongea", stepsound.getVolume() * 0.15f, stepsound.getPitch() + (this.rand.nextFloat() / 5.0f - 0.1f));
                    }
                    else {
                        this.worldObj.playSoundAtEntity(this, "step.spongeb", stepsound.getVolume() * 0.15f, stepsound.getPitch() + (this.rand.nextFloat() / 5.0f - 0.1f));
                    }
                    this.flipflop = !this.flipflop;
                }
                else if (this.worldObj.getBlockId(m, j3 + 1, l3) == Block.snow.blockID) {
                    stepsound = Block.snow.stepSound;
                    this.worldObj.playSoundAtEntity(this, stepsound.func_1145_d(), stepsound.getVolume() * vol, stepsound.getPitch() * pit);
                }
                else if (!Block.allBlocks[i2].blockMaterial.getIsGroundCover()) {
                    this.worldObj.playSoundAtEntity(this, stepsound.func_1145_d(), stepsound.getVolume() * vol, stepsound.getPitch() * pit);
                }
                Block.allBlocks[i2].onEntityWalking(this.worldObj, m, j3, l3, this);
            }
        }
        final int i3 = MathHelper.floor_double(this.boundingBox.minX);
        final int k3 = MathHelper.floor_double(this.boundingBox.minY);
        final int i4 = MathHelper.floor_double(this.boundingBox.minZ);
        final int j4 = MathHelper.floor_double(this.boundingBox.maxX);
        final int k4 = MathHelper.floor_double(this.boundingBox.maxY);
        final int l4 = MathHelper.floor_double(this.boundingBox.maxZ);
        for (int i5 = i3; i5 <= j4; ++i5) {
            for (int j5 = k3; j5 <= k4; ++j5) {
                for (int k5 = i4; k5 <= l4; ++k5) {
                    final int l5 = this.worldObj.getBlockId(i5, j5, k5);
                    if (l5 > 0) {
                        Block.allBlocks[l5].onEntityCollidedWithBlock(this.worldObj, i5, j5, k5, this);
                    }
                }
            }
        }
        this.ySize *= 0.4f;
        final boolean flag3 = this.handleWaterMovement();
        if (this.worldObj.isBoundingBoxBurning(this.boundingBox)) {
            this.dealFireDamage(1);
            if (!flag3) {
                ++this.fire;
                if (this.fire == 0) {
                    this.fire = 300;
                }
            }
        }
        else if (this.fire <= 0) {
            this.fire = -this.fireResistance;
        }
        if (flag3 && this.fire > 0) {
            this.worldObj.playSoundAtEntity(this, "random.fizz", 0.7f, 1.6f + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4f);
            this.fire = -this.fireResistance;
        }
    }
    
    public boolean getIsSneaking() {
        return this.isSneaking();
    }
    
    public AxisAlignedBB func_372_f_() {
        return null;
    }
    
    protected void dealFireDamage(final int i) {
        this.attackEntityFrom(null, i + this.steelArmor + this.diamondArmor * 2);
    }
    
    protected void fall(final float f) {
    }
    
    public boolean handleWaterMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox.expand(0.0, -0.4000000059604645, 0.0), Material.water, this);
    }
    
    public boolean handleLeavesMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox.expand(0.0, -0.4000000059604645, 0.0), Material.leaves, this);
    }
    
    public boolean isInsideOfMaterial(final Material material) {
        final double d = this.posY + this.func_373_s();
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_float((float)MathHelper.floor_double(d));
        final int k = MathHelper.floor_double(this.posZ);
        final int l = this.worldObj.getBlockId(i, j, k);
        if (l != 0 && Block.allBlocks[l].blockMaterial == material) {
            final float f = BlockFluids.getFluidLevel(this.worldObj.getBlockMetadata(i, j, k)) - 0.1111111f;
            final float f2 = j + 1 - f;
            return d < f2;
        }
        return false;
    }
    
    protected float func_373_s() {
        return 0.0f;
    }
    
    public boolean handleLavaMovement() {
        return this.worldObj.func_689_a(this.boundingBox.expand(0.0, -0.4000000059604645, 0.0), Material.lava);
    }
    
    public void moveFlying(float f, float f1, final float f2) {
        float f3 = MathHelper.sqrt_float(f * f + f1 * f1);
        if (f3 < 0.01f) {
            return;
        }
        if (f3 < 1.0f) {
            f3 = 1.0f;
        }
        f3 = f2 / f3;
        f *= f3;
        f1 *= f3;
        final float f4 = MathHelper.sin(this.rotationYaw * 3.141593f / 180.0f);
        final float f5 = MathHelper.cos(this.rotationYaw * 3.141593f / 180.0f);
        this.motionX += f * f5 - f1 * f4;
        this.motionZ += f1 * f5 + f * f4;
    }
    
    public float getEntityBrightness(final float f) {
        final int i = MathHelper.floor_double(this.posX);
        final double d = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66;
        final int j = MathHelper.floor_double(this.posY - this.yOffset + d);
        final int k = MathHelper.floor_double(this.posZ);
        return this.worldObj.getBrightness(i, j, k);
    }
    
    public void setWorld(final World world) {
        this.worldObj = world;
    }
    
    public void setPositionAndRotation(final double d, final double d1, final double d2, final float f, final float f1) {
        this.posX = d;
        this.prevPosX = d;
        this.posY = d1;
        this.prevPosY = d1;
        this.posZ = d2;
        this.prevPosZ = d2;
        this.rotationYaw = f;
        this.rotationPitch = f1;
        this.ySize = 0.0f;
        final double d3 = this.prevRotationYaw - f;
        if (d3 < -180.0) {
            this.prevRotationYaw += 360.0f;
        }
        if (d3 >= 180.0) {
            this.prevRotationYaw -= 360.0f;
        }
        this.setPosition(this.posX, this.posY, this.posZ);
    }
    
    public void setLocationAndAngles(final double d, final double d1, final double d2, final float f, final float f1) {
        this.posX = d;
        this.prevPosX = d;
        final double n = d1 + this.yOffset;
        this.posY = n;
        this.prevPosY = n;
        this.posZ = d2;
        this.prevPosZ = d2;
        this.rotationYaw = f;
        this.rotationPitch = f1;
        this.setPosition(this.posX, this.posY, this.posZ);
    }
    
    public float getDistanceToEntity(final Entity entity) {
        final float f = (float)(this.posX - entity.posX);
        final float f2 = (float)(this.posY - entity.posY);
        final float f3 = (float)(this.posZ - entity.posZ);
        return MathHelper.sqrt_float(f * f + f2 * f2 + f3 * f3);
    }
    
    public double getDistanceSq(final double d, final double d1, final double d2) {
        final double d3 = this.posX - d;
        final double d4 = this.posY - d1;
        final double d5 = this.posZ - d2;
        return d3 * d3 + d4 * d4 + d5 * d5;
    }
    
    public double getDistance(final double d, final double d1, final double d2) {
        final double d3 = this.posX - d;
        final double d4 = this.posY - d1;
        final double d5 = this.posZ - d2;
        return MathHelper.sqrt_double(d3 * d3 + d4 * d4 + d5 * d5);
    }
    
    public double getDistanceSqToEntity(final Entity entity) {
        final double d = this.posX - entity.posX;
        final double d2 = this.posY - entity.posY;
        final double d3 = this.posZ - entity.posZ;
        return d * d + d2 * d2 + d3 * d3;
    }
    
    public void onCollideWithPlayer(final EntityPlayer entityplayer) {
    }
    
    public void applyEntityCollision(final Entity entity) {
        if (entity.riddenByEntity == this || entity.entityBeingRidden == this) {
            return;
        }
        double d = entity.posX - this.posX;
        double d2 = entity.posZ - this.posZ;
        double d3 = MathHelper.func_1107_a(d, d2);
        if (d3 >= 0.009999999776482582) {
            d3 = MathHelper.sqrt_double(d3);
            d /= d3;
            d2 /= d3;
            double d4 = 1.0 / d3;
            if (d4 > 1.0) {
                d4 = 1.0;
            }
            d *= d4;
            d2 *= d4;
            d *= 0.05000000074505806;
            d2 *= 0.05000000074505806;
            d *= 1.0f - this.entityCollisionReduction;
            d2 *= 1.0f - this.entityCollisionReduction;
            this.addVelocity(-d, 0.0, -d2);
            entity.addVelocity(d, 0.0, d2);
        }
    }
    
    public void addVelocity(final double d, final double d1, final double d2) {
        this.motionX += d;
        this.motionY += d1;
        this.motionZ += d2;
    }
    
    public void setVelocity(final double d, final double d1, final double d2) {
        this.motionX = d;
        this.motionY = d1;
        this.motionZ = d2;
    }
    
    public void handleHealthUpdate(final byte byte0) {
    }
    
    public boolean attackEntityFrom(final Entity entity, final int i) {
        return false;
    }
    
    public boolean canBeCollidedWith() {
        return false;
    }
    
    public boolean canBePushed() {
        return false;
    }
    
    public void addToPlayerScore(final Entity entity, final int i) {
    }
    
    public boolean isInRangeToRenderVec3D(final Vec3D vec3d) {
        final double d = this.posX - vec3d.xCoord;
        final double d2 = this.posY - vec3d.yCoord;
        final double d3 = this.posZ - vec3d.zCoord;
        final double d4 = d * d + d2 * d2 + d3 * d3;
        return this.isInRangeToRenderDist(d4);
    }
    
    public boolean isInRangeToRenderDist(final double d) {
        double d2 = this.boundingBox.getAverageEdgeLength();
        d2 *= 64.0 * this.renderDistanceWeight;
        return d < d2 * d2;
    }
    
    public String getEntityTexture() {
        return null;
    }
    
    public boolean addEntityID(final NBTTagCompound nbttagcompound) {
        final String s = this.getEntityString();
        if (this.isDead || s == null) {
            return false;
        }
        nbttagcompound.setString("id", s);
        this.writeToNBT(nbttagcompound);
        return true;
    }
    
    public void writeToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.func_762_a("Pos", this.newDoubleNBTList(new double[] { this.posX, this.posY, this.posZ }));
        nbttagcompound.func_762_a("Motion", this.newDoubleNBTList(new double[] { this.motionX, this.motionY, this.motionZ }));
        nbttagcompound.func_762_a("Rotation", this.newFloatNBTList(new float[] { this.rotationYaw, this.rotationPitch }));
        nbttagcompound.setFloat("FallDistance", this.fallDistance);
        nbttagcompound.setShort("Fire", (short)this.fire);
        nbttagcompound.setShort("Air", (short)this.air);
        nbttagcompound.setBool("OnGround", this.onGround);
        this.writeEntityToNBT(nbttagcompound);
    }
    
    public void readFromNBT(final NBTTagCompound nbttagcompound) {
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Pos");
        final NBTTagList nbttaglist2 = nbttagcompound.getTagList("Motion");
        final NBTTagList nbttaglist3 = nbttagcompound.getTagList("Rotation");
        this.setPosition(0.0, 0.0, 0.0);
        this.motionX = ((NBTTagDouble)nbttaglist2.tagAt(0)).doubleValue;
        this.motionY = ((NBTTagDouble)nbttaglist2.tagAt(1)).doubleValue;
        this.motionZ = ((NBTTagDouble)nbttaglist2.tagAt(2)).doubleValue;
        final double doubleValue = ((NBTTagDouble)nbttaglist.tagAt(0)).doubleValue;
        this.posX = doubleValue;
        this.lastTickPosX = doubleValue;
        this.prevPosX = doubleValue;
        final double doubleValue2 = ((NBTTagDouble)nbttaglist.tagAt(1)).doubleValue;
        this.posY = doubleValue2;
        this.lastTickPosY = doubleValue2;
        this.prevPosY = doubleValue2;
        final double doubleValue3 = ((NBTTagDouble)nbttaglist.tagAt(2)).doubleValue;
        this.posZ = doubleValue3;
        this.lastTickPosZ = doubleValue3;
        this.prevPosZ = doubleValue3;
        final float floatValue = ((NBTTagFloat)nbttaglist3.tagAt(0)).floatValue;
        this.rotationYaw = floatValue;
        this.prevRotationYaw = floatValue;
        final float floatValue2 = ((NBTTagFloat)nbttaglist3.tagAt(1)).floatValue;
        this.rotationPitch = floatValue2;
        this.prevRotationPitch = floatValue2;
        this.fallDistance = nbttagcompound.getFloat("FallDistance");
        this.fire = nbttagcompound.getShort("Fire");
        this.air = nbttagcompound.getShort("Air");
        this.onGround = nbttagcompound.getBoolean("OnGround");
        this.setPosition(this.posX, this.posY, this.posZ);
        this.readEntityFromNBT(nbttagcompound);
    }
    
    protected final String getEntityString() {
        return EntityList.getEntityString(this);
    }
    
    protected abstract void readEntityFromNBT(final NBTTagCompound p0);
    
    protected abstract void writeEntityToNBT(final NBTTagCompound p0);
    
    protected NBTTagList newDoubleNBTList(final double[] ad) {
        final NBTTagList nbttaglist = new NBTTagList();
        for (final double d : ad) {
            nbttaglist.setTag(new NBTTagDouble(d));
        }
        return nbttaglist;
    }
    
    protected NBTTagList newFloatNBTList(final float[] af) {
        final NBTTagList nbttaglist = new NBTTagList();
        for (final float f : af) {
            nbttaglist.setTag(new NBTTagFloat(f));
        }
        return nbttaglist;
    }
    
    public float getShadowSize() {
        return this.height / 2.0f;
    }
    
    public EntityItem dropItem(final int i, final int j) {
        return this.dropItemWithOffset(i, j, 0.0f);
    }
    
    public EntityItem dropItemWithOffset(final int i, final int j, final float f) {
        final EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY + f, this.posZ, new ItemStack(i, j));
        entityitem.delayBeforeCanPickup = 10;
        this.worldObj.entityJoinedWorld(entityitem);
        return entityitem;
    }
    
    public boolean isEntityAlive() {
        return !this.isDead;
    }
    
    public boolean isEntityInsideOpaqueBlock() {
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.posY + this.func_373_s());
        final int k = MathHelper.floor_double(this.posZ);
        return this.worldObj.isBlockNormalCube(i, j, k);
    }
    
    public boolean interact(final EntityPlayer entityplayer) {
        return false;
    }
    
    public AxisAlignedBB getCollisionBox(final Entity entity) {
        return null;
    }
    
    public void updateRidden() {
        if (this.entityBeingRidden.isDead) {
            this.entityBeingRidden = null;
            return;
        }
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.onUpdate();
        if (this.entityBeingRidden == null) {
            return;
        }
        this.entityBeingRidden.updateRiderPosition();
        if (!this.worldObj.multiplayerWorld) {
            this.entityRiderYawDelta += this.entityBeingRidden.rotationYaw - this.entityBeingRidden.prevRotationYaw;
            this.entityRiderPitchDelta += this.entityBeingRidden.rotationPitch - this.entityBeingRidden.prevRotationPitch;
        }
        while (this.entityRiderYawDelta >= 180.0) {
            this.entityRiderYawDelta -= 360.0;
        }
        while (this.entityRiderYawDelta < -180.0) {
            this.entityRiderYawDelta += 360.0;
        }
        while (this.entityRiderPitchDelta >= 180.0) {
            this.entityRiderPitchDelta -= 360.0;
        }
        while (this.entityRiderPitchDelta < -180.0) {
            this.entityRiderPitchDelta += 360.0;
        }
        double d = this.entityRiderYawDelta * 0.5;
        double d2 = this.entityRiderPitchDelta * 0.5;
        final float f = 10.0f;
        if (d > f) {
            d = f;
        }
        if (d < -f) {
            d = -f;
        }
        if (d2 > f) {
            d2 = f;
        }
        if (d2 < -f) {
            d2 = -f;
        }
        this.entityRiderYawDelta -= d;
        this.entityRiderPitchDelta -= d2;
        this.rotationYaw += (float)d;
        this.rotationPitch += (float)d2;
    }
    
    protected void updateRiderPosition() {
        this.riddenByEntity.setPosition(this.posX, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ);
    }
    
    public double getYOffset() {
        return this.yOffset;
    }
    
    public double getMountedYOffset() {
        return this.height * 0.75;
    }
    
    public void mountEntity(final Entity entity) {
        this.entityRiderPitchDelta = 0.0;
        this.entityRiderYawDelta = 0.0;
        if (entity == null) {
            if (this.entityBeingRidden != null) {
                this.setLocationAndAngles(this.entityBeingRidden.posX, this.entityBeingRidden.boundingBox.minY + this.entityBeingRidden.height, this.entityBeingRidden.posZ, this.rotationYaw, this.rotationPitch);
                this.entityBeingRidden.riddenByEntity = null;
            }
            this.entityBeingRidden = null;
            return;
        }
        if (this.entityBeingRidden == entity) {
            this.entityBeingRidden.riddenByEntity = null;
            this.entityBeingRidden = null;
            this.setLocationAndAngles(entity.posX, entity.boundingBox.minY + entity.height, entity.posZ, this.rotationYaw, this.rotationPitch);
            return;
        }
        if (this.entityBeingRidden != null) {
            this.entityBeingRidden.riddenByEntity = null;
        }
        if (entity.riddenByEntity != null) {
            entity.riddenByEntity.entityBeingRidden = null;
        }
        this.entityBeingRidden = entity;
        entity.riddenByEntity = this;
    }
    
    public void setPositionAndRotation2(final double d, final double d1, final double d2, final float f, final float f1, final int i) {
        this.setPosition(d, d1, d2);
        this.setRotation(f, f1);
        final List list = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.expand(0.03125, 0.0, 0.03125));
        if (list.size() > 0) {
            double d3 = 0.0;
            for (int j = 0; j < list.size(); ++j) {
                final AxisAlignedBB axisalignedbb = list.get(j);
                if (axisalignedbb.maxY > d3) {
                    d3 = axisalignedbb.maxY;
                }
            }
            this.setPosition(d, d1, d2);
        }
    }
    
    public double getRealMoveSpeed() {
        return 0.5;
    }
    
    public boolean isBurning() {
        return this.fire > 0 || this.getEntityFlag(0);
    }
    
    public void performHurtAnimation() {
    }
    
    public void updateCloak() {
    }
    
    public void outfitWithItem(final int i, final int j, final int k) {
    }
    
    public boolean isRiding() {
        return this.entityBeingRidden != null || this.getEntityFlag(2);
    }
    
    public void setSneaking(final boolean flag) {
        this.setEntityFlag(1, flag);
    }
    
    public boolean isSneaking() {
        return this.getEntityFlag(1);
    }
    
    public void setRunning(final boolean flag) {
        this.setEntityFlag(5, flag);
    }
    
    public boolean isRunning() {
        return this.getEntityFlag(5);
    }
    
    protected boolean getEntityFlag(final int i) {
        return (this.dataWatcher.getWatchableObjectByte(0) & 1 << i) != 0x0;
    }
    
    protected void setEntityFlag(final int i, final boolean flag) {
        final byte byte0 = this.dataWatcher.getWatchableObjectByte(0);
        if (flag) {
            this.dataWatcher.updateObject(0, (byte)(byte0 | 1 << i));
        }
        else {
            this.dataWatcher.updateObject(0, (byte)(byte0 & ~(1 << i)));
        }
    }
    
    public float getEyeHeight() {
        return this.yOffset;
    }
}
