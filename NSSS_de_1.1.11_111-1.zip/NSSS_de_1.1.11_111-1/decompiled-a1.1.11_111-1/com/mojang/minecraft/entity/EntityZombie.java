package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.item.*;

public class EntityZombie extends EntityMobs
{
    public EntityZombie(final World world) {
        super(world);
        this.scoreYield = 30;
        this.texture = "/mob/zombie.png";
        this.move_speed = 0.5f;
        this.maxHealth = 5;
    }
    
    @Override
    public void onLivingUpdate() {
        if (this.worldObj.func_624_b()) {
            final float f = this.getEntityBrightness(1.0f);
            if (f > 0.5f && this.worldObj.func_647_i(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0f < (f - 0.4f) * 2.0f) {
                this.fire = 300;
            }
        }
        super.onLivingUpdate();
    }
    
    @Override
    public void onDeath(final Entity entity) {
        super.onDeath(entity);
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        final int i = Item.flint.shiftedIndex;
        if (i > 0) {
            for (int j = this.rand.nextInt(3), k = 0; k < j; ++k) {
                this.dropItem(i, 1);
            }
        }
    }
    
    @Override
    protected String idleSound() {
        return "mob.zombie";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.zombiehurt";
    }
    
    @Override
    protected String deathSound() {
        return "mob.zombiedeath";
    }
    
    @Override
    protected int deathDropItem() {
        return Item.feather.shiftedIndex;
    }
}
