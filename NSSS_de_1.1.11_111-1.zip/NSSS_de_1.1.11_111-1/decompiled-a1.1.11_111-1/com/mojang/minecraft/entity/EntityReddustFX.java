package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;

public class EntityReddustFX extends EntityFX
{
    float field_673_a;
    
    public EntityReddustFX(final World world, final double d, final double d1, final double d2) {
        this(world, d, d1, d2, 1.0f);
    }
    
    public EntityReddustFX(final World world, final double d, final double d1, final double d2, final float f) {
        super(world, d, d1, d2, 0.0, 0.0, 0.0);
        this.motionX *= 0.10000000149011612;
        this.motionY *= 0.10000000149011612;
        this.motionZ *= 0.10000000149011612;
        this.particleRed = (float)(Math.random() * 0.30000001192092896) + 0.7f;
        final float n = (float)(Math.random() * 0.10000000149011612);
        this.particleBlue = n;
        this.particleGreen = n;
        this.particleScale *= 0.75f;
        this.particleScale *= f;
        this.field_673_a = this.particleScale;
        this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2));
        this.particleMaxAge *= (int)f;
        this.noClip = false;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        float f6 = (this.particleAge + f) / this.particleMaxAge * 32.0f;
        if (f6 < 0.0f) {
            f6 = 0.0f;
        }
        if (f6 > 1.0f) {
            f6 = 1.0f;
        }
        this.particleScale = this.field_673_a * f6;
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
        this.particleTextureIndex = 7 - this.particleAge * 8 / this.particleMaxAge;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        if (this.posY == this.prevPosY) {
            this.motionX *= 1.1;
            this.motionZ *= 1.1;
        }
        this.motionX *= 0.9599999785423279;
        this.motionY *= 0.9599999785423279;
        this.motionZ *= 0.9599999785423279;
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
        }
    }
}
