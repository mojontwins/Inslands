package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.nbt.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class EntitySkeleton extends EntityMobs
{
    public EntitySkeleton(final World world) {
        super(world);
        this.scoreYield = 40;
        this.texture = "/mob/skeleton.png";
        this.currentSpeed = 0.5;
    }
    
    @Override
    protected String idleSound() {
        return "mob.skeleton";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.skeletonhurt";
    }
    
    @Override
    protected String deathSound() {
        return "mob.skeletonhurt";
    }
    
    @Override
    public void onLivingUpdate() {
        if (this.worldObj.func_624_b()) {
            final float f = this.getEntityBrightness(1.0f);
            if (f > 0.5f && this.worldObj.func_647_i(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0f < (f - 0.4f) * 2.0f) {
                this.fire = 300;
            }
        }
        super.onLivingUpdate();
    }
    
    @Override
    protected void attackEntity(final Entity entity, final float f) {
        if (f < 10.0f) {
            final double d = entity.posX - this.posX;
            final double d2 = entity.posZ - this.posZ;
            if (this.attackTime == 0) {
                final EntityArrow entityarrow = new EntityArrow(this.worldObj, this);
                if (this.fire > 0) {
                    entityarrow.fire = 300;
                }
                final EntityArrow entityArrow = entityarrow;
                entityArrow.posY += 1.399999976158142;
                final double d3 = entity.posY - 0.20000000298023224 - entityarrow.posY;
                final float f2 = MathHelper.sqrt_double(d * d + d2 * d2) * 0.2f;
                this.worldObj.playSoundAtEntity(this, "random.bow", 1.0f, 1.0f / (this.rand.nextFloat() * 0.4f + 0.8f));
                this.worldObj.entityJoinedWorld(entityarrow);
                entityarrow.setArrowHeading(d, d3 + f2, d2, 0.6f, 12.0f);
                this.attackTime = 30;
            }
            this.rotationYaw = (float)(Math.atan2(d2, d) * 180.0 / 3.1415927410125732) - 90.0f;
            this.hasAttacked = true;
        }
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected int deathDropItem() {
        if (new Random().nextBoolean()) {
            return Item.bone.shiftedIndex;
        }
        return Item.arrow.shiftedIndex;
    }
    
    @Override
    public double getRealMoveSpeed() {
        return this.currentSpeed;
    }
}
