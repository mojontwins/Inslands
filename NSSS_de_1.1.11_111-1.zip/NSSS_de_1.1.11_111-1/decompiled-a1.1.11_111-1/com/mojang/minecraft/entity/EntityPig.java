package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntityPig extends EntityAnimals
{
    public EntityPig(final World world) {
        super(world);
        this.setSaddled(false);
        this.scoreYield = 10;
        this.texture = "/mob/pig.png";
        this.setSize(0.9f, 0.9f);
        this.setSaddled(false);
    }
    
    @Override
    protected void entityInit() {
        this.dataWatcher.addObject(16, 0);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setBool("Saddle", this.getSaddled());
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
        this.setSaddled(nbttagcompound.getBoolean("Saddle"));
    }
    
    @Override
    protected String idleSound() {
        return "mob.pig";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.pig";
    }
    
    @Override
    protected String deathSound() {
        return "mob.pigdeath";
    }
    
    @Override
    public boolean interact(final EntityPlayer entityplayer) {
        if (this.getSaddled() && !this.worldObj.multiplayerWorld && (this.riddenByEntity == null || this.riddenByEntity == entityplayer)) {
            entityplayer.mountEntity(this);
            return true;
        }
        return false;
    }
    
    @Override
    protected int deathDropItem() {
        if (this.worldObj.multiplayerWorld) {
            return 0;
        }
        if (!this.getSaddled()) {
            if (this.fire > 0) {
                return Item.porkCooked.shiftedIndex;
            }
            return Item.porkRaw.shiftedIndex;
        }
        else {
            this.dropItem(Item.saddle.shiftedIndex, 1);
            if (this.fire > 0) {
                return Item.porkCooked.shiftedIndex;
            }
            return Item.porkRaw.shiftedIndex;
        }
    }
    
    public boolean getSaddled() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 0x1) != 0x0;
    }
    
    public void setSaddled(final boolean flag) {
        if (flag) {
            this.dataWatcher.updateObject(16, 1);
        }
        else {
            this.dataWatcher.updateObject(16, 0);
        }
    }
}
