package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;

public class Pathfinder
{
    public static boolean oldai;
    private IBlockAccess worldMap;
    private Path path;
    private MCHashTable pointMap;
    private PathPoint[] pathOptions;
    
    static {
        Pathfinder.oldai = false;
    }
    
    public Pathfinder(final IBlockAccess iblockaccess) {
        this.path = new Path();
        this.pointMap = new MCHashTable();
        this.pathOptions = new PathPoint[32];
        this.worldMap = iblockaccess;
    }
    
    public PathEntity createEntityPathTo(final Entity entity, final Entity entity1, final float f) {
        return this.createEntityPathTo(entity, entity1.posX, entity1.boundingBox.minY, entity1.posZ, f);
    }
    
    public PathEntity createEntityPathTo(final Entity entity, final int i, final int j, final int k, final float f) {
        return this.createEntityPathTo(entity, i + 0.5f, j + 0.5f, k + 0.5f, f);
    }
    
    private PathEntity createEntityPathTo(final Entity entity, final double d, final double d1, final double d2, final float f) {
        this.path.func_1038_a();
        this.pointMap.func_1058_a();
        final PathPoint pathpoint = this.openPoint(MathHelper.floor_double(entity.boundingBox.minX), MathHelper.floor_double(entity.boundingBox.minY), MathHelper.floor_double(entity.boundingBox.minZ));
        final PathPoint pathpoint2 = this.openPoint(MathHelper.floor_double(d - entity.width / 2.0f), MathHelper.floor_double(d1), MathHelper.floor_double(d2 - entity.width / 2.0f));
        final PathPoint pathpoint3 = new PathPoint(MathHelper.floor_float(entity.width + 1.0f), MathHelper.floor_float(entity.height + 1.0f), MathHelper.floor_float(entity.width + 1.0f));
        final PathEntity pathentity = this.func_1129_a(entity, pathpoint, pathpoint2, pathpoint3, f);
        return pathentity;
    }
    
    private PathEntity func_1129_a(final Entity entity, final PathPoint pathpoint, final PathPoint pathpoint1, final PathPoint pathpoint2, final float f) {
        pathpoint.field_1713_f = 0.0f;
        pathpoint.field_1712_g = pathpoint.getMagnitude(pathpoint1);
        pathpoint.field_1711_h = pathpoint.field_1712_g;
        this.path.func_1038_a();
        this.path.func_1034_a(pathpoint);
        PathPoint pathpoint3 = pathpoint;
        while (!this.path.func_1039_c()) {
            final PathPoint pathpoint4 = this.path.func_1036_b();
            if (pathpoint4.posHash == pathpoint1.posHash) {
                return this.createEntityPath(pathpoint, pathpoint1);
            }
            if (pathpoint4.getMagnitude(pathpoint1) < pathpoint3.getMagnitude(pathpoint1)) {
                pathpoint3 = pathpoint4;
            }
            pathpoint4.field_1709_j = true;
            for (int i = this.findPathOptions(entity, pathpoint4, pathpoint2, pathpoint1, f), j = 0; j < i; ++j) {
                final PathPoint pathpoint5 = this.pathOptions[j];
                final float f2 = pathpoint4.field_1713_f + pathpoint4.getMagnitude(pathpoint5);
                if (!pathpoint5.func_1179_a() || f2 < pathpoint5.field_1713_f) {
                    pathpoint5.field_1710_i = pathpoint4;
                    pathpoint5.field_1713_f = f2;
                    pathpoint5.field_1712_g = pathpoint5.getMagnitude(pathpoint1);
                    if (pathpoint5.func_1179_a()) {
                        this.path.func_1035_a(pathpoint5, pathpoint5.field_1713_f + pathpoint5.field_1712_g);
                    }
                    else {
                        pathpoint5.field_1711_h = pathpoint5.field_1713_f + pathpoint5.field_1712_g;
                        this.path.func_1034_a(pathpoint5);
                    }
                }
            }
        }
        if (pathpoint3 == pathpoint) {
            return null;
        }
        return this.createEntityPath(pathpoint, pathpoint3);
    }
    
    private int findPathOptions(final Entity entity, final PathPoint pathpoint, final PathPoint pathpoint1, final PathPoint pathpoint2, final float f) {
        int i = 0;
        int j = 0;
        if (this.getVerticalOffset(entity, pathpoint.posX, pathpoint.posY + 1, pathpoint.posZ, pathpoint1) > 0) {
            j = 1;
        }
        final PathPoint pathpoint3 = this.getSafePoint(entity, pathpoint.posX, pathpoint.posY, pathpoint.posZ + 1, pathpoint1, j);
        final PathPoint pathpoint4 = this.getSafePoint(entity, pathpoint.posX - 1, pathpoint.posY, pathpoint.posZ, pathpoint1, j);
        final PathPoint pathpoint5 = this.getSafePoint(entity, pathpoint.posX + 1, pathpoint.posY, pathpoint.posZ, pathpoint1, j);
        final PathPoint pathpoint6 = this.getSafePoint(entity, pathpoint.posX, pathpoint.posY, pathpoint.posZ - 1, pathpoint1, j);
        if (pathpoint3 != null && !pathpoint3.field_1709_j && pathpoint3.getMagnitude(pathpoint2) < f) {
            this.pathOptions[i++] = pathpoint3;
        }
        if (pathpoint4 != null && !pathpoint4.field_1709_j && pathpoint4.getMagnitude(pathpoint2) < f) {
            this.pathOptions[i++] = pathpoint4;
        }
        if (pathpoint5 != null && !pathpoint5.field_1709_j && pathpoint5.getMagnitude(pathpoint2) < f) {
            this.pathOptions[i++] = pathpoint5;
        }
        if (pathpoint6 != null && !pathpoint6.field_1709_j && pathpoint6.getMagnitude(pathpoint2) < f) {
            this.pathOptions[i++] = pathpoint6;
        }
        return i;
    }
    
    private PathPoint getSafePoint(final Entity entity, final int x, int y, final int z, final PathPoint pathpoint, final int l) {
        PathPoint pathpoint2 = null;
        if (this.getVerticalOffset(entity, x, y, z, pathpoint) > 0) {
            pathpoint2 = this.openPoint(x, y, z);
        }
        if (pathpoint2 == null && this.getVerticalOffset(entity, x, y + l, z, pathpoint) > 0) {
            pathpoint2 = this.openPoint(x, y + l, z);
            y += l;
        }
        if (pathpoint2 != null) {
            int i1 = 0;
            int j1 = 0;
            while (y > 0 && (j1 = this.getVerticalOffset(entity, x, y - 1, z, pathpoint)) > 0) {
                if (j1 < 0) {
                    return null;
                }
                if (++i1 >= 4) {
                    return null;
                }
                --y;
            }
            if (y > 0) {
                pathpoint2 = this.openPoint(x, y, z);
            }
        }
        return pathpoint2;
    }
    
    private final PathPoint openPoint(final int x, final int y, final int z) {
        final int l = x | y << 10 | z << 20;
        PathPoint pathpoint = (PathPoint)this.pointMap.func_1057_a(l);
        if (pathpoint == null) {
            pathpoint = new PathPoint(x, y, z);
            this.pointMap.addKey(l, pathpoint);
        }
        return pathpoint;
    }
    
    private int getVerticalOffset(final Entity entity, final int i, final int j, final int k, final PathPoint pathpoint) {
        for (int l = i; l < i + pathpoint.posX; ++l) {
            for (int i2 = j; i2 < j + pathpoint.posY; ++i2) {
                for (int j2 = k; j2 < k + pathpoint.posZ; ++j2) {
                    final Material material = this.worldMap.getMaterialXYZ(i, j, k);
                    if (material.blocksMovement()) {
                        return 0;
                    }
                    if (material == Material.water || material == Material.lava) {
                        return -1;
                    }
                }
            }
        }
        return 1;
    }
    
    private PathEntity createEntityPath(final PathPoint pathpoint, final PathPoint pathpoint1) {
        int i = 1;
        for (PathPoint pathpoint2 = pathpoint1; pathpoint2.field_1710_i != null; pathpoint2 = pathpoint2.field_1710_i) {
            ++i;
        }
        final PathPoint[] apathpoint = new PathPoint[i];
        PathPoint pathpoint3 = pathpoint1;
        apathpoint[--i] = pathpoint3;
        while (pathpoint3.field_1710_i != null) {
            pathpoint3 = pathpoint3.field_1710_i;
            apathpoint[--i] = pathpoint3;
        }
        return new PathEntity(apathpoint);
    }
}
