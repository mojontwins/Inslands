package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.util.*;

public final class PathPointIndev
{
    public final int x;
    public final int y;
    public final int z;
    public final int hash;
    int e;
    float f;
    float g;
    float h;
    PathPointIndev i;
    public boolean j;
    
    public PathPointIndev(final int var1, final int var2, final int var3) {
        this.e = -1;
        this.j = false;
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.hash = (var1 | var2 << 10 | var3 << 20);
    }
    
    public final float a(final PathPointIndev var1) {
        final float var2 = (float)(var1.x - this.x);
        final float var3 = (float)(var1.y - this.y);
        final float var4 = (float)(var1.z - this.z);
        return MathHelper.sqrt_float(var2 * var2 + var3 * var3 + var4 * var4);
    }
    
    @Override
    public final boolean equals(final Object var1) {
        return ((PathPointIndev)var1).hash == this.hash;
    }
    
    @Override
    public final int hashCode() {
        return this.hash;
    }
    
    public final boolean a() {
        return this.e >= 0;
    }
    
    @Override
    public final String toString() {
        return String.valueOf(this.x) + ", " + this.y + ", " + this.z;
    }
}
