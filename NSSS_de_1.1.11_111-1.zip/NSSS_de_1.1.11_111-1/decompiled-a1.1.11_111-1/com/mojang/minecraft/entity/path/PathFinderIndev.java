package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.tile.material.*;

public final class PathFinderIndev
{
    public static int width;
    public static int length;
    public static int height;
    public World worldObj;
    private PathIndev b;
    private Map<Integer, PathPointIndev> c;
    private PathPointIndev[] d;
    
    static {
        PathFinderIndev.width = 0;
        PathFinderIndev.length = 0;
        PathFinderIndev.height = 0;
    }
    
    public PathFinderIndev(final World var1) {
        this.b = new PathIndev();
        this.c = new HashMap<Integer, PathPointIndev>();
        this.d = new PathPointIndev[32];
        this.worldObj = var1;
    }
    
    public final PathEntityIndev a(final Entity var1, final Entity var2, final float var3) {
        return this.a(var1, (float)var2.posX, (float)var2.boundingBox.minY, (float)var2.posZ, 16.0f);
    }
    
    public final PathEntityIndev a(final Entity var1, final int var2, final int var3, final int var4, final float var5) {
        return this.a(var1, var2 + 0.5f, var3 + 0.5f, var4 + 0.5f, 16.0f);
    }
    
    private PathEntityIndev a(final Entity var1, final double var2, final double var3, final double var4, final float var5) {
        this.b.a();
        this.c.clear();
        final PathPointIndev var6 = this.a((int)var1.boundingBox.minX, (int)var1.boundingBox.minY, (int)var1.boundingBox.minZ);
        final PathPointIndev var7 = this.a((int)(var2 - var1.width / 2.0f), (int)var3, (int)(var4 - var1.width / 2.0f));
        final PathPointIndev var8 = new PathPointIndev((int)(var1.width + 1.0f), (int)(var1.height + 1.0f), (int)(var1.width + 1.0f));
        final float var9 = var5;
        final PathPointIndev var10 = var8;
        final PathPointIndev var11 = var7;
        final Entity var12 = var1;
        final PathFinderIndev var13 = this;
        var6.f = 0.0f;
        var6.g = var6.a(var7);
        var6.h = var6.g;
        this.b.a();
        this.b.a(var6);
        PathPointIndev var14 = var6;
        while (!var13.b.c()) {
            final PathPointIndev var15 = var13.b.b();
            if (var15.hash == var11.hash) {
                final PathEntityIndev var16 = a(var11);
                return var16;
            }
            if (var15.a(var11) < var14.a(var11)) {
                var14 = var15;
            }
            var15.j = true;
            int var17 = 0;
            byte var18 = 0;
            if (var13.a(var15.x, var15.y + 1, var15.z, var10) > 0) {
                var18 = 1;
            }
            final PathPointIndev var19 = var13.a(var12, var15.x, var15.y, var15.z + 1, var10, var18);
            final PathPointIndev var20 = var13.a(var12, var15.x - 1, var15.y, var15.z, var10, var18);
            final PathPointIndev var21 = var13.a(var12, var15.x + 1, var15.y, var15.z, var10, var18);
            final PathPointIndev var22 = var13.a(var12, var15.x, var15.y, var15.z - 1, var10, var18);
            if (var19 != null && !var19.j && var19.a(var11) < var9) {
                ++var17;
                var13.d[0] = var19;
            }
            if (var20 != null && !var20.j && var20.a(var11) < var9) {
                var13.d[var17++] = var20;
            }
            if (var21 != null && !var21.j && var21.a(var11) < var9) {
                var13.d[var17++] = var21;
            }
            if (var22 != null && !var22.j && var22.a(var11) < var9) {
                var13.d[var17++] = var22;
            }
            for (int var23 = var17, var24 = 0; var24 < var23; ++var24) {
                final PathPointIndev var25 = var13.d[var24];
                final float var26 = var15.f + var15.a(var25);
                if (!var25.a() || var26 < var25.f) {
                    var25.i = var15;
                    var25.f = var26;
                    var25.g = var25.a(var11);
                    if (var25.a()) {
                        var13.b.a(var25, var25.f + var25.g);
                    }
                    else {
                        var25.h = var25.f + var25.g;
                        var13.b.a(var25);
                    }
                }
            }
        }
        final PathEntityIndev var16 = (var14 == var6) ? null : a(var14);
        return var16;
    }
    
    private PathPointIndev a(final Entity var1, final int var2, int var3, final int var4, final PathPointIndev var5, int var6) {
        PathPointIndev var7 = null;
        if (this.a(var2, var3, var4, var5) > 0) {
            var7 = this.a(var2, var3, var4);
        }
        if (var7 == null && this.a(var2, var3 + var6, var4, var5) > 0) {
            var7 = this.a(var2, var3 + var6, var4);
        }
        if (var7 != null) {
            var6 = 0;
            int var8;
            while (var3 > 0 && (var8 = this.a(var2, var3 - 1, var4, var5)) > 0) {
                if (var8 < 0) {
                    return null;
                }
                if (++var6 >= 4) {
                    return null;
                }
                --var3;
                var7 = this.a(var2, var3, var4);
            }
            final Material var9 = this.worldObj.getMaterialXYZ(var2, var3 - 1, var4);
            if (var9 == Material.water || var9 == Material.lava) {
                return null;
            }
        }
        return var7;
    }
    
    private final PathPointIndev a(final int var1, final int var2, final int var3) {
        final int var4 = var1 | var2 << 10 | var3 << 20;
        PathPointIndev var5;
        if ((var5 = this.c.get(var4)) == null) {
            var5 = new PathPointIndev(var1, var2, var3);
            this.c.put(var4, var5);
        }
        return var5;
    }
    
    private int a(final int var1, final int var2, final int var3, final PathPointIndev var4) {
        for (int var5 = var1; var5 < var1 + var4.x; ++var5) {
            if ((var5 < 0 || var5 >= PathFinderIndev.width) && PathFinderIndev.width > 0) {
                return 0;
            }
            for (int var6 = var2; var6 < var2 + var4.y; ++var6) {
                if ((var6 < 0 || var6 >= PathFinderIndev.height) && PathFinderIndev.height > 0) {
                    return 0;
                }
                for (int var7 = var3; var7 < var3 + var4.z; ++var7) {
                    if ((var7 < 0 || var7 >= PathFinderIndev.length) && PathFinderIndev.length > 0) {
                        return 0;
                    }
                    final Material var8 = this.worldObj.getMaterialXYZ(var1, var2, var3);
                    if (var8.blocksMovement()) {
                        return 0;
                    }
                    if (var8 == Material.water || var8 == Material.lava) {
                        return -1;
                    }
                }
            }
        }
        return 1;
    }
    
    private static PathEntityIndev a(final PathPointIndev var0) {
        int var = 1;
        for (PathPointIndev var2 = var0; var2.i != null; var2 = var2.i) {
            ++var;
        }
        final PathPointIndev[] var3 = new PathPointIndev[var];
        PathPointIndev var2 = var0;
        --var;
        var3[var] = var0;
        while (var2.i != null) {
            var2 = var2.i;
            --var;
            var3[var] = var2;
        }
        return new PathEntityIndev(var3);
    }
}
