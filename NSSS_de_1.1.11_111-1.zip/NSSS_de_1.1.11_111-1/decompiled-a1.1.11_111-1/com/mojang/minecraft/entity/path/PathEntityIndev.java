package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.render.*;

public final class PathEntityIndev
{
    private final PathPointIndev[] a;
    private int b;
    
    public PathEntityIndev(final PathPointIndev[] var1) {
        this.a = var1;
    }
    
    public final void a() {
        ++this.b;
    }
    
    public final boolean b() {
        return this.b >= this.a.length;
    }
    
    public final Vec3D a(final Entity var1) {
        final float var2 = this.a[this.b].x + (int)(var1.width + 1.0f) * 0.5f;
        final float var3 = (float)this.a[this.b].y;
        final float var4 = this.a[this.b].z + (int)(var1.width + 1.0f) * 0.5f;
        return Vec3D.createVector(var2, var3, var4);
    }
}
