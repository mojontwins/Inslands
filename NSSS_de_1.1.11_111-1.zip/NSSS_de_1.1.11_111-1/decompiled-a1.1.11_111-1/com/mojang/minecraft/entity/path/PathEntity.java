package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.render.*;

public class PathEntity
{
    private final PathPoint[] field_1764_b;
    public final int field_1765_a;
    private int field_1766_c;
    
    public PathEntity(final PathPoint[] apathpoint) {
        this.field_1764_b = apathpoint;
        this.field_1765_a = apathpoint.length;
    }
    
    public void incrementPathIndex() {
        ++this.field_1766_c;
    }
    
    public boolean isFinished() {
        return this.field_1766_c >= this.field_1764_b.length;
    }
    
    public Vec3D getPosition(final Entity entity) {
        final double d = this.field_1764_b[this.field_1766_c].posX + (int)(entity.width + 1.0f) * 0.5;
        final double d2 = this.field_1764_b[this.field_1766_c].posY;
        final double d3 = this.field_1764_b[this.field_1766_c].posZ + (int)(entity.width + 1.0f) * 0.5;
        return Vec3D.createVector(d, d2, d3);
    }
}
