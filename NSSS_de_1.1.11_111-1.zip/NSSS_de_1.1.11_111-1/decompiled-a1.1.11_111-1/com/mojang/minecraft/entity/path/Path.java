package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.level.*;

public class Path
{
    private PathPoint[] field_1556_a;
    private int field_1555_b;
    
    public Path() {
        this.field_1556_a = new PathPoint[1024];
        this.field_1555_b = 0;
    }
    
    public PathPoint func_1034_a(final PathPoint pathpoint) {
        if (pathpoint.field_1714_e >= 0) {
            throw new IllegalStateException("OW KNOWS!");
        }
        if (this.field_1555_b == this.field_1556_a.length) {
            final PathPoint[] apathpoint = new PathPoint[this.field_1555_b << 1];
            System.arraycopy(this.field_1556_a, 0, apathpoint, 0, this.field_1555_b);
            this.field_1556_a = apathpoint;
        }
        this.field_1556_a[this.field_1555_b] = pathpoint;
        pathpoint.field_1714_e = this.field_1555_b;
        this.func_1033_a(this.field_1555_b++);
        return pathpoint;
    }
    
    public void func_1038_a() {
        this.field_1555_b = 0;
    }
    
    public PathPoint func_1036_b() {
        final PathPoint pathpoint = this.field_1556_a[0];
        final PathPoint[] field_1556_a = this.field_1556_a;
        final int n = 0;
        final PathPoint[] field_1556_a2 = this.field_1556_a;
        final int field_1555_b = this.field_1555_b - 1;
        this.field_1555_b = field_1555_b;
        field_1556_a[n] = field_1556_a2[field_1555_b];
        this.field_1556_a[this.field_1555_b] = null;
        if (this.field_1555_b > 0) {
            this.func_1037_b(0);
        }
        pathpoint.field_1714_e = -1;
        return pathpoint;
    }
    
    public void func_1035_a(final PathPoint pathpoint, final float f) {
        final float f2 = pathpoint.field_1711_h;
        pathpoint.field_1711_h = f;
        if (f < f2) {
            this.func_1033_a(pathpoint.field_1714_e);
        }
        else {
            this.func_1037_b(pathpoint.field_1714_e);
        }
    }
    
    private void func_1033_a(int i) {
        final PathPoint pathpoint = this.field_1556_a[i];
        final float f = pathpoint.field_1711_h;
        while (true) {
            while (i > 0) {
                final int j = i - 1 >> 1;
                final PathPoint pathpoint2 = this.field_1556_a[j];
                if (f >= pathpoint2.field_1711_h) {
                    this.field_1556_a[i] = pathpoint;
                    pathpoint.field_1714_e = i;
                    return;
                }
                this.field_1556_a[i] = pathpoint2;
                pathpoint2.field_1714_e = i;
                i = j;
            }
            continue;
        }
    }
    
    private void func_1037_b(int i) {
        final PathPoint pathpoint = this.field_1556_a[i];
        final float f = pathpoint.field_1711_h;
        while (true) {
            final int j = 1 + (i << 1);
            final int k = j + 1;
            if (j >= this.field_1555_b) {
                break;
            }
            final PathPoint pathpoint2 = this.field_1556_a[j];
            final float f2 = pathpoint2.field_1711_h;
            PathPoint pathpoint3;
            float f3;
            if (k >= this.field_1555_b) {
                pathpoint3 = null;
                f3 = Float.POSITIVE_INFINITY;
            }
            else {
                pathpoint3 = this.field_1556_a[k];
                f3 = pathpoint3.field_1711_h;
            }
            if (f2 < f3) {
                if (f2 >= f) {
                    break;
                }
                this.field_1556_a[i] = pathpoint2;
                pathpoint2.field_1714_e = i;
                i = j;
            }
            else {
                if (f3 >= f) {
                    break;
                }
                this.field_1556_a[i] = pathpoint3;
                pathpoint3.field_1714_e = i;
                i = k;
            }
        }
        this.field_1556_a[i] = pathpoint;
        pathpoint.field_1714_e = i;
    }
    
    public boolean func_1039_c() {
        return this.field_1555_b == 0;
    }
    
    public void visualize(final World world) {
        for (int i = 0; i < this.field_1556_a.length; ++i) {
            if (this.field_1556_a[i] != null) {
                world.spawnParticle("smoke", this.field_1556_a[i].posX, this.field_1556_a[i].posY, this.field_1556_a[i].posZ, 0.0, 0.0, 0.0);
            }
        }
    }
}
