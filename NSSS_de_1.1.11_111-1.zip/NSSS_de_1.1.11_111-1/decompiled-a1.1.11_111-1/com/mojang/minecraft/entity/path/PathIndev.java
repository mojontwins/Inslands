package com.mojang.minecraft.entity.path;

public final class PathIndev
{
    private PathPointIndev[] a;
    private int b;
    
    public PathIndev() {
        this.a = new PathPointIndev[1024];
        this.b = 0;
    }
    
    public final PathPointIndev a(final PathPointIndev var1) {
        if (var1.e >= 0) {
            throw new IllegalStateException("OW KNOWS!");
        }
        if (this.b == this.a.length) {
            final PathPointIndev[] var2 = new PathPointIndev[this.b << 1];
            System.arraycopy(this.a, 0, var2, 0, this.b);
            this.a = var2;
        }
        this.a[this.b] = var1;
        var1.e = this.b;
        this.a(this.b++);
        return var1;
    }
    
    public final void a() {
        this.b = 0;
    }
    
    public final PathPointIndev b() {
        final PathPointIndev var1 = this.a[0];
        final PathPointIndev[] a = this.a;
        final int n = 0;
        final PathPointIndev[] a2 = this.a;
        final int b = this.b - 1;
        this.b = b;
        a[n] = a2[b];
        this.a[this.b] = null;
        if (this.b > 0) {
            this.b(0);
        }
        var1.e = -1;
        return var1;
    }
    
    public final void a(final PathPointIndev var1, final float var2) {
        final float var3 = var1.h;
        var1.h = var2;
        if (var2 < var3) {
            this.a(var1.e);
        }
        else {
            this.b(var1.e);
        }
    }
    
    private void a(int var1) {
        final PathPointIndev var3;
        final float var2 = (var3 = this.a[var1]).h;
        while (var1 > 0) {
            final int var4 = var1 - 1 >> 1;
            final PathPointIndev var5 = this.a[var4];
            if (var2 >= var5.h) {
                break;
            }
            this.a[var1] = var5;
            var5.e = var1;
            var1 = var4;
        }
        this.a[var1] = var3;
        var3.e = var1;
    }
    
    private void b(int var1) {
        final PathPointIndev var3;
        final float var2 = (var3 = this.a[var1]).h;
        while (true) {
            final int var5;
            final int var4 = (var5 = 1 + (var1 << 1)) + 1;
            if (var5 >= this.b) {
                break;
            }
            final PathPointIndev var7;
            final float var6 = (var7 = this.a[var5]).h;
            PathPointIndev var8;
            float var9;
            if (var4 >= this.b) {
                var8 = null;
                var9 = Float.POSITIVE_INFINITY;
            }
            else {
                var9 = (var8 = this.a[var4]).h;
            }
            if (var6 < var9) {
                if (var6 >= var2) {
                    break;
                }
                this.a[var1] = var7;
                var7.e = var1;
                var1 = var5;
            }
            else {
                if (var9 >= var2) {
                    break;
                }
                this.a[var1] = var8;
                var8.e = var1;
                var1 = var4;
            }
        }
        this.a[var1] = var3;
        var3.e = var1;
    }
    
    public final boolean c() {
        return this.b == 0;
    }
}
