package com.mojang.minecraft.entity.path;

import com.mojang.minecraft.util.*;

public class PathPoint
{
    public final int posX;
    public final int posY;
    public final int posZ;
    public final int posHash;
    int field_1714_e;
    float field_1713_f;
    float field_1712_g;
    float field_1711_h;
    PathPoint field_1710_i;
    public boolean field_1709_j;
    
    public PathPoint(final int x, final int y, final int z) {
        this.field_1714_e = -1;
        this.field_1709_j = false;
        this.posX = x;
        this.posY = y;
        this.posZ = z;
        this.posHash = (x | y << 10 | z << 20);
    }
    
    public float getMagnitude(final PathPoint pathpoint) {
        final float distX = (float)(pathpoint.posX - this.posX);
        final float distY = (float)(pathpoint.posY - this.posY);
        final float distZ = (float)(pathpoint.posZ - this.posZ);
        return MathHelper.sqrt_float(distX * distX + distY * distY + distZ * distZ);
    }
    
    @Override
    public boolean equals(final Object obj) {
        return ((PathPoint)obj).posHash == this.posHash;
    }
    
    @Override
    public int hashCode() {
        return this.posHash;
    }
    
    public boolean func_1179_a() {
        return this.field_1714_e >= 0;
    }
    
    @Override
    public String toString() {
        return this.posX + ", " + this.posY + ", " + this.posZ;
    }
}
