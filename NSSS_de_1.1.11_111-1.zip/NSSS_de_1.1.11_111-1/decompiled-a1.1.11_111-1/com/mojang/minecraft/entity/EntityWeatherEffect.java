package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;

public abstract class EntityWeatherEffect extends Entity
{
    public EntityWeatherEffect(final World world) {
        super(world);
    }
}
