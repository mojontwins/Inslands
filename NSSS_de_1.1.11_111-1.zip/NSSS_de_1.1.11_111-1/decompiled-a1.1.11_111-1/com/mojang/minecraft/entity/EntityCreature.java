package com.mojang.minecraft.entity;

import com.mojang.minecraft.entity.path.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.util.*;

public class EntityCreature extends EntityLiving
{
    private PathEntity pathToEntity;
    private PathEntityIndev indevPathToEntity;
    protected Entity entityToAttack;
    protected boolean hasAttacked;
    public boolean indevai;
    public static PathFinderIndev pathFinderIndev;
    
    public EntityCreature(final World world) {
        super(world);
        this.hasAttacked = false;
        if (world != null) {
            final int difficulty = world.difficulty;
        }
        if (this.worldObj != null && (EntityCreature.pathFinderIndev == null || EntityCreature.pathFinderIndev.worldObj != world)) {
            EntityCreature.pathFinderIndev = new PathFinderIndev(this.worldObj);
        }
    }
    
    @Override
    public void setWorld(final World par1World) {
        this.worldObj = par1World;
        if (EntityCreature.pathFinderIndev == null || EntityCreature.pathFinderIndev.worldObj != par1World) {
            EntityCreature.pathFinderIndev = new PathFinderIndev(this.worldObj);
        }
    }
    
    @Override
    protected void updateEntityActionStateIndev() {
        this.hasAttacked = false;
        final PathFinderIndev pathFinder = EntityCreature.pathFinderIndev;
        if (this.entityToAttack == null) {
            this.entityToAttack = this.findPlayerToAttack();
            if (this.entityToAttack != null) {
                this.indevPathToEntity = pathFinder.a(this, this.entityToAttack, 16.0f);
            }
        }
        else if (!this.entityToAttack.isEntityAlive()) {
            this.entityToAttack = null;
        }
        else {
            final float var1 = this.entityToAttack.getDistanceToEntity(this);
            if (this.worldObj.rayTraceBlocks(Vec3D.createVector(this.posX, this.posY + this.getEyeHeight(), this.posZ), Vec3D.createVector(this.posX, this.posY + this.getEyeHeight(), this.posZ)) == null) {
                this.attackEntity(this.entityToAttack, var1);
            }
        }
        if (this.hasAttacked) {
            this.movingLeftRight = 0.0f;
            this.movingForwardBack = 0.0f;
            this.isJumping = false;
        }
        else {
            if (this.entityToAttack != null && (this.indevPathToEntity == null || this.rand.nextInt(20) == 0)) {
                this.indevPathToEntity = pathFinder.a(this, this.entityToAttack, 16.0f);
            }
            else if (this.indevPathToEntity == null || this.rand.nextInt(100) == 0) {
                int var2 = -1;
                int var3 = -1;
                int var4 = -1;
                float var5 = -99999.0f;
                for (int var6 = 0; var6 < 200; ++var6) {
                    final int var7 = (int)(this.posX + (float)this.rand.nextInt(21) - 10.0);
                    final int var8 = (int)(this.posY + (float)this.rand.nextInt(9) - 4.0);
                    final int var9 = (int)(this.posZ + (float)this.rand.nextInt(21) - 10.0);
                    final float var10;
                    if ((var10 = this.getBlockPathWeight(var7, var8, var9)) > var5) {
                        var5 = var10;
                        var2 = var7;
                        var3 = var8;
                        var4 = var9;
                    }
                }
                if (var2 > 0) {
                    this.indevPathToEntity = pathFinder.a(this, var2, var3, var4, 16.0f);
                }
            }
            final boolean var11 = this.handleWaterMovement();
            final boolean var12 = this.handleLavaMovement();
            if (this.indevPathToEntity != null && this.rand.nextInt(100) != 0) {
                Vec3D var13 = this.indevPathToEntity.a(this);
                final float var5 = this.width * 2.0f;
                while (var13 != null) {
                    final double var14 = this.posZ;
                    double var15 = this.posY;
                    double var16 = this.posX;
                    var16 -= var13.xCoord;
                    var15 -= var13.yCoord;
                    final double var17 = var14 - var13.zCoord;
                    if (var16 * var16 + var15 * var15 + var17 * var17 >= var5 * var5) {
                        break;
                    }
                    if (var13.yCoord > this.posY) {
                        break;
                    }
                    this.indevPathToEntity.a();
                    if (this.indevPathToEntity.b()) {
                        var13 = null;
                        this.indevPathToEntity = null;
                    }
                    else {
                        var13 = this.indevPathToEntity.a(this);
                    }
                }
                this.isJumping = false;
                if (var13 != null) {
                    final double var17 = var13.xCoord - this.posX;
                    final double var16 = var13.zCoord - this.posZ;
                    final double var15 = var13.yCoord - this.posY;
                    this.rotationYaw = (float)(Math.atan2(var16, var17) * 180.0 / 3.141592653589793) - 90.0f;
                    this.movingForwardBack = (float)this.getRealMoveSpeed();
                    if (var15 > 0.0) {
                        this.isJumping = true;
                    }
                }
                if (this.rand.nextFloat() < 0.8f && (var11 || var12)) {
                    this.isJumping = true;
                }
            }
            else {
                super.updateEntityActionStateIndev();
                this.indevPathToEntity = null;
            }
        }
    }
    
    @Override
    protected void updateEntityActionState() {
        if (this.indevai) {
            this.updateEntityActionStateIndev();
            return;
        }
        this.hasAttacked = false;
        final float f = 16.0f;
        if (this.entityToAttack == null) {
            this.entityToAttack = this.findPlayerToAttack();
            if (this.entityToAttack != null) {
                this.pathToEntity = this.worldObj.getPathEntityToEntity(this, this.entityToAttack, f);
            }
        }
        else if (!this.entityToAttack.isEntityAlive()) {
            this.entityToAttack = null;
        }
        else {
            final float f2 = this.entityToAttack.getDistanceToEntity(this);
            if (this.canEntityBeSeen(this.entityToAttack)) {
                this.attackEntity(this.entityToAttack, f2);
            }
            else {
                this.attackBlockedEntity(this.entityToAttack, f2);
            }
        }
        if (!this.hasAttacked && this.entityToAttack != null && (this.pathToEntity == null || this.rand.nextInt(20) == 0)) {
            this.pathToEntity = this.worldObj.getPathEntityToEntity(this, this.entityToAttack, f);
        }
        else if ((this.pathToEntity == null && this.rand.nextInt(80) == 0) || this.rand.nextInt(80) == 0) {
            boolean flag = false;
            int j = -1;
            int k = -1;
            int l = -1;
            float f3 = -99999.0f;
            for (int i1 = 0; i1 < 10; ++i1) {
                final int j2 = MathHelper.floor_double(this.posX + this.rand.nextInt(13) - 6.0);
                final int k2 = MathHelper.floor_double(this.posY + this.rand.nextInt(7) - 3.0);
                final int l2 = MathHelper.floor_double(this.posZ + this.rand.nextInt(13) - 6.0);
                final float f4 = this.getBlockPathWeight(j2, k2, l2);
                if (f4 > f3) {
                    f3 = f4;
                    j = j2;
                    k = k2;
                    l = l2;
                    flag = true;
                }
            }
            if (flag) {
                this.pathToEntity = this.worldObj.func_637_a(this, j, k, l, 10.0f);
            }
        }
        final int m = MathHelper.floor_double(this.boundingBox.minY);
        final boolean flag2 = this.handleWaterMovement();
        final boolean flag3 = this.handleLavaMovement();
        this.rotationPitch = 0.0f;
        if (this.pathToEntity == null || this.rand.nextInt(100) == 0) {
            super.updateEntityActionState();
            this.pathToEntity = null;
            return;
        }
        Vec3D vec3d = this.pathToEntity.getPosition(this);
        final double d = this.width * 2.0f;
        while (vec3d != null && vec3d.squareDistanceTo(this.posX, vec3d.yCoord, this.posZ) < d * d) {
            this.pathToEntity.incrementPathIndex();
            if (this.pathToEntity.isFinished()) {
                vec3d = null;
                this.pathToEntity = null;
            }
            else {
                vec3d = this.pathToEntity.getPosition(this);
            }
        }
        this.isJumping = false;
        if (vec3d != null) {
            final double d2 = vec3d.xCoord - this.posX;
            final double d3 = vec3d.zCoord - this.posZ;
            final double d4 = vec3d.yCoord - m;
            final float f5 = (float)(Math.atan2(d3, d2) * 180.0 / 3.1415927410125732) - 90.0f;
            float f6 = f5 - this.rotationYaw;
            this.movingForwardBack = this.move_speed;
            while (f6 < -180.0f) {
                f6 += 360.0f;
            }
            while (f6 >= 180.0f) {
                f6 -= 360.0f;
            }
            if (f6 > 30.0f) {
                f6 = 30.0f;
            }
            if (f6 < -30.0f) {
                f6 = -30.0f;
            }
            this.rotationYaw += f6;
            if (this.hasAttacked && this.entityToAttack != null) {
                final double d5 = this.entityToAttack.posX - this.posX;
                final double d6 = this.entityToAttack.posZ - this.posZ;
                final float f7 = this.rotationYaw;
                this.rotationYaw = (float)(Math.atan2(d6, d5) * 180.0 / 3.1415927410125732) - 90.0f;
                final float f8 = (f7 - this.rotationYaw + 90.0f) * 3.141593f / 180.0f;
                this.movingLeftRight = -MathHelper.sin(f8) * this.movingForwardBack * 1.0f;
                this.movingForwardBack = MathHelper.cos(f8) * this.movingForwardBack * 1.0f;
            }
            if (d4 > 0.0) {
                this.isJumping = true;
            }
        }
        if (this.entityToAttack != null) {
            this.func_426_b(this.entityToAttack, 30.0f);
        }
        if (this.isCollidedHorizionally) {
            this.isJumping = true;
        }
        if (this.rand.nextFloat() < 0.8f && (flag2 || flag3)) {
            this.isJumping = true;
        }
    }
    
    protected void attackEntity(final Entity entity, final float f) {
    }
    
    protected void attackBlockedEntity(final Entity entity, final float f) {
    }
    
    protected float getBlockPathWeight(final int i, final int j, final int k) {
        return 0.0f;
    }
    
    protected Entity findPlayerToAttack() {
        return null;
    }
    
    @Override
    public boolean shouldSpawnOnTile() {
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.boundingBox.minY);
        final int k = MathHelper.floor_double(this.posZ);
        return super.shouldSpawnOnTile() && this.getBlockPathWeight(i, j, k) >= 0.0f;
    }
}
