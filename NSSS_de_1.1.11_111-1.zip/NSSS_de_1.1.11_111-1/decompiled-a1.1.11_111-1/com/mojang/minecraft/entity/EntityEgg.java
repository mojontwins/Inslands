package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.render.*;
import java.util.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntityEgg extends Entity
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private boolean inGround;
    public int shake;
    private EntityLiving field_20083_aj;
    private int field_20081_ak;
    private int field_20079_al;
    
    public EntityEgg(final World world) {
        super(world);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.shake = 0;
        this.field_20079_al = 0;
        this.setSize(0.25f, 0.25f);
    }
    
    @Override
    protected void entityInit() {
    }
    
    public EntityEgg(final World world, final EntityLiving entityliving) {
        super(world);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.shake = 0;
        this.field_20079_al = 0;
        this.field_20083_aj = entityliving;
        this.setSize(0.25f, 0.25f);
        this.setLocationAndAngles(entityliving.posX, entityliving.posY + entityliving.getEyeHeight(), entityliving.posZ, entityliving.rotationYaw, entityliving.rotationPitch);
        this.posX -= MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.posY -= 0.10000000149011612;
        this.posZ -= MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.yOffset = 0.0f;
        final float f = 0.4f;
        this.motionX = -MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionZ = MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionY = -MathHelper.sin(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.func_20078_a(this.motionX, this.motionY, this.motionZ, 1.5f, 1.0f);
    }
    
    public EntityEgg(final World world, final double d, final double d1, final double d2) {
        super(world);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.shake = 0;
        this.field_20079_al = 0;
        this.field_20081_ak = 0;
        this.setSize(0.25f, 0.25f);
        this.setPosition(d, d1, d2);
        this.yOffset = 0.0f;
    }
    
    public void func_20078_a(double d, double d1, double d2, final float f, final float f1) {
        final float f2 = MathHelper.sqrt_double(d * d + d1 * d1 + d2 * d2);
        d /= f2;
        d1 /= f2;
        d2 /= f2;
        d += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d1 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d2 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d *= f;
        d1 *= f;
        d2 *= f;
        this.motionX = d;
        this.motionY = d1;
        this.motionZ = d2;
        final float f3 = MathHelper.sqrt_double(d * d + d2 * d2);
        final float n = (float)(Math.atan2(d, d2) * 180.0 / 3.1415927410125732);
        this.rotationYaw = n;
        this.prevRotationYaw = n;
        final float n2 = (float)(Math.atan2(d1, f3) * 180.0 / 3.1415927410125732);
        this.rotationPitch = n2;
        this.prevRotationPitch = n2;
        this.field_20081_ak = 0;
    }
    
    @Override
    public void onUpdate() {
        this.lastTickPosX = this.posX;
        this.lastTickPosY = this.posY;
        this.lastTickPosZ = this.posZ;
        super.onUpdate();
        if (this.shake > 0) {
            --this.shake;
        }
        if (this.inGround) {
            final int i = this.worldObj.getBlockId(this.xTile, this.yTile, this.zTile);
            if (i == this.inTile) {
                ++this.field_20081_ak;
                if (this.field_20081_ak == 1200) {
                    this.setEntityDead();
                }
                return;
            }
            this.inGround = false;
            this.motionX *= this.rand.nextFloat() * 0.2f;
            this.motionY *= this.rand.nextFloat() * 0.2f;
            this.motionZ *= this.rand.nextFloat() * 0.2f;
            this.field_20081_ak = 0;
            this.field_20079_al = 0;
        }
        else {
            ++this.field_20079_al;
        }
        Vec3D vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        Vec3D vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(vec3d, vec3d2);
        vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        if (movingobjectposition != null) {
            vec3d2 = Vec3D.createVector(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
        }
        if (!this.worldObj.multiplayerWorld) {
            Entity entity = null;
            final List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0));
            double d = 0.0;
            for (int i2 = 0; i2 < list.size(); ++i2) {
                final Entity entity2 = list.get(i2);
                if (entity2.canBeCollidedWith()) {
                    if (entity2 != this.field_20083_aj || this.field_20079_al >= 5) {
                        final float f4 = 0.3f;
                        final AxisAlignedBB axisalignedbb = entity2.boundingBox.expand(f4, f4, f4);
                        final MovingObjectPosition movingobjectposition2 = axisalignedbb.func_1169_a(vec3d, vec3d2);
                        if (movingobjectposition2 != null) {
                            final double d2 = vec3d.distanceTo(movingobjectposition2.hitVec);
                            if (d2 < d || d == 0.0) {
                                entity = entity2;
                                d = d2;
                            }
                        }
                    }
                }
            }
            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }
        }
        if (movingobjectposition != null) {
            if (movingobjectposition.entityHit == null || !movingobjectposition.entityHit.attackEntityFrom(this.field_20083_aj, 0)) {}
            if (!this.worldObj.multiplayerWorld && this.rand.nextInt(8) == 0) {
                byte byte0 = 1;
                if (this.rand.nextInt(32) == 0) {
                    byte0 = 4;
                }
                for (int k = 0; k < byte0; ++k) {
                    final EntityChicken entitychicken = new EntityChicken(this.worldObj);
                    entitychicken.setLocationAndAngles(this.posX, this.posY, this.posZ, this.rotationYaw, 0.0f);
                    this.worldObj.entityJoinedWorld(entitychicken);
                }
            }
            for (int j = 0; j < 8; ++j) {
                this.worldObj.spawnParticle("snowballpoof", this.posX, this.posY, this.posZ, 0.0, 0.0, 0.0);
            }
            this.setEntityDead();
        }
        this.posX += this.motionX;
        this.posY += this.motionY;
        this.posZ += this.motionZ;
        final float f5 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0 / 3.1415927410125732);
        this.rotationPitch = (float)(Math.atan2(this.motionY, f5) * 180.0 / 3.1415927410125732);
        while (this.rotationPitch - this.prevRotationPitch < -180.0f) {
            this.prevRotationPitch -= 360.0f;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0f) {
            this.prevRotationPitch += 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0f) {
            this.prevRotationYaw -= 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0f) {
            this.prevRotationYaw += 360.0f;
        }
        this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2f;
        this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2f;
        final float f6 = 0.99f;
        final float f7 = 0.03f;
        this.motionX *= f6;
        this.motionY *= f6;
        this.motionZ *= f6;
        this.motionY -= f7;
        this.setPosition(this.posX, this.posY, this.posZ);
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("xTile", (short)this.xTile);
        nbttagcompound.setShort("yTile", (short)this.yTile);
        nbttagcompound.setShort("zTile", (short)this.zTile);
        nbttagcompound.setByte("inTile", (byte)this.inTile);
        nbttagcompound.setByte("shake", (byte)this.shake);
        nbttagcompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.xTile = nbttagcompound.getShort("xTile");
        this.yTile = nbttagcompound.getShort("yTile");
        this.zTile = nbttagcompound.getShort("zTile");
        this.inTile = (nbttagcompound.getByte("inTile") & 0xFF);
        this.shake = (nbttagcompound.getByte("shake") & 0xFF);
        this.inGround = (nbttagcompound.getByte("inGround") == 1);
    }
    
    @Override
    public void onCollideWithPlayer(final EntityPlayer entityplayer) {
        if (this.inGround && this.field_20083_aj == entityplayer && this.shake <= 0 && entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.arrow, 1))) {
            this.worldObj.playSoundAtEntity(this, "random.pop", 0.2f, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            entityplayer.onItemPickup(this, 1);
            this.setEntityDead();
        }
    }
}
