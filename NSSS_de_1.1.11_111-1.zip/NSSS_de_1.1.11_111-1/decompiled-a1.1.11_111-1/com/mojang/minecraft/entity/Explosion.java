package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.render.*;
import java.util.*;

public class Explosion
{
    public boolean isFlaming;
    private Random ExplosionRNG;
    public Set destroyedBlockPositions;
    private World worldObj;
    public Entity exploder;
    public float explosionSize;
    public double explosionX;
    public double explosionY;
    public double explosionZ;
    
    public Explosion() {
    }
    
    public Explosion(final World world, final Entity entity, final double d, final double d1, final double d2, final float f) {
        this.isFlaming = false;
        this.ExplosionRNG = new Random();
        this.destroyedBlockPositions = new HashSet();
        this.worldObj = world;
        this.exploder = entity;
        this.explosionSize = f;
        this.explosionX = d;
        this.explosionY = d1;
        this.explosionZ = d2;
    }
    
    public void doExplosionA() {
        this.func_901_a(this.worldObj, this.exploder, this.explosionX, this.explosionY, this.explosionZ, this.explosionSize);
    }
    
    public void doExplosionB(final boolean flag) {
        this.func_901_a(this.worldObj, this.exploder, this.explosionX, this.explosionY, this.explosionZ, this.explosionSize);
    }
    
    public void func_901_a(final World world, final Entity entity, final double d, final double d1, final double d2, float f) {
        world.playSoundEffect(d, d1, d2, "random.explode", 4.0f, (1.0f + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.2f) * 0.7f);
        final HashSet<ChunkPosition> hashset = new HashSet<ChunkPosition>();
        final float f2 = f;
        for (int i = 16, j = 0; j < i; ++j) {
            for (int l = 0; l < i; ++l) {
                for (int j2 = 0; j2 < i; ++j2) {
                    if (j == 0 || j == i - 1 || l == 0 || l == i - 1 || j2 == 0 || j2 == i - 1) {
                        double d3 = j / (i - 1.0f) * 2.0f - 1.0f;
                        double d4 = l / (i - 1.0f) * 2.0f - 1.0f;
                        double d5 = j2 / (i - 1.0f) * 2.0f - 1.0f;
                        final double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
                        d3 /= d6;
                        d4 /= d6;
                        d5 /= d6;
                        float f3 = f * (0.7f + world.rand.nextFloat() * 0.6f);
                        double d7 = d;
                        double d8 = d1;
                        double d9 = d2;
                        for (float f4 = 0.3f; f3 > 0.0f; f3 -= f4 * 0.75f) {
                            final int j3 = MathHelper.floor_double(d7);
                            final int k4 = MathHelper.floor_double(d8);
                            final int l2 = MathHelper.floor_double(d9);
                            final int i2 = world.getBlockId(j3, k4, l2);
                            if (i2 > 0) {
                                f3 -= (Block.allBlocks[i2].getExplosionResistance(entity) + 0.3f) * f4;
                            }
                            if (f3 > 0.0f) {
                                hashset.add(new ChunkPosition(j3, k4, l2));
                            }
                            d7 += d3 * f4;
                            d8 += d4 * f4;
                            d9 += d5 * f4;
                        }
                    }
                }
            }
        }
        f *= 2.0f;
        final int m = MathHelper.floor_double(d - f - 1.0);
        final int i3 = MathHelper.floor_double(d + f + 1.0);
        final int k5 = MathHelper.floor_double(d1 - f - 1.0);
        final int l3 = MathHelper.floor_double(d1 + f + 1.0);
        final int i4 = MathHelper.floor_double(d2 - f - 1.0);
        final int j4 = MathHelper.floor_double(d2 + f + 1.0);
        final List<?> list = world.getEntitiesWithinAABBExcludingEntity(entity, AxisAlignedBB.getBoundingBoxFromPool(m, k5, i4, i3, l3, j4));
        final Vec3D vec3d = Vec3D.createVector(d, d1, d2);
        for (int k6 = 0; k6 < list.size(); ++k6) {
            final Entity entity2 = (Entity)list.get(k6);
            final double d10 = entity2.getDistance(d, d1, d2) / f;
            if (d10 <= 1.0) {
                double d11 = entity2.posX - d;
                double d12 = entity2.posY - d1;
                double d13 = entity2.posZ - d2;
                final double d14 = MathHelper.sqrt_double(d11 * d11 + d12 * d12 + d13 * d13);
                d11 /= d14;
                d12 /= d14;
                d13 /= d14;
                final double d15 = world.func_675_a(vec3d, entity2.boundingBox);
                final double d16 = (1.0 - d10) * d15;
                entity2.attackEntityFrom(entity, (int)((d16 * d16 + d16) / 2.0 * 8.0 * f + 1.0) - entity2.goldArmor * 4);
                final double d17 = d16;
                final Entity entity3 = entity2;
                entity3.motionX += d11 * d17;
                final Entity entity4 = entity2;
                entity4.motionY += d12 * d17;
                final Entity entity5 = entity2;
                entity5.motionZ += d13 * d17;
            }
        }
        f = f2;
        final ArrayList<ChunkPosition> arraylist = new ArrayList<ChunkPosition>();
        arraylist.addAll(hashset);
        for (int l4 = arraylist.size() - 1; l4 >= 0; --l4) {
            final ChunkPosition chunkposition = arraylist.get(l4);
            final int i5 = chunkposition.x;
            final int j5 = chunkposition.y;
            final int k7 = chunkposition.z;
            final int l5 = world.getBlockId(i5, j5, k7);
            for (int i6 = 0; i6 < 1; ++i6) {
                final double d18 = i5 + world.rand.nextFloat();
                final double d19 = j5 + world.rand.nextFloat();
                final double d20 = k7 + world.rand.nextFloat();
                double d21 = d18 - d;
                double d22 = d19 - d1;
                double d23 = d20 - d2;
                final double d24 = MathHelper.sqrt_double(d21 * d21 + d22 * d22 + d23 * d23);
                d21 /= d24;
                d22 /= d24;
                d23 /= d24;
                double d25 = 0.5 / (d24 / f + 0.1);
                d25 *= world.rand.nextFloat() * world.rand.nextFloat() + 0.3f;
                d21 *= d25;
                d22 *= d25;
                d23 *= d25;
                world.spawnParticle("explode", (d18 + d * 1.0) / 2.0, (d19 + d1 * 1.0) / 2.0, (d20 + d2 * 1.0) / 2.0, d21, d22, d23);
                world.spawnParticle("smoke", d18, d19, d20, d21, d22, d23);
            }
            if (l5 > 0) {
                Block.allBlocks[l5].dropBlockAsItemWithChance(world, i5, j5, k7, world.getBlockMetadata(i5, j5, k7), 0.3f);
                world.setBlockWithNotify(i5, j5, k7, 0);
                Block.allBlocks[l5].onBlockDestroyedByExplosion(world, i5, j5, k7);
            }
        }
    }
}
