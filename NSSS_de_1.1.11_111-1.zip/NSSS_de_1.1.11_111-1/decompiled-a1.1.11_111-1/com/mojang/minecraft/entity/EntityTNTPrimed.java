package com.mojang.minecraft.entity;

import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;

public class EntityTNTPrimed extends Entity
{
    public int field_689_a;
    public static boolean extinguish;
    
    static {
        EntityTNTPrimed.extinguish = true;
    }
    
    public EntityTNTPrimed(final World world) {
        super(world);
        this.field_689_a = 0;
        this.preventEntitySpawning = true;
        this.setSize(0.98f, 0.98f);
        this.yOffset = this.height / 2.0f;
    }
    
    public EntityTNTPrimed(final World world, final float f, final float f1, final float f2) {
        this(world);
        this.setPosition(f, f1, f2);
        final float f3 = (float)(Math.random() * 3.1415927410125732 * 2.0);
        this.motionX = -MathHelper.sin(f3 * 3.141593f / 180.0f) * 0.02f;
        this.motionY = 0.20000000298023224;
        this.motionZ = -MathHelper.cos(f3 * 3.141593f / 180.0f) * 0.02f;
        this.field_640_aG = false;
        this.field_689_a = 80;
        this.prevPosX = f;
        this.prevPosY = f1;
        this.prevPosZ = f2;
    }
    
    @Override
    protected void entityInit() {
    }
    
    public EntityTNTPrimed(final WorldClient worldClient, final double d, final double d1, final double d2) {
        this((World)worldClient, (float)d, (float)d1, (float)d2);
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.03999999910593033;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9800000190734863;
        this.motionY *= 0.9800000190734863;
        this.motionZ *= 0.9800000190734863;
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
            this.motionY *= -0.5;
        }
        if (this.field_689_a-- <= 0) {
            this.setEntityDead();
            this.explode();
        }
        else {
            this.worldObj.spawnParticle("smoke", this.posX, this.posY + 0.5, this.posZ, 0.0, 0.0, 0.0);
        }
    }
    
    @Override
    public boolean attackEntityFrom(final Entity damagesource, final int i) {
        final Entity entity = damagesource;
        if (this.isDead || !(damagesource instanceof EntityPlayer)) {
            return true;
        }
        this.worldObj.playSoundAtEntity(this, "dig.grass", 1.0f, 1.0f);
        this.setEntityDead();
        if (((EntityPlayer)entity).isCreative) {
            return true;
        }
        this.dropItemWithOffset(Block.tnt.blockID, 1, 0.0f);
        return true;
    }
    
    private void explode() {
        final float f = 4.0f;
        this.worldObj.createExplosion(null, this.posX, this.posY, this.posZ, f);
    }
    
    @Override
    protected void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setByte("Fuse", (byte)this.field_689_a);
    }
    
    @Override
    protected void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.field_689_a = nbttagcompound.getByte("Fuse");
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
}
