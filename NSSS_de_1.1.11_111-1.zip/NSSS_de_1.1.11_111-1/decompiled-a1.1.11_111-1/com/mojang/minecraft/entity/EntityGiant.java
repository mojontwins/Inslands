package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;

public class EntityGiant extends EntityMobs
{
    public EntityGiant(final World world) {
        super(world);
        this.texture = "/mob/zombie.png";
        this.scoreYield = 250;
        this.move_speed = 15.0f;
        this.maxHealth = 50;
        this.health *= 10;
        this.yOffset *= 6.0f;
        this.setSize(this.width * 6.0f, this.height * 6.0f);
    }
    
    @Override
    protected float getBlockPathWeight(final int i, final int j, final int k) {
        return 0.0f;
    }
    
    @Override
    protected Entity findPlayerToAttack() {
        final float f = 0.0f;
        if (f < 0.5f) {
            final double d = 128.0;
            this.currentSpeed = 15.0;
            return this.worldObj.getClosestPlayerToEntity(this, d);
        }
        return null;
    }
    
    @Override
    public double getRealMoveSpeed() {
        return 15.0;
    }
    
    @Override
    protected void updateEntityActionState() {
        this.updateEntityActionStateIndev();
    }
    
    @Override
    public void onDeath(final Entity entity) {
        super.onDeath(entity);
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        final int i = Item.shovelObsidian.shiftedIndex;
        if (i > 0) {
            final int j = this.rand.nextInt(3);
            this.dropItem(i + j, 1);
        }
    }
}
