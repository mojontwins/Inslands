package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;
import java.util.*;

public class EntityLiving extends Entity
{
    int spongeArmor;
    int airQuart;
    public int maxHealth;
    public float field_738_k;
    public float field_737_l;
    public float field_736_m;
    public float renderYawOffset;
    public float prevRenderYawOffset;
    public float field_733_p;
    public float field_732_q;
    public float field_731_r;
    public float unknownFloat;
    protected boolean field_729_t;
    protected String texture;
    protected boolean field_727_v;
    protected float field_726_w;
    protected String field_725_x;
    protected float field_724_y;
    protected int scoreYield;
    protected float field_721_A;
    public boolean isMultiplayerEntity;
    public float prevSwingProgress;
    public float swingProgress;
    public int health;
    public int prevHealth;
    private int field_748_a;
    public int hurtTime;
    public int maxHurtTime;
    public float attackedAtYaw;
    public int deathTime;
    public int attackTime;
    public float lookPitch;
    public float field_709_M;
    protected boolean dead;
    public int entityAge;
    public float field_706_P;
    public float field_705_Q;
    public float limbSwingAmount;
    public float limbSwing;
    private int field_747_b;
    private double field_746_c;
    private double field_745_d;
    private double field_744_e;
    private double field_743_f;
    private double field_742_g;
    float field_702_T;
    protected int field_701_U;
    protected float movingLeftRight;
    protected float movingForwardBack;
    protected float field_698_X;
    protected boolean isJumping;
    public boolean isRunning;
    protected float field_696_Z;
    protected float move_speed;
    public Entity ridingEntity;
    private int field_740_i;
    public boolean isCreative;
    
    public EntityLiving(final World world) {
        super(world);
        this.airQuart = this.spongeArmor;
        this.maxHealth = 20;
        this.renderYawOffset = 0.0f;
        this.prevRenderYawOffset = 0.0f;
        this.field_729_t = true;
        this.texture = "/char.png";
        this.field_727_v = true;
        this.field_726_w = 0.0f;
        this.field_725_x = null;
        this.field_724_y = 1.0f;
        this.scoreYield = 0;
        this.field_721_A = 0.0f;
        this.isMultiplayerEntity = false;
        this.attackedAtYaw = 0.0f;
        this.deathTime = 0;
        this.attackTime = 0;
        this.dead = false;
        this.entityAge = -1;
        this.field_706_P = (float)(Math.random() * 0.8999999761581421 + 0.10000000149011612);
        this.field_702_T = 0.0f;
        this.field_701_U = 0;
        this.isJumping = false;
        this.isRunning = false;
        this.field_696_Z = 0.0f;
        this.move_speed = 0.7f;
        this.field_740_i = 0;
        this.health = 10;
        this.preventEntitySpawning = true;
        this.field_736_m = (float)(Math.random() + 1.0) * 0.01f;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.field_738_k = (float)Math.random() * 12398.0f;
        this.rotationYaw = (float)(Math.random() * 3.1415927410125732 * 2.0);
        this.field_737_l = 1.0f;
        this.stepHeight = 0.5f;
        this.isCreative = false;
        this.leatherArmor = 0;
        this.goldArmor = 0;
        this.chainArmor = 0;
        this.steelArmor = 0;
        this.diamondArmor = 0;
    }
    
    @Override
    protected void entityInit() {
    }
    
    protected void damageEntity(final int i) {
        this.health -= i;
    }
    
    protected boolean canEntityBeSeen(final Entity entity) {
        return this.worldObj.rayTraceBlocks(Vec3D.createVector(this.posX, this.posY + this.func_373_s(), this.posZ), Vec3D.createVector(entity.posX, entity.posY + entity.func_373_s(), entity.posZ)) == null;
    }
    
    @Override
    public String getEntityTexture() {
        return this.texture;
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }
    
    @Override
    public boolean canBePushed() {
        return !this.isDead;
    }
    
    @Override
    protected float func_373_s() {
        return this.height * 0.85f;
    }
    
    public int func_421_b() {
        return 80;
    }
    
    @Override
    public void onEntityUpdate() {
        this.prevSwingProgress = this.swingProgress;
        super.onEntityUpdate();
        if (this.rand.nextInt(1000) < this.field_748_a++) {
            this.field_748_a = -this.func_421_b();
            final String s = this.idleSound();
            if (s != null) {
                this.worldObj.playSoundAtEntity(this, s, this.func_413_f(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            }
        }
        if (this.isEntityAlive() && this.isEntityInsideOpaqueBlock()) {
            this.attackEntityFrom(null, 1);
        }
        if (this.worldObj.multiplayerWorld) {
            this.fire = 0;
        }
        if (this.isEntityAlive() && this.isInsideOfMaterial(Material.water)) {
            if (this.spongeArmor > 0 && this.airQuart > 0) {
                --this.airQuart;
            }
            else if (this.spongeArmor == 0 || this.airQuart == 0) {
                --this.air;
                this.airQuart = this.spongeArmor;
            }
            if (this.air == -20) {
                this.air = 0;
                for (int i = 0; i < 8; ++i) {
                    final float f = this.rand.nextFloat() - this.rand.nextFloat();
                    final float f2 = this.rand.nextFloat() - this.rand.nextFloat();
                    final float f3 = this.rand.nextFloat() - this.rand.nextFloat();
                    this.worldObj.spawnParticle("bubble", this.posX + f, this.posY + f2, this.posZ + f3, this.motionX, this.motionY, this.motionZ);
                }
                this.attackEntityFrom(null, 2);
            }
            this.fire = 0;
        }
        else {
            this.air = this.maxAir;
        }
        this.lookPitch = this.field_709_M;
        if (this.attackTime > 0) {
            --this.attackTime;
        }
        if (this.hurtTime > 0) {
            --this.hurtTime;
        }
        if (this.heartsLife > 0) {
            --this.heartsLife;
        }
        if (this.health <= 0) {
            ++this.deathTime;
            if (this.deathTime > 20 && !(this instanceof EntityClientPlayerMP)) {
                this.func_436_D();
                this.setEntityDead();
                for (int j = 0; j < 20; ++j) {
                    final double d = this.rand.nextGaussian() * 0.02;
                    final double d2 = this.rand.nextGaussian() * 0.02;
                    final double d3 = this.rand.nextGaussian() * 0.02;
                    this.worldObj.spawnParticle("explode", this.posX + this.rand.nextFloat() * this.width * 2.0f - this.width, this.posY + this.rand.nextFloat() * this.height, this.posZ + this.rand.nextFloat() * this.width * 2.0f - this.width, d, d2, d3);
                }
            }
        }
        this.unknownFloat = this.field_731_r;
        this.prevRenderYawOffset = this.renderYawOffset;
        this.prevRotationYaw = this.rotationYaw;
        this.prevRotationPitch = this.rotationPitch;
    }
    
    public void func_415_z() {
        for (int i = 0; i < 20; ++i) {
            final double d = this.rand.nextGaussian() * 0.02;
            final double d2 = this.rand.nextGaussian() * 0.02;
            final double d3 = this.rand.nextGaussian() * 0.02;
            final double d4 = 10.0;
            this.worldObj.spawnParticle("explode", this.posX + this.rand.nextFloat() * this.width * 2.0f - this.width - d * d4, this.posY + this.rand.nextFloat() * this.height - d2 * d4, this.posZ + this.rand.nextFloat() * this.width * 2.0f - this.width - d3 * d4, d, d2, d3);
        }
    }
    
    @Override
    public void updateRidden() {
        super.updateRidden();
        this.field_733_p = this.field_732_q;
        this.field_732_q = 0.0f;
    }
    
    @Override
    public void setPositionAndRotation2(final double d, final double d1, final double d2, final float f, final float f1, final int i) {
        this.yOffset = 0.0f;
        this.field_746_c = d;
        this.field_745_d = d1;
        this.field_744_e = d2;
        this.field_743_f = f;
        this.field_742_g = f1;
        this.field_747_b = i;
    }
    
    @Override
    public float getEyeHeight() {
        return this.yOffset;
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        this.onLivingUpdate();
        final double d = this.posX - this.prevPosX;
        final double d2 = this.posZ - this.prevPosZ;
        final float f = MathHelper.sqrt_double(d * d + d2 * d2);
        float f2 = this.renderYawOffset;
        float f3 = 0.0f;
        this.field_733_p = this.field_732_q;
        float f4 = 0.0f;
        if (f > 0.05f) {
            f4 = 1.0f;
            f3 = f * 3.0f;
            f2 = (float)Math.atan2(d2, d) * 180.0f / 3.141593f - 90.0f;
        }
        if (this.swingProgress > 0.0f) {
            f2 = this.rotationYaw;
        }
        if (!this.onGround) {
            f4 = 0.0f;
        }
        this.field_732_q += (f4 - this.field_732_q) * 0.3f;
        float f5;
        for (f5 = f2 - this.renderYawOffset; f5 < -180.0f; f5 += 360.0f) {}
        while (f5 >= 180.0f) {
            f5 -= 360.0f;
        }
        this.renderYawOffset += f5 * 0.3f;
        float f6;
        for (f6 = this.rotationYaw - this.renderYawOffset; f6 < -180.0f; f6 += 360.0f) {}
        while (f6 >= 180.0f) {
            f6 -= 360.0f;
        }
        final boolean flag = f6 < -90.0f || f6 >= 90.0f;
        if (f6 < -75.0f) {
            f6 = -75.0f;
        }
        if (f6 >= 75.0f) {
            f6 = 75.0f;
        }
        this.renderYawOffset = this.rotationYaw - f6;
        if (f6 * f6 > 2500.0f) {
            this.renderYawOffset += f6 * 0.2f;
        }
        if (flag) {
            f3 *= -1.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0f) {
            this.prevRotationYaw -= 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0f) {
            this.prevRotationYaw += 360.0f;
        }
        while (this.renderYawOffset - this.prevRenderYawOffset < -180.0f) {
            this.prevRenderYawOffset -= 360.0f;
        }
        while (this.renderYawOffset - this.prevRenderYawOffset >= 180.0f) {
            this.prevRenderYawOffset += 360.0f;
        }
        while (this.rotationPitch - this.prevRotationPitch < -180.0f) {
            this.prevRotationPitch -= 360.0f;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0f) {
            this.prevRotationPitch += 360.0f;
        }
        this.field_731_r += f3;
    }
    
    @Override
    protected void setSize(final float f, final float f1) {
        super.setSize(f, f1);
    }
    
    @Override
    public void performHurtAnimation() {
        final int n = 10;
        this.maxHurtTime = n;
        this.hurtTime = n;
        this.attackedAtYaw = 0.0f;
    }
    
    @Override
    public void handleHealthUpdate(final byte byte0) {
        if (byte0 == 2) {
            this.limbSwingAmount = 1.5f;
            this.heartsLife = this.maxHealth;
            final int n = 10;
            this.maxHurtTime = n;
            this.hurtTime = n;
            this.attackedAtYaw = 0.0f;
            this.worldObj.playSoundAtEntity(this, this.hurtSound(), 1.0f, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            this.attackEntityFrom(null, 0);
        }
        else if (byte0 == 3) {
            this.worldObj.playSoundAtEntity(this, this.deathSound(), 1.0f, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            this.health = 0;
            this.onDeath(null);
        }
        else {
            super.handleHealthUpdate(byte0);
        }
    }
    
    public void heal(final int i) {
        if (this.health <= 0) {
            return;
        }
        this.health += i;
        if (this.health > 20) {
            this.health = 20;
        }
        this.heartsLife = this.maxHealth / 2;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        this.attackedAtYaw = 0.0f;
        if (entity != null) {
            double d;
            double d2;
            for (d = entity.posX - this.posX, d2 = entity.posZ - this.posZ; d * d + d2 * d2 < 1.0E-4; d = (Math.random() - Math.random()) * 0.01, d2 = (Math.random() - Math.random()) * 0.01) {}
            this.attackedAtYaw = (float)(Math.atan2(d2, d) * 180.0 / 3.1415927410125732) - this.rotationYaw;
            this.func_434_a(entity, i, d, d2);
        }
        else {
            this.attackedAtYaw = (float)((int)(Math.random() * 2.0) * 180);
        }
        if (this.worldObj.multiplayerWorld) {
            return false;
        }
        this.field_701_U = 0;
        if (this.health <= 0 || this.isCreative) {
            return false;
        }
        this.limbSwingAmount = 1.5f;
        if (this.heartsLife > this.maxHealth / 2.0f) {
            if (this.prevHealth - i >= this.health) {
                return false;
            }
            this.health = this.prevHealth - i;
        }
        else {
            this.prevHealth = this.health;
            this.heartsLife = this.maxHealth;
            this.health -= i;
            final int n = 10;
            this.maxHurtTime = n;
            this.hurtTime = n;
        }
        if (this.health <= 0) {
            this.worldObj.playSoundAtEntity(this, this.deathSound(), this.func_413_f(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            this.onDeath(entity);
        }
        else {
            this.worldObj.playSoundAtEntity(this, this.hurtSound(), this.func_413_f(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
        }
        return true;
    }
    
    protected float func_413_f() {
        return 1.0f;
    }
    
    protected String idleSound() {
        return null;
    }
    
    protected String hurtSound() {
        return "random.hurt";
    }
    
    protected String deathSound() {
        return "random.hurt";
    }
    
    public void func_434_a(final Entity entity, final int i, final double d, final double d1) {
        final float f = MathHelper.sqrt_double(d * d + d1 * d1);
        final float f2 = 0.4f;
        this.motionX /= 2.0;
        this.motionY /= 2.0;
        this.motionZ /= 2.0;
        this.motionX -= d / f * f2;
        this.motionY += 0.4000000059604645;
        this.motionZ -= d1 / f * f2;
        if (this.motionY > 0.4000000059604645) {
            this.motionY = 0.4000000059604645;
        }
    }
    
    public void onDeath(final Entity entity) {
        if (this.scoreYield > 0 && entity != null) {
            entity.addToPlayerScore(this, this.scoreYield);
        }
        this.dead = true;
        final int i = this.deathDropItem();
        if (i > 0 && !this.worldObj.multiplayerWorld) {
            for (int j = this.rand.nextInt(3), k = 0; k < j; ++k) {
                this.dropItem(i, 1);
            }
        }
    }
    
    protected int deathDropItem() {
        return 0;
    }
    
    @Override
    protected void fall(final float fallDist) {
        final int damage = (int)Math.ceil(fallDist - 3.0f) - this.goldArmor * 2;
        if (damage > 0) {
            this.attackEntityFrom(null, damage);
            final int j = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY - 0.20000000298023224 - this.yOffset), MathHelper.floor_double(this.posZ));
            if (j > 0) {
                final StepSound stepsound = Block.allBlocks[j].stepSound;
                this.worldObj.playSoundAtEntity(this, stepsound.func_1145_d(), stepsound.getVolume() * 0.5f, stepsound.getPitch() * 0.75f);
            }
        }
    }
    
    public void func_435_b(final float leftRight, final float forwardBack) {
        if (this.handleWaterMovement()) {
            final double d = this.posY;
            this.moveFlying(leftRight, forwardBack, 0.02f);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.800000011920929;
            this.motionY *= 0.800000011920929;
            this.motionZ *= 0.800000011920929;
            this.motionY -= 0.02;
            this.motionX += this.motionX * (this.spongeArmor / 4 * 0.15);
            this.motionZ += this.motionZ * (this.spongeArmor / 4 * 0.15);
            if (this.isCollidedHorizionally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6000000238418579 - this.posY + d, this.motionZ)) {
                this.motionY = 0.30000001192092896;
            }
        }
        else if (this.handleLavaMovement()) {
            final double d2 = this.posY;
            this.moveFlying(leftRight, forwardBack, 0.02f);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.5;
            this.motionY *= 0.5;
            this.motionZ *= 0.5;
            this.motionY -= 0.02;
            if (this.isCollidedHorizionally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6000000238418579 - this.posY + d2, this.motionZ)) {
                this.motionY = 0.30000001192092896;
            }
        }
        else {
            float f2 = 0.91f;
            if (this.onGround) {
                f2 = 0.5460001f;
                final int i = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (i > 0) {
                    f2 = Block.allBlocks[i].slipperiness * 0.91f;
                }
            }
            final float f3 = 0.1627714f / (f2 * f2 * f2);
            this.moveFlying(leftRight, forwardBack, this.onGround ? (0.1f * f3) : 0.02f);
            f2 = 0.91f;
            if (this.onGround) {
                f2 = 0.5460001f;
                final int j = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (j > 0) {
                    f2 = Block.allBlocks[j].slipperiness * 0.91f;
                }
            }
            if (this.onLadder()) {
                this.fallDistance = 0.0f;
                if (this.motionY < -0.15) {
                    this.motionY = -0.15;
                }
            }
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            if (this.isCollidedHorizionally && this.onLadder()) {
                this.motionY = 0.2;
            }
            this.motionY -= 0.08;
            this.motionY *= 0.9800000190734863;
            this.motionX *= f2;
            this.motionZ *= f2;
        }
        this.field_705_Q = this.limbSwingAmount;
        final double d3 = this.posX - this.prevPosX;
        final double d4 = this.posZ - this.prevPosZ;
        float f4 = MathHelper.sqrt_double(d3 * d3 + d4 * d4) * 4.0f;
        if (f4 > 1.0f) {
            f4 = 1.0f;
        }
        this.limbSwingAmount += (f4 - this.limbSwingAmount) * 0.4f;
        this.limbSwing += this.limbSwingAmount;
    }
    
    public boolean onLadder() {
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.boundingBox.minY);
        final int k = MathHelper.floor_double(this.posZ);
        return this.worldObj.getBlockId(i, j, k) == Block.ladder.blockID || this.worldObj.getBlockId(i, j + 1, k) == Block.ladder.blockID;
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("Health", (short)this.health);
        nbttagcompound.setShort("HurtTime", (short)this.hurtTime);
        nbttagcompound.setShort("DeathTime", (short)this.deathTime);
        nbttagcompound.setShort("AttackTime", (short)this.attackTime);
        nbttagcompound.setBool("isCreative", this.isCreative);
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.health = nbttagcompound.getShort("Health");
        if (!nbttagcompound.hasKey("Health")) {
            this.health = 10;
        }
        this.hurtTime = nbttagcompound.getShort("HurtTime");
        this.deathTime = nbttagcompound.getShort("DeathTime");
        this.attackTime = nbttagcompound.getShort("AttackTime");
        this.isCreative = nbttagcompound.getBoolean("isCreative");
    }
    
    @Override
    public boolean isEntityAlive() {
        return !this.isDead && this.health > 0;
    }
    
    public void onLivingUpdate() {
        if (this.field_747_b > 0) {
            final double d = this.posX + (this.field_746_c - this.posX) / this.field_747_b;
            final double d2 = this.posY + (this.field_745_d - this.posY) / this.field_747_b;
            final double d3 = this.posZ + (this.field_744_e - this.posZ) / this.field_747_b;
            double d4;
            for (d4 = this.field_743_f - this.rotationYaw; d4 < -180.0; d4 += 360.0) {}
            while (d4 >= 180.0) {
                d4 -= 360.0;
            }
            this.rotationYaw += (float)(d4 / this.field_747_b);
            this.rotationPitch += (float)((this.field_742_g - this.rotationPitch) / this.field_747_b);
            --this.field_747_b;
            this.setPosition(d, d2, d3);
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }
        if (this.health <= 0) {
            this.isJumping = false;
            this.movingLeftRight = 0.0f;
            this.movingForwardBack = 0.0f;
            this.field_698_X = 0.0f;
        }
        else if (!this.isMultiplayerEntity) {
            this.updateEntityActionState();
        }
        final boolean flag = this.handleWaterMovement();
        final boolean flag2 = this.handleLavaMovement();
        if (this.isJumping) {
            if (flag) {
                this.motionY += 0.03999999910593033;
            }
            else if (flag2) {
                this.motionY += 0.03999999910593033;
            }
            else if (this.onGround) {
                this.func_424_C();
            }
        }
        this.movingLeftRight *= 0.98f;
        this.movingForwardBack *= 0.98f;
        this.field_698_X *= 0.9f;
        this.func_435_b(this.movingLeftRight, this.movingForwardBack);
        final List<?> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.20000000298023224, 0.0, 0.20000000298023224));
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); ++i) {
                final Entity entity = (Entity)list.get(i);
                if (entity.canBePushed()) {
                    entity.applyEntityCollision(this);
                }
            }
        }
    }
    
    protected void func_424_C() {
        this.motionY = 0.41999998688697815;
    }
    
    protected void updateEntityActionState() {
        ++this.field_701_U;
        final EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, -1.0);
        if (entityplayer != null) {
            final double d = entityplayer.posX - this.posX;
            final double d2 = entityplayer.posY - this.posY;
            final double d3 = entityplayer.posZ - this.posZ;
            final double d4 = d * d + d2 * d2 + d3 * d3;
            if (d4 > 16384.0) {
                this.setEntityDead();
            }
            if (this.field_701_U > 600 && this.rand.nextInt(800) == 0) {
                if (d4 < 1024.0) {
                    this.field_701_U = 0;
                }
                else {
                    this.setEntityDead();
                }
            }
        }
        this.movingLeftRight = 0.0f;
        this.movingForwardBack = 0.0f;
        final float f = 8.0f;
        if (this.rand.nextFloat() < 0.02f) {
            final EntityPlayer entityplayer2 = this.worldObj.getClosestPlayerToEntity(this, f);
            if (entityplayer2 != null) {
                this.ridingEntity = entityplayer2;
                this.field_740_i = 10 + this.rand.nextInt(20);
            }
            else {
                this.field_698_X = (this.rand.nextFloat() - 0.5f) * 20.0f;
            }
        }
        if (this.ridingEntity != null) {
            this.func_426_b(this.ridingEntity, 10.0f);
            if (this.field_740_i-- <= 0 || this.ridingEntity.isDead || this.ridingEntity.getDistanceSqToEntity(this) > f * f) {
                this.ridingEntity = null;
            }
        }
        else {
            if (this.rand.nextFloat() < 0.05f) {
                this.field_698_X = (this.rand.nextFloat() - 0.5f) * 20.0f;
            }
            this.rotationYaw += this.field_698_X;
            this.rotationPitch = this.field_696_Z;
        }
        final boolean flag = this.handleWaterMovement();
        final boolean flag2 = this.handleLavaMovement();
        if (flag || flag2) {
            this.isJumping = (this.rand.nextFloat() < 0.8f);
        }
    }
    
    public void func_426_b(final Entity entity, final float f) {
        final double d = entity.posX - this.posX;
        final double d2 = entity.posZ - this.posZ;
        double d3;
        if (entity instanceof EntityLiving) {
            final EntityLiving entityliving = (EntityLiving)entity;
            d3 = entityliving.posY + entityliving.func_373_s() - (this.posY + this.func_373_s());
        }
        else {
            d3 = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0 - (this.posY + this.func_373_s());
        }
        final double d4 = MathHelper.sqrt_double(d * d + d2 * d2);
        final float f2 = (float)(Math.atan2(d2, d) * 180.0 / 3.1415927410125732) - 90.0f;
        final float f3 = (float)(Math.atan2(d3, d4) * 180.0 / 3.1415927410125732);
        this.rotationPitch = this.func_417_b(this.rotationPitch, f3, f);
        this.rotationYaw = this.func_417_b(this.rotationYaw, f2, f);
    }
    
    private float func_417_b(final float f, final float f1, final float f2) {
        float f3;
        for (f3 = f1 - f; f3 < -180.0f; f3 += 360.0f) {}
        while (f3 >= 180.0f) {
            f3 -= 360.0f;
        }
        if (f3 > f2) {
            f3 = f2;
        }
        if (f3 < -f2) {
            f3 = -f2;
        }
        return f + f3;
    }
    
    public void func_436_D() {
    }
    
    public boolean shouldSpawnOnTile() {
        return this.worldObj.func_604_a(this.boundingBox) && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0 && !this.worldObj.getIsAnyLiquid(this.boundingBox);
    }
    
    @Override
    protected void kill() {
        this.attackEntityFrom(null, 4);
    }
    
    public float getSwingProgress(final float f) {
        float f2 = this.swingProgress - this.prevSwingProgress;
        if (f2 < 0.0f) {
            ++f2;
        }
        return this.prevSwingProgress + f2 * f;
    }
    
    public Vec3D getPosition(final float f) {
        if (f == 1.0f) {
            return Vec3D.createVector(this.posX, this.posY, this.posZ);
        }
        final double d = this.prevPosX + (this.posX - this.prevPosX) * f;
        final double d2 = this.prevPosY + (this.posY - this.prevPosY) * f;
        final double d3 = this.prevPosZ + (this.posZ - this.prevPosZ) * f;
        return Vec3D.createVector(d, d2, d3);
    }
    
    public Vec3D getLook(final float f) {
        if (f == 1.0f) {
            final float f2 = MathHelper.cos(-this.rotationYaw * 0.01745329f - 3.141593f);
            final float f3 = MathHelper.sin(-this.rotationYaw * 0.01745329f - 3.141593f);
            final float f4 = -MathHelper.cos(-this.rotationPitch * 0.01745329f);
            final float f5 = MathHelper.sin(-this.rotationPitch * 0.01745329f);
            return Vec3D.createVector(f3 * f4, f5, f2 * f4);
        }
        final float f6 = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * f;
        final float f7 = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * f;
        final float f8 = MathHelper.cos(-f7 * 0.01745329f - 3.141593f);
        final float f9 = MathHelper.sin(-f7 * 0.01745329f - 3.141593f);
        final float f10 = -MathHelper.cos(-f6 * 0.01745329f);
        final float f11 = MathHelper.sin(-f6 * 0.01745329f);
        return Vec3D.createVector(f9 * f10, f11, f8 * f10);
    }
    
    public MovingObjectPosition rayTrace(final double d, final float f) {
        final Vec3D vec3d = this.getPosition(f);
        final Vec3D vec3d2 = this.getLook(f);
        final Vec3D vec3d3 = vec3d.addVector(vec3d2.xCoord * d, vec3d2.yCoord * d, vec3d2.zCoord * d);
        return this.worldObj.rayTraceBlocks(vec3d, vec3d3);
    }
    
    protected void updateEntityActionStateIndev() {
    }
}
