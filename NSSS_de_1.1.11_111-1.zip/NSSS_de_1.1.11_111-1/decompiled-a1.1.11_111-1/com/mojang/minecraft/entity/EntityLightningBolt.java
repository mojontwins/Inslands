package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.render.*;

public class EntityLightningBolt extends EntityWeatherEffect
{
    private int field_27028_b;
    public long field_27029_a;
    private int field_27030_c;
    
    public EntityLightningBolt(final World world, final double d, final double d1, final double d2) {
        super(world);
        this.field_27029_a = 0L;
        this.setLocationAndAngles(d, d1, d2, 0.0f, 0.0f);
        this.field_27028_b = 2;
        this.field_27029_a = this.rand.nextLong();
        this.field_27030_c = this.rand.nextInt(3) + 1;
        if (world.difficulty >= 2 && world.doChunksNearChunkExist(MathHelper.floor_double(d), MathHelper.floor_double(d1), MathHelper.floor_double(d2), 10)) {
            final int i = MathHelper.floor_double(d);
            final int k = MathHelper.floor_double(d1);
            final int i2 = MathHelper.floor_double(d2);
            for (int j = 0; j < 4; ++j) {
                final int l = MathHelper.floor_double(d) + this.rand.nextInt(3) - 1;
                final int j2 = MathHelper.floor_double(d1) + this.rand.nextInt(3) - 1;
                final int n = MathHelper.floor_double(d2) + this.rand.nextInt(3) - 1;
            }
        }
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.field_27028_b == 2) {
            this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ, "ambient.weather.thunder", 10000.0f, 0.8f + this.rand.nextFloat() * 0.2f);
            this.worldObj.playSoundEffect(this.posX, this.posY, this.posZ, "random.explode", 2.0f, 0.5f + this.rand.nextFloat() * 0.2f);
        }
        --this.field_27028_b;
        if (this.field_27028_b < 0) {
            if (this.field_27030_c == 0) {
                this.setEntityDead();
            }
            else if (this.field_27028_b < -this.rand.nextInt(10)) {
                --this.field_27030_c;
                this.field_27028_b = 1;
                this.field_27029_a = this.rand.nextLong();
                if (this.worldObj.doChunksNearChunkExist(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ), 10)) {
                    final int i = MathHelper.floor_double(this.posX);
                    final int j = MathHelper.floor_double(this.posY);
                    final int k = MathHelper.floor_double(this.posZ);
                    if (this.worldObj.getBlockId(i, j, k) == 0 && Block.fire.canPlace(this.worldObj, i, j, k)) {
                        this.worldObj.setBlockWithNotify(i, j, k, Block.fire.blockID);
                    }
                }
            }
        }
        if (this.field_27028_b >= 0) {
            final double d = 3.0;
            final List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, AxisAlignedBB.getBoundingBoxFromPool(this.posX - d, this.posY - d, this.posZ - d, this.posX + d, this.posY + 6.0 + d, this.posZ + d));
            for (int l = 0; l < list.size(); ++l) {
                final Entity entity = list.get(l);
            }
        }
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    protected void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    protected void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    public boolean isInRangeToRenderVec3D(final Vec3D vec3d) {
        return this.field_27028_b >= 0;
    }
}
