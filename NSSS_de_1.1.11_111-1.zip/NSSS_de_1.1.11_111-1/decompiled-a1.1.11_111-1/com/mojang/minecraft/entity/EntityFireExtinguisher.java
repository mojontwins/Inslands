package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.render.*;
import java.util.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntityFireExtinguisher extends Entity
{
    private int xTileFireExt;
    private int yTileFireExt;
    private int zTileFireExt;
    private int inTileFireExt;
    private boolean inGroundFireExt;
    public int shakeFireExt;
    private EntityLiving thrower;
    private int ticksInGroundSnowball;
    private int ticksInAirFireExt;
    
    public EntityFireExtinguisher(final World world) {
        super(world);
        this.xTileFireExt = -1;
        this.yTileFireExt = -1;
        this.zTileFireExt = -1;
        this.inTileFireExt = 0;
        this.inGroundFireExt = false;
        this.shakeFireExt = 0;
        this.ticksInAirFireExt = 0;
        this.setSize(0.25f, 0.25f);
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public boolean isInRangeToRenderDist(final double d) {
        double d2 = this.boundingBox.getAverageEdgeLength() * 4.0;
        d2 *= 64.0;
        return d < d2 * d2;
    }
    
    public EntityFireExtinguisher(final World world, final EntityLiving entityliving) {
        super(world);
        this.xTileFireExt = -1;
        this.yTileFireExt = -1;
        this.zTileFireExt = -1;
        this.inTileFireExt = 0;
        this.inGroundFireExt = false;
        this.shakeFireExt = 0;
        this.ticksInAirFireExt = 0;
        this.thrower = entityliving;
        this.setSize(0.25f, 0.25f);
        this.setLocationAndAngles(entityliving.posX, entityliving.posY, entityliving.posZ, entityliving.rotationYaw, entityliving.rotationPitch);
        this.posX -= MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.posY -= 0.10000000149011612;
        this.posZ -= MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.yOffset = 0.0f;
        final float f = 0.4f;
        this.motionX = -MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionZ = MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionY = -MathHelper.sin(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.setSnowballHeading(this.motionX, this.motionY, this.motionZ, 1.5f, 1.0f);
    }
    
    public EntityFireExtinguisher(final World world, final double d, final double d1, final double d2) {
        super(world);
        this.xTileFireExt = -1;
        this.yTileFireExt = -1;
        this.zTileFireExt = -1;
        this.inTileFireExt = 0;
        this.inGroundFireExt = false;
        this.shakeFireExt = 0;
        this.ticksInAirFireExt = 0;
        this.ticksInGroundSnowball = 0;
        this.setSize(0.25f, 0.25f);
        this.setPosition(d, d1, d2);
        this.yOffset = 0.0f;
    }
    
    public void setSnowballHeading(double d, double d1, double d2, final float f, final float f1) {
        final float f2 = MathHelper.sqrt_double(d * d + d1 * d1 + d2 * d2);
        d /= f2;
        d1 /= f2;
        d2 /= f2;
        d += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d1 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d2 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d *= f;
        d1 *= f;
        d2 *= f;
        this.motionX = d;
        this.motionY = d1;
        this.motionZ = d2;
        final float f3 = MathHelper.sqrt_double(d * d + d2 * d2);
        final float n = (float)(Math.atan2(d, d2) * 180.0 / 3.1415927410125732);
        this.rotationYaw = n;
        this.prevRotationYaw = n;
        final float n2 = (float)(Math.atan2(d1, f3) * 180.0 / 3.1415927410125732);
        this.rotationPitch = n2;
        this.prevRotationPitch = n2;
        this.ticksInGroundSnowball = 0;
    }
    
    @Override
    public void setVelocity(final double d, final double d1, final double d2) {
        this.motionX = d;
        this.motionY = d1;
        this.motionZ = d2;
        if (this.prevRotationPitch == 0.0f && this.prevRotationYaw == 0.0f) {
            final float f = MathHelper.sqrt_double(d * d + d2 * d2);
            final float n = (float)(Math.atan2(d, d2) * 180.0 / 3.1415927410125732);
            this.rotationYaw = n;
            this.prevRotationYaw = n;
            final float n2 = (float)(Math.atan2(d1, f) * 180.0 / 3.1415927410125732);
            this.rotationPitch = n2;
            this.prevRotationPitch = n2;
        }
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.shakeFireExt > 0) {
            --this.shakeFireExt;
        }
        if (this.inGroundFireExt) {
            final int i = this.worldObj.getBlockId(this.xTileFireExt, this.yTileFireExt, this.zTileFireExt);
            if (i == this.inTileFireExt) {
                ++this.ticksInGroundSnowball;
                if (this.ticksInGroundSnowball == 1200) {
                    this.setEntityDead();
                }
                return;
            }
            this.inGroundFireExt = false;
            this.motionX *= this.rand.nextFloat() * 0.2f;
            this.motionY *= this.rand.nextFloat() * 0.2f;
            this.motionZ *= this.rand.nextFloat() * 0.2f;
            this.ticksInGroundSnowball = 0;
            this.ticksInAirFireExt = 0;
        }
        else {
            ++this.ticksInAirFireExt;
        }
        Vec3D vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        Vec3D vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(vec3d, vec3d2);
        vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        if (movingobjectposition != null) {
            vec3d2 = Vec3D.createVector(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
        }
        if (!this.worldObj.multiplayerWorld) {
            Entity entity = null;
            final List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0));
            double d = 0.0;
            for (int j = 0; j < list.size(); ++j) {
                final Entity entity2 = list.get(j);
                if (entity2.canBeCollidedWith()) {
                    if (entity2 != this.thrower || this.ticksInAirFireExt >= 5) {
                        final float f2 = 0.3f;
                        final AxisAlignedBB axisalignedbb = entity2.boundingBox.expand(f2, f2, f2);
                        final MovingObjectPosition movingobjectposition2 = axisalignedbb.func_1169_a(vec3d, vec3d2);
                        if (movingobjectposition2 != null) {
                            final double d2 = vec3d.distanceTo(movingobjectposition2.hitVec);
                            if (d2 < d || d == 0.0) {
                                entity = entity2;
                                d = d2;
                            }
                        }
                    }
                }
            }
            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }
        }
        if (movingobjectposition != null) {
            if (movingobjectposition.entityHit == null || !movingobjectposition.entityHit.attackEntityFrom(this.thrower, 0)) {}
            for (int k = 0; k < 8; ++k) {
                this.worldObj.spawnParticle("explode", this.posX, this.posY, this.posZ, 0.0, 0.0, 0.0);
            }
            this.extinguish((int)this.posX, (int)this.posY, (int)this.posZ);
            this.setEntityDead();
        }
        this.posX += this.motionX;
        this.posY += this.motionY;
        this.posZ += this.motionZ;
        final float f3 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0 / 3.1415927410125732);
        this.rotationPitch = (float)(Math.atan2(this.motionY, f3) * 180.0 / 3.1415927410125732);
        while (this.rotationPitch - this.prevRotationPitch < -180.0f) {
            this.prevRotationPitch -= 360.0f;
        }
        while (this.rotationPitch - this.prevRotationPitch >= 180.0f) {
            this.prevRotationPitch += 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw < -180.0f) {
            this.prevRotationYaw -= 360.0f;
        }
        while (this.rotationYaw - this.prevRotationYaw >= 180.0f) {
            this.prevRotationYaw += 360.0f;
        }
        this.rotationPitch = this.prevRotationPitch + (this.rotationPitch - this.prevRotationPitch) * 0.2f;
        this.rotationYaw = this.prevRotationYaw + (this.rotationYaw - this.prevRotationYaw) * 0.2f;
        float f4 = 0.99f;
        final float f5 = 0.03f;
        if (this.handleWaterMovement()) {
            for (int l = 0; l < 4; ++l) {
                final float f6 = 0.25f;
                this.worldObj.spawnParticle("bubble", this.posX - this.motionX * f6, this.posY - this.motionY * f6, this.posZ - this.motionZ * f6, this.motionX, this.motionY, this.motionZ);
            }
            f4 = 0.8f;
        }
        this.motionX *= f4;
        this.motionY *= f4;
        this.motionZ *= f4;
        this.motionY -= f5;
        this.setPosition(this.posX, this.posY, this.posZ);
    }
    
    private void extinguish(final int xp, final int yp, final int zp) {
        final int radius = 3;
        final float f = (float)Math.random() / 10.0f + 1.0f;
        final float f2 = (float)Math.random() / 10.0f + 1.0f;
        this.worldObj.playSoundAtEntity(this, "random.glass", 1.0f, f - 0.25f);
        this.worldObj.playSoundAtEntity(this, "random.splash", 1.0f, f2 + 0.25f);
        for (int l = 0; l < 128; ++l) {
            final double f3 = Math.random() * 5.0 - 2.5;
            final double f4 = Math.random() * 5.0 - 2.5;
            final double f5 = Math.random() * 5.0 - 2.5;
            this.worldObj.spawnParticle("bigsplash", this.posX + f3, this.posY + f5, this.posZ + f4, 0.0, this.motionY, 0.0);
        }
        final List<Entity> entities = this.worldObj.getEntitiesWithinAABB(EntityLiving.class, AxisAlignedBB.getBoundingBoxFromPool(xp, yp, zp, xp + 1, yp + 1, zp + 1).expand(radius, radius, radius));
        for (int i = 0; i < entities.size(); ++i) {
            if (entities.get(i).fire > 0) {
                this.worldObj.spawnParticle("bigsmoke", entities.get(i).posX, entities.get(i).posY + 1.0, entities.get(i).posZ, 0.0, 1.0, 0.0);
                final float f6 = (float)Math.random() / 10.0f + 1.0f;
                this.worldObj.playSoundEffect(entities.get(i).posX, entities.get(i).posY, entities.get(i).posZ, "random.fizz", 1.0f, f6 + 0.25f);
                entities.get(i).fire = 0;
            }
        }
        for (int x = xp - radius; x <= xp + radius; ++x) {
            for (int y = yp - radius; y <= yp + radius; ++y) {
                for (int z = zp - radius; z <= zp + radius; ++z) {
                    if (this.worldObj.getBlockId(x, y, z) == Block.fire.blockID) {
                        this.worldObj.spawnParticle("bigsmoke", x, y, z, 0.0, 1.0, 0.0);
                        final float f7 = (float)Math.random() / 10.0f + 1.0f;
                        this.worldObj.playSoundEffect(x, y, z, "random.fizz", 1.0f, f7 + 0.25f);
                        this.worldObj.setBlock(x, y, z, 0);
                    }
                }
            }
        }
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("xTile", (short)this.xTileFireExt);
        nbttagcompound.setShort("yTile", (short)this.yTileFireExt);
        nbttagcompound.setShort("zTile", (short)this.zTileFireExt);
        nbttagcompound.setByte("inTile", (byte)this.inTileFireExt);
        nbttagcompound.setByte("shake", (byte)this.shakeFireExt);
        nbttagcompound.setByte("inGround", (byte)(this.inGroundFireExt ? 1 : 0));
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.xTileFireExt = nbttagcompound.getShort("xTile");
        this.yTileFireExt = nbttagcompound.getShort("yTile");
        this.zTileFireExt = nbttagcompound.getShort("zTile");
        this.inTileFireExt = (nbttagcompound.getByte("inTile") & 0xFF);
        this.shakeFireExt = (nbttagcompound.getByte("shake") & 0xFF);
        this.inGroundFireExt = (nbttagcompound.getByte("inGround") == 1);
    }
    
    @Override
    public void onCollideWithPlayer(final EntityPlayer entityplayer) {
        if (this.inGroundFireExt && this.thrower == entityplayer && this.shakeFireExt <= 0 && entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.arrow.shiftedIndex, 1))) {
            this.worldObj.playSoundAtEntity(this, "random.pop", 0.2f, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            entityplayer.onItemPickup(this, 1);
            this.setEntityDead();
        }
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
}
