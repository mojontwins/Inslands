package com.mojang.minecraft.entity;

import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.networknew.packet.*;
import com.mojang.minecraft.entity.item.*;

public class EntityClientPlayerMP extends EntityPlayerSP
{
    public NetClientHandler sendQueue;
    private int field_9380_bx;
    private boolean field_21093_bH;
    private double oldPosX;
    private double field_9378_bz;
    private double oldPosY;
    private double oldPosZ;
    private float oldRotationYaw;
    private float oldRotationPitch;
    private InventoryPlayer field_789_bo;
    private boolean field_9382_bF;
    private boolean wasSneaking;
    private boolean wasRunning;
    private int field_12242_bI;
    
    public EntityClientPlayerMP(final Minecraft minecraft, final World world, final Session session, final NetClientHandler netclienthandler) {
        super(minecraft, world, session);
        this.field_9380_bx = 0;
        this.field_789_bo = new InventoryPlayer(null);
        this.sendQueue = netclienthandler;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        return false;
    }
    
    @Override
    public void heal(final int i) {
    }
    
    @Override
    public void onUpdate() {
        if (!this.worldObj.blockExists(MathHelper.floor_double(this.posX), 64, MathHelper.floor_double(this.posZ))) {
            return;
        }
        super.onUpdate();
        this.func_464_J();
    }
    
    public void func_464_J() {
        if (this.field_9380_bx++ == 20) {
            this.sendInventoryChanged();
            this.field_9380_bx = 0;
        }
        final boolean flag = this.getIsSneaking();
        if (flag != this.wasSneaking) {
            if (flag) {
                this.sendQueue.addToSendQueue(new Packet19EntityAction(this, 1));
            }
            else {
                this.sendQueue.addToSendQueue(new Packet19EntityAction(this, 2));
            }
            this.wasSneaking = flag;
        }
        final boolean flagr = this.isRunning();
        if (flagr != this.wasRunning) {
            if (flagr) {
                this.sendQueue.addToSendQueue(new Packet19EntityAction(this, 3));
            }
            else {
                this.sendQueue.addToSendQueue(new Packet19EntityAction(this, 4));
            }
            this.wasRunning = flagr;
        }
        final double d = this.posX - this.oldPosX;
        final double d2 = this.boundingBox.minY - this.field_9378_bz;
        final double d3 = this.posY - this.oldPosY;
        final double d4 = this.posZ - this.oldPosZ;
        final double d5 = this.rotationYaw - this.oldRotationYaw;
        final double d6 = this.rotationPitch - this.oldRotationPitch;
        boolean flag2 = d2 != 0.0 || d3 != 0.0 || d != 0.0 || d4 != 0.0;
        final boolean flag3 = d5 != 0.0 || d6 != 0.0;
        if (this.entityBeingRidden != null) {
            if (flag3) {
                this.sendQueue.addToSendQueue(new Packet11PlayerPosition(this.motionX, -999.0, -999.0, this.motionZ, this.onGround));
            }
            else {
                this.sendQueue.addToSendQueue(new Packet13PlayerLookMove(this.motionX, -999.0, -999.0, this.motionZ, this.rotationYaw, this.rotationPitch, this.onGround));
            }
            flag2 = false;
        }
        else if (flag2 && flag3) {
            this.sendQueue.addToSendQueue(new Packet13PlayerLookMove(this.posX, this.boundingBox.minY, this.posY, this.posZ, this.rotationYaw, this.rotationPitch, this.onGround));
            this.field_12242_bI = 0;
        }
        else if (flag2) {
            this.sendQueue.addToSendQueue(new Packet11PlayerPosition(this.posX, this.boundingBox.minY, this.posY, this.posZ, this.onGround));
            this.field_12242_bI = 0;
        }
        else if (flag3) {
            this.sendQueue.addToSendQueue(new Packet12PlayerLook(this.rotationYaw, this.rotationPitch, this.onGround));
            this.field_12242_bI = 0;
        }
        else {
            this.sendQueue.addToSendQueue(new Packet10Flying(this.onGround));
            if (this.field_9382_bF != this.onGround || this.field_12242_bI > 200) {
                this.field_12242_bI = 0;
            }
            else {
                ++this.field_12242_bI;
            }
        }
        this.field_9382_bF = this.onGround;
        if (flag2) {
            this.oldPosX = this.posX;
            this.field_9378_bz = this.boundingBox.minY;
            this.oldPosY = this.posY;
            this.oldPosZ = this.posZ;
        }
        if (flag3) {
            this.oldRotationYaw = this.rotationYaw;
            this.oldRotationPitch = this.rotationPitch;
        }
    }
    
    public void dropCurrentItem() {
        this.sendQueue.addToSendQueue(new Packet14BlockDig(4, 0, 0, 0, 0));
    }
    
    private void sendInventoryChanged() {
    }
    
    protected void joinEntityItemWithWorld(final EntityItem entityitem) {
    }
    
    @Override
    public void sendChatMessage(final String s) {
        this.sendQueue.addToSendQueue(new Packet3Chat(s));
    }
    
    @Override
    public void swingItem() {
        super.swingItem();
        this.sendQueue.addToSendQueue(new Packet18Animation(this, 1));
    }
    
    @Override
    public void respawnPlayer() {
        this.sendInventoryChanged();
        this.sendQueue.addToSendQueue(new Packet9Respawn((byte)(-1)));
    }
    
    @Override
    protected void damageEntity(final int i) {
        this.health -= i;
    }
    
    @Override
    public void closeScreen() {
        this.sendQueue.addToSendQueue(new Packet101CloseWindow(this.craftingInventory.windowId));
        this.inventory.setItemStack(null);
        super.closeScreen();
    }
    
    @Override
    public void setHealth(final int i) {
        if (this.field_21093_bH) {
            super.setHealth(i);
        }
        else {
            this.health = i;
            this.field_21093_bH = true;
        }
    }
}
