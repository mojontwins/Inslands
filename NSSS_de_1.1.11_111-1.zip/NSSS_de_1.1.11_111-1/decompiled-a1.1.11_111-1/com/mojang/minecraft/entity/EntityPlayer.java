package com.mojang.minecraft.entity;

import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.player.inventory.*;
import java.io.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.tile.*;

public class EntityPlayer extends EntityLiving
{
    static String[] PLAYER_COLORS;
    public InventoryPlayer inventory;
    public MovementInput currentInput;
    public Container inventorySlots;
    public Container craftingInventory;
    public byte field_777_c;
    public int score;
    public float field_775_e;
    public float field_774_f;
    public boolean field_773_g;
    public int field_772_h;
    public String playerName;
    public String particleEffect;
    public String chatColor;
    public String playerCloakUrl;
    public double field_20066_r;
    public double field_20065_s;
    public double field_20064_t;
    public double field_20063_u;
    public double field_20062_v;
    public double field_20061_w;
    private int damageRemainder;
    public EntityFish fishEntity;
    public boolean modelRene;
    private ChunkCoordinates playerSpawnCoordinate;
    
    static {
        EntityPlayer.PLAYER_COLORS = new String[] { "c", "b", "a", "5", "6", "e", "d", "7" };
    }
    
    public EntityPlayer(final World world) {
        super(world);
        this.playerName = "";
        this.particleEffect = "";
        this.modelRene = false;
        this.inventory = new InventoryPlayer(this);
        this.field_777_c = 0;
        this.score = 0;
        this.field_773_g = false;
        this.field_772_h = 0;
        this.damageRemainder = 0;
        this.inventorySlots = new ContainerPlayer(this.inventory, !world.multiplayerWorld);
        this.craftingInventory = this.inventorySlots;
        this.yOffset = 1.62f;
        this.setLocationAndAngles(world.spawnX + 0.5, world.spawnY + 1, world.spawnZ + 0.5, 0.0f, 0.0f);
        this.health = 20;
        this.field_725_x = "humanoid";
        this.field_726_w = 180.0f;
        this.fireResistance = 20;
        this.texture = "/char.png";
        this.spongeArmor = 0;
        this.leatherArmor = 0;
        this.goldArmor = 0;
        this.chainArmor = 0;
        this.steelArmor = 0;
        this.diamondArmor = 0;
        this.chatColor = computePlayerColor(this.worldObj.mc.session.username);
    }
    
    public static String computePlayerColor(final String name) {
        byte[] pName = null;
        try {
            pName = name.getBytes("US-ASCII");
        }
        catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        final int length = pName.length;
        final int oddShift = 1 - length % 2;
        int value = 0;
        for (int i = 0; i < length; ++i) {
            final byte by = pName[i];
            final int rev = length - (i + 1) + oddShift;
            if (rev % 4 >= 2) {
                value -= by;
            }
            else {
                value += by;
            }
        }
        value %= 8;
        if (value < 0) {
            value += EntityPlayer.PLAYER_COLORS.length;
        }
        System.out.println(value);
        return EntityPlayer.PLAYER_COLORS[value];
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.multiplayerWorld && this.craftingInventory != null && !this.craftingInventory.isUsableByPlayer(this)) {
            this.closeScreen();
            this.craftingInventory = this.inventorySlots;
        }
        this.field_20066_r = this.field_20063_u;
        this.field_20065_s = this.field_20062_v;
        this.field_20064_t = this.field_20061_w;
        final double d = this.posX - this.field_20063_u;
        final double d2 = this.posY - this.field_20062_v;
        final double d3 = this.posZ - this.field_20061_w;
        final double d4 = 10.0;
        if (d > d4) {
            final double posX = this.posX;
            this.field_20063_u = posX;
            this.field_20066_r = posX;
        }
        if (d3 > d4) {
            final double posZ = this.posZ;
            this.field_20061_w = posZ;
            this.field_20064_t = posZ;
        }
        if (d2 > d4) {
            final double posY = this.posY;
            this.field_20062_v = posY;
            this.field_20065_s = posY;
        }
        if (d < -d4) {
            final double posX2 = this.posX;
            this.field_20063_u = posX2;
            this.field_20066_r = posX2;
        }
        if (d3 < -d4) {
            final double posZ2 = this.posZ;
            this.field_20061_w = posZ2;
            this.field_20064_t = posZ2;
        }
        if (d2 < -d4) {
            final double posY2 = this.posY;
            this.field_20062_v = posY2;
            this.field_20065_s = posY2;
        }
        this.field_20063_u += d * 0.25;
        this.field_20061_w += d3 * 0.25;
        this.field_20062_v += d2 * 0.25;
    }
    
    public int posXInt() {
        return (int)Math.round(this.posX);
    }
    
    public int posYInt() {
        return (int)Math.round(this.posY);
    }
    
    public int posZInt() {
        return (int)Math.round(this.posZ);
    }
    
    protected void closeScreen() {
        this.craftingInventory = this.inventorySlots;
    }
    
    @Override
    public void updateCloak() {
        this.playerCloakUrl = this.cloakURL;
    }
    
    @Override
    public void updateRidden() {
        super.updateRidden();
        this.field_775_e = this.field_774_f;
        this.field_774_f = 0.0f;
    }
    
    public void preparePlayerToSpawn() {
        this.yOffset = 1.62f;
        this.setSize(0.6f, 1.8f);
        super.preparePlayerToSpawn();
        this.health = 20;
        this.deathTime = 0;
    }
    
    @Override
    protected void updateEntityActionState() {
        if (this.field_773_g) {
            ++this.field_772_h;
            if (this.field_772_h == 8) {
                this.field_772_h = 0;
                this.field_773_g = false;
            }
        }
        else {
            this.field_772_h = 0;
        }
        this.swingProgress = this.field_772_h / 8.0f;
    }
    
    @Override
    public void onLivingUpdate() {
        if (!(this.worldObj instanceof WorldClient) && this.worldObj.difficulty == 0 && this.health < 20 && this.ticksExisted % 20 * 4 == 0) {
            this.heal(1);
        }
        this.spongeArmor = this.inventory.getArmorCount("sponge");
        this.leatherArmor = this.inventory.getArmorCount("leather");
        this.goldArmor = this.inventory.getArmorCount("gold");
        this.chainArmor = this.inventory.getArmorCount("chain");
        this.steelArmor = this.inventory.getArmorCount("steel");
        this.diamondArmor = this.inventory.getArmorCount("diamond");
        this.inventory.decrementAnimations();
        this.field_775_e = this.field_774_f;
        super.onLivingUpdate();
        float hypotenuseMove = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        float f1 = (float)Math.atan(-this.motionY * 0.20000000298023224) * 15.0f;
        if (hypotenuseMove > 0.15f) {
            hypotenuseMove = 0.15f;
        }
        if (!this.onGround || this.health <= 0) {
            hypotenuseMove = 0.0f;
        }
        if (this.onGround || this.health <= 0) {
            f1 = 0.0f;
        }
        this.field_774_f += (hypotenuseMove - this.field_774_f) * 0.4f;
        this.field_709_M += (f1 - this.field_709_M) * 0.8f;
        if (this.health > 0) {
            final List<Entity> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(1.0, 0.0, 1.0));
            if (list != null) {
                for (int i = 0; i < list.size(); ++i) {
                    this.func_451_h(list.get(i));
                }
            }
        }
        if (this.posY < -64.0) {
            this.health -= 4;
        }
    }
    
    private void func_451_h(final Entity entity) {
        entity.onCollideWithPlayer(this);
    }
    
    public int getScore() {
        return this.score;
    }
    
    @Override
    public void onDeath(final Entity entity) {
        this.setSize(0.2f, 0.2f);
        this.setPosition(this.posX, this.posY, this.posZ);
        this.motionY = 0.10000000149011612;
        if (this.playerName.equals("Noptch")) {
            this.dropInventory(new ItemStack(Item.appleRed, 1), true);
        }
        if (!this.worldObj.multiplayerWorld) {
            this.inventory.dropAllItems();
        }
        if (entity != null) {
            this.motionX = -MathHelper.cos((this.attackedAtYaw + this.rotationYaw) * 3.141593f / 180.0f) * 0.1f;
            this.motionZ = -MathHelper.sin((this.attackedAtYaw + this.rotationYaw) * 3.141593f / 180.0f) * 0.1f;
        }
        else {
            final double n = 0.0;
            this.motionZ = n;
            this.motionX = n;
        }
        this.yOffset = 0.1f;
    }
    
    @Override
    public void addToPlayerScore(final Entity entity, final int i) {
        this.score += i;
    }
    
    public void dropPlayerItem(final ItemStack itemstack) {
        this.dropInventory(itemstack, false);
    }
    
    public void dropInventory(final ItemStack itemstack, final boolean flag) {
        if (itemstack == null || this.worldObj.multiplayerWorld) {
            return;
        }
        final EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY - 0.30000001192092896 + this.func_373_s(), this.posZ, itemstack);
        entityitem.delayBeforeCanPickup = 40;
        if (flag) {
            final float f2 = this.rand.nextFloat() * 0.5f;
            final float f3 = this.rand.nextFloat() * 3.141593f * 2.0f;
            entityitem.motionX = -MathHelper.sin(f3) * f2;
            entityitem.motionZ = MathHelper.cos(f3) * f2;
            entityitem.motionY = 0.20000000298023224;
        }
        else {
            float f4 = 0.3f;
            entityitem.motionX = -MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f4;
            entityitem.motionZ = MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f4;
            entityitem.motionY = -MathHelper.sin(this.rotationPitch / 180.0f * 3.141593f) * f4 + 0.1f;
            f4 = 0.02f;
            final float f5 = this.rand.nextFloat() * 3.141593f * 2.0f;
            f4 *= this.rand.nextFloat();
            final EntityItem entityItem = entityitem;
            entityItem.motionX += Math.cos(f5) * f4;
            final EntityItem entityItem2 = entityitem;
            entityItem2.motionY += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1f;
            final EntityItem entityItem3 = entityitem;
            entityItem3.motionZ += Math.sin(f5) * f4;
        }
        this.func_446_a(entityitem);
    }
    
    protected void func_446_a(final EntityItem entityitem) {
        this.worldObj.entityJoinedWorld(entityitem);
    }
    
    public float getMiningInhibitors(final Block block) {
        float f = this.inventory.getStrVsBlock(block);
        if (this.isInsideOfMaterial(Material.water)) {
            if (this.spongeArmor > 0) {
                f /= 5 - this.spongeArmor;
            }
            else {
                f /= 5.0f;
            }
        }
        if (!this.onGround) {
            f /= 5.0f;
        }
        return f;
    }
    
    public boolean checkBreakBlock(final Block block) {
        return this.inventory.canHarvestBlock(block);
    }
    
    public boolean checkGoldTouch(final Block block) {
        return this.inventory.canHarvestBlockGoldTouch(block);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Inventory");
        this.inventory.readFromNBT(nbttaglist);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.func_762_a("Inventory", this.inventory.writeToNBT(new NBTTagList()));
    }
    
    public void displayGUIChest(final IInventory iinventory) {
    }
    
    public void displayWorkbenchGUI() {
    }
    
    public void onItemPickup(final Entity entity, final int i) {
    }
    
    @Override
    protected float func_373_s() {
        return 0.12f;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, int damage) {
        this.field_701_U = 0;
        if (this.health <= 0) {
            return false;
        }
        if (this.heartsLife > this.maxHealth / 2.0f) {
            return false;
        }
        if (entity instanceof EntityMobs || entity instanceof EntityArrow) {
            if (this.worldObj.difficulty == 0) {
                damage = 0;
            }
            if (this.worldObj.difficulty == 1) {
                damage = damage / 3 + 1;
            }
            if (this.worldObj.difficulty == 3) {
                damage = damage * 3 / 2;
            }
        }
        final int j = 25 - this.inventory.getTotalArmorValue();
        final int k = damage * j + this.damageRemainder;
        this.inventory.damageArmor(damage);
        damage = k / 25;
        this.damageRemainder = k % 25;
        return (damage != 0 || entity instanceof EntityArrow || entity instanceof EntitySpider || entity instanceof EntityZombie || entity instanceof EntitySkeleton) && super.attackEntityFrom(entity, damage);
    }
    
    @Override
    protected void damageEntity(int i) {
        final int j = 25 - this.inventory.getTotalArmorValue();
        final int k = i * j + this.damageRemainder;
        this.inventory.damageArmor(i);
        i = k / 25;
        this.damageRemainder = k % 25;
        super.damageEntity(i);
    }
    
    public void displayGUIFurnace(final TileEntityFurnace tileentityfurnace) {
    }
    
    public void displayGUIEditSign(final TileEntitySign tileentitysign) {
    }
    
    public void useCurrentItemOnEntity(final Entity entity) {
    }
    
    public ItemStack getCurrentEquippedItem() {
        return this.inventory.getCurrentItem();
    }
    
    public void destroyCurrentEquippedItem() {
        this.inventory.setInventorySlotContents(this.inventory.currentItem, null);
    }
    
    @Override
    public double getYOffset() {
        return this.yOffset - 0.5f;
    }
    
    public void swingItem() {
        this.field_772_h = -1;
        this.field_773_g = true;
    }
    
    public void attackTargetEntityWithCurrentItem(final Entity entity) {
        int i = this.inventory.getDamageVsEntity(entity);
        if (i > 0) {
            if (this.motionY < 0.0) {
                ++i;
            }
            entity.attackEntityFrom(this, i);
            final ItemStack itemstack = this.getCurrentEquippedItem();
            if (itemstack != null && entity instanceof EntityLiving) {
                itemstack.hitEntity((EntityLiving)entity);
                if (itemstack.stackSize <= 0) {
                    itemstack.func_1097_a(this);
                    this.destroyCurrentEquippedItem();
                }
            }
        }
    }
    
    public void func_6420_o() {
    }
    
    @Override
    public void setEntityDead() {
        super.setEntityDead();
        this.inventorySlots.onCraftGuiClosed(this);
        if (this.craftingInventory != null) {
            this.craftingInventory.onCraftGuiClosed(this);
        }
    }
    
    public void onItemStackChanged(final ItemStack itemstack) {
    }
    
    public static ChunkCoordinates func_25060_a(final World world, final ChunkCoordinates chunkcoordinates) {
        return null;
    }
    
    public ChunkCoordinates getPlayerSpawnCoordinate() {
        return this.playerSpawnCoordinate;
    }
    
    public void setPlayerSpawnCoordinate(final ChunkCoordinates chunkcoordinates) {
        if (chunkcoordinates != null) {
            this.playerSpawnCoordinate = new ChunkCoordinates(chunkcoordinates.x, chunkcoordinates.z);
        }
        else {
            this.playerSpawnCoordinate = null;
        }
    }
    
    @Override
    public void onEntityUpdate() {
        final float f1 = (float)MathHelper.floor_double(this.boundingBox.minY);
        for (int i = 0; i < 1.0f + this.width * 20.0f; ++i) {
            final float f2 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
            final float f3 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
            this.worldObj.spawnParticle(this.particleEffect, this.posX + f2, f1, this.posZ + f3, this.motionX, this.motionY, this.motionZ);
        }
        super.onEntityUpdate();
    }
    
    public void setEyeHeight(final float f) {
    }
    
    public void handleKeyPress(final int eventKey, final boolean eventKeyState) {
    }
    
    public void displayWorkbenchGUI(final int i, final int j, final int k) {
    }
}
