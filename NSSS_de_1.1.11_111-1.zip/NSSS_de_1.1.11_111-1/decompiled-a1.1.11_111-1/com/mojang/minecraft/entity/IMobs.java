package com.mojang.minecraft.entity;

public interface IMobs
{
}
