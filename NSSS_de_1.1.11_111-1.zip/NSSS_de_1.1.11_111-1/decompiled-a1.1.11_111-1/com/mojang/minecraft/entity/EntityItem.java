package com.mojang.minecraft.entity;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;

public class EntityItem extends Entity
{
    public ItemStack item;
    public int age;
    public int delayBeforeCanPickup;
    private int health;
    public float field_804_d;
    
    public EntityItem(final World world, final double d, final double d1, final double d2, final ItemStack itemstack) {
        super(world);
        this.age = 0;
        this.health = 5;
        this.field_804_d = (float)(Math.random() * 3.141592653589793 * 2.0);
        this.setSize(0.25f, 0.25f);
        this.yOffset = this.height / 2.0f;
        this.setPosition(d, d1, d2);
        this.item = itemstack;
        this.rotationYaw = (float)(Math.random() * 360.0);
        this.motionX = (float)(Math.random() * 0.20000000298023224 - 0.10000000149011612);
        this.motionY = 0.20000000298023224;
        this.motionZ = (float)(Math.random() * 0.20000000298023224 - 0.10000000149011612);
        this.field_640_aG = false;
    }
    
    public EntityItem(final World world) {
        super(world);
        this.age = 0;
        this.health = 5;
        this.field_804_d = (float)(Math.random() * 3.141592653589793 * 2.0);
        this.setSize(0.25f, 0.25f);
        this.yOffset = this.height / 2.0f;
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.delayBeforeCanPickup > 0) {
            --this.delayBeforeCanPickup;
        }
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= 0.03999999910593033;
        if (this.worldObj.getMaterialXYZ(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) == Material.lava) {
            this.motionY = 0.20000000298023224;
            this.motionX = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f;
            this.motionZ = (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f;
            this.worldObj.playSoundAtEntity(this, "random.fizz", 0.4f, 2.0f + this.rand.nextFloat() * 0.4f);
        }
        this.func_466_g(this.posX, this.posY, this.posZ);
        this.handleWaterMovement();
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        float f = 0.98f;
        if (this.onGround) {
            f = 0.5880001f;
            final int i = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
            if (i > 0) {
                f = Block.allBlocks[i].slipperiness * 0.98f;
            }
        }
        this.motionX *= f;
        this.motionY *= 0.9800000190734863;
        this.motionZ *= f;
        if (this.onGround) {
            this.motionY *= -0.5;
        }
        ++this.age;
        if (this.age >= 6000) {
            this.setEntityDead();
        }
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public boolean handleWaterMovement() {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }
    
    private boolean func_466_g(final double d, final double d1, final double d2) {
        if (this.worldObj.multiplayerWorld) {
            return false;
        }
        final int i = MathHelper.floor_double(d);
        final int j = MathHelper.floor_double(d1);
        final int k = MathHelper.floor_double(d2);
        final double d3 = d - i;
        final double d4 = d1 - j;
        final double d5 = d2 - k;
        if (Block.opaqueCubeLookup[this.worldObj.getBlockId(i, j, k)]) {
            final boolean flag = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i - 1, j, k)];
            final boolean flag2 = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i + 1, j, k)];
            final boolean flag3 = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i, j - 1, k)];
            final boolean flag4 = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i, j + 1, k)];
            final boolean flag5 = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i, j, k - 1)];
            final boolean flag6 = !Block.opaqueCubeLookup[this.worldObj.getBlockId(i, j, k + 1)];
            byte byte0 = -1;
            double d6 = 9999.0;
            if (flag && d3 < d6) {
                d6 = d3;
                byte0 = 0;
            }
            if (flag2 && 1.0 - d3 < d6) {
                d6 = 1.0 - d3;
                byte0 = 1;
            }
            if (flag3 && d4 < d6) {
                d6 = d4;
                byte0 = 2;
            }
            if (flag4 && 1.0 - d4 < d6) {
                d6 = 1.0 - d4;
                byte0 = 3;
            }
            if (flag5 && d5 < d6) {
                d6 = d5;
                byte0 = 4;
            }
            if (flag6 && 1.0 - d5 < d6) {
                byte0 = 5;
            }
            final float f = this.rand.nextFloat() * 0.2f + 0.1f;
            if (byte0 == 0) {
                this.motionX = -f;
            }
            if (byte0 == 1) {
                this.motionX = f;
            }
            if (byte0 == 2) {
                this.motionY = -f;
            }
            if (byte0 == 3) {
                this.motionY = f;
            }
            if (byte0 == 4) {
                this.motionZ = -f;
            }
            if (byte0 == 5) {
                this.motionZ = f;
            }
        }
        return false;
    }
    
    @Override
    protected void dealFireDamage(final int i) {
        this.attackEntityFrom(null, i);
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        this.health -= i;
        if (this.health <= 0) {
            this.setEntityDead();
        }
        return false;
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("Health", (byte)this.health);
        nbttagcompound.setShort("Age", (short)this.age);
        nbttagcompound.func_763_a("Item", this.item.writeToNBT(new NBTTagCompound()));
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.health = (nbttagcompound.getShort("Health") & 0xFF);
        this.age = nbttagcompound.getShort("Age");
        final NBTTagCompound nbttagcompound2 = nbttagcompound.getCompoundTag("Item");
        this.item = new ItemStack(nbttagcompound2);
    }
    
    @Override
    public void onCollideWithPlayer(final EntityPlayer entityplayer) {
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        final int i = this.item.stackSize;
        if (this.delayBeforeCanPickup == 0 && entityplayer.inventory.addItemStackToInventory(this.item)) {
            this.worldObj.playSoundAtEntity(this, "random.pop", 0.2f, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            entityplayer.onItemPickup(this, i);
            this.setEntityDead();
        }
    }
    
    protected boolean func_25017_l() {
        return false;
    }
}
