package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class ItemFood extends Item
{
    private int foodValue;
    
    public ItemFood(final int i, final int j) {
        super(i);
        this.foodValue = j;
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        if (entityplayer.health != 20) {
            --itemstack.stackSize;
            if (!(entityplayer instanceof EntityClientPlayerMP)) {
                entityplayer.heal(this.foodValue);
            }
        }
        return itemstack;
    }
}
