package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;

public class ItemFlintAndSteel extends Item
{
    public ItemFlintAndSteel(final int i) {
        super(i);
        this.maxStackSize = 1;
        this.maxDamage = 64;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, int i, int j, int k, final int l) {
        if (l == 0) {
            --j;
        }
        if (l == 1) {
            ++j;
        }
        if (l == 2) {
            --k;
        }
        if (l == 3) {
            ++k;
        }
        if (l == 4) {
            --i;
        }
        if (l == 5) {
            ++i;
        }
        final int i2 = world.getBlockId(i, j, k);
        if (i2 == 0) {
            world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "fire.ignite", 1.0f, ItemFlintAndSteel.itemRand.nextFloat() * 0.4f + 0.8f);
            world.setBlockWithNotify(i, j, k, Block.fire.blockID);
        }
        itemstack.damageItem(1);
        return true;
    }
}
