package com.mojang.minecraft.entity.item;

import java.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class Item
{
    protected static Random itemRand;
    public static Item[] itemsList;
    public static Item shovel;
    public static Item pickaxeSteel;
    public static Item axeSteel;
    public static Item striker;
    public static Item appleRed;
    public static Item bow;
    public static Item arrow;
    public static Item coal;
    public static Item diamond;
    public static Item ingotIron;
    public static Item ingotGold;
    public static Item swordSteel;
    public static Item swordWood;
    public static Item shovelWood;
    public static Item pickaxeWood;
    public static Item axeWood;
    public static Item swordStone;
    public static Item shovelStone;
    public static Item pickaxeStone;
    public static Item axeStone;
    public static Item swordDiamond;
    public static Item shovelDiamond;
    public static Item pickaxeDiamond;
    public static Item axeDiamond;
    public static Item stick;
    public static Item bowlEmpty;
    public static Item bowlSoup;
    public static Item swordGold;
    public static Item shovelGold;
    public static Item pickaxeGold;
    public static Item axeGold;
    public static Item silk;
    public static Item feather;
    public static Item gunpowder;
    public static Item hoeWood;
    public static Item hoeStone;
    public static Item hoeSteel;
    public static Item hoeDiamond;
    public static Item hoeGold;
    public static Item seeds;
    public static Item wheat;
    public static Item bread;
    public static Item helmetLeather;
    public static Item plateLeather;
    public static Item legsLeather;
    public static Item bootsLeather;
    public static Item helmetChain;
    public static Item plateChain;
    public static Item legsChain;
    public static Item bootsChain;
    public static Item helmetSteel;
    public static Item plateSteel;
    public static Item legsSteel;
    public static Item bootsSteel;
    public static Item helmetDiamond;
    public static Item plateDiamond;
    public static Item legsDiamond;
    public static Item bootsDiamond;
    public static Item helmetGold;
    public static Item plateGold;
    public static Item legsGold;
    public static Item bootsGold;
    public static Item flint;
    public static Item porkRaw;
    public static Item porkCooked;
    public static Item painting;
    public static Item appleGold;
    public static Item sign;
    public static Item doorWood;
    public static Item bucketEmpty;
    public static Item bucketWater;
    public static Item bucketLava;
    public static Item minecartEmpty;
    public static Item saddle;
    public static Item doorSteel;
    public static Item redstone;
    public static Item snowball;
    public static Item boat;
    public static Item leather;
    public static Item bucketMilk;
    public static Item brick;
    public static Item clay;
    public static Item reed;
    public static Item paper;
    public static Item book;
    public static Item slimeBall;
    public static Item minecartBox;
    public static Item minecartEngine;
    public static Item egg;
    public static Item compass;
    public static Item fishingRod;
    public static Item dyePurple;
    public static Item dyeBlack;
    public static Item dyeRed;
    public static Item dyePink;
    public static Item dyeGreen;
    public static Item dyeLime;
    public static Item dyeIndigo;
    public static Item dyeYellow;
    public static Item dyeCyan;
    public static Item dyeBlue;
    public static Item dyeViolet;
    public static Item dyeMagenta;
    public static Item dyeAquaGreen;
    public static Item dyeOrange;
    public static Item dyeGrey;
    public static Item bone;
    public static Item bonemeal;
    public static Item cocoa;
    public static Item record13;
    public static Item recordCat;
    public static Item recordBlocks;
    public static Item recordChirp;
    public static Item recordFar;
    public static Item recordMall;
    public static Item recordMellohi;
    public static Item recordStal;
    public static Item recordStrad;
    public static Item recordWard;
    public static Item record11;
    public static Item recordWait;
    public static Item recordMagnet;
    public static Item swordObsidian;
    public static Item shovelObsidian;
    public static Item pickaxeObsidian;
    public static Item axeObsidian;
    public static Item eggCooked;
    public static Item quiver;
    public static Item helmetSponge;
    public static Item plateSponge;
    public static Item legsSponge;
    public static Item bootsSponge;
    public static Item ingotCopper;
    public static Item fishRaw;
    public static Item fishCooked;
    public static Item carbonFilament;
    public final int shiftedIndex;
    public int maxStackSize;
    protected int maxDamage;
    protected int iconIndex;
    protected boolean bFull3D;
    private Item containerItem;
    
    static {
        Item.itemRand = new Random();
        Item.itemsList = new Item[32000];
        Item.shovel = new ItemSpade(0, 2).setIconIndex(82);
        Item.pickaxeSteel = new ItemPickaxe(1, 2).setIconIndex(98);
        Item.axeSteel = new ItemAxe(2, 2).setIconIndex(114);
        Item.striker = new ItemFlintAndSteel(3).setIconIndex(5);
        Item.appleRed = new ItemFood(4, 3).setIconIndex(10);
        Item.bow = new ItemBow(5).setIconIndex(21);
        Item.arrow = new Item(6).setIconIndex(37);
        Item.coal = new Item(7).setIconIndex(7);
        Item.diamond = new Item(8).setIconIndex(55);
        Item.ingotIron = new Item(9).setIconIndex(23);
        Item.ingotGold = new Item(10).setIconIndex(39);
        Item.swordSteel = new ItemSword(11, 2).setIconIndex(66);
        Item.swordWood = new ItemSword(12, 0).setIconIndex(64);
        Item.shovelWood = new ItemSpade(13, 0).setIconIndex(80);
        Item.pickaxeWood = new ItemPickaxe(14, 0).setIconIndex(96);
        Item.axeWood = new ItemAxe(15, 0).setIconIndex(112);
        Item.swordStone = new ItemSword(16, 1).setIconIndex(65);
        Item.shovelStone = new ItemSpade(17, 1).setIconIndex(81);
        Item.pickaxeStone = new ItemPickaxe(18, 1).setIconIndex(97);
        Item.axeStone = new ItemAxe(19, 1).setIconIndex(113);
        Item.swordDiamond = new ItemSword(20, 3).setIconIndex(67);
        Item.shovelDiamond = new ItemSpade(21, 3).setIconIndex(83);
        Item.pickaxeDiamond = new ItemPickaxe(22, 3).setIconIndex(99);
        Item.axeDiamond = new ItemAxe(23, 3).setIconIndex(115);
        Item.stick = new Item(24).setIconIndex(53).setFull3D();
        Item.bowlEmpty = new Item(25).setIconIndex(71);
        Item.bowlSoup = new ItemSoup(26, 10).setIconIndex(72);
        Item.swordGold = new ItemSword(27, 0).setIconIndex(68);
        Item.shovelGold = new ItemSpade(28, 0).setIconIndex(84);
        Item.pickaxeGold = new ItemPickaxe(29, 0).setIconIndex(100);
        Item.axeGold = new ItemAxe(30, 0).setIconIndex(116);
        Item.silk = new Item(31).setIconIndex(8);
        Item.feather = new Item(32).setIconIndex(24);
        Item.gunpowder = new Item(33).setIconIndex(40);
        Item.hoeWood = new ItemHoe(34, 0).setIconIndex(128);
        Item.hoeStone = new ItemHoe(35, 1).setIconIndex(129);
        Item.hoeSteel = new ItemHoe(36, 2).setIconIndex(130);
        Item.hoeDiamond = new ItemHoe(37, 3).setIconIndex(131);
        Item.hoeGold = new ItemHoe(38, 1).setIconIndex(132);
        Item.wheat = new Item(40).setIconIndex(25);
        Item.bread = new ItemFood(41, 5).setIconIndex(41);
        Item.helmetLeather = new ItemArmor(42, 0, 0, 0).setIconIndex(0);
        Item.plateLeather = new ItemArmor(43, 0, 0, 1).setIconIndex(16);
        Item.legsLeather = new ItemArmor(44, 0, 0, 2).setIconIndex(32);
        Item.bootsLeather = new ItemArmor(45, 0, 0, 3).setIconIndex(48);
        Item.helmetChain = new ItemArmor(46, 1, 1, 0).setIconIndex(1);
        Item.plateChain = new ItemArmor(47, 1, 1, 1).setIconIndex(17);
        Item.legsChain = new ItemArmor(48, 1, 1, 2).setIconIndex(33);
        Item.bootsChain = new ItemArmor(49, 1, 1, 3).setIconIndex(49);
        Item.helmetSteel = new ItemArmor(50, 2, 2, 0).setIconIndex(2);
        Item.plateSteel = new ItemArmor(51, 2, 2, 1).setIconIndex(18);
        Item.legsSteel = new ItemArmor(52, 2, 2, 2).setIconIndex(34);
        Item.bootsSteel = new ItemArmor(53, 2, 2, 3).setIconIndex(50);
        Item.helmetDiamond = new ItemArmor(54, 3, 3, 0).setIconIndex(3);
        Item.plateDiamond = new ItemArmor(55, 3, 3, 1).setIconIndex(19);
        Item.legsDiamond = new ItemArmor(56, 3, 3, 2).setIconIndex(35);
        Item.bootsDiamond = new ItemArmor(57, 3, 3, 3).setIconIndex(51);
        Item.helmetGold = new ItemArmor(58, 1, 4, 0).setIconIndex(4);
        Item.plateGold = new ItemArmor(59, 1, 4, 1).setIconIndex(20);
        Item.legsGold = new ItemArmor(60, 1, 4, 2).setIconIndex(36);
        Item.bootsGold = new ItemArmor(61, 1, 4, 3).setIconIndex(52);
        Item.flint = new Item(62).setIconIndex(6);
        Item.porkRaw = new ItemFood(63, 3).setIconIndex(87);
        Item.porkCooked = new ItemFood(64, 8).setIconIndex(88);
        Item.painting = new ItemPainting(65).setIconIndex(26);
        Item.appleGold = new ItemFood(66, 42).setIconIndex(11);
        Item.sign = new ItemSign(67).setIconIndex(42);
        Item.bucketEmpty = new ItemBucket(69, 0).setIconIndex(74);
        Item.minecartEmpty = new ItemMinecart(72, 0).setIconIndex(135);
        Item.saddle = new ItemSaddle(73).setIconIndex(104);
        Item.redstone = new ItemRedstone(75).setIconIndex(56);
        Item.snowball = new ItemSnowball(76).setIconIndex(14);
        Item.boat = new ItemBoat(77).setIconIndex(136);
        Item.leather = new Item(78).setIconIndex(103);
        Item.bucketMilk = new ItemBucket(79, -1).setIconIndex(77).setContainerItem(Item.bucketEmpty);
        Item.brick = new Item(80).setIconIndex(22);
        Item.clay = new Item(81).setIconIndex(57);
        Item.paper = new Item(83).setIconIndex(58);
        Item.book = new Item(84).setIconIndex(59);
        Item.slimeBall = new Item(85).setIconIndex(30);
        Item.minecartBox = new ItemMinecart(86, 1).setIconIndex(151);
        Item.minecartEngine = new ItemMinecart(87, 2).setIconIndex(167);
        Item.egg = new Item(88).setIconIndex(12);
        Item.compass = new Item(89).setIconIndex(54);
        Item.fishingRod = new ItemFishingRod(90).setIconIndex(69);
        Item.dyePurple = new Item(91).setIconIndex(78);
        Item.dyeBlack = new Item(92).setIconIndex(79);
        Item.dyeRed = new Item(93).setIconIndex(94);
        Item.dyePink = new Item(94).setIconIndex(95);
        Item.dyeGreen = new Item(95).setIconIndex(110);
        Item.dyeLime = new Item(96).setIconIndex(111);
        Item.dyeIndigo = new Item(97).setIconIndex(126);
        Item.dyeYellow = new Item(98).setIconIndex(127);
        Item.dyeCyan = new Item(99).setIconIndex(142);
        Item.dyeBlue = new Item(100).setIconIndex(143);
        Item.dyeViolet = new Item(101).setIconIndex(158);
        Item.dyeMagenta = new Item(102).setIconIndex(159);
        Item.dyeAquaGreen = new Item(103).setIconIndex(174);
        Item.dyeOrange = new Item(104).setIconIndex(175);
        Item.dyeGrey = new Item(105).setIconIndex(190);
        Item.bone = new Item(106).setIconIndex(206);
        Item.bonemeal = new ItemDye(107).setIconIndex(191);
        Item.cocoa = new Item(108).setIconIndex(207);
        Item.record13 = new ItemRecord(2000, "13").setIconIndex(240);
        Item.recordCat = new ItemRecord(2001, "cat").setIconIndex(241);
        Item.recordBlocks = new ItemRecord(2002, "blocks").setIconIndex(242);
        Item.recordChirp = new ItemRecord(2003, "chirp").setIconIndex(243);
        Item.recordFar = new ItemRecord(2004, "far").setIconIndex(244);
        Item.recordMall = new ItemRecord(2005, "mall").setIconIndex(245);
        Item.recordMellohi = new ItemRecord(2006, "mellohi").setIconIndex(246);
        Item.recordStal = new ItemRecord(2007, "stal").setIconIndex(247);
        Item.recordStrad = new ItemRecord(2008, "strad").setIconIndex(248);
        Item.recordWard = new ItemRecord(2009, "ward").setIconIndex(249);
        Item.record11 = new ItemRecord(2010, "11").setIconIndex(250);
        Item.recordWait = new ItemRecord(2011, "where are we now").setIconIndex(251);
        Item.recordMagnet = new ItemRecord(2012, "magnet").setIconIndex(252);
        Item.swordObsidian = new ItemSword(109, 1000).setIconIndex(85);
        Item.shovelObsidian = new ItemSpade(110, 5).setIconIndex(101);
        Item.pickaxeObsidian = new ItemPickaxe(111, 5).setIconIndex(117);
        Item.axeObsidian = new ItemAxe(112, 5).setIconIndex(133);
        Item.eggCooked = new ItemFood(113, 1).setIconIndex(13);
        Item.quiver = new Item(114).setIconIndex(38);
        Item.helmetSponge = new ItemArmor(115, 5, 5, 0).setIconIndex(144);
        Item.plateSponge = new ItemArmor(116, 5, 5, 1).setIconIndex(160);
        Item.legsSponge = new ItemArmor(117, 5, 5, 2).setIconIndex(176);
        Item.bootsSponge = new ItemArmor(118, 5, 5, 3).setIconIndex(192);
        Item.ingotCopper = new Item(119).setIconIndex(73);
        Item.fishRaw = new ItemFood(120, 2).setIconIndex(89);
        Item.fishCooked = new ItemFood(121, 5).setIconIndex(90);
        Item.carbonFilament = new Item(122).setIconIndex(28);
        Item.seeds = new ItemSeeds(39, Block.crops.blockID).setIconIndex(9);
        Item.doorWood = new ItemDoor(68, Material.wood).setIconIndex(43);
        Item.bucketWater = new ItemBucket(70, Block.waterMoving.blockID).setIconIndex(75).setContainerItem(Item.bucketEmpty);
        Item.bucketLava = new ItemBucket(71, Block.lavaMoving.blockID).setIconIndex(76).setContainerItem(Item.bucketEmpty);
        Item.doorSteel = new ItemDoor(74, Material.iron).setIconIndex(44);
        Item.reed = new ItemReed(82, Block.reed).setIconIndex(27);
        Item.appleGold.maxStackSize = 1;
        Item.porkRaw.maxStackSize = 1;
        Item.porkCooked.maxStackSize = 1;
        Item.bowlSoup.maxStackSize = 1;
        Item.fishRaw.maxStackSize = 1;
        Item.fishCooked.maxStackSize = 1;
        Item.egg.maxStackSize = 12;
        Item.eggCooked.maxStackSize = 12;
        Item.appleRed.maxStackSize = 4;
    }
    
    protected Item(final int i) {
        this.maxStackSize = 64;
        this.maxDamage = 32;
        this.bFull3D = false;
        this.containerItem = null;
        this.shiftedIndex = 256 + i;
        if (Item.itemsList[256 + i] != null) {
            System.out.println("CONFLICT @ " + i);
        }
        Item.itemsList[256 + i] = this;
    }
    
    public Item setIconIndex(final int i) {
        this.iconIndex = i;
        return this;
    }
    
    public int getIconIndex(final ItemStack itemstack) {
        return this.iconIndex;
    }
    
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        return false;
    }
    
    public float getStrVsBlock(final ItemStack itemstack, final Block block) {
        return 1.0f;
    }
    
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        return itemstack;
    }
    
    public int func_200_b() {
        return this.maxStackSize;
    }
    
    public int getMaxDmg() {
        return this.maxDamage;
    }
    
    public void damageItemHit(final ItemStack itemstack, final EntityLiving entityliving) {
    }
    
    public void damageItemMine(final ItemStack itemstack, final int i, final int j, final int k, final int l) {
    }
    
    public int getDamageVsEntity(final Entity entity) {
        return 1;
    }
    
    public boolean breaking(final Block block) {
        return false;
    }
    
    public void saddleEntity(final ItemStack itemstack, final EntityLiving entityliving) {
    }
    
    public Item setFull3D() {
        this.bFull3D = true;
        return this;
    }
    
    public boolean isFull3D() {
        return this.bFull3D;
    }
    
    public Item setContainerItem(final Item item) {
        if (this.maxStackSize > 1) {
            throw new IllegalArgumentException("Max stack size must be 1 for items with crafting results");
        }
        this.containerItem = item;
        return this;
    }
    
    public Item getContainerItem() {
        return this.containerItem;
    }
    
    public boolean hasContainerItem() {
        return this.containerItem != null;
    }
}
