package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;

public class ItemSaddle extends Item
{
    public ItemSaddle(final int i) {
        super(i);
        this.maxStackSize = 1;
        this.maxDamage = 64;
    }
    
    @Override
    public void saddleEntity(final ItemStack itemstack, final EntityLiving entityliving) {
        if (entityliving instanceof EntityPig) {
            final EntityPig entitypig = (EntityPig)entityliving;
            if (!entitypig.getSaddled()) {
                entitypig.setSaddled(true);
                --itemstack.stackSize;
            }
        }
    }
    
    @Override
    public void damageItemHit(final ItemStack itemstack, final EntityLiving entityliving) {
        this.saddleEntity(itemstack, entityliving);
    }
}
