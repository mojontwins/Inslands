package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.*;

public class ItemBucket extends Item
{
    private int bucketItem;
    
    public ItemBucket(final int i, final int j) {
        super(i);
        this.maxStackSize = 1;
        this.maxDamage = 64;
        this.bucketItem = j;
    }
    
    @Override
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        final float f = 1.0f;
        final float f2 = entityplayer.prevRotationPitch + (entityplayer.rotationPitch - entityplayer.prevRotationPitch) * f;
        final float f3 = entityplayer.prevRotationYaw + (entityplayer.rotationYaw - entityplayer.prevRotationYaw) * f;
        final double d = entityplayer.prevPosX + (entityplayer.posX - entityplayer.prevPosX) * f;
        final double d2 = entityplayer.prevPosY + (entityplayer.posY - entityplayer.prevPosY) * f;
        final double d3 = entityplayer.prevPosZ + (entityplayer.posZ - entityplayer.prevPosZ) * f;
        final Vec3D vec3d = Vec3D.createVector(d, d2, d3);
        final float f4 = MathHelper.cos(-f3 * 0.01745329f - 3.141593f);
        final float f5 = MathHelper.sin(-f3 * 0.01745329f - 3.141593f);
        final float f6 = -MathHelper.cos(-f2 * 0.01745329f);
        final float f7 = MathHelper.sin(-f2 * 0.01745329f);
        final float f8 = f5 * f6;
        final float f9 = f7;
        final float f10 = f4 * f6;
        final double d4 = 5.0;
        final Vec3D vec3d2 = vec3d.addVector(f8 * d4, f9 * d4, f10 * d4);
        final MovingObjectPosition movingobjectposition = world.rayTraceBlocks_do(vec3d, vec3d2, this.bucketItem == 0);
        if (movingobjectposition == null && this.shiftedIndex != Item.bucketMilk.shiftedIndex) {
            return itemstack;
        }
        if (this.shiftedIndex != Item.bucketMilk.shiftedIndex && movingobjectposition.typeOfHit == 0) {
            int i = movingobjectposition.blockX;
            int j = movingobjectposition.blockY;
            int k = movingobjectposition.blockZ;
            if (this.bucketItem == 0) {
                if (world.getMaterialXYZ(i, j, k) == Material.water && world.getBlockMetadata(i, j, k) == 0) {
                    world.setBlockWithNotify(i, j, k, 0);
                    return new ItemStack(Item.bucketWater);
                }
                if (world.getMaterialXYZ(i, j, k) == Material.lava && world.getBlockMetadata(i, j, k) == 0) {
                    world.setBlockWithNotify(i, j, k, 0);
                    return new ItemStack(Item.bucketLava);
                }
            }
            else {
                if (movingobjectposition.sideHit == 0) {
                    --j;
                }
                if (movingobjectposition.sideHit == 1) {
                    ++j;
                }
                if (movingobjectposition.sideHit == 2) {
                    --k;
                }
                if (movingobjectposition.sideHit == 3) {
                    ++k;
                }
                if (movingobjectposition.sideHit == 4) {
                    --i;
                }
                if (movingobjectposition.sideHit == 5) {
                    ++i;
                }
                if ((world.getBlockId(i, j, k) == 0 || !world.getMaterialXYZ(i, j, k).isSolidMaterial()) && this.shiftedIndex != Item.bucketMilk.shiftedIndex) {
                    world.setBlockAndMetadataWithNotify(i, j, k, this.bucketItem, 0);
                    return new ItemStack(Item.bucketEmpty);
                }
            }
        }
        else if (this.bucketItem == 0 && movingobjectposition.entityHit instanceof EntityCow) {
            return new ItemStack(Item.bucketMilk);
        }
        if (this.shiftedIndex == Item.bucketMilk.shiftedIndex && entityplayer instanceof EntityPlayerSP) {
            if (movingobjectposition != null && movingobjectposition.entityHit != null && movingobjectposition.entityHit instanceof EntityCow) {
                return itemstack;
            }
            if (((EntityPlayerSP)entityplayer).getStamina() < ((EntityPlayerSP)entityplayer).getMaxStamina()) {
                ((EntityPlayerSP)entityplayer).setStamina(((EntityPlayerSP)entityplayer).getMaxStamina());
                return new ItemStack(Item.bucketEmpty);
            }
        }
        return itemstack;
    }
}
