package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;

public class ItemReed extends Item
{
    private int field_320_a;
    
    public ItemReed(final int i, final Block block) {
        super(i);
        this.field_320_a = block.blockID;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, int i, int j, int k, int l) {
        if (world.getBlockId(i, j, k) == Block.snow.blockID) {
            l = 0;
        }
        else {
            if (l == 0) {
                --j;
            }
            if (l == 1) {
                ++j;
            }
            if (l == 2) {
                --k;
            }
            if (l == 3) {
                ++k;
            }
            if (l == 4) {
                --i;
            }
            if (l == 5) {
                ++i;
            }
        }
        if (itemstack.stackSize == 0) {
            return false;
        }
        if (world.func_695_a(this.field_320_a, i, j, k, false)) {
            final Block block = Block.allBlocks[this.field_320_a];
            if (world.setBlockWithNotify(i, j, k, this.field_320_a)) {
                Block.allBlocks[this.field_320_a].onBlockPlaced(world, i, j, k, l);
                world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, block.stepSound.func_1145_d(), (block.stepSound.getVolume() + 1.0f) / 2.0f, block.stepSound.getPitch() * 0.8f);
                --itemstack.stackSize;
            }
        }
        return true;
    }
}
