package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;

public class ItemRecord extends Item
{
    public String recordName;
    
    protected ItemRecord(final int i, final String s) {
        super(i);
        this.recordName = s;
        this.maxStackSize = 1;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        if (world.getBlockId(i, j, k) != Block.jukebox.blockID || world.getBlockMetadata(i, j, k) != 0) {
            return false;
        }
        if (world.multiplayerWorld) {
            return true;
        }
        world.setBlockMetadataWithNotify(i, j, k, this.shiftedIndex - Item.record13.shiftedIndex + 1);
        world.playRecord(this.recordName, i, j, k);
        --itemstack.stackSize;
        return true;
    }
}
