package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;

public class ItemDoor extends Item
{
    private Material field_321_a;
    
    public ItemDoor(final int i, final Material material) {
        super(i);
        this.field_321_a = material;
        this.maxDamage = 64;
        this.maxStackSize = 16;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, int j, final int k, final int l) {
        if (l != 1) {
            return false;
        }
        ++j;
        Block block;
        if (this.field_321_a == Material.wood) {
            block = Block.doorWood;
        }
        else {
            block = Block.doorSteel;
        }
        if (!block.canPlace(world, i, j, k)) {
            return false;
        }
        int i2 = MathHelper.floor_double((entityplayer.rotationYaw + 180.0f) * 4.0f / 360.0f - 0.5) & 0x3;
        byte byte0 = 0;
        byte byte2 = 0;
        if (i2 == 0) {
            byte2 = 1;
        }
        if (i2 == 1) {
            byte0 = -1;
        }
        if (i2 == 2) {
            byte2 = -1;
        }
        if (i2 == 3) {
            byte0 = 1;
        }
        final int j2 = (world.isBlockNormalCube(i - byte0, j, k - byte2) + world.isBlockNormalCube(i - byte0, j + 1, k - byte2)) ? 1 : 0;
        final int k2 = (world.isBlockNormalCube(i + byte0, j, k + byte2) + world.isBlockNormalCube(i + byte0, j + 1, k + byte2)) ? 1 : 0;
        final boolean flag = world.getBlockId(i - byte0, j, k - byte2) == block.blockID || world.getBlockId(i - byte0, j + 1, k - byte2) == block.blockID;
        final boolean flag2 = world.getBlockId(i + byte0, j, k + byte2) == block.blockID || world.getBlockId(i + byte0, j + 1, k + byte2) == block.blockID;
        boolean flag3 = false;
        if (flag && !flag2) {
            flag3 = true;
        }
        else if (k2 > j2) {
            flag3 = true;
        }
        if (flag3) {
            i2 = (i2 - 1 & 0x3);
            i2 += 4;
        }
        world.setBlockWithNotify(i, j, k, block.blockID);
        world.setBlockMetadataWithNotify(i, j, k, i2);
        world.setBlockWithNotify(i, j + 1, k, block.blockID);
        world.setBlockMetadataWithNotify(i, j + 1, k, i2 + 8);
        --itemstack.stackSize;
        return true;
    }
}
