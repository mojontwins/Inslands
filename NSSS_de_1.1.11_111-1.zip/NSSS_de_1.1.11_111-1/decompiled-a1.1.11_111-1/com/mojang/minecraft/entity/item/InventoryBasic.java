package com.mojang.minecraft.entity.item;

import java.util.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.*;

public class InventoryBasic implements IInventory
{
    private String inventoryTitle;
    private int slotsCount;
    private ItemStack[] inventoryContents;
    private List field_20073_d;
    
    public InventoryBasic(final String s, final int i) {
        this.inventoryTitle = s;
        if (i >= 0) {
            this.slotsCount = i;
            this.inventoryContents = new ItemStack[i];
        }
        else {
            this.slotsCount = 135;
            this.inventoryContents = new ItemStack[135];
        }
    }
    
    public int getSizeInventory() {
        return this.slotsCount;
    }
    
    public ItemStack getStackInSlot(final int i) {
        return this.inventoryContents[i];
    }
    
    public ItemStack decrStackSize(final int i, final int j) {
        if (this.inventoryContents[i] == null) {
            return null;
        }
        if (this.inventoryContents[i].stackSize <= j) {
            final ItemStack itemstack = this.inventoryContents[i];
            this.inventoryContents[i] = null;
            this.onInventoryChanged();
            return itemstack;
        }
        final ItemStack itemstack2 = this.inventoryContents[i].splitStack(j);
        if (this.inventoryContents[i].stackSize == 0) {
            this.inventoryContents[i] = null;
        }
        this.onInventoryChanged();
        return itemstack2;
    }
    
    public void setInventorySlotContents(final int i, final ItemStack itemstack) {
        this.inventoryContents[i] = itemstack;
        if (itemstack != null && itemstack.stackSize > this.getInventoryStackLimit()) {
            itemstack.stackSize = this.getInventoryStackLimit();
        }
        this.onInventoryChanged();
    }
    
    public String getInvName() {
        return this.inventoryTitle;
    }
    
    public int getInventoryStackLimit() {
        return 64;
    }
    
    public void onInventoryChanged() {
        if (this.field_20073_d != null) {
            for (int i = 0; i < this.field_20073_d.size(); ++i) {
                this.field_20073_d.get(i).func_20134_a(this);
            }
        }
    }
    
    public boolean canInteractWith(final EntityPlayer entityplayer) {
        return true;
    }
}
