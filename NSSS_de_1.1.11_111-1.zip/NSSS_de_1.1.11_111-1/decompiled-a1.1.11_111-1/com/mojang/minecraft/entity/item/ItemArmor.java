package com.mojang.minecraft.entity.item;

public class ItemArmor extends Item
{
    private static final int[] protection;
    private static final int[] durability;
    public final int armorTier;
    public final int article;
    public final int protectionLevel;
    public final int armorMaterial;
    
    static {
        protection = new int[] { 3, 8, 6, 3, 0 };
        durability = new int[] { 11, 16, 15, 13, 0 };
    }
    
    public ItemArmor(final int i, final int tier, final int material, final int art) {
        super(i);
        this.armorTier = tier;
        this.article = art;
        this.armorMaterial = material;
        this.protectionLevel = ItemArmor.protection[art];
        this.maxDamage = ItemArmor.durability[art] * 4 << tier;
        this.maxStackSize = 1;
        if (tier == 5) {
            this.maxDamage = -16383;
        }
    }
}
