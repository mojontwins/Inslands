package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class ItemPainting extends Item
{
    public ItemPainting(final int i) {
        super(i);
        this.maxDamage = 64;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        if (l == 0) {
            return false;
        }
        if (l == 1) {
            return false;
        }
        byte byte0 = 0;
        if (l == 4) {
            byte0 = 1;
        }
        if (l == 3) {
            byte0 = 2;
        }
        if (l == 5) {
            byte0 = 3;
        }
        final EntityPainting entitypainting = new EntityPainting(world, i, j, k, byte0);
        if (entitypainting.func_410_i()) {
            if (!world.multiplayerWorld) {
                world.entityJoinedWorld(entitypainting);
            }
            --itemstack.stackSize;
        }
        return true;
    }
}
