package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;

public class ItemTool extends Item
{
    private Block[] toolBreakList;
    public boolean isGold;
    private float efficiencyOnProperMaterial;
    private int damageVsEntity;
    protected int toolMaterial_Int;
    
    public ItemTool(final int i, final int j, final int k, final Block[] ablock) {
        super(i);
        if (i == 27 || i == 28 || i == 29 || i == 30) {
            this.isGold = true;
        }
        else {
            this.isGold = false;
        }
        this.efficiencyOnProperMaterial = 4.0f;
        this.toolMaterial_Int = k;
        this.toolBreakList = ablock;
        this.maxStackSize = 1;
        this.maxDamage = 32 << k;
        if (k >= 3) {
            this.maxDamage *= 4;
        }
        this.maxDamage *= 2;
        this.efficiencyOnProperMaterial = (float)((k + 1) * 2);
        this.damageVsEntity = j + k;
    }
    
    @Override
    public float getStrVsBlock(final ItemStack itemstack, final Block block) {
        for (int i = 0; i < this.toolBreakList.length; ++i) {
            if (this.toolBreakList[i] == block) {
                return this.efficiencyOnProperMaterial;
            }
        }
        return 1.0f;
    }
    
    @Override
    public void damageItemHit(final ItemStack itemstack, final EntityLiving entityliving) {
        itemstack.damageItem(2);
    }
    
    @Override
    public void damageItemMine(final ItemStack itemstack, final int i, final int j, final int k, final int l) {
        itemstack.damageItem(1);
    }
    
    @Override
    public int getDamageVsEntity(final Entity entity) {
        return this.damageVsEntity;
    }
    
    @Override
    public boolean isFull3D() {
        return true;
    }
}
