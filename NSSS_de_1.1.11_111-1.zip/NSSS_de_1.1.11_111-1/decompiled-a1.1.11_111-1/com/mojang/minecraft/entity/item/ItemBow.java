package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class ItemBow extends Item
{
    public ItemBow(final int i) {
        super(i);
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        float damageMult = 1.0f;
        if (entityplayer.inventory.armorInventory[2] != null && entityplayer.inventory.armorInventory[2].itemID == Item.quiver.shiftedIndex) {
            damageMult = 2.0f;
        }
        if (entityplayer.inventory.consumeInventoryItem(Item.arrow.shiftedIndex) || entityplayer.isCreative) {
            world.playSoundAtEntity(entityplayer, "random.bow", 1.0f, 1.0f / (ItemBow.itemRand.nextFloat() * 0.4f + 0.8f));
            if (!world.multiplayerWorld) {
                world.entityJoinedWorld(new EntityArrow(world, entityplayer, damageMult));
            }
        }
        return itemstack;
    }
}
