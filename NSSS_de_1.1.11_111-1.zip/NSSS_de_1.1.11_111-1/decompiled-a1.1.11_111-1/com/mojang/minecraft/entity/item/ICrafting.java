package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.player.inventory.*;

public interface ICrafting
{
    void func_20159_a(final Container p0, final int p1, final ItemStack p2);
    
    void func_20158_a(final Container p0, final int p1, final int p2);
}
