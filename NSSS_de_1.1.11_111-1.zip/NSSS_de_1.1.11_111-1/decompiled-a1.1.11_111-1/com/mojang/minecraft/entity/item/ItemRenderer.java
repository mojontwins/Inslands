package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.render.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.tile.material.*;

public class ItemRenderer
{
    private Minecraft field_1356_a;
    private ItemStack field_1355_b;
    private float field_1359_c;
    private float field_1358_d;
    private RenderBlocks field_1357_e;
    
    public ItemRenderer(final Minecraft minecraft) {
        this.field_1355_b = null;
        this.field_1359_c = 0.0f;
        this.field_1358_d = 0.0f;
        this.field_1357_e = new RenderBlocks();
        this.field_1356_a = minecraft;
    }
    
    public void renderItem(final ItemStack itemstack) {
        GL11.glPushMatrix();
        if (itemstack.itemID < 256 && RenderBlocks.getRenderItemType(Block.allBlocks[itemstack.itemID].getRenderType())) {
            GL11.glBindTexture(3553, this.field_1356_a.renderEngine.getTex("/terrain.png"));
            this.field_1357_e.renderThrownItems(Block.allBlocks[itemstack.itemID]);
        }
        else {
            if (itemstack.itemID < 256) {
                GL11.glBindTexture(3553, this.field_1356_a.renderEngine.getTex("/terrain.png"));
            }
            else {
                GL11.glBindTexture(3553, this.field_1356_a.renderEngine.getTex("/gui/items.png"));
            }
            final Tessellator tessellator = Tessellator.instance;
            final float f = (itemstack.getIconIndex() % 16 * 16 + 0) / 256.0f;
            final float f2 = (itemstack.getIconIndex() % 16 * 16 + 16) / 256.0f;
            final float f3 = (itemstack.getIconIndex() / 16 * 16 + 0) / 256.0f;
            final float f4 = (itemstack.getIconIndex() / 16 * 16 + 16) / 256.0f;
            final float f5 = 1.0f;
            final float f6 = 0.0f;
            final float f7 = 0.3f;
            GL11.glEnable(32826);
            GL11.glTranslatef(-f6, -f7, 0.0f);
            final float f8 = 1.5f;
            GL11.glScalef(f8, f8, f8);
            GL11.glRotatef(50.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(335.0f, 0.0f, 0.0f, 1.0f);
            GL11.glTranslatef(-0.9375f, -0.0625f, 0.0f);
            final float f9 = 0.0625f;
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0f, 0.0f, 1.0f);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0, f2, f4);
            tessellator.addVertexWithUV(f5, 0.0, 0.0, f, f4);
            tessellator.addVertexWithUV(f5, 1.0, 0.0, f, f3);
            tessellator.addVertexWithUV(0.0, 1.0, 0.0, f2, f3);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0f, 0.0f, -1.0f);
            tessellator.addVertexWithUV(0.0, 1.0, 0.0f - f9, f2, f3);
            tessellator.addVertexWithUV(f5, 1.0, 0.0f - f9, f, f3);
            tessellator.addVertexWithUV(f5, 0.0, 0.0f - f9, f, f4);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0f - f9, f2, f4);
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(-1.0f, 0.0f, 0.0f);
            for (int i = 0; i < 16; ++i) {
                final float f10 = i / 16.0f;
                final float f11 = f2 + (f - f2) * f10 - 0.001953125f;
                final float f12 = f5 * f10;
                tessellator.addVertexWithUV(f12, 0.0, 0.0f - f9, f11, f4);
                tessellator.addVertexWithUV(f12, 0.0, 0.0, f11, f4);
                tessellator.addVertexWithUV(f12, 1.0, 0.0, f11, f3);
                tessellator.addVertexWithUV(f12, 1.0, 0.0f - f9, f11, f3);
            }
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(1.0f, 0.0f, 0.0f);
            for (int j = 0; j < 16; ++j) {
                final float f13 = j / 16.0f;
                final float f14 = f2 + (f - f2) * f13 - 0.001953125f;
                final float f15 = f5 * f13 + 0.0625f;
                tessellator.addVertexWithUV(f15, 1.0, 0.0f - f9, f14, f3);
                tessellator.addVertexWithUV(f15, 1.0, 0.0, f14, f3);
                tessellator.addVertexWithUV(f15, 0.0, 0.0, f14, f4);
                tessellator.addVertexWithUV(f15, 0.0, 0.0f - f9, f14, f4);
            }
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0f, 1.0f, 0.0f);
            for (int k = 0; k < 16; ++k) {
                final float f16 = k / 16.0f;
                final float f17 = f4 + (f3 - f4) * f16 - 0.001953125f;
                final float f18 = f5 * f16 + 0.0625f;
                tessellator.addVertexWithUV(0.0, f18, 0.0, f2, f17);
                tessellator.addVertexWithUV(f5, f18, 0.0, f, f17);
                tessellator.addVertexWithUV(f5, f18, 0.0f - f9, f, f17);
                tessellator.addVertexWithUV(0.0, f18, 0.0f - f9, f2, f17);
            }
            tessellator.draw();
            tessellator.startDrawingQuads();
            tessellator.setNormal(0.0f, -1.0f, 0.0f);
            for (int l = 0; l < 16; ++l) {
                final float f19 = l / 16.0f;
                final float f20 = f4 + (f3 - f4) * f19 - 0.001953125f;
                final float f21 = f5 * f19;
                tessellator.addVertexWithUV(f5, f21, 0.0, f, f20);
                tessellator.addVertexWithUV(0.0, f21, 0.0, f2, f20);
                tessellator.addVertexWithUV(0.0, f21, 0.0f - f9, f2, f20);
                tessellator.addVertexWithUV(f5, f21, 0.0f - f9, f, f20);
            }
            tessellator.draw();
            GL11.glDisable(32826);
        }
        GL11.glPopMatrix();
    }
    
    public void renderViewModel(final float f) {
        final float f2 = this.field_1358_d + (this.field_1359_c - this.field_1358_d) * f;
        final EntityPlayerSP entityplayersp = this.field_1356_a.thePlayer;
        GL11.glPushMatrix();
        GL11.glRotatef(entityplayersp.prevRotationPitch + (entityplayersp.rotationPitch - entityplayersp.prevRotationPitch) * f, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(entityplayersp.prevRotationYaw + (entityplayersp.rotationYaw - entityplayersp.prevRotationYaw) * f, 0.0f, 1.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GL11.glPopMatrix();
        final float f3 = this.field_1356_a.mcWorld.getBrightness(MathHelper.floor_double(entityplayersp.posX), MathHelper.floor_double(entityplayersp.posY), MathHelper.floor_double(entityplayersp.posZ));
        GL11.glColor4f(f3, f3, f3, 1.0f);
        if (this.field_1355_b != null) {
            GL11.glPushMatrix();
            final float f4 = 0.8f;
            float f5 = entityplayersp.getSwingProgress(f);
            float f6 = MathHelper.sin(f5 * 3.141593f);
            float f7 = MathHelper.sin(MathHelper.sqrt_float(f5) * 3.141593f);
            GL11.glTranslatef(-f7 * 0.4f, MathHelper.sin(MathHelper.sqrt_float(f5) * 3.141593f * 2.0f) * 0.2f, -f6 * 0.2f);
            GL11.glTranslatef(0.7f * f4, -0.65f * f4 - (1.0f - f2) * 0.6f, -0.9f * f4);
            GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            GL11.glEnable(32826);
            f5 = entityplayersp.getSwingProgress(f);
            f6 = MathHelper.sin(f5 * f5 * 3.141593f);
            f7 = MathHelper.sin(MathHelper.sqrt_float(f5) * 3.141593f);
            GL11.glRotatef(-f6 * 20.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(-f7 * 20.0f, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(-f7 * 80.0f, 1.0f, 0.0f, 0.0f);
            f5 = 0.4f;
            GL11.glScalef(f5, f5, f5);
            this.renderItem(this.field_1355_b);
            GL11.glPopMatrix();
        }
        else {
            GL11.glPushMatrix();
            final float f8 = 0.8f;
            float f9 = entityplayersp.getSwingProgress(f);
            float f10 = MathHelper.sin(f9 * 3.141593f);
            float f11 = MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593f);
            GL11.glTranslatef(-f11 * 0.3f, MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593f * 2.0f) * 0.4f, -f10 * 0.4f);
            GL11.glTranslatef(0.8f * f8, -0.75f * f8 - (1.0f - f2) * 0.6f, -0.9f * f8);
            GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            GL11.glEnable(32826);
            f9 = entityplayersp.getSwingProgress(f);
            f10 = MathHelper.sin(f9 * f9 * 3.141593f);
            f11 = MathHelper.sin(MathHelper.sqrt_float(f9) * 3.141593f);
            GL11.glRotatef(f11 * 70.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(-f10 * 20.0f, 0.0f, 0.0f, 1.0f);
            GL11.glBindTexture(3553, this.field_1356_a.renderEngine.getTextureForDownloadableImage(this.field_1356_a.thePlayer.skinURL, this.field_1356_a.thePlayer.getEntityTexture()));
            GL11.glTranslatef(-1.0f, 3.6f, 3.5f);
            GL11.glRotatef(120.0f, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(200.0f, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(-135.0f, 0.0f, 1.0f, 0.0f);
            GL11.glScalef(1.0f, 1.0f, 1.0f);
            GL11.glTranslatef(5.6f, 0.0f, 0.0f);
            final Render render = RenderManager.subManager.getEntityRenderObject(this.field_1356_a.thePlayer);
            final RenderPlayer renderplayer = (RenderPlayer)render;
            f11 = 1.0f;
            GL11.glScalef(f11, f11, f11);
            renderplayer.renderArmViewModel(this.field_1356_a.thePlayer);
            GL11.glPopMatrix();
        }
        GL11.glDisable(32826);
        RenderHelper.disableStandardItemLighting();
    }
    
    public void func_893_b(final float f) {
        GL11.glDisable(3008);
        if (this.field_1356_a.thePlayer.fire > 0) {
            final int i = this.field_1356_a.renderEngine.getTex("/terrain.png");
            GL11.glBindTexture(3553, i);
            this.func_890_d(f);
        }
        if (this.field_1356_a.thePlayer.isEntityInsideOpaqueBlock()) {
            final int j = MathHelper.floor_double(this.field_1356_a.thePlayer.posX);
            final int l = MathHelper.floor_double(this.field_1356_a.thePlayer.posY);
            final int i2 = MathHelper.floor_double(this.field_1356_a.thePlayer.posZ);
            final int j2 = this.field_1356_a.renderEngine.getTex("/terrain.png");
            GL11.glBindTexture(3553, j2);
            final int k1 = this.field_1356_a.mcWorld.getBlockId(j, l, i2);
            if (Block.allBlocks[k1] != null) {
                this.func_898_a(f, Block.allBlocks[k1].getTextureIndex(2));
            }
        }
        if (this.field_1356_a.thePlayer.isInsideOfMaterial(Material.water)) {
            final int m = this.field_1356_a.renderEngine.getTex("/water.png");
            GL11.glBindTexture(3553, m);
            this.func_892_c(f);
        }
        GL11.glEnable(3008);
    }
    
    private void func_898_a(final float f, final int i) {
        final Tessellator tessellator = Tessellator.instance;
        float f2 = this.field_1356_a.thePlayer.getEntityBrightness(f);
        f2 = 0.1f;
        GL11.glColor4f(f2, f2, f2, 0.5f);
        GL11.glPushMatrix();
        final float f3 = -1.0f;
        final float f4 = 1.0f;
        final float f5 = -1.0f;
        final float f6 = 1.0f;
        final float f7 = -0.5f;
        final float f8 = 0.0078125f;
        final float f9 = i % 16 / 256.0f - f8;
        final float f10 = (i % 16 + 15.99f) / 256.0f + f8;
        final float f11 = i / 16 / 256.0f - f8;
        final float f12 = (i / 16 + 15.99f) / 256.0f + f8;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(f3, f5, f7, f10, f12);
        tessellator.addVertexWithUV(f4, f5, f7, f9, f12);
        tessellator.addVertexWithUV(f4, f6, f7, f9, f11);
        tessellator.addVertexWithUV(f3, f6, f7, f10, f11);
        tessellator.draw();
        GL11.glPopMatrix();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    }
    
    private void func_892_c(final float f) {
        final Tessellator tessellator = Tessellator.instance;
        final float f2 = this.field_1356_a.thePlayer.getEntityBrightness(f);
        GL11.glColor4f(f2, f2, f2, 0.5f);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glPushMatrix();
        final float f3 = 80.0f;
        final float f4 = -20.0f;
        final float f5 = 20.0f;
        final float f6 = -20.0f;
        final float f7 = 20.0f;
        final float f8 = -0.5f;
        final float f9 = -this.field_1356_a.thePlayer.rotationYaw / 64.0f;
        final float f10 = this.field_1356_a.thePlayer.rotationPitch / 64.0f;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(f4, f6, f8, f3 + f9, f3 + f10);
        tessellator.addVertexWithUV(f5, f6, f8, 0.0f + f9, f3 + f10);
        tessellator.addVertexWithUV(f5, f7, f8, 0.0f + f9, 0.0f + f10);
        tessellator.addVertexWithUV(f4, f7, f8, f3 + f9, 0.0f + f10);
        tessellator.draw();
        GL11.glPopMatrix();
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3042);
    }
    
    private void func_890_d(final float f) {
        final Tessellator tessellator = Tessellator.instance;
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 0.9f);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        final float f2 = 1.0f;
        for (int i = 0; i < 2; ++i) {
            GL11.glPushMatrix();
            final int j = Block.fire.blockIndexInTexture + i * 16;
            final int k = (j & 0xF) << 4;
            final int l = j & 0xF0;
            final float f3 = k / 256.0f;
            final float f4 = (k + 15.99f) / 256.0f;
            final float f5 = l / 256.0f;
            final float f6 = (l + 15.99f) / 256.0f;
            final float f7 = (0.0f - f2) / 2.0f;
            final float f8 = f7 + f2;
            final float f9 = 0.0f - f2 / 2.0f;
            final float f10 = f9 + f2;
            final float f11 = -0.5f;
            GL11.glTranslatef(-(i * 2 - 1) * 0.24f, -0.3f, 0.0f);
            GL11.glRotatef((i * 2 - 1) * 10.0f, 0.0f, 1.0f, 0.0f);
            tessellator.startDrawingQuads();
            tessellator.addVertexWithUV(f7, f9, f11, f4, f6);
            tessellator.addVertexWithUV(f8, f9, f11, f3, f6);
            tessellator.addVertexWithUV(f8, f10, f11, f3, f5);
            tessellator.addVertexWithUV(f7, f10, f11, f4, f5);
            tessellator.draw();
            GL11.glPopMatrix();
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glDisable(3042);
    }
    
    public void updateEquippedItem() {
        this.field_1358_d = this.field_1359_c;
        final EntityPlayerSP entityplayersp = this.field_1356_a.thePlayer;
        final ItemStack itemstack2;
        final ItemStack itemstack = itemstack2 = entityplayersp.inventory.getCurrentItem();
        final float f = 0.4f;
        final float f2 = (itemstack2 != this.field_1355_b) ? 0.0f : 1.0f;
        float f3 = f2 - this.field_1359_c;
        if (f3 < -f) {
            f3 = -f;
        }
        if (f3 > f) {
            f3 = f;
        }
        this.field_1359_c += f3;
        if (this.field_1359_c < 0.1f) {
            this.field_1355_b = itemstack2;
        }
    }
    
    public void func_891_b() {
        this.field_1359_c = 0.0f;
    }
    
    public void func_896_c() {
        this.field_1359_c = 0.0f;
    }
}
