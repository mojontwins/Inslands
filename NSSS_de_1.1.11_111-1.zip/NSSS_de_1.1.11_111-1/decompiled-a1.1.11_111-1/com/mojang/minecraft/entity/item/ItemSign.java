package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.tile.*;

public class ItemSign extends Item
{
    public ItemSign(final int i) {
        super(i);
        this.maxDamage = 64;
        this.maxStackSize = 16;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, int i, int j, int k, final int l) {
        if (l == 0) {
            return false;
        }
        if (!world.getMaterialXYZ(i, j, k).isSolidMaterial()) {
            return false;
        }
        if (l == 1) {
            ++j;
        }
        if (l == 2) {
            --k;
        }
        if (l == 3) {
            ++k;
        }
        if (l == 4) {
            --i;
        }
        if (l == 5) {
            ++i;
        }
        if (!Block.signPost.canPlace(world, i, j, k)) {
            return false;
        }
        if (l == 1) {
            world.setBlockAndMetadataWithNotify(i, j, k, Block.signPost.blockID, MathHelper.floor_double((entityplayer.rotationYaw + 180.0f) * 16.0f / 360.0f + 0.5) & 0xF);
        }
        else {
            world.setBlockAndMetadataWithNotify(i, j, k, Block.pressurePlateWoodIdle.blockID, l);
        }
        --itemstack.stackSize;
        entityplayer.displayGUIEditSign((TileEntitySign)world.getBlockTileEntity(i, j, k));
        return true;
    }
}
