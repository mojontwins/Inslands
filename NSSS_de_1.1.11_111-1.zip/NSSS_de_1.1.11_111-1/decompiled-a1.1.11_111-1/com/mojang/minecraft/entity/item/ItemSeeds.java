package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;

public class ItemSeeds extends Item
{
    private int field_318_a;
    
    public ItemSeeds(final int i, final int j) {
        super(i);
        this.field_318_a = j;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        if (l != 1) {
            return false;
        }
        final int i2 = world.getBlockId(i, j, k);
        if (i2 == Block.tilledField.blockID) {
            world.setBlockWithNotify(i, j + 1, k, this.field_318_a);
            --itemstack.stackSize;
            return true;
        }
        return false;
    }
}
