package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;

public class ItemSword extends Item
{
    private int weaponDamage;
    private static Block[] swordBreakList;
    
    static {
        ItemSword.swordBreakList = new Block[] { Block.sponge, Block.leaves, Block.cactus, Block.cloth, Block.cloth_red, Block.cloth_orange, Block.cloth_yellow, Block.cloth_lime, Block.cloth_green, Block.cloth_teal, Block.cloth_cyan, Block.cloth_blue, Block.cloth_indigo, Block.cloth_violet, Block.cloth_lilac, Block.cloth_pink, Block.cloth_magenta, Block.cloth_darkgray, Block.cloth_lightgray, Block.web };
    }
    
    public ItemSword(final int i, final int j) {
        super(i);
        this.maxStackSize = 1;
        this.maxDamage = 32 << j;
        if (j == 3) {
            this.maxDamage *= 4;
        }
        this.maxDamage *= 2;
        this.weaponDamage = 4 + j * 2;
    }
    
    @Override
    public float getStrVsBlock(final ItemStack itemstack, final Block block) {
        for (int i = 0; i < ItemSword.swordBreakList.length; ++i) {
            if (ItemSword.swordBreakList[i] == block) {
                return 0.02f * this.maxDamage;
            }
        }
        return 1.5f;
    }
    
    @Override
    public void damageItemHit(final ItemStack itemstack, final EntityLiving entityliving) {
        itemstack.damageItem(1);
    }
    
    @Override
    public void damageItemMine(final ItemStack itemstack, final int i, final int j, final int k, final int l) {
        itemstack.damageItem(2);
    }
    
    @Override
    public int getDamageVsEntity(final Entity entity) {
        return this.weaponDamage;
    }
    
    @Override
    public boolean isFull3D() {
        return true;
    }
}
