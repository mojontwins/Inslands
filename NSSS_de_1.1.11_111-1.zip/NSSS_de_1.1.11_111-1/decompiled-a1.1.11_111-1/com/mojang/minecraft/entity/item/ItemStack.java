package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public final class ItemStack
{
    public int stackSize;
    public int animationsToGo;
    public int itemID;
    public int itemDamage;
    public boolean isGold;
    
    public ItemStack(final Block block) {
        this(block, 1);
    }
    
    public ItemStack(final Block block, final int i) {
        this(block.blockID, i);
    }
    
    public ItemStack(final Item item) {
        this(item, 1);
        if (item.shiftedIndex == 283 || item.shiftedIndex == 284 || item.shiftedIndex == 285 || item.shiftedIndex == 286) {
            this.isGold = true;
        }
    }
    
    public ItemStack(final Item item, final int i) {
        this(item.shiftedIndex, i);
        if (item.shiftedIndex == 283 || item.shiftedIndex == 284 || item.shiftedIndex == 285 || item.shiftedIndex == 286) {
            this.isGold = true;
        }
    }
    
    public ItemStack(final int i) {
        this(i, 1);
        if (i == 283 || i == 284 || i == 285 || i == 286) {
            this.isGold = true;
        }
    }
    
    public ItemStack(final int i, final int j) {
        this.stackSize = 0;
        this.itemID = i;
        this.stackSize = j;
        if (i == 283 || i == 284 || i == 285 || i == 286) {
            this.isGold = true;
        }
    }
    
    public ItemStack(final int i, final int j, final int k) {
        this.stackSize = 0;
        this.itemID = i;
        this.stackSize = j;
        this.itemDamage = k;
        if (i == 283 || i == 284 || i == 285 || i == 286) {
            this.isGold = true;
        }
    }
    
    public ItemStack(final NBTTagCompound nbttagcompound) {
        this.stackSize = 0;
        this.readFromNBT(nbttagcompound);
    }
    
    public ItemStack(final Block block, final int i, final int j) {
        this(block.blockID, i, j);
    }
    
    public ItemStack splitStack(final int i) {
        this.stackSize -= i;
        return new ItemStack(this.itemID, i, this.itemDamage);
    }
    
    public Item getItem() {
        return Item.itemsList[this.itemID];
    }
    
    public boolean getHasSubtypes() {
        return false;
    }
    
    public int getIconIndex() {
        return this.getItem().getIconIndex(this);
    }
    
    public boolean useItem(final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        return this.getItem().onItemUse(this, entityplayer, world, i, j, k, l);
    }
    
    public float getStrVsBlock(final Block block) {
        return this.getItem().getStrVsBlock(this, block);
    }
    
    public ItemStack useItemRightClick(final World world, final EntityPlayer entityplayer) {
        return this.getItem().onItemRightClick(this, world, entityplayer);
    }
    
    public NBTTagCompound writeToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("id", (short)this.itemID);
        nbttagcompound.setByte("Count", (byte)this.stackSize);
        nbttagcompound.setShort("Damage", (short)this.itemDamage);
        return nbttagcompound;
    }
    
    public void readFromNBT(final NBTTagCompound nbttagcompound) {
        this.itemID = nbttagcompound.getShort("id");
        this.stackSize = nbttagcompound.getByte("Count");
        this.itemDamage = nbttagcompound.getShort("Damage");
        if (this.itemID == 283 || this.itemID == 284 || this.itemID == 285 || this.itemID == 286) {
            this.isGold = true;
        }
    }
    
    public int getMaxStackSize() {
        return this.getItem().func_200_b();
    }
    
    public boolean isStackable() {
        return this.getMaxStackSize() > 1 && (!this.isItemStackDamageable() || !this.isItemDamaged());
    }
    
    public boolean isItemStackDamageable() {
        return Item.itemsList[this.itemID].maxDamage > 0;
    }
    
    public boolean isItemDamaged() {
        return this.isItemStackDamageable() && this.itemDamage > 0;
    }
    
    public int getItemDamage() {
        return this.itemDamage;
    }
    
    public void setItemDamage(final int i) {
        this.itemDamage = i;
    }
    
    public int getMaxDmg() {
        return Item.itemsList[this.itemID].getMaxDmg();
    }
    
    public void damageItem(final int i) {
        this.itemDamage += i;
        if (this.itemDamage > this.getMaxDmg()) {
            --this.stackSize;
            if (this.stackSize < 0) {
                this.stackSize = 0;
            }
            this.itemDamage = 0;
        }
    }
    
    public void hitEntity(final EntityLiving entityliving) {
        Item.itemsList[this.itemID].damageItemHit(this, entityliving);
    }
    
    public void onDestroyBlock(final int i, final int j, final int k, final int l) {
        Item.itemsList[this.itemID].damageItemMine(this, i, j, k, l);
    }
    
    public int getDamageVsEntity(final Entity entity) {
        return Item.itemsList[this.itemID].getDamageVsEntity(entity);
    }
    
    public boolean canHarvestBlock(final Block block) {
        return Item.itemsList[this.itemID].breaking(block);
    }
    
    public void func_1097_a(final EntityPlayer entityplayer) {
    }
    
    public void useItemOnEntity(final EntityLiving entityliving) {
        Item.itemsList[this.itemID].saddleEntity(this, entityliving);
    }
    
    public ItemStack copy() {
        return new ItemStack(this.itemID, this.stackSize, this.itemDamage);
    }
    
    public static boolean areItemStacksEqual(final ItemStack itemstack, final ItemStack itemstack1) {
        return (itemstack == null && itemstack1 == null) || (itemstack != null && itemstack1 != null && itemstack.isItemStackEqual(itemstack1));
    }
    
    private boolean isItemStackEqual(final ItemStack itemstack) {
        return this.stackSize == itemstack.stackSize && this.itemID == itemstack.itemID && this.itemDamage == itemstack.itemDamage;
    }
    
    public boolean isItemEqual(final ItemStack itemstack) {
        return this.itemID == itemstack.itemID && this.itemDamage == itemstack.itemDamage;
    }
    
    public String getItemName() {
        return Item.itemsList[this.itemID].toString();
    }
    
    public static ItemStack copyItemStack(final ItemStack itemstack) {
        return (itemstack != null) ? itemstack.copy() : null;
    }
    
    @Override
    public String toString() {
        return Item.itemsList[this.itemID].toString();
    }
    
    public boolean isStackEqual(final ItemStack itemstack) {
        return this.itemID == itemstack.itemID && this.stackSize == itemstack.stackSize && this.itemDamage == itemstack.itemDamage;
    }
    
    public boolean isGold() {
        return this.isGold;
    }
}
