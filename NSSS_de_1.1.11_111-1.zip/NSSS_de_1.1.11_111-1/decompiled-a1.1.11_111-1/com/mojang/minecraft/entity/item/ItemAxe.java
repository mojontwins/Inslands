package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;

public class ItemAxe extends ItemTool
{
    private static Block[] axeBreakList;
    
    static {
        ItemAxe.axeBreakList = new Block[] { Block.planks, Block.bookShelf, Block.wood, Block.crate, Block.workbench, Block.doorWood, Block.fence, Block.stairCompact_Wood, Block.ladder, Block.pressurePlateWood, Block.signPost, Block.jukebox, Block.pressurePlateWoodIdle };
    }
    
    public ItemAxe(final int i, final int j) {
        super(i, 3, j, ItemAxe.axeBreakList);
    }
}
