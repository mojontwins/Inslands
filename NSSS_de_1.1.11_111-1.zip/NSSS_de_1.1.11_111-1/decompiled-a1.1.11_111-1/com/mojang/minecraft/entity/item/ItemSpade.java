package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;

public class ItemSpade extends ItemTool
{
    private static Block[] spadeBreakList;
    
    static {
        ItemSpade.spadeBreakList = new Block[] { Block.grass, Block.dirt, Block.sand, Block.gravel, Block.snow, Block.blockSnow, Block.blockClay };
    }
    
    public ItemSpade(final int i, final int j) {
        super(i, 1, j, ItemSpade.spadeBreakList);
    }
    
    @Override
    public boolean breaking(final Block block) {
        if (block == Block.grass) {
            block.goldTouch();
            System.out.println("SSASDA");
            return this.isGold;
        }
        return block == Block.snow || block == Block.blockSnow;
    }
}
