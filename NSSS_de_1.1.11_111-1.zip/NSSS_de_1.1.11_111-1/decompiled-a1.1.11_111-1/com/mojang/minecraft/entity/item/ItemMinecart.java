package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;

public class ItemMinecart extends Item
{
    public int field_317_a;
    
    public ItemMinecart(final int i, final int j) {
        super(i);
        this.maxStackSize = 1;
        this.field_317_a = j;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockId(i, j, k);
        if (i2 == Block.minecartTrack.blockID) {
            if (!world.multiplayerWorld) {
                world.entityJoinedWorld(new EntityMinecart(world, i + 0.5f, j + 0.5f, k + 0.5f, this.field_317_a));
            }
            --itemstack.stackSize;
            return true;
        }
        return false;
    }
}
