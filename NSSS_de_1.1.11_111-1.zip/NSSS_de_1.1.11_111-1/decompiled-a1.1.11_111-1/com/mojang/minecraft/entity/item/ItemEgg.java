package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class ItemEgg extends Item
{
    public ItemEgg(final int i) {
        super(i);
        this.maxStackSize = 12;
    }
    
    @Override
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        --itemstack.stackSize;
        world.playSoundAtEntity(entityplayer, "random.bow", 0.5f, 0.4f / (ItemEgg.itemRand.nextFloat() * 0.4f + 0.8f));
        if (!world.multiplayerWorld) {
            world.entityJoinedWorld(new EntityEgg(world, entityplayer));
        }
        return itemstack;
    }
}
