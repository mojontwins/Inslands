package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;

public class ItemBoat extends Item
{
    public ItemBoat(final int i) {
        super(i);
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack onItemRightClick(final ItemStack itemstack, final World world, final EntityPlayer entityplayer) {
        final float f = 1.0f;
        final float f2 = entityplayer.prevRotationPitch + (entityplayer.rotationPitch - entityplayer.prevRotationPitch) * f;
        final float f3 = entityplayer.prevRotationYaw + (entityplayer.rotationYaw - entityplayer.prevRotationYaw) * f;
        final double d = entityplayer.prevPosX + (entityplayer.posX - entityplayer.prevPosX) * f;
        final double d2 = entityplayer.prevPosY + (entityplayer.posY - entityplayer.prevPosY) * f;
        final double d3 = entityplayer.prevPosZ + (entityplayer.posZ - entityplayer.prevPosZ) * f;
        final Vec3D vec3d = Vec3D.createVector(d, d2, d3);
        final float f4 = MathHelper.cos(-f3 * 0.01745329f - 3.141593f);
        final float f5 = MathHelper.sin(-f3 * 0.01745329f - 3.141593f);
        final float f6 = -MathHelper.cos(-f2 * 0.01745329f);
        final float f7 = MathHelper.sin(-f2 * 0.01745329f);
        final float f8 = f5 * f6;
        final float f9 = f7;
        final float f10 = f4 * f6;
        final double d4 = 5.0;
        final Vec3D vec3d2 = vec3d.addVector(f8 * d4, f9 * d4, f10 * d4);
        final MovingObjectPosition movingobjectposition = world.rayTraceBlocks_do(vec3d, vec3d2, true);
        if (movingobjectposition == null) {
            return itemstack;
        }
        if (movingobjectposition.typeOfHit == 0) {
            final int i = movingobjectposition.blockX;
            final int j = movingobjectposition.blockY;
            final int k = movingobjectposition.blockZ;
            if (!world.multiplayerWorld) {
                world.entityJoinedWorld(new EntityBoat(world, i + 0.5f, j + 1.5f, k + 0.5f));
            }
            --itemstack.stackSize;
        }
        return itemstack;
    }
}
