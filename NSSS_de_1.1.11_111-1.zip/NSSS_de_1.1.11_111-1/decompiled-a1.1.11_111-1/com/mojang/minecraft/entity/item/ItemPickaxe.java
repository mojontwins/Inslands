package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;

public class ItemPickaxe extends ItemTool
{
    private static Block[] pickaxeBreakList;
    private int miningPower;
    
    static {
        ItemPickaxe.pickaxeBreakList = new Block[] { Block.cobblestone, Block.stairDouble, Block.stairSingle, Block.stone, Block.cobblestoneMossy, Block.oreIron, Block.blockSteel, Block.oreCoal, Block.blockGold, Block.oreGold, Block.glass, Block.gear, Block.oreDiamond, Block.blockDiamond, Block.ice, Block.oreRed, Block.oreRedstoneGlowing, Block.stoneOvenIdle, Block.stoneOvenActive, Block.brick, Block.minecartTrack, Block.stairCompactStone, Block.oreCopper, Block.blockCopper, Block.brickMossy, Block.lightBulbOn, Block.lightBulb };
    }
    
    public ItemPickaxe(final int i, final int miningPower) {
        super(i, 2, miningPower, ItemPickaxe.pickaxeBreakList);
        if (i == 27 || i == 28 || i == 29 || i == 30) {
            this.isGold = true;
        }
        else {
            this.isGold = false;
        }
        this.miningPower = miningPower;
    }
    
    @Override
    public boolean breaking(final Block block) {
        if (block == Block.glass || block == Block.ice || block == Block.lightBulb || block == Block.lightBulbOn || block == Block.brickMossy) {
            return true;
        }
        if (block == Block.oreCopper) {
            return this.miningPower >= 2 && this.miningPower != 5;
        }
        if (block == Block.obsidian || block == Block.bleedingObsidian) {
            return this.miningPower >= 3;
        }
        if (block == Block.blockDiamond || block == Block.oreDiamond) {
            return this.miningPower >= 2 && this.miningPower != 5;
        }
        if (block == Block.blockGold || block == Block.oreGold) {
            return this.miningPower >= 2 && this.miningPower != 5;
        }
        if (block == Block.blockSteel || block == Block.oreIron) {
            return this.miningPower >= 1 && this.miningPower != 5;
        }
        if (block == Block.oreRed || block == Block.oreRedstoneGlowing) {
            return this.miningPower >= 2 && this.miningPower != 5;
        }
        return block.blockMaterial == Material.rock || block.blockMaterial == Material.iron;
    }
}
