package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;

public class ItemDye extends Item
{
    public ItemDye(final int i) {
        super(i);
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockId(i, j, k);
        if (i2 == Block.sapling.blockID) {
            if (!world.multiplayerWorld) {
                ((BlockSapling)Block.sapling).growTree(world, i, j, k, world.rand);
                --itemstack.stackSize;
            }
            return true;
        }
        if (i2 == Block.crops.blockID) {
            if (!world.multiplayerWorld) {
                ((BlockCrops)Block.crops).fertilize(world, i, j, k);
                --itemstack.stackSize;
            }
            return true;
        }
        if (i2 == Block.grass.blockID) {
            if (!world.multiplayerWorld) {
                --itemstack.stackSize;
                int j2 = 0;
            Label_0360_Outer:
                while (j2 < 128) {
                    int k2 = i;
                    int l2 = j + 1;
                    int i3 = k;
                    int j3 = 0;
                    while (true) {
                        while (j3 < j2 / 16) {
                            k2 += ItemDye.itemRand.nextInt(3) - 1;
                            l2 += (ItemDye.itemRand.nextInt(3) - 1) * ItemDye.itemRand.nextInt(3) / 2;
                            i3 += ItemDye.itemRand.nextInt(3) - 1;
                            if (world.getBlockId(k2, l2 - 1, i3) == Block.grass.blockID) {
                                if (!world.isBlockNormalCube(k2, l2, i3)) {
                                    ++j3;
                                    continue Label_0360_Outer;
                                }
                            }
                            ++j2;
                            continue Label_0360_Outer;
                        }
                        if (world.getBlockId(k2, l2, i3) != 0) {
                            continue;
                        }
                        if (ItemDye.itemRand.nextInt(7) > 1) {
                            world.setBlockWithNotify(k2, l2, i3, Block.plantYellow.blockID);
                            continue;
                        }
                        if (ItemDye.itemRand.nextInt(3) == 1) {
                            world.setBlockWithNotify(k2, l2, i3, Block.plantBlue.blockID);
                            continue;
                        }
                        world.setBlockWithNotify(k2, l2, i3, Block.plantRed.blockID);
                        continue;
                    }
                }
            }
            return true;
        }
        return false;
    }
}
