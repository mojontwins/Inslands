package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.entity.*;

public interface IInventory
{
    int getSizeInventory();
    
    ItemStack getStackInSlot(final int p0);
    
    ItemStack decrStackSize(final int p0, final int p1);
    
    void setInventorySlotContents(final int p0, final ItemStack p1);
    
    String getInvName();
    
    int getInventoryStackLimit();
    
    void onInventoryChanged();
    
    boolean canInteractWith(final EntityPlayer p0);
}
