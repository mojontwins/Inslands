package com.mojang.minecraft.entity.item;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.tile.material.*;

public class ItemHoe extends Item
{
    public ItemHoe(final int i, final int j) {
        super(i);
        this.maxStackSize = 1;
        this.maxDamage = 32 << j;
    }
    
    @Override
    public boolean onItemUse(final ItemStack itemstack, final EntityPlayer entityplayer, final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockId(i, j, k);
        final Material material = world.getMaterialXYZ(i, j + 1, k);
        if ((material.isSolidMaterial() || i2 != Block.grass.blockID) && i2 != Block.dirt.blockID) {
            return false;
        }
        final Block block = Block.tilledField;
        world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, block.stepSound.func_1145_d(), (block.stepSound.getVolume() + 1.0f) / 2.0f, block.stepSound.getPitch() * 0.8f);
        if (world.multiplayerWorld) {
            return true;
        }
        world.setBlockWithNotify(i, j, k, block.blockID);
        itemstack.damageItem(1);
        if (world.rand.nextInt(8) == 0 && i2 == Block.grass.blockID) {
            for (int j2 = 1, k2 = 0; k2 < j2; ++k2) {
                final float f = 0.7f;
                final float f2 = world.rand.nextFloat() * f + (1.0f - f) * 0.5f;
                final float f3 = 1.2f;
                final float f4 = world.rand.nextFloat() * f + (1.0f - f) * 0.5f;
                final EntityItem entityitem = new EntityItem(world, i + f2, j + f3, k + f4, new ItemStack(Item.seeds));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
        }
        return true;
    }
    
    @Override
    public boolean isFull3D() {
        return true;
    }
}
