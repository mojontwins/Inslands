package com.mojang.minecraft.entity;

import com.mojang.minecraft.render.*;

public class MovingObjectPosition
{
    public int typeOfHit;
    public int blockX;
    public int blockY;
    public int blockZ;
    public int sideHit;
    public Vec3D hitVec;
    public Entity entityHit;
    
    public MovingObjectPosition(final int i, final int j, final int k, final int l, final Vec3D vec3d) {
        this.typeOfHit = 0;
        this.blockX = i;
        this.blockY = j;
        this.blockZ = k;
        this.sideHit = l;
        this.hitVec = Vec3D.createVector(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
    }
    
    public MovingObjectPosition(final Entity entity) {
        this.typeOfHit = 1;
        this.entityHit = entity;
        this.hitVec = Vec3D.createVector(entity.posX, entity.posY, entity.posZ);
    }
}
