package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;

public class EntityRainFX extends EntityFX
{
    public EntityRainFX(final World world, final double d, final double d1, final double d2) {
        super(world, d, d1, d2, 0.0, 0.0, 0.0);
        this.motionX *= 0.30000001192092896;
        this.motionY = (float)Math.random() * 0.2f + 0.1f;
        this.motionZ *= 0.30000001192092896;
        this.particleRed = 1.0f;
        this.particleGreen = 1.0f;
        this.particleBlue = 1.0f;
        this.particleTextureIndex = 19 + this.rand.nextInt(4);
        this.setSize(0.01f, 0.01f);
        this.field_664_h = 0.06f;
        this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2));
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY -= this.field_664_h;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9800000190734863;
        this.motionY *= 0.9800000190734863;
        this.motionZ *= 0.9800000190734863;
        if (this.particleMaxAge-- <= 0) {
            this.setEntityDead();
        }
        if (this.onGround) {
            if (Math.random() < 0.5) {
                this.setEntityDead();
            }
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
        }
        final Material material = this.worldObj.getMaterialXYZ(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ));
        if (material.getIsGroundCover() || material.isSolidMaterial()) {
            final double d = MathHelper.floor_double(this.posY) + 1 - BlockFluids.getFluidLevel(this.worldObj.getBlockMetadata(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)));
            if (this.posY < d) {
                this.setEntityDead();
            }
        }
    }
}
