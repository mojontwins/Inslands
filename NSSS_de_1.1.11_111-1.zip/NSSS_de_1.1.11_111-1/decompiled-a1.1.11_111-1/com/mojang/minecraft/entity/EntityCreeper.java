package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntityCreeper extends EntityMobs
{
    int timeSinceIgnited;
    int lastActiveTime;
    int field_766_c;
    
    public EntityCreeper(final World world) {
        super(world);
        this.scoreYield = 50;
        this.texture = "/mob/creeper.png";
    }
    
    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, -1);
        this.dataWatcher.addObject(17, 0);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected void attackBlockedEntity(final Entity entity, final float f) {
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        if (this.timeSinceIgnited > 0) {
            this.setCreeperState(-1);
            --this.timeSinceIgnited;
            if (this.timeSinceIgnited < 0) {
                this.timeSinceIgnited = 0;
            }
        }
    }
    
    @Override
    public void onUpdate() {
        this.lastActiveTime = this.timeSinceIgnited;
        if (this.worldObj.multiplayerWorld) {
            final int i = this.getCreeperState();
            if (i > 0 && this.timeSinceIgnited == 0) {
                this.worldObj.playSoundAtEntity(this, "random.fuse", 1.0f, 0.5f);
            }
            this.timeSinceIgnited += i;
            if (this.timeSinceIgnited < 0) {
                this.timeSinceIgnited = 0;
            }
            if (this.timeSinceIgnited >= 30) {
                this.timeSinceIgnited = 30;
            }
        }
        super.onUpdate();
        if (this.entityToAttack == null && this.timeSinceIgnited > 0) {
            this.setCreeperState(-1);
            --this.timeSinceIgnited;
            if (this.timeSinceIgnited < 0) {
                this.timeSinceIgnited = 0;
            }
        }
    }
    
    @Override
    protected String hurtSound() {
        return "mob.creeper";
    }
    
    @Override
    protected String deathSound() {
        return "mob.creeperdeath";
    }
    
    @Override
    public void onDeath(final Entity entity) {
        super.onDeath(entity);
        if (entity instanceof EntitySkeleton) {
            if (this.worldObj.multiplayerWorld) {
                return;
            }
            this.dropItem(Item.record13.shiftedIndex + this.rand.nextInt(13), 1);
        }
    }
    
    @Override
    protected void attackEntity(final Entity entity, final float f) {
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        final int i = this.getCreeperState();
        if ((i <= 0 && f < 3.0f) || (i > 0 && f < 7.0f)) {
            if (this.timeSinceIgnited == 0) {
                this.worldObj.playSoundAtEntity(this, "random.fuse", 1.0f, 0.5f);
            }
            this.setCreeperState(1);
            ++this.timeSinceIgnited;
            if (this.timeSinceIgnited >= 30) {
                this.worldObj.createExplosion(this, this.posX, this.posY, this.posZ, 3.0f);
                this.setEntityDead();
            }
            this.hasAttacked = true;
        }
        else {
            this.setCreeperState(-1);
            --this.timeSinceIgnited;
            if (this.timeSinceIgnited < 0) {
                this.timeSinceIgnited = 0;
            }
        }
    }
    
    public float setCreeperFlashTime(final float f) {
        return (this.lastActiveTime + (this.timeSinceIgnited - this.lastActiveTime) * f) / 28.0f;
    }
    
    @Override
    protected int deathDropItem() {
        return Item.gunpowder.shiftedIndex;
    }
    
    private int getCreeperState() {
        return this.dataWatcher.getWatchableObjectByte(16);
    }
    
    private void setCreeperState(final int i) {
        this.dataWatcher.updateObject(16, (byte)i);
    }
}
