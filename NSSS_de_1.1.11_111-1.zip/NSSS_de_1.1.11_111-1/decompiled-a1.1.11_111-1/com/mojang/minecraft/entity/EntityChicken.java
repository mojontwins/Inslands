package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.nbt.*;

public class EntityChicken extends EntityAnimals
{
    public boolean field_753_a;
    public float field_752_b;
    public float field_758_c;
    public float field_757_d;
    public float field_756_e;
    public float field_755_h;
    public int field_754_i;
    
    public EntityChicken(final World world) {
        super(world);
        this.field_753_a = false;
        this.scoreYield = 10;
        this.field_752_b = 0.0f;
        this.field_758_c = 0.0f;
        this.field_755_h = 1.0f;
        this.texture = "/mob/chicken.png";
        this.setSize(0.3f, 0.4f);
        this.health = 4;
        this.field_754_i = this.rand.nextInt(6000) + 6000;
    }
    
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        this.field_756_e = this.field_752_b;
        this.field_757_d = this.field_758_c;
        this.field_758_c += (float)((this.onGround ? -1 : 4) * 0.3);
        if (this.field_758_c < 0.0f) {
            this.field_758_c = 0.0f;
        }
        if (this.field_758_c > 1.0f) {
            this.field_758_c = 1.0f;
        }
        if (!this.onGround && this.field_755_h < 1.0f) {
            this.field_755_h = 1.0f;
        }
        this.field_755_h *= (float)0.9;
        if (!this.onGround && this.motionY < 0.0) {
            this.motionY *= 0.6;
        }
        this.field_752_b += this.field_755_h * 2.0f;
        if (!this.worldObj.multiplayerWorld && --this.field_754_i <= 0) {
            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0f, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            this.dropItem(Item.egg.shiftedIndex, 1);
            this.field_754_i = this.rand.nextInt(6000) + 6000;
        }
    }
    
    @Override
    protected void fall(final float f) {
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected String idleSound() {
        return "mob.chicken";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.chickenhurt";
    }
    
    @Override
    protected String deathSound() {
        return "mob.chickenhurt";
    }
    
    @Override
    protected int deathDropItem() {
        return Item.feather.shiftedIndex;
    }
}
