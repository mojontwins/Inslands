package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.*;

public class RenderSlime extends RenderLiving
{
    private ModelBase field_205_f;
    
    public RenderSlime(final ModelBase modelbase, final ModelBase modelbase1, final float f) {
        super(modelbase, f);
        this.field_205_f = modelbase1;
    }
    
    protected boolean func_179_a(final EntitySlime entityslime, final int i) {
        if (i == 0) {
            this.func_169_a(this.field_205_f);
            GL11.glEnable(2977);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            return true;
        }
        if (i == 1) {
            GL11.glDisable(3042);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
        return false;
    }
    
    protected void func_178_a(final EntitySlime entityslime, final float f) {
        final float f2 = (entityslime.field_767_b + (entityslime.field_768_a - entityslime.field_767_b) * f) / (entityslime.getSlimeSize() * 0.5f + 1.0f);
        final float f3 = 1.0f / (f2 + 1.0f);
        final float f4 = (float)entityslime.getSlimeSize();
        GL11.glScalef(f3 * f4, 1.0f / f3 * f4, f3 * f4);
    }
    
    @Override
    protected void func_168_a(final EntityLiving entityliving, final float f) {
        this.func_178_a((EntitySlime)entityliving, f);
    }
    
    @Override
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return this.func_179_a((EntitySlime)entityliving, i);
    }
}
