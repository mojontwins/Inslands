package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class RenderMinecart extends Render
{
    protected ModelBase field_195_d;
    
    public RenderMinecart() {
        this.shadowSize = 0.5f;
        this.field_195_d = new ModelMinecart();
    }
    
    public void func_152_a(final EntityMinecart entityminecart, double d, double d1, double d2, float f, final float f1) {
        GL11.glPushMatrix();
        final double d3 = entityminecart.lastTickPosX + (entityminecart.posX - entityminecart.lastTickPosX) * f1;
        final double d4 = entityminecart.lastTickPosY + (entityminecart.posY - entityminecart.lastTickPosY) * f1;
        final double d5 = entityminecart.lastTickPosZ + (entityminecart.posZ - entityminecart.lastTickPosZ) * f1;
        final double d6 = 0.30000001192092896;
        final Vec3D vec3d = entityminecart.func_514_g(d3, d4, d5);
        float f2 = entityminecart.prevRotationPitch + (entityminecart.rotationPitch - entityminecart.prevRotationPitch) * f1;
        if (vec3d != null) {
            Vec3D vec3d2 = entityminecart.func_515_a(d3, d4, d5, d6);
            Vec3D vec3d3 = entityminecart.func_515_a(d3, d4, d5, -d6);
            if (vec3d2 == null) {
                vec3d2 = vec3d;
            }
            if (vec3d3 == null) {
                vec3d3 = vec3d;
            }
            d += vec3d.xCoord - d3;
            d1 += (vec3d2.yCoord + vec3d3.yCoord) / 2.0 - d4;
            d2 += vec3d.zCoord - d5;
            Vec3D vec3d4 = vec3d3.addVector(-vec3d2.xCoord, -vec3d2.yCoord, -vec3d2.zCoord);
            if (vec3d4.lengthVector() != 0.0) {
                vec3d4 = vec3d4.normalize();
                f = (float)(Math.atan2(vec3d4.zCoord, vec3d4.xCoord) * 180.0 / 3.141592653589793);
                f2 = (float)(Math.atan(vec3d4.yCoord) * 73.0);
            }
        }
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        GL11.glRotatef(180.0f - f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-f2, 0.0f, 0.0f, 1.0f);
        final float f3 = entityminecart.minecartTimeSinceHit - f1;
        float f4 = entityminecart.minecartCurrentDamage - f1;
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        if (f3 > 0.0f) {
            GL11.glRotatef(MathHelper.sin(f3) * f3 * f4 / 10.0f * entityminecart.minecartRockDirection, 1.0f, 0.0f, 0.0f);
        }
        if (entityminecart.minecartType != 0) {
            this.loadTexture("/terrain.png");
            final float f5 = 0.75f;
            GL11.glScalef(f5, f5, f5);
            GL11.glTranslatef(0.0f, 0.3125f, 0.0f);
            GL11.glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
            if (entityminecart.minecartType == 1) {
                new RenderBlocks().renderThrownItems(Block.crate);
            }
            else if (entityminecart.minecartType == 2) {
                new RenderBlocks().renderThrownItems(Block.stoneOvenIdle);
            }
            GL11.glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
            GL11.glTranslatef(0.0f, -0.3125f, 0.0f);
            GL11.glScalef(1.0f / f5, 1.0f / f5, 1.0f / f5);
        }
        this.loadTexture("/item/cart.png");
        GL11.glScalef(-1.0f, -1.0f, 1.0f);
        this.field_195_d.setRotationAnglesAndRender(0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_152_a((EntityMinecart)entity, d, d1, d2, f, f1);
    }
}
