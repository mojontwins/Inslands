package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.render.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;

public class RenderTNTPrimed extends Render
{
    private RenderBlocks field_196_d;
    
    public RenderTNTPrimed() {
        this.field_196_d = new RenderBlocks();
        this.shadowSize = 0.5f;
    }
    
    public void func_153_a(final EntityTNTPrimed entitytntprimed, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        if (entitytntprimed.field_689_a - f1 + 1.0f < 10.0f) {
            float f2 = 1.0f - (entitytntprimed.field_689_a - f1 + 1.0f) / 10.0f;
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            f2 *= f2;
            f2 *= f2;
            final float f3 = 1.0f + f2 * 0.3f;
            GL11.glScalef(f3, f3, f3);
        }
        final float f4 = (1.0f - (entitytntprimed.field_689_a - f1 + 1.0f) / 100.0f) * 0.8f;
        this.loadTexture("/terrain.png");
        this.field_196_d.renderThrownItems(Block.tnt);
        if (entitytntprimed.field_689_a / 5 % 2 == 0) {
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 772);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, f4);
            this.field_196_d.renderThrownItems(Block.tnt);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glDisable(3042);
            GL11.glEnable(2896);
            GL11.glEnable(3553);
        }
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_153_a((EntityTNTPrimed)entity, d, d1, d2, f, f1);
    }
}
