package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.entity.*;

public class RenderSheep extends RenderLiving
{
    public RenderSheep(final ModelBase modelbase, final ModelBase modelbase1, final float f) {
        super(modelbase, f);
        this.func_169_a(modelbase1);
    }
    
    protected boolean func_176_a(final EntitySheep entitysheep, final int i) {
        this.loadTexture("/mob/sheep_fur.png");
        return i == 0 && !entitysheep.getSheared();
    }
    
    @Override
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return this.func_176_a((EntitySheep)entityliving, i);
    }
}
