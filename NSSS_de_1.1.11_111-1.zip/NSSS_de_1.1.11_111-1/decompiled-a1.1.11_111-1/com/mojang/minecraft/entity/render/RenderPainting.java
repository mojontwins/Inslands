package com.mojang.minecraft.entity.render;

import java.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;

public class RenderPainting extends Render
{
    private Random field_199_d;
    
    public RenderPainting() {
        this.field_199_d = new Random();
    }
    
    public void func_158_a(final EntityPainting entitypainting, final double d, final double d1, final double d2, final float f, final float f1) {
        this.field_199_d.setSeed(187L);
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        GL11.glRotatef(f, 0.0f, 1.0f, 0.0f);
        GL11.glEnable(32826);
        this.loadTexture("/art/kz.png");
        final EnumArt enumart = entitypainting.art;
        final float f2 = 0.0625f;
        GL11.glScalef(f2, f2, f2);
        if (enumart != null) {
            this.func_159_a(entitypainting, enumart.sizeX, enumart.sizeY, enumart.offsetX, enumart.offsetY);
        }
        GL11.glDisable(32826);
        GL11.glPopMatrix();
    }
    
    private void func_159_a(final EntityPainting entitypainting, final int i, final int j, final int k, final int l) {
        final float f = -i / 2.0f;
        final float f2 = -j / 2.0f;
        final float f3 = -0.5f;
        final float f4 = 0.5f;
        for (int i2 = 0; i2 < i / 16; ++i2) {
            for (int j2 = 0; j2 < j / 16; ++j2) {
                final float f5 = f + (i2 + 1) * 16;
                final float f6 = f + i2 * 16;
                final float f7 = f2 + (j2 + 1) * 16;
                final float f8 = f2 + j2 * 16;
                this.func_160_a(entitypainting, (f5 + f6) / 2.0f, (f7 + f8) / 2.0f);
                final float f9 = (k + i - i2 * 16) / 256.0f;
                final float f10 = (k + i - (i2 + 1) * 16) / 256.0f;
                final float f11 = (l + j - j2 * 16) / 256.0f;
                final float f12 = (l + j - (j2 + 1) * 16) / 256.0f;
                final float f13 = 0.75f;
                final float f14 = 0.8125f;
                final float f15 = 0.0f;
                final float f16 = 0.0625f;
                final float f17 = 0.75f;
                final float f18 = 0.8125f;
                final float f19 = 0.001953125f;
                final float f20 = 0.001953125f;
                final float f21 = 0.7519531f;
                final float f22 = 0.7519531f;
                final float f23 = 0.0f;
                final float f24 = 0.0625f;
                final Tessellator tessellator = Tessellator.instance;
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0f, 0.0f, -1.0f);
                tessellator.addVertexWithUV(f5, f8, f3, f10, f11);
                tessellator.addVertexWithUV(f6, f8, f3, f9, f11);
                tessellator.addVertexWithUV(f6, f7, f3, f9, f12);
                tessellator.addVertexWithUV(f5, f7, f3, f10, f12);
                tessellator.setNormal(0.0f, 0.0f, 1.0f);
                tessellator.addVertexWithUV(f5, f7, f4, f13, f15);
                tessellator.addVertexWithUV(f6, f7, f4, f14, f15);
                tessellator.addVertexWithUV(f6, f8, f4, f14, f16);
                tessellator.addVertexWithUV(f5, f8, f4, f13, f16);
                tessellator.setNormal(0.0f, -1.0f, 0.0f);
                tessellator.addVertexWithUV(f5, f7, f3, f17, f19);
                tessellator.addVertexWithUV(f6, f7, f3, f18, f19);
                tessellator.addVertexWithUV(f6, f7, f4, f18, f20);
                tessellator.addVertexWithUV(f5, f7, f4, f17, f20);
                tessellator.setNormal(0.0f, 1.0f, 0.0f);
                tessellator.addVertexWithUV(f5, f8, f4, f17, f19);
                tessellator.addVertexWithUV(f6, f8, f4, f18, f19);
                tessellator.addVertexWithUV(f6, f8, f3, f18, f20);
                tessellator.addVertexWithUV(f5, f8, f3, f17, f20);
                tessellator.setNormal(-1.0f, 0.0f, 0.0f);
                tessellator.addVertexWithUV(f5, f7, f4, f22, f23);
                tessellator.addVertexWithUV(f5, f8, f4, f22, f24);
                tessellator.addVertexWithUV(f5, f8, f3, f21, f24);
                tessellator.addVertexWithUV(f5, f7, f3, f21, f23);
                tessellator.setNormal(1.0f, 0.0f, 0.0f);
                tessellator.addVertexWithUV(f6, f7, f3, f22, f23);
                tessellator.addVertexWithUV(f6, f8, f3, f22, f24);
                tessellator.addVertexWithUV(f6, f8, f4, f21, f24);
                tessellator.addVertexWithUV(f6, f7, f4, f21, f23);
                tessellator.draw();
            }
        }
    }
    
    private void func_160_a(final EntityPainting entitypainting, final float f, final float f1) {
        int i = MathHelper.floor_double(entitypainting.posX);
        final int j = MathHelper.floor_double(entitypainting.posY + f1 / 16.0f);
        int k = MathHelper.floor_double(entitypainting.posZ);
        if (entitypainting.direction == 0) {
            i = MathHelper.floor_double(entitypainting.posX + f / 16.0f);
        }
        if (entitypainting.direction == 1) {
            k = MathHelper.floor_double(entitypainting.posZ - f / 16.0f);
        }
        if (entitypainting.direction == 2) {
            i = MathHelper.floor_double(entitypainting.posX - f / 16.0f);
        }
        if (entitypainting.direction == 3) {
            k = MathHelper.floor_double(entitypainting.posZ + f / 16.0f);
        }
        final float f2 = this.renderManager.worldObj.getBrightness(i, j, k);
        GL11.glColor3f(f2, f2, f2);
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_158_a((EntityPainting)entity, d, d1, d2, f, f1);
    }
}
