package com.mojang.minecraft.entity.render;

import java.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class RenderItem extends Render
{
    private RenderBlocks renderBlocks;
    private Random field_200_e;
    public boolean field_27004_a;
    
    public RenderItem() {
        this.renderBlocks = new RenderBlocks();
        this.field_200_e = new Random();
        this.shadowSize = 0.15f;
        this.field_194_c = 0.75f;
    }
    
    public void initialize(final EntityItem entityitem, final double d, final double d1, final double d2, final float f, final float f1) {
        this.field_200_e.setSeed(187L);
        final ItemStack itemstack = entityitem.item;
        GL11.glPushMatrix();
        final float f2 = MathHelper.sin((entityitem.age + f1) / 10.0f + entityitem.field_804_d) * 0.1f + 0.1f;
        final float f3 = ((entityitem.age + f1) / 20.0f + entityitem.field_804_d) * 57.29578f;
        byte byte0 = 1;
        if (entityitem.item.stackSize > 1) {
            byte0 = 2;
        }
        if (entityitem.item.stackSize > 5) {
            byte0 = 3;
        }
        if (entityitem.item.stackSize > 20) {
            byte0 = 4;
        }
        GL11.glTranslatef((float)d, (float)d1 + f2, (float)d2);
        GL11.glEnable(32826);
        if (itemstack.itemID == 0) {
            System.out.println("Got a bad item ID!");
            itemstack.itemID = new Random().nextInt(64);
        }
        if (itemstack.itemID < 256 && RenderBlocks.getRenderItemType(Block.allBlocks[itemstack.itemID].getRenderType())) {
            GL11.glRotatef(f3, 0.0f, 1.0f, 0.0f);
            this.loadTexture("/terrain.png");
            float f4 = 0.25f;
            if (!Block.allBlocks[itemstack.itemID].renderAsNormalBlock() && itemstack.itemID != Block.stairSingle.blockID) {
                f4 = 0.5f;
            }
            GL11.glScalef(f4, f4, f4);
            for (int j = 0; j < byte0; ++j) {
                GL11.glPushMatrix();
                if (j > 0) {
                    final float f5 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.2f / f4;
                    final float f6 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.2f / f4;
                    final float f7 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.2f / f4;
                    GL11.glTranslatef(f5, f6, f7);
                }
                this.renderBlocks.renderThrownItems(Block.allBlocks[itemstack.itemID]);
                GL11.glPopMatrix();
            }
        }
        else {
            GL11.glScalef(0.5f, 0.5f, 0.5f);
            final int i = itemstack.getIconIndex();
            if (itemstack.itemID < 256) {
                this.loadTexture("/terrain.png");
            }
            else {
                this.loadTexture("/gui/items.png");
            }
            final Tessellator tessellator = Tessellator.instance;
            final float f8 = (i % 16 * 16 + 0) / 256.0f;
            final float f9 = (i % 16 * 16 + 16) / 256.0f;
            final float f10 = (i / 16 * 16 + 0) / 256.0f;
            final float f11 = (i / 16 * 16 + 16) / 256.0f;
            final float f12 = 1.0f;
            final float f13 = 0.5f;
            final float f14 = 0.25f;
            for (int k = 0; k < byte0; ++k) {
                GL11.glPushMatrix();
                if (k > 0) {
                    final float f15 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.3f;
                    final float f16 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.3f;
                    final float f17 = (this.field_200_e.nextFloat() * 2.0f - 1.0f) * 0.3f;
                    GL11.glTranslatef(f15, f16, f17);
                }
                GL11.glRotatef(180.0f - this.renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
                tessellator.startDrawingQuads();
                tessellator.setNormal(0.0f, 1.0f, 0.0f);
                tessellator.addVertexWithUV(0.0f - f13, 0.0f - f14, 0.0, f8, f11);
                tessellator.addVertexWithUV(f12 - f13, 0.0f - f14, 0.0, f9, f11);
                tessellator.addVertexWithUV(f12 - f13, 1.0f - f14, 0.0, f9, f10);
                tessellator.addVertexWithUV(0.0f - f13, 1.0f - f14, 0.0, f8, f10);
                tessellator.draw();
                GL11.glPopMatrix();
            }
        }
        GL11.glDisable(32826);
        GL11.glPopMatrix();
    }
    
    public void renderItemBlock(final FontRenderer fontrenderer, final RenderEngine renderengine, final ItemStack itemstack, final int i, final int j) {
        if (itemstack == null) {
            return;
        }
        if (itemstack.itemID == 0) {
            System.out.println("Got a bad item ID!");
            itemstack.itemID = new Random().nextInt(64);
        }
        if (itemstack.itemID < 256 && RenderBlocks.getRenderItemType(Block.allBlocks[itemstack.itemID].getRenderType())) {
            final int k = itemstack.itemID;
            renderengine.bindTex(renderengine.getTex("/terrain.png"));
            final Block block = Block.allBlocks[k];
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(i - 2), (float)(j + 3), 0.0f);
            GL11.glScalef(10.0f, 10.0f, 10.0f);
            GL11.glTranslatef(1.0f, 0.5f, 8.0f);
            GL11.glRotatef(210.0f, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glScalef(1.0f, 1.0f, 1.0f);
            this.renderBlocks.renderThrownItems(block);
            GL11.glPopMatrix();
        }
        else if (itemstack.getIconIndex() >= 0) {
            GL11.glDisable(2896);
            if (itemstack.itemID < 256) {
                renderengine.bindTex(renderengine.getTex("/terrain.png"));
            }
            else {
                renderengine.bindTex(renderengine.getTex("/gui/items.png"));
            }
            this.renderTexturedQuad(i, j, itemstack.getIconIndex() % 16 * 16, itemstack.getIconIndex() / 16 * 16, 16, 16);
            GL11.glEnable(2896);
        }
        GL11.glEnable(2884);
    }
    
    public void drawItemIntoGui(final FontRenderer fontrenderer, final RenderEngine renderengine, final int i, final int j, final int k, final int l, final int i1) {
        if (i < 256 && RenderBlocks.getRenderItemType(Block.allBlocks[i].getRenderType())) {
            final int j2 = i;
            renderengine.bindTex(renderengine.getTex("/terrain.png"));
            final Block block = Block.allBlocks[j2];
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(l - 2), (float)(i1 + 3), -3.0f);
            GL11.glScalef(10.0f, 10.0f, 10.0f);
            GL11.glTranslatef(1.0f, 0.5f, 1.0f);
            GL11.glScalef(1.0f, 1.0f, -1.0f);
            GL11.glRotatef(210.0f, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            final int l2 = 16777215;
            final float f2 = (l2 >> 16 & 0xFF) / 255.0f;
            final float f3 = (l2 >> 8 & 0xFF) / 255.0f;
            final float f4 = (l2 & 0xFF) / 255.0f;
            if (this.field_27004_a) {
                GL11.glColor4f(f2, f3, f4, 1.0f);
            }
            GL11.glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
            this.renderBlocks.renderThrownItems(block);
            GL11.glPopMatrix();
        }
        else if (k >= 0) {
            GL11.glDisable(2896);
            if (i < 256) {
                renderengine.bindTex(renderengine.getTex("/terrain.png"));
            }
            else {
                renderengine.bindTex(renderengine.getTex("/gui/items.png"));
            }
            final int k2 = 16777215;
            final float f5 = (k2 >> 16 & 0xFF) / 255.0f;
            final float f6 = (k2 >> 8 & 0xFF) / 255.0f;
            final float f7 = (k2 & 0xFF) / 255.0f;
            if (this.field_27004_a) {
                GL11.glColor4f(f5, f6, f7, 1.0f);
            }
            this.renderTexturedQuad(l, i1, k % 16 * 16, k / 16 * 16, 16, 16);
            GL11.glEnable(2896);
        }
        GL11.glEnable(2884);
    }
    
    public void renderItemIntoGUI(final FontRenderer fontrenderer, final RenderEngine renderengine, final ItemStack itemstack, final int i, final int j) {
        if (itemstack == null) {
            return;
        }
        this.drawItemIntoGui(fontrenderer, renderengine, itemstack.itemID, itemstack.getItemDamage(), itemstack.getIconIndex(), i, j);
    }
    
    public void renderTextDmg(final FontRenderer fontrenderer, final RenderEngine renderengine, final ItemStack itemstack, final int i, final int j) {
        if (itemstack == null) {
            return;
        }
        if (itemstack.stackSize > 1) {
            final String s = "" + itemstack.stackSize;
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            fontrenderer.drawStringWithShadow(s, i + 19 - 2 - fontrenderer.getStringWidth(s), j + 6 + 3, 16777215);
            GL11.glEnable(2896);
            GL11.glEnable(2929);
        }
        if (itemstack.itemDamage > 0) {
            final int k = 13 - itemstack.itemDamage * 13 / itemstack.getMaxDmg();
            final int l = 255 - itemstack.itemDamage * 255 / itemstack.getMaxDmg();
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glDisable(3553);
            final Tessellator tessellator = Tessellator.instance;
            final int i2 = 255 - l << 16 | l << 8;
            final int j2 = (255 - l) / 4 << 16 | 0x3F00;
            this.func_162_a(tessellator, i + 2, j + 13, 13, 2, 0);
            this.func_162_a(tessellator, i + 2, j + 13, 12, 1, j2);
            this.func_162_a(tessellator, i + 2, j + 13, k, 1, i2);
            GL11.glEnable(3553);
            GL11.glEnable(2896);
            GL11.glEnable(2929);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
    
    private void func_162_a(final Tessellator tessellator, final int i, final int j, final int k, final int l, final int i1) {
        tessellator.startDrawingQuads();
        tessellator.setColorOpaque_I(i1);
        tessellator.addVertex(i + 0, j + 0, 0.0);
        tessellator.addVertex(i + 0, j + l, 0.0);
        tessellator.addVertex(i + k, j + l, 0.0);
        tessellator.addVertex(i + k, j + 0, 0.0);
        tessellator.draw();
    }
    
    public void renderTexturedQuad(final int i, final int j, final int k, final int l, final int i1, final int j1) {
        final float f = 0.0f;
        final float f2 = 0.00390625f;
        final float f3 = 0.00390625f;
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(i + 0, j + j1, f, (k + 0) * f2, (l + j1) * f3);
        tessellator.addVertexWithUV(i + i1, j + j1, f, (k + i1) * f2, (l + j1) * f3);
        tessellator.addVertexWithUV(i + i1, j + 0, f, (k + i1) * f2, (l + 0) * f3);
        tessellator.addVertexWithUV(i + 0, j + 0, f, (k + 0) * f2, (l + 0) * f3);
        tessellator.draw();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.initialize((EntityItem)entity, d, d1, d2, f, f1);
    }
}
