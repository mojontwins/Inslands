package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;

public class RenderBoat extends Render
{
    protected ModelBase field_198_d;
    
    public RenderBoat() {
        this.shadowSize = 0.5f;
        this.field_198_d = new ModelBoat();
    }
    
    public void func_157_a(final EntityBoat entityboat, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        GL11.glRotatef(180.0f - f, 0.0f, 1.0f, 0.0f);
        final float f2 = entityboat.boatTimeSinceHit - f1;
        float f3 = entityboat.boatCurrentDamage - f1;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f2 > 0.0f) {
            GL11.glRotatef(MathHelper.sin(f2) * f2 * f3 / 10.0f * entityboat.boatRockDirection, 1.0f, 0.0f, 0.0f);
        }
        this.loadTexture("/terrain.png");
        final float f4 = 0.75f;
        GL11.glScalef(f4, f4, f4);
        GL11.glScalef(1.0f / f4, 1.0f / f4, 1.0f / f4);
        this.loadTexture("/item/boat.png");
        GL11.glScalef(-1.0f, -1.0f, 1.0f);
        this.field_198_d.setRotationAnglesAndRender(0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_157_a((EntityBoat)entity, d, d1, d2, f, f1);
    }
}
