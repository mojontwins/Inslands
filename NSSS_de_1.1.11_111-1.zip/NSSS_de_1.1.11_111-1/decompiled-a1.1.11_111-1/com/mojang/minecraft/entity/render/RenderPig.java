package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.entity.*;

public class RenderPig extends RenderLiving
{
    public RenderPig(final ModelBase modelbase, final ModelBase modelbase1, final float f) {
        super(modelbase, f);
        this.func_169_a(modelbase1);
    }
    
    protected boolean func_180_a(final EntityPig entitypig, final int i) {
        this.loadTexture("/mob/saddle.png");
        return i == 0 && entitypig.getSaddled();
    }
    
    @Override
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return this.func_180_a((EntityPig)entityliving, i);
    }
}
