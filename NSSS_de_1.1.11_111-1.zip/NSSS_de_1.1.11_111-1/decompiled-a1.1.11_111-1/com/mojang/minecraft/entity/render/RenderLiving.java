package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.gui.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.render.*;

public class RenderLiving extends Render
{
    protected ModelBase mainModel;
    protected ModelBase field_202_e;
    public static boolean bobbing;
    
    static {
        RenderLiving.bobbing = true;
    }
    
    public RenderLiving(final ModelBase modelbase, final float f) {
        this.mainModel = modelbase;
        this.shadowSize = f;
    }
    
    public void func_169_a(final ModelBase modelbase) {
        this.field_202_e = modelbase;
    }
    
    private float setBobbing(final EntityLiving par1EntityLivingBase, final float f5, final float par9) {
        if (par1EntityLivingBase.ridingEntity != null && par1EntityLivingBase.ridingEntity instanceof EntityLiving) {
            return this.setBobbing((EntityLiving)par1EntityLivingBase.ridingEntity, f5, par9);
        }
        float bobStrength = 0.0f;
        if (RenderLiving.bobbing && par1EntityLivingBase instanceof EntityPlayer) {
            bobStrength = 1.0f;
            final float f6 = par1EntityLivingBase.unknownFloat + (par1EntityLivingBase.field_731_r - par1EntityLivingBase.unknownFloat) * par9;
            final float f7 = par1EntityLivingBase.field_733_p + (par1EntityLivingBase.field_732_q - par1EntityLivingBase.field_733_p) * par9;
            final float bob = -Math.abs(MathHelper.cos(f6 * 0.6662f)) * 5.0f * f7 * bobStrength - 23.0f;
            GL11.glTranslatef(0.0f, bob * f5 + 1.4f, 0.0f);
            return f6;
        }
        GL11.glTranslatef(0.0f, -24.0f * f5 + 1.4f, 0.0f);
        final float f6 = par1EntityLivingBase.limbSwing - par1EntityLivingBase.limbSwingAmount * (1.0f - par9);
        return f6;
    }
    
    public void func_171_a(final EntityLiving entityliving, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        GL11.glDisable(2884);
        this.mainModel.onGround = this.func_167_c(entityliving, f1);
        this.mainModel.field_1243_l = (entityliving.entityBeingRidden != null);
        if (this.field_202_e != null) {
            this.field_202_e.field_1243_l = this.mainModel.field_1243_l;
        }
        try {
            final float f2 = entityliving.prevRenderYawOffset + (entityliving.renderYawOffset - entityliving.prevRenderYawOffset) * f1;
            final float f3 = entityliving.prevRotationYaw + (entityliving.rotationYaw - entityliving.prevRotationYaw) * f1;
            final float f4 = entityliving.prevRotationPitch + (entityliving.rotationPitch - entityliving.prevRotationPitch) * f1;
            GL11.glTranslatef((float)d, (float)d1, (float)d2);
            final float f5 = this.func_170_d(entityliving, f1);
            GL11.glRotatef(180.0f - f2, 0.0f, 1.0f, 0.0f);
            if (entityliving.deathTime > 0) {
                float f6 = (entityliving.deathTime + f1 - 1.0f) / 20.0f * 1.6f;
                f6 = MathHelper.sqrt_float(f6);
                if (f6 > 1.0f) {
                    f6 = 1.0f;
                }
                GL11.glRotatef(f6 * this.func_172_a(entityliving), 0.0f, 0.0f, 1.0f);
            }
            final float f7 = 0.0625f;
            GL11.glEnable(32826);
            GL11.glScalef(-1.0f, -1.0f, 1.0f);
            this.func_168_a(entityliving, f1);
            GL11.glTranslatef(0.0f, -24.0f * f7 - 0.0078125f, 0.0f);
            float f8 = entityliving.field_705_Q + (entityliving.limbSwingAmount - entityliving.field_705_Q) * f1;
            final float f9 = this.setBobbing(entityliving, f7, f1);
            if (f8 > 1.0f) {
                f8 = 1.0f;
            }
            this.func_140_a(entityliving.skinURL, entityliving.getEntityTexture());
            GL11.glEnable(3008);
            this.mainModel.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
            for (int i = 0; i < 4; ++i) {
                if (this.func_166_a(entityliving, i)) {
                    this.field_202_e.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
                    GL11.glDisable(3042);
                    GL11.glEnable(3008);
                }
            }
            this.func_174_b(entityliving, f1);
            final float f10 = entityliving.getEntityBrightness(f1);
            final int j = this.func_173_a(entityliving, f10, f1);
            if ((j >> 24 & 0xFF) > 0 || entityliving.hurtTime > 0 || entityliving.deathTime > 0) {
                GL11.glDisable(3553);
                GL11.glDisable(3008);
                GL11.glEnable(3042);
                GL11.glBlendFunc(770, 771);
                GL11.glDepthFunc(514);
                if (entityliving.hurtTime > 0 || entityliving.deathTime > 0) {
                    GL11.glColor4f(f10, 0.0f, 0.0f, 0.4f);
                    this.mainModel.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
                    for (int k = 0; k < 4; ++k) {
                        if (this.func_166_a(entityliving, k)) {
                            GL11.glColor4f(f10, 0.0f, 0.0f, 0.4f);
                            this.field_202_e.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
                        }
                    }
                }
                if ((j >> 24 & 0xFF) > 0) {
                    final float f11 = (j >> 16 & 0xFF) / 255.0f;
                    final float f12 = (j >> 8 & 0xFF) / 255.0f;
                    final float f13 = (j & 0xFF) / 255.0f;
                    final float f14 = (j >> 24 & 0xFF) / 255.0f;
                    GL11.glColor4f(f11, f12, f13, f14);
                    this.mainModel.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
                    for (int l = 0; l < 4; ++l) {
                        if (this.func_166_a(entityliving, l)) {
                            GL11.glColor4f(f11, f12, f13, f14);
                            this.field_202_e.setRotationAnglesAndRender(f9, f8, f5, f3 - f2, f4, f7);
                        }
                    }
                }
                GL11.glDepthFunc(515);
                GL11.glDisable(3042);
                GL11.glEnable(3008);
                GL11.glEnable(3553);
            }
            GL11.glDisable(32826);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        GL11.glEnable(2884);
        GL11.glPopMatrix();
        this.passSpecialRender(entityliving, d, d1, d2);
    }
    
    protected float func_167_c(final EntityLiving entityliving, final float f) {
        return entityliving.getSwingProgress(f);
    }
    
    protected float func_170_d(final EntityLiving entityliving, final float f) {
        return entityliving.ticksExisted + f;
    }
    
    protected void func_174_b(final EntityLiving entityliving, final float f) {
    }
    
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return false;
    }
    
    protected float func_172_a(final EntityLiving entityliving) {
        return 90.0f;
    }
    
    protected int func_173_a(final EntityLiving entityliving, final float f, final float f1) {
        return 0;
    }
    
    protected void func_168_a(final EntityLiving entityliving, final float f) {
    }
    
    protected void passSpecialRender(final EntityLiving entityliving, final double d, final double d1, final double d2) {
        if (GuiIngame.debugOpen) {
            this.renderLivingLabel(entityliving, Integer.toString(entityliving.entityId), d, d1, d2, 64);
        }
    }
    
    protected void renderLivingLabel(final EntityLiving entityliving, final String s, final double d, final double d1, final double d2, final int i) {
        final float f = entityliving.getDistanceToEntity(this.renderManager.livingPlayer);
        if (f > i) {
            return;
        }
        final FontRenderer fontrenderer = this.getFontRendererFromRenderManager();
        final float f2 = 1.6f;
        float f3 = 0.01666667f * f2;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d + 0.0f, (float)d1 + 2.3f, (float)d2);
        GL11.glNormal3f(0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-this.renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(this.renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
        final float f4 = entityliving.getDistanceToEntity(this.renderManager.livingPlayer);
        f3 *= (float)(Math.sqrt(f4) / 2.0);
        GL11.glScalef(-f3, -f3, f3);
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        final Tessellator tessellator = Tessellator.instance;
        byte byte0 = 0;
        if (s.equals("deadmau5")) {
            byte0 = -10;
        }
        GL11.glDisable(3553);
        tessellator.startDrawingQuads();
        final int j = fontrenderer.getStringWidth(s) / 2;
        tessellator.setColorRGBA_F(0.0f, 0.0f, 0.0f, 0.25f);
        tessellator.addVertex(-j - 1, -1 + byte0, 0.0);
        tessellator.addVertex(-j - 1, 8 + byte0, 0.0);
        tessellator.addVertex(j + 1, 8 + byte0, 0.0);
        tessellator.addVertex(j + 1, -1 + byte0, 0.0);
        tessellator.draw();
        GL11.glEnable(3553);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, byte0, 553648127);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, byte0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_171_a((EntityLiving)entity, d, d1, d2, f, f1);
    }
}
