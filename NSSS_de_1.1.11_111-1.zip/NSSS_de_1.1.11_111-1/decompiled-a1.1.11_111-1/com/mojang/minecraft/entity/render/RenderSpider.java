package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.*;

public class RenderSpider extends RenderLiving
{
    public RenderSpider() {
        super(new ModelSpider(), 1.0f);
        this.func_169_a(new ModelSpider());
    }
    
    protected float func_191_a(final EntitySpider entityspider) {
        return 180.0f;
    }
    
    protected boolean func_190_a(final EntitySpider entityspider, final int i) {
        if (i != 0) {
            return false;
        }
        if (i != 0) {
            return false;
        }
        this.loadTexture("/mob/spider_eyes.png");
        final float f = (1.0f - entityspider.getEntityBrightness(1.0f)) * 0.5f;
        GL11.glEnable(3042);
        GL11.glDisable(3008);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, f);
        return true;
    }
    
    @Override
    protected float func_172_a(final EntityLiving entityliving) {
        return this.func_191_a((EntitySpider)entityliving);
    }
    
    @Override
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return this.func_190_a((EntitySpider)entityliving, i);
    }
}
