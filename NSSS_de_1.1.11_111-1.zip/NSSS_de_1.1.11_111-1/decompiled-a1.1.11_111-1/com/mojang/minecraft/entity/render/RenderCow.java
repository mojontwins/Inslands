package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.entity.*;

public class RenderCow extends RenderLiving
{
    public RenderCow(final ModelBase modelbase, final float f) {
        super(modelbase, f);
    }
    
    public void func_177_a(final EntityCow entitycow, final double d, final double d1, final double d2, final float f, final float f1) {
        super.func_171_a(entitycow, d, d1, d2, f, f1);
    }
    
    @Override
    public void func_171_a(final EntityLiving entityliving, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_177_a((EntityCow)entityliving, d, d1, d2, f, f1);
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_177_a((EntityCow)entity, d, d1, d2, f, f1);
    }
}
