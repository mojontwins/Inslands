package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.render.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class RenderFallingSand extends Render
{
    private RenderBlocks field_197_d;
    
    public RenderFallingSand() {
        this.field_197_d = new RenderBlocks();
        this.shadowSize = 0.5f;
    }
    
    public void func_156_a(final EntityFallingSand entityfallingsand, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        this.loadTexture("/terrain.png");
        final Block block = Block.allBlocks[entityfallingsand.field_799_a];
        final World world = entityfallingsand.func_465_i();
        GL11.glDisable(2896);
        this.field_197_d.func_1243_a(block, world, MathHelper.floor_double(entityfallingsand.posX), MathHelper.floor_double(entityfallingsand.posY), MathHelper.floor_double(entityfallingsand.posZ));
        GL11.glEnable(2896);
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_156_a((EntityFallingSand)entity, d, d1, d2, f, f1);
    }
}
