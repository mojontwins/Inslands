package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.entity.item.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.*;
import java.util.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;

public class RenderPlayer extends RenderLiving
{
    private ModelPlayer modelBipedMain;
    private ModelBiped modelArmorChestplate;
    private ModelBiped modelArmor;
    private ModelPlayerRene modelRene;
    private ModelPlayer modelSteve;
    private static final String[] armorFilenamePrefix;
    
    static {
        armorFilenamePrefix = new String[] { "cloth", "chain", "iron", "diamond", "gold", "sponge", "quiver" };
    }
    
    public RenderPlayer() {
        super(new ModelPlayer(0.0f), 0.5f);
        this.modelBipedMain = (ModelPlayer)this.mainModel;
        this.modelArmorChestplate = new ModelBiped(1.0f);
        this.modelArmor = new ModelBiped(0.5f);
        this.modelRene = new ModelPlayerRene(0.0f);
        this.modelSteve = new ModelPlayer(0.0f);
        RenderPlayer.bobbing = true;
    }
    
    protected boolean setArmorModel(final EntityPlayer entityplayer, final int i) {
        final ItemStack itemstack = entityplayer.inventory.armorItemInSlot(3 - i);
        if (itemstack != null) {
            final Item item = itemstack.getItem();
            if (item instanceof ItemArmor) {
                final ItemArmor itemarmor = (ItemArmor)item;
                this.loadTexture("/armor/" + RenderPlayer.armorFilenamePrefix[itemarmor.armorMaterial] + "_" + ((i != 2) ? 1 : 2) + ".png");
                final ModelBiped modelbiped = (i != 2) ? this.modelArmorChestplate : this.modelArmor;
                modelbiped.bipedHead.showModel = (i == 0);
                modelbiped.bipedHeadwear.showModel = (i == 0);
                modelbiped.bipedBody.showModel = (i == 1 || i == 2);
                modelbiped.bipedRightArm.showModel = (i == 1);
                modelbiped.bipedLeftArm.showModel = (i == 1);
                modelbiped.bipedRightLeg.showModel = (i == 2 || i == 3);
                modelbiped.bipedLeftLeg.showModel = (i == 2 || i == 3);
                this.func_169_a(modelbiped);
                return true;
            }
        }
        return false;
    }
    
    public void func_188_a(final EntityPlayer entityplayer, final double d, final double d1, final double d2, final float f, final float f1) {
        if (entityplayer.modelRene) {
            this.mainModel = this.modelRene;
            this.modelBipedMain = this.modelRene;
        }
        else {
            this.mainModel = this.modelSteve;
            this.modelBipedMain = this.modelSteve;
        }
        this.modelBipedMain = (entityplayer.modelRene ? this.modelRene : this.modelBipedMain);
        final ItemStack itemstack = entityplayer.inventory.getCurrentItem();
        final ModelBiped modelArmorChestplate = this.modelArmorChestplate;
        final ModelBiped modelArmor = this.modelArmor;
        final ModelPlayer modelBipedMain = this.modelBipedMain;
        final boolean field_1278_i;
        final boolean b = field_1278_i = (((itemstack != null) ? 1 : 0) != 0);
        modelBipedMain.field_1278_i = b;
        modelArmor.field_1278_i = b;
        modelArmorChestplate.field_1278_i = field_1278_i;
        final ModelBiped modelArmorChestplate2 = this.modelArmorChestplate;
        final ModelBiped modelArmor2 = this.modelArmor;
        final ModelPlayer modelBipedMain2 = this.modelBipedMain;
        final boolean isSneaking = entityplayer.getIsSneaking();
        modelBipedMain2.bipedIsSneaking = isSneaking;
        modelArmor2.bipedIsSneaking = isSneaking;
        modelArmorChestplate2.bipedIsSneaking = isSneaking;
        ModelBiped.oldWalking = entityplayer.isRunning();
        RenderPlayer.bobbing = entityplayer.isRunning();
        super.func_171_a(entityplayer, d, d1 - entityplayer.yOffset, d2, f, f1);
        final ModelBiped modelArmorChestplate3 = this.modelArmorChestplate;
        final ModelBiped modelArmor3 = this.modelArmor;
        final ModelPlayer modelBipedMain3 = this.modelBipedMain;
        final boolean bipedIsSneaking = false;
        modelBipedMain3.bipedIsSneaking = bipedIsSneaking;
        modelArmor3.bipedIsSneaking = bipedIsSneaking;
        modelArmorChestplate3.bipedIsSneaking = bipedIsSneaking;
        final ModelBiped modelArmorChestplate4 = this.modelArmorChestplate;
        final ModelBiped modelArmor4 = this.modelArmor;
        final ModelPlayer modelBipedMain4 = this.modelBipedMain;
        final boolean field_1278_i2 = false;
        modelBipedMain4.field_1278_i = field_1278_i2;
        modelArmor4.field_1278_i = field_1278_i2;
        modelArmorChestplate4.field_1278_i = field_1278_i2;
        final FontRenderer fontrenderer = this.getFontRendererFromRenderManager();
        final float f2 = 1.6f;
        float f3 = 0.01666667f * f2;
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d + 0.0f, (float)d1 + 2.3f, (float)d2);
        GL11.glNormal3f(0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-this.renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(this.renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
        final float f4 = entityplayer.getDistanceToEntity(this.renderManager.livingPlayer);
        f3 *= (float)(Math.sqrt(f4) / 2.0);
        GL11.glScalef(-f3, -f3, f3);
        final String s = entityplayer.playerName;
        GL11.glDisable(2896);
        GL11.glDepthMask(false);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        final Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(3553);
        tessellator.startDrawingQuads();
        final int i = fontrenderer.getStringWidth(s) / 2;
        tessellator.setColorRGBA_F(0.0f, 0.0f, 0.0f, 0.25f);
        tessellator.addVertex(-i - 1, -1.0, 0.0);
        tessellator.addVertex(-i - 1, 8.0, 0.0);
        tessellator.addVertex(i + 1, 8.0, 0.0);
        tessellator.addVertex(i + 1, -1.0, 0.0);
        tessellator.draw();
        GL11.glEnable(3553);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, 0, 553648127);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        fontrenderer.drawString(s, -fontrenderer.getStringWidth(s) / 2, 0, -1);
        GL11.glEnable(2896);
        GL11.glDisable(3042);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    protected void renderSpecials(final EntityPlayer entityplayer, final float f) {
        if ((Minecraft.getMinecraft().session.getProfile().getId() != null || entityplayer.playerName == "deadmau5") && (Minecraft.getMinecraft().session.getProfile().getId().equals(UUID.fromString("1e18d5ff-643d-45c8-b509-43b8461d8614")) || entityplayer.playerName == "deadmau5")) {
            for (int i = 0; i < 2; ++i) {
                final float f2 = entityplayer.prevRotationYaw + (entityplayer.rotationYaw - entityplayer.prevRotationYaw) * f - (entityplayer.prevRenderYawOffset + (entityplayer.renderYawOffset - entityplayer.prevRenderYawOffset) * f);
                final float f3 = entityplayer.prevRotationPitch + (entityplayer.rotationPitch - entityplayer.prevRotationPitch) * f;
                GL11.glPushMatrix();
                GL11.glRotatef(f2, 0.0f, 1.0f, 0.0f);
                GL11.glRotatef(f3, 1.0f, 0.0f, 0.0f);
                GL11.glTranslatef(0.375f * (i * 2 - 1), 0.0f, 0.0f);
                GL11.glTranslatef(0.0f, -0.375f, 0.0f);
                GL11.glRotatef(-f3, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(-f2, 0.0f, 1.0f, 0.0f);
                final float f4 = 1.333333f;
                GL11.glScalef(f4, f4, f4);
                this.modelBipedMain.renderEars(0.0625f);
                GL11.glPopMatrix();
            }
        }
        if (this.loadDownloadableImageTexture(entityplayer.cloakURL, null)) {
            GL11.glPushMatrix();
            GL11.glTranslatef(0.0f, 0.0f, 0.125f);
            final double d = entityplayer.field_20066_r + (entityplayer.field_20063_u - entityplayer.field_20066_r) * f - (entityplayer.prevPosX + (entityplayer.posX - entityplayer.prevPosX) * f);
            final double d2 = entityplayer.field_20065_s + (entityplayer.field_20062_v - entityplayer.field_20065_s) * f - (entityplayer.prevPosY + (entityplayer.posY - entityplayer.prevPosY) * f);
            final double d3 = entityplayer.field_20064_t + (entityplayer.field_20061_w - entityplayer.field_20064_t) * f - (entityplayer.prevPosZ + (entityplayer.posZ - entityplayer.prevPosZ) * f);
            final float f5 = entityplayer.prevRenderYawOffset + (entityplayer.renderYawOffset - entityplayer.prevRenderYawOffset) * f;
            final double d4 = MathHelper.sin(f5 * 3.141593f / 180.0f);
            final double d5 = -MathHelper.cos(f5 * 3.141593f / 180.0f);
            float f6 = (float)d2 * 10.0f;
            if (f6 < -6.0f) {
                f6 = -6.0f;
            }
            if (f6 > 32.0f) {
                f6 = 32.0f;
            }
            float f7 = (float)(d * d4 + d3 * d5) * 100.0f;
            final float f8 = (float)(d * d5 - d3 * d4) * 100.0f;
            if (f7 < 0.0f) {
                f7 = 0.0f;
            }
            final float f9 = entityplayer.field_775_e + (entityplayer.field_774_f - entityplayer.field_775_e) * f;
            f6 += MathHelper.sin((entityplayer.prevDistanceWalkedModified + (entityplayer.distanceWalkedModified - entityplayer.prevDistanceWalkedModified) * f) * 6.0f) * 32.0f * f9;
            if (entityplayer.isSneaking()) {
                f6 += 25.0f;
            }
            GL11.glRotatef(6.0f + f7 / 2.0f + f6, 1.0f, 0.0f, 0.0f);
            GL11.glRotatef(f8 / 2.0f, 0.0f, 0.0f, 1.0f);
            GL11.glRotatef(-f8 / 2.0f, 0.0f, 1.0f, 0.0f);
            GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
            this.modelBipedMain.renderCloak(0.0625f);
            GL11.glPopMatrix();
        }
        ItemStack itemstack1 = entityplayer.inventory.getCurrentItem();
        if (itemstack1 != null) {
            GL11.glPushMatrix();
            this.modelBipedMain.bipedRightArm.postRender(0.0625f);
            GL11.glTranslatef(-0.0625f, 0.4375f, 0.0625f);
            if (entityplayer.fishEntity != null) {
                itemstack1 = new ItemStack(Item.fishingRod, 1);
            }
            if (itemstack1.itemID >= 256) {
                float f10 = this.renderManager.worldObj.getBrightness(MathHelper.floor_double(entityplayer.posX), MathHelper.floor_double(entityplayer.posY), MathHelper.floor_double(entityplayer.posZ));
                if (entityplayer.getEntityBrightness(1.0f) == 1.0f) {
                    f10 = 1.0f;
                }
            }
            if (itemstack1.itemID < 256) {
                float f11 = 0.5f;
                GL11.glTranslatef(0.0f, 0.1875f, -0.3125f);
                f11 *= 0.75f;
                GL11.glRotatef(20.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(f11, -f11, f11);
            }
            else if (Item.itemsList[itemstack1.itemID].isFull3D()) {
                final float f12 = 0.625f;
                GL11.glTranslatef(0.0f, 0.1875f, 0.0f);
                GL11.glScalef(f12, -f12, f12);
                GL11.glRotatef(-100.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
            }
            else {
                final float f13 = 0.375f;
                GL11.glTranslatef(0.25f, 0.1875f, -0.1875f);
                GL11.glScalef(f13, f13, f13);
                GL11.glRotatef(60.0f, 0.0f, 0.0f, 1.0f);
                GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
                GL11.glRotatef(20.0f, 0.0f, 0.0f, 1.0f);
            }
            this.renderManager.itemRenderer.renderItem(itemstack1);
            GL11.glPopMatrix();
        }
    }
    
    protected void func_186_b(final EntityPlayer entityplayer, final float f) {
        final float f2 = 0.9375f;
        GL11.glScalef(f2, f2, f2);
    }
    
    public void renderArmViewModel(final EntityPlayer entityplayer) {
        if (entityplayer instanceof EntityPlayerSP && entityplayer.modelRene) {
            this.modelBipedMain = this.modelRene;
        }
        else {
            this.modelBipedMain = this.modelSteve;
        }
        this.modelBipedMain.onGround = 0.0f;
        this.modelBipedMain.setRotationAngles(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0625f);
        this.modelBipedMain.bipedRightArm.render(0.0625f);
    }
    
    @Override
    protected void func_168_a(final EntityLiving entityliving, final float f) {
        this.func_186_b((EntityPlayer)entityliving, f);
    }
    
    @Override
    protected boolean func_166_a(final EntityLiving entityliving, final int i) {
        return this.setArmorModel((EntityPlayer)entityliving, i);
    }
    
    @Override
    protected void func_174_b(final EntityLiving entityliving, final float f) {
        this.renderSpecials((EntityPlayer)entityliving, f);
    }
    
    @Override
    public void func_171_a(final EntityLiving entityliving, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_188_a((EntityPlayer)entityliving, d, d1, d2, f, f1);
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_188_a((EntityPlayer)entity, d, d1, d2, f, f1);
    }
}
