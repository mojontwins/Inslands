package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.*;

public class RenderCreeper extends RenderLiving
{
    public RenderCreeper() {
        super(new ModelCreeper(), 0.5f);
    }
    
    protected void func_184_a(final EntityCreeper entitycreeper, final float f) {
        final EntityCreeper entitycreeper2 = entitycreeper;
        float f2 = entitycreeper2.setCreeperFlashTime(f);
        final float f3 = 1.0f + MathHelper.sin(f2 * 100.0f) * f2 * 0.01f;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        f2 *= f2;
        f2 *= f2;
        final float f4 = (1.0f + f2 * 0.4f) * f3;
        final float f5 = (1.0f + f2 * 0.1f) / f3;
        GL11.glScalef(f4, f5, f4);
    }
    
    protected int func_183_a(final EntityCreeper entitycreeper, final float f, final float f1) {
        final EntityCreeper entitycreeper2 = entitycreeper;
        final float f2 = entitycreeper2.setCreeperFlashTime(f1);
        if ((int)(f2 * 10.0f) % 2 == 0) {
            return 0;
        }
        int i = (int)(f2 * 0.2f * 255.0f);
        if (i < 0) {
            i = 0;
        }
        if (i > 255) {
            i = 255;
        }
        final char c = '\u00ff';
        final char c2 = '\u00ff';
        final char c3 = '\u00ff';
        return i << 24 | c << 16 | c2 << 8 | c3;
    }
    
    @Override
    protected void func_168_a(final EntityLiving entityliving, final float f) {
        this.func_184_a((EntityCreeper)entityliving, f);
    }
    
    @Override
    protected int func_173_a(final EntityLiving entityliving, final float f, final float f1) {
        return this.func_183_a((EntityCreeper)entityliving, f, f1);
    }
}
