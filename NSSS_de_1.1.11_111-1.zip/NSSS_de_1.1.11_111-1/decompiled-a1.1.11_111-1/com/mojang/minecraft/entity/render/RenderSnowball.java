package com.mojang.minecraft.entity.render;

import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class RenderSnowball extends Render
{
    public void func_155_a(final EntitySnowball entitysnowball, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float)d, (float)d1, (float)d2);
        GL11.glEnable(32826);
        GL11.glScalef(0.5f, 0.5f, 0.5f);
        final int i = Item.snowball.getIconIndex(null);
        this.loadTexture("/gui/items.png");
        final Tessellator tessellator = Tessellator.instance;
        final float f2 = (i % 16 * 16 + 0) / 256.0f;
        final float f3 = (i % 16 * 16 + 16) / 256.0f;
        final float f4 = (i / 16 * 16 + 0) / 256.0f;
        final float f5 = (i / 16 * 16 + 16) / 256.0f;
        final float f6 = 1.0f;
        final float f7 = 0.5f;
        final float f8 = 0.25f;
        GL11.glRotatef(180.0f - this.renderManager.playerViewY, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(-this.renderManager.playerViewX, 1.0f, 0.0f, 0.0f);
        tessellator.startDrawingQuads();
        tessellator.setNormal(0.0f, 1.0f, 0.0f);
        tessellator.addVertexWithUV(0.0f - f7, 0.0f - f8, 0.0, f2, f5);
        tessellator.addVertexWithUV(f6 - f7, 0.0f - f8, 0.0, f3, f5);
        tessellator.addVertexWithUV(f6 - f7, 1.0f - f8, 0.0, f3, f4);
        tessellator.addVertexWithUV(0.0f - f7, 1.0f - f8, 0.0, f2, f4);
        tessellator.draw();
        GL11.glDisable(32826);
        GL11.glPopMatrix();
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_155_a((EntitySnowball)entity, d, d1, d2, f, f1);
    }
}
