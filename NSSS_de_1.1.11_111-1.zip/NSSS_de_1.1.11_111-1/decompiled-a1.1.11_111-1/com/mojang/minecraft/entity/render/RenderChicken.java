package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;

public class RenderChicken extends RenderLiving
{
    public RenderChicken(final ModelBase modelbase, final float f) {
        super(modelbase, f);
    }
    
    public void func_181_a(final EntityChicken entitychicken, final double d, final double d1, final double d2, final float f, final float f1) {
        super.func_171_a(entitychicken, d, d1, d2, f, f1);
    }
    
    protected float func_182_a(final EntityChicken entitychicken, final float f) {
        final float f2 = entitychicken.field_756_e + (entitychicken.field_752_b - entitychicken.field_756_e) * f;
        final float f3 = entitychicken.field_757_d + (entitychicken.field_758_c - entitychicken.field_757_d) * f;
        return (MathHelper.sin(f2) + 1.0f) * f3;
    }
    
    @Override
    protected float func_170_d(final EntityLiving entityliving, final float f) {
        return this.func_182_a((EntityChicken)entityliving, f);
    }
    
    @Override
    public void func_171_a(final EntityLiving entityliving, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_181_a((EntityChicken)entityliving, d, d1, d2, f, f1);
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_181_a((EntityChicken)entity, d, d1, d2, f, f1);
    }
}
