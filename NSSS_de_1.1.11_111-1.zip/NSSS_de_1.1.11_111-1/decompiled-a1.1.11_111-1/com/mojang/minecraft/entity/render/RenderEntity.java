package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;
import org.lwjgl.opengl.*;

public class RenderEntity extends Render
{
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        GL11.glPushMatrix();
        Render.renderOffsetAABB(entity.boundingBox, d - entity.lastTickPosX, d1 - entity.lastTickPosY, d2 - entity.lastTickPosZ);
        GL11.glPopMatrix();
    }
}
