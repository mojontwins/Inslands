package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.entity.model.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.entity.*;

public class RenderZombieSimple extends RenderLiving
{
    private float field_204_f;
    
    public RenderZombieSimple(final ModelBase modelbase, final float f, final float f1) {
        super(modelbase, f * f1);
        this.field_204_f = f1;
    }
    
    protected void func_175_a(final EntityGiant entityzombiesimple, final float f) {
        GL11.glScalef(this.field_204_f, this.field_204_f, this.field_204_f);
    }
    
    @Override
    protected void func_168_a(final EntityLiving entityliving, final float f) {
        this.func_175_a((EntityGiant)entityliving, f);
    }
}
