package com.mojang.minecraft.entity.render;

import com.mojang.minecraft.render.*;
import org.lwjgl.opengl.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public class RenderLightningBolt extends Render
{
    public void func_27002_a(final EntityLightningBolt entitylightningbolt, final double d, final double d1, final double d2, final float f, final float f1) {
        final Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 1);
        final double[] ad = new double[8];
        final double[] ad2 = new double[8];
        double d3 = 0.0;
        double d4 = 0.0;
        final Random random = new Random(entitylightningbolt.field_27029_a);
        for (int j = 7; j >= 0; --j) {
            ad[j] = d3;
            ad2[j] = d4;
            d3 += random.nextInt(11) - 5;
            d4 += random.nextInt(11) - 5;
        }
        for (int i = 0; i < 4; ++i) {
            final Random random2 = new Random(entitylightningbolt.field_27029_a);
            for (int k = 0; k < 3; ++k) {
                int l = 7;
                int i2 = 0;
                if (k > 0) {
                    l = 7 - k;
                }
                if (k > 0) {
                    i2 = l - 2;
                }
                double d5 = ad[l] - d3;
                double d6 = ad2[l] - d4;
                for (int j2 = l; j2 >= i2; --j2) {
                    final double d7 = d5;
                    final double d8 = d6;
                    if (k == 0) {
                        d5 += random2.nextInt(11) - 5;
                        d6 += random2.nextInt(11) - 5;
                    }
                    else {
                        d5 += random2.nextInt(31) - 15;
                        d6 += random2.nextInt(31) - 15;
                    }
                    tessellator.startDrawing(5);
                    final float f2 = 0.5f;
                    tessellator.setColorRGBA_F(0.9f * f2, 0.9f * f2, 1.0f * f2, 0.3f);
                    double d9 = 0.1 + i * 0.2;
                    if (k == 0) {
                        d9 *= j2 * 0.1 + 1.0;
                    }
                    double d10 = 0.1 + i * 0.2;
                    if (k == 0) {
                        d10 *= (j2 - 1) * 0.1 + 1.0;
                    }
                    for (int k2 = 0; k2 < 5; ++k2) {
                        double d11 = d + 0.5 - d9;
                        double d12 = d2 + 0.5 - d9;
                        if (k2 == 1 || k2 == 2) {
                            d11 += d9 * 2.0;
                        }
                        if (k2 == 2 || k2 == 3) {
                            d12 += d9 * 2.0;
                        }
                        double d13 = d + 0.5 - d10;
                        double d14 = d2 + 0.5 - d10;
                        if (k2 == 1 || k2 == 2) {
                            d13 += d10 * 2.0;
                        }
                        if (k2 == 2 || k2 == 3) {
                            d14 += d10 * 2.0;
                        }
                        tessellator.addVertex(d13 + d5, d1 + j2 * 16, d14 + d6);
                        tessellator.addVertex(d11 + d7, d1 + (j2 + 1) * 16, d12 + d8);
                    }
                    tessellator.draw();
                }
            }
        }
        GL11.glDisable(3042);
        GL11.glEnable(2896);
        GL11.glEnable(3553);
    }
    
    @Override
    public void doRender(final Entity entity, final double d, final double d1, final double d2, final float f, final float f1) {
        this.func_27002_a((EntityLightningBolt)entity, d, d1, d2, f, f1);
    }
}
