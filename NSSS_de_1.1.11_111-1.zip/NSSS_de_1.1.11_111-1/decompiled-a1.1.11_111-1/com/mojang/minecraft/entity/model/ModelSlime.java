package com.mojang.minecraft.entity.model;

public class ModelSlime extends ModelBase
{
    ModelRenderer field_1258_a;
    ModelRenderer field_1257_b;
    ModelRenderer field_1260_c;
    ModelRenderer field_1259_d;
    
    public ModelSlime(final int i) {
        (this.field_1258_a = new ModelRenderer(0, i)).func_921_a(-4.0f, 16.0f, -4.0f, 8, 8, 8);
        if (i > 0) {
            (this.field_1258_a = new ModelRenderer(0, i)).func_921_a(-3.0f, 17.0f, -3.0f, 6, 6, 6);
            (this.field_1257_b = new ModelRenderer(32, 0)).func_921_a(-3.25f, 18.0f, -3.5f, 2, 2, 2);
            (this.field_1260_c = new ModelRenderer(32, 4)).func_921_a(1.25f, 18.0f, -3.5f, 2, 2, 2);
            (this.field_1259_d = new ModelRenderer(32, 8)).func_921_a(0.0f, 21.0f, -3.5f, 1, 1, 1);
        }
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.field_1258_a.render(f5);
        if (this.field_1257_b != null) {
            this.field_1257_b.render(f5);
            this.field_1260_c.render(f5);
            this.field_1259_d.render(f5);
        }
    }
}
