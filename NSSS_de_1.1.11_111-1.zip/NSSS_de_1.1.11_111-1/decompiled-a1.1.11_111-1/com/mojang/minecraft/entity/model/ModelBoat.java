package com.mojang.minecraft.entity.model;

public class ModelBoat extends ModelBase
{
    public ModelRenderer[] field_1287_a;
    
    public ModelBoat() {
        (this.field_1287_a = new ModelRenderer[5])[0] = new ModelRenderer(0, 8);
        this.field_1287_a[1] = new ModelRenderer(0, 0);
        this.field_1287_a[2] = new ModelRenderer(0, 0);
        this.field_1287_a[3] = new ModelRenderer(0, 0);
        this.field_1287_a[4] = new ModelRenderer(0, 0);
        final byte byte0 = 24;
        final byte byte2 = 6;
        final byte byte3 = 20;
        final byte byte4 = 4;
        this.field_1287_a[0].addBox((float)(-byte0 / 2), (float)(-byte3 / 2 + 2), -3.0f, byte0, byte3 - 4, 4, 0.0f);
        this.field_1287_a[0].setRotationPoint(0.0f, (float)(0 + byte4), 0.0f);
        this.field_1287_a[1].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1287_a[1].setRotationPoint((float)(-byte0 / 2 + 1), (float)(0 + byte4), 0.0f);
        this.field_1287_a[2].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1287_a[2].setRotationPoint((float)(byte0 / 2 - 1), (float)(0 + byte4), 0.0f);
        this.field_1287_a[3].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1287_a[3].setRotationPoint(0.0f, (float)(0 + byte4), (float)(-byte3 / 2 + 1));
        this.field_1287_a[4].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1287_a[4].setRotationPoint(0.0f, (float)(0 + byte4), (float)(byte3 / 2 - 1));
        this.field_1287_a[0].rotateAngleX = 1.570796f;
        this.field_1287_a[1].rotateAngleY = 4.712389f;
        this.field_1287_a[2].rotateAngleY = 1.570796f;
        this.field_1287_a[3].rotateAngleY = 3.141593f;
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        for (int i = 0; i < 5; ++i) {
            this.field_1287_a[i].render(f5);
        }
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
    }
}
