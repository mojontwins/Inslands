package com.mojang.minecraft.entity.model;

import com.mojang.minecraft.util.*;

public class ModelSpider extends ModelBase
{
    public ModelRenderer field_1255_a;
    public ModelRenderer field_1254_b;
    public ModelRenderer field_1253_c;
    public ModelRenderer field_1252_d;
    public ModelRenderer field_1251_e;
    public ModelRenderer field_1250_f;
    public ModelRenderer field_1249_g;
    public ModelRenderer field_1248_h;
    public ModelRenderer field_1247_i;
    public ModelRenderer field_1246_j;
    public ModelRenderer field_1245_m;
    
    public ModelSpider() {
        final float f = 0.0f;
        final int i = 15;
        (this.field_1255_a = new ModelRenderer(32, 4)).addBox(-4.0f, -4.0f, -8.0f, 8, 8, 8, f);
        this.field_1255_a.setRotationPoint(0.0f, (float)(0 + i), -3.0f);
        (this.field_1254_b = new ModelRenderer(0, 0)).addBox(-3.0f, -3.0f, -3.0f, 6, 6, 6, f);
        this.field_1254_b.setRotationPoint(0.0f, (float)i, 0.0f);
        (this.field_1253_c = new ModelRenderer(0, 12)).addBox(-5.0f, -4.0f, -6.0f, 10, 8, 12, f);
        this.field_1253_c.setRotationPoint(0.0f, (float)(0 + i), 9.0f);
        (this.field_1252_d = new ModelRenderer(18, 0)).addBox(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1252_d.setRotationPoint(-4.0f, (float)(0 + i), 2.0f);
        (this.field_1251_e = new ModelRenderer(18, 0)).addBox(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1251_e.setRotationPoint(4.0f, (float)(0 + i), 2.0f);
        (this.field_1250_f = new ModelRenderer(18, 0)).addBox(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1250_f.setRotationPoint(-4.0f, (float)(0 + i), 1.0f);
        (this.field_1249_g = new ModelRenderer(18, 0)).addBox(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1249_g.setRotationPoint(4.0f, (float)(0 + i), 1.0f);
        (this.field_1248_h = new ModelRenderer(18, 0)).addBox(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1248_h.setRotationPoint(-4.0f, (float)(0 + i), 0.0f);
        (this.field_1247_i = new ModelRenderer(18, 0)).addBox(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1247_i.setRotationPoint(4.0f, (float)(0 + i), 0.0f);
        (this.field_1246_j = new ModelRenderer(18, 0)).addBox(-15.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1246_j.setRotationPoint(-4.0f, (float)(0 + i), -1.0f);
        (this.field_1245_m = new ModelRenderer(18, 0)).addBox(-1.0f, -1.0f, -1.0f, 16, 2, 2, f);
        this.field_1245_m.setRotationPoint(4.0f, (float)(0 + i), -1.0f);
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.field_1255_a.render(f5);
        this.field_1254_b.render(f5);
        this.field_1253_c.render(f5);
        this.field_1252_d.render(f5);
        this.field_1251_e.render(f5);
        this.field_1250_f.render(f5);
        this.field_1249_g.render(f5);
        this.field_1248_h.render(f5);
        this.field_1247_i.render(f5);
        this.field_1246_j.render(f5);
        this.field_1245_m.render(f5);
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.field_1255_a.rotateAngleY = f3 / 57.29578f;
        this.field_1255_a.rotateAngleX = -f4 / 57.29578f;
        final float f6 = 0.7853982f;
        this.field_1252_d.rotateAngleZ = -f6;
        this.field_1251_e.rotateAngleZ = f6;
        this.field_1250_f.rotateAngleZ = -f6 * 0.74f;
        this.field_1249_g.rotateAngleZ = f6 * 0.74f;
        this.field_1248_h.rotateAngleZ = -f6 * 0.74f;
        this.field_1247_i.rotateAngleZ = f6 * 0.74f;
        this.field_1246_j.rotateAngleZ = -f6;
        this.field_1245_m.rotateAngleZ = f6;
        final float f7 = -0.0f;
        final float f8 = 0.3926991f;
        this.field_1252_d.rotateAngleY = f8 * 2.0f + f7;
        this.field_1251_e.rotateAngleY = -f8 * 2.0f - f7;
        this.field_1250_f.rotateAngleY = f8 * 1.0f + f7;
        this.field_1249_g.rotateAngleY = -f8 * 1.0f - f7;
        this.field_1248_h.rotateAngleY = -f8 * 1.0f + f7;
        this.field_1247_i.rotateAngleY = f8 * 1.0f - f7;
        this.field_1246_j.rotateAngleY = -f8 * 2.0f + f7;
        this.field_1245_m.rotateAngleY = f8 * 2.0f - f7;
        final float f9 = -(MathHelper.cos(f * 0.6662f * 2.0f + 0.0f) * 0.4f) * f1;
        final float f10 = -(MathHelper.cos(f * 0.6662f * 2.0f + 3.141593f) * 0.4f) * f1;
        final float f11 = -(MathHelper.cos(f * 0.6662f * 2.0f + 1.570796f) * 0.4f) * f1;
        final float f12 = -(MathHelper.cos(f * 0.6662f * 2.0f + 4.712389f) * 0.4f) * f1;
        final float f13 = Math.abs(MathHelper.sin(f * 0.6662f + 0.0f) * 0.4f) * f1;
        final float f14 = Math.abs(MathHelper.sin(f * 0.6662f + 3.141593f) * 0.4f) * f1;
        final float f15 = Math.abs(MathHelper.sin(f * 0.6662f + 1.570796f) * 0.4f) * f1;
        final float f16 = Math.abs(MathHelper.sin(f * 0.6662f + 4.712389f) * 0.4f) * f1;
        final ModelRenderer field_1252_d = this.field_1252_d;
        field_1252_d.rotateAngleY += f9;
        final ModelRenderer field_1251_e = this.field_1251_e;
        field_1251_e.rotateAngleY += -f9;
        final ModelRenderer field_1250_f = this.field_1250_f;
        field_1250_f.rotateAngleY += f10;
        final ModelRenderer field_1249_g = this.field_1249_g;
        field_1249_g.rotateAngleY += -f10;
        final ModelRenderer field_1248_h = this.field_1248_h;
        field_1248_h.rotateAngleY += f11;
        final ModelRenderer field_1247_i = this.field_1247_i;
        field_1247_i.rotateAngleY += -f11;
        final ModelRenderer field_1246_j = this.field_1246_j;
        field_1246_j.rotateAngleY += f12;
        final ModelRenderer field_1245_m = this.field_1245_m;
        field_1245_m.rotateAngleY += -f12;
        final ModelRenderer field_1252_d2 = this.field_1252_d;
        field_1252_d2.rotateAngleZ += f13;
        final ModelRenderer field_1251_e2 = this.field_1251_e;
        field_1251_e2.rotateAngleZ += -f13;
        final ModelRenderer field_1250_f2 = this.field_1250_f;
        field_1250_f2.rotateAngleZ += f14;
        final ModelRenderer field_1249_g2 = this.field_1249_g;
        field_1249_g2.rotateAngleZ += -f14;
        final ModelRenderer field_1248_h2 = this.field_1248_h;
        field_1248_h2.rotateAngleZ += f15;
        final ModelRenderer field_1247_i2 = this.field_1247_i;
        field_1247_i2.rotateAngleZ += -f15;
        final ModelRenderer field_1246_j2 = this.field_1246_j;
        field_1246_j2.rotateAngleZ += f16;
        final ModelRenderer field_1245_m2 = this.field_1245_m;
        field_1245_m2.rotateAngleZ += -f16;
    }
}
