package com.mojang.minecraft.entity.model;

public class ModelPig extends ModelQuadraped
{
    public ModelPig() {
        super(6, 0.0f);
    }
    
    public ModelPig(final float f) {
        super(6, f);
    }
}
