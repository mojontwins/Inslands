package com.mojang.minecraft.entity.model;

public class ModelPlayer extends ModelBiped
{
    public ModelRenderer field_178734_a;
    public ModelRenderer field_178732_b;
    public ModelRenderer field_178733_c;
    public ModelRenderer field_178731_d;
    public ModelRenderer field_178730_v;
    
    public ModelPlayer(final float f) {
        this(f, 0.0f);
    }
    
    public ModelPlayer(final float f, final float f1) {
        this.field_1279_h = false;
        this.field_1278_i = false;
        this.bipedIsSneaking = false;
        (this.bipedCloak = new ModelRenderer(0, 0, 64, 64)).addBox(-5.0f, 0.0f, -1.0f, 10, 16, 1, f);
        (this.bipedEars = new ModelRenderer(24, 0, 64, 64)).addBox(-3.0f, -6.0f, -1.0f, 6, 6, 1, f);
        this.bipedLeftArm = new ModelRenderer(40, 16, 64, 64);
        this.bipedLeftArm.mirror = true;
        this.bipedLeftArm.addBox(-1.0f, -2.0f, -2.0f, 4, 12, 4, f);
        this.bipedLeftArm.setRotationPoint(5.0f, 2.0f, 0.0f);
        this.bipedLeftLeg = new ModelRenderer(0, 16, 64, 64);
        this.bipedLeftLeg.mirror = true;
        this.bipedLeftLeg.addBox(-2.0f, 0.0f, -2.0f, 4, 12, 4, f);
        this.bipedLeftLeg.setRotationPoint(1.9f, 12.0f, 0.0f);
        (this.bipedHead = new ModelRenderer(0, 0, 64, 64)).addBox(-4.0f, -8.0f, -4.0f, 8, 8, 8, f);
        this.bipedHead.setRotationPoint(0.0f, 0.0f + f1, 0.0f);
        (this.bipedHeadwear = new ModelRenderer(32, 0, 64, 64)).addBox(-4.0f, -8.0f, -4.0f, 8, 8, 8, f + 0.5f);
        this.bipedHeadwear.setRotationPoint(0.0f, 0.0f + f1, 0.0f);
        (this.bipedBody = new ModelRenderer(16, 16, 64, 64)).addBox(-4.0f, 0.0f, -2.0f, 8, 12, 4, f);
        this.bipedBody.setRotationPoint(0.0f, 0.0f + f1, 0.0f);
        (this.bipedRightArm = new ModelRenderer(40, 16, 64, 64)).addBox(-3.0f, -2.0f, -2.0f, 4, 12, 4, f);
        this.bipedRightArm.setRotationPoint(-5.0f, 2.0f + f1, 0.0f);
        (this.bipedRightLeg = new ModelRenderer(0, 16, 64, 64)).addBox(-2.0f, 0.0f, -2.0f, 4, 12, 4, f);
        this.bipedRightLeg.setRotationPoint(-2.0f, 12.0f + f1, 0.0f);
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.setRotationAnglesAndRender(f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.setRotationAngles(f, f1, f2, f3, f4, f5);
        func_178685_a(this.bipedLeftLeg, this.field_178733_c);
        func_178685_a(this.bipedRightLeg, this.field_178731_d);
        func_178685_a(this.bipedLeftArm, this.field_178734_a);
        func_178685_a(this.bipedRightArm, this.field_178732_b);
        func_178685_a(this.bipedBody, this.field_178730_v);
    }
    
    public static void func_178685_a(final ModelRenderer p_178685_0_, final ModelRenderer p_178685_1_) {
    }
    
    @Override
    public void renderEars(final float f) {
        this.bipedEars.rotateAngleY = this.bipedHead.rotateAngleY;
        this.bipedEars.rotateAngleX = this.bipedHead.rotateAngleX;
        this.bipedEars.rotationPointX = 0.0f;
        this.bipedEars.rotationPointY = 0.0f;
        this.bipedEars.render(f);
    }
    
    @Override
    public void renderCloak(final float f) {
        this.bipedCloak.render(f);
    }
}
