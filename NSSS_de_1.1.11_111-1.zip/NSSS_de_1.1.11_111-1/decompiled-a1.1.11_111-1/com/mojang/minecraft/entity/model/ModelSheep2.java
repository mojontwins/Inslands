package com.mojang.minecraft.entity.model;

public class ModelSheep2 extends ModelQuadraped
{
    public ModelSheep2() {
        super(12, 0.0f);
        (this.quadrapedHead = new ModelRenderer(0, 0)).addBox(-3.0f, -4.0f, -6.0f, 6, 6, 8, 0.0f);
        this.quadrapedHead.setRotationPoint(0.0f, 6.0f, -8.0f);
        (this.field_1265_e = new ModelRenderer(28, 8)).addBox(-4.0f, -10.0f, -7.0f, 8, 16, 6, 0.0f);
        this.field_1265_e.setRotationPoint(0.0f, 5.0f, 2.0f);
    }
}
