package com.mojang.minecraft.entity.model;

public class ModelMinecart extends ModelBase
{
    public ModelRenderer[] field_1256_a;
    
    public ModelMinecart() {
        (this.field_1256_a = new ModelRenderer[7])[0] = new ModelRenderer(0, 10);
        this.field_1256_a[1] = new ModelRenderer(0, 0);
        this.field_1256_a[2] = new ModelRenderer(0, 0);
        this.field_1256_a[3] = new ModelRenderer(0, 0);
        this.field_1256_a[4] = new ModelRenderer(0, 0);
        this.field_1256_a[5] = new ModelRenderer(44, 10);
        final byte byte0 = 20;
        final byte byte2 = 8;
        final byte byte3 = 16;
        final byte byte4 = 4;
        this.field_1256_a[0].addBox((float)(-byte0 / 2), (float)(-byte3 / 2), -1.0f, byte0, byte3, 2, 0.0f);
        this.field_1256_a[0].setRotationPoint(0.0f, (float)(0 + byte4), 0.0f);
        this.field_1256_a[5].addBox((float)(-byte0 / 2 + 1), (float)(-byte3 / 2 + 1), -1.0f, byte0 - 2, byte3 - 2, 1, 0.0f);
        this.field_1256_a[5].setRotationPoint(0.0f, (float)(0 + byte4), 0.0f);
        this.field_1256_a[1].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1256_a[1].setRotationPoint((float)(-byte0 / 2 + 1), (float)(0 + byte4), 0.0f);
        this.field_1256_a[2].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1256_a[2].setRotationPoint((float)(byte0 / 2 - 1), (float)(0 + byte4), 0.0f);
        this.field_1256_a[3].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1256_a[3].setRotationPoint(0.0f, (float)(0 + byte4), (float)(-byte3 / 2 + 1));
        this.field_1256_a[4].addBox((float)(-byte0 / 2 + 2), (float)(-byte2 - 1), -1.0f, byte0 - 4, byte2, 2, 0.0f);
        this.field_1256_a[4].setRotationPoint(0.0f, (float)(0 + byte4), (float)(byte3 / 2 - 1));
        this.field_1256_a[0].rotateAngleX = 1.570796f;
        this.field_1256_a[1].rotateAngleY = 4.712389f;
        this.field_1256_a[2].rotateAngleY = 1.570796f;
        this.field_1256_a[3].rotateAngleY = 3.141593f;
        this.field_1256_a[5].rotateAngleX = -1.570796f;
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.field_1256_a[5].rotationPointY = 4.0f - f2;
        for (int i = 0; i < 6; ++i) {
            this.field_1256_a[i].render(f5);
        }
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
    }
}
