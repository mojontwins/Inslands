package com.mojang.minecraft.entity.model;

public class ModelPlayerRene extends ModelPlayer
{
    public ModelPlayerRene(final float f) {
        this(f, 0.0f);
    }
    
    public ModelPlayerRene(final float f, final float f1) {
        super(f, f1);
        (this.field_178734_a = new ModelRenderer(48, 48, 64, 64)).addBox(-1.0f, -2.0f, -2.0f, 3, 12, 4, f + 0.25f);
        this.field_178734_a.setRotationPoint(5.0f, 2.5f, 0.0f);
        (this.field_178732_b = new ModelRenderer(40, 32, 64, 64)).addBox(-2.0f, -2.0f, -2.0f, 3, 12, 4, f + 0.25f);
        this.field_178732_b.setRotationPoint(-5.0f, 2.5f, 10.0f);
        this.bipedLeftArm = new ModelRenderer(40, 16, 64, 64);
        this.bipedLeftArm.mirror = true;
        this.bipedLeftArm.addBox(-1.0f, -2.0f, -2.0f, 3, 12, 4, f);
        this.bipedLeftArm.setRotationPoint(5.0f, 2.5f, 0.0f);
        (this.bipedRightArm = new ModelRenderer(40, 16, 64, 64)).addBox(-2.0f, -2.0f, -2.0f, 3, 12, 4, f);
        this.bipedRightArm.setRotationPoint(-5.0f, 2.5f + f1, 0.0f);
    }
}
