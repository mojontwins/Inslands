package com.mojang.minecraft.entity.model;

import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class ModelRenderer
{
    private PositionTexureVertex[] corners;
    private TexturedQuad[] faces;
    private int textureOffsetX;
    private int textureOffsetY;
    public float rotationPointX;
    public float rotationPointY;
    public float rotationPointZ;
    public float rotateAngleX;
    public float rotateAngleY;
    public float rotateAngleZ;
    private boolean compiled;
    private int displayList;
    public boolean mirror;
    public boolean showModel;
    public boolean field_1402_i;
    public int scalex;
    public int scaley;
    
    public ModelRenderer(final int i, final int j, final int x, final int y) {
        this.compiled = false;
        this.displayList = 0;
        this.mirror = false;
        this.showModel = true;
        this.field_1402_i = false;
        this.textureOffsetX = i;
        this.textureOffsetY = j;
        this.scalex = x;
        this.scaley = y;
    }
    
    public ModelRenderer(final int i, final int j) {
        this.compiled = false;
        this.displayList = 0;
        this.mirror = false;
        this.showModel = true;
        this.field_1402_i = false;
        this.textureOffsetX = i;
        this.textureOffsetY = j;
    }
    
    public void func_921_a(final float f, final float f1, final float f2, final int i, final int j, final int k) {
        this.addBox(f, f1, f2, i, j, k, 0.0f);
    }
    
    public void addBox(float f, float f1, float f2, final int i, final int j, final int k, final float f3) {
        this.corners = new PositionTexureVertex[8];
        this.faces = new TexturedQuad[6];
        float f4 = f + i;
        float f5 = f1 + j;
        float f6 = f2 + k;
        f -= f3;
        f1 -= f3;
        f2 -= f3;
        f4 += f3;
        f5 += f3;
        f6 += f3;
        if (this.mirror) {
            final float f7 = f4;
            f4 = f;
            f = f7;
        }
        final PositionTexureVertex positiontexurevertex = new PositionTexureVertex(f, f1, f2, 0.0f, 0.0f);
        final PositionTexureVertex positiontexurevertex2 = new PositionTexureVertex(f4, f1, f2, 0.0f, 8.0f);
        final PositionTexureVertex positiontexurevertex3 = new PositionTexureVertex(f4, f5, f2, 8.0f, 8.0f);
        final PositionTexureVertex positiontexurevertex4 = new PositionTexureVertex(f, f5, f2, 8.0f, 0.0f);
        final PositionTexureVertex positiontexurevertex5 = new PositionTexureVertex(f, f1, f6, 0.0f, 0.0f);
        final PositionTexureVertex positiontexurevertex6 = new PositionTexureVertex(f4, f1, f6, 0.0f, 8.0f);
        final PositionTexureVertex positiontexurevertex7 = new PositionTexureVertex(f4, f5, f6, 8.0f, 8.0f);
        final PositionTexureVertex positiontexurevertex8 = new PositionTexureVertex(f, f5, f6, 8.0f, 0.0f);
        this.corners[0] = positiontexurevertex;
        this.corners[1] = positiontexurevertex2;
        this.corners[2] = positiontexurevertex3;
        this.corners[3] = positiontexurevertex4;
        this.corners[4] = positiontexurevertex5;
        this.corners[5] = positiontexurevertex6;
        this.corners[6] = positiontexurevertex7;
        this.corners[7] = positiontexurevertex8;
        this.faces[0] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex6, positiontexurevertex2, positiontexurevertex3, positiontexurevertex7 }, this.textureOffsetX + k + i, this.textureOffsetY + k, this.textureOffsetX + k + i + k, this.textureOffsetY + k + j);
        this.faces[1] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex, positiontexurevertex5, positiontexurevertex8, positiontexurevertex4 }, this.textureOffsetX + 0, this.textureOffsetY + k, this.textureOffsetX + k, this.textureOffsetY + k + j);
        this.faces[2] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex6, positiontexurevertex5, positiontexurevertex, positiontexurevertex2 }, this.textureOffsetX + k, this.textureOffsetY + 0, this.textureOffsetX + k + i, this.textureOffsetY + k);
        this.faces[3] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex3, positiontexurevertex4, positiontexurevertex8, positiontexurevertex7 }, this.textureOffsetX + k + i, this.textureOffsetY + 0, this.textureOffsetX + k + i + i, this.textureOffsetY + k);
        this.faces[4] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex2, positiontexurevertex, positiontexurevertex4, positiontexurevertex3 }, this.textureOffsetX + k, this.textureOffsetY + k, this.textureOffsetX + k + i, this.textureOffsetY + k + j);
        this.faces[5] = new TexturedQuad(new PositionTexureVertex[] { positiontexurevertex5, positiontexurevertex6, positiontexurevertex7, positiontexurevertex8 }, this.textureOffsetX + k + i + k, this.textureOffsetY + k, this.textureOffsetX + k + i + k + i, this.textureOffsetY + k + j);
        if (this.mirror) {
            for (int l = 0; l < this.faces.length; ++l) {
                this.faces[l].func_809_a();
            }
        }
    }
    
    public void setRotationPoint(final float f, final float f1, final float f2) {
        this.rotationPointX = f;
        this.rotationPointY = f1;
        this.rotationPointZ = f2;
    }
    
    public void render(final float f) {
        if (this.field_1402_i) {
            return;
        }
        if (!this.showModel) {
            return;
        }
        if (!this.compiled) {
            this.compileDisplayList(f);
        }
        if (this.rotateAngleX != 0.0f || this.rotateAngleY != 0.0f || this.rotateAngleZ != 0.0f) {
            GL11.glPushMatrix();
            GL11.glTranslatef(this.rotationPointX * f, this.rotationPointY * f, this.rotationPointZ * f);
            if (this.rotateAngleZ != 0.0f) {
                GL11.glRotatef(this.rotateAngleZ * 57.29578f, 0.0f, 0.0f, 1.0f);
            }
            if (this.rotateAngleY != 0.0f) {
                GL11.glRotatef(this.rotateAngleY * 57.29578f, 0.0f, 1.0f, 0.0f);
            }
            if (this.rotateAngleX != 0.0f) {
                GL11.glRotatef(this.rotateAngleX * 57.29578f, 1.0f, 0.0f, 0.0f);
            }
            GL11.glCallList(this.displayList);
            GL11.glPopMatrix();
        }
        else if (this.rotationPointX != 0.0f || this.rotationPointY != 0.0f || this.rotationPointZ != 0.0f) {
            GL11.glTranslatef(this.rotationPointX * f, this.rotationPointY * f, this.rotationPointZ * f);
            GL11.glCallList(this.displayList);
            GL11.glTranslatef(-this.rotationPointX * f, -this.rotationPointY * f, -this.rotationPointZ * f);
        }
        else {
            GL11.glCallList(this.displayList);
        }
    }
    
    public void postRender(final float f) {
        if (this.field_1402_i) {
            return;
        }
        if (!this.showModel) {
            return;
        }
        if (!this.compiled) {
            this.compileDisplayList(f);
        }
        if (this.rotateAngleX != 0.0f || this.rotateAngleY != 0.0f || this.rotateAngleZ != 0.0f) {
            GL11.glTranslatef(this.rotationPointX * f, this.rotationPointY * f, this.rotationPointZ * f);
            if (this.rotateAngleZ != 0.0f) {
                GL11.glRotatef(this.rotateAngleZ * 57.29578f, 0.0f, 0.0f, 1.0f);
            }
            if (this.rotateAngleY != 0.0f) {
                GL11.glRotatef(this.rotateAngleY * 57.29578f, 0.0f, 1.0f, 0.0f);
            }
            if (this.rotateAngleX != 0.0f) {
                GL11.glRotatef(this.rotateAngleX * 57.29578f, 1.0f, 0.0f, 0.0f);
            }
        }
        else if (this.rotationPointX != 0.0f || this.rotationPointY != 0.0f || this.rotationPointZ != 0.0f) {
            GL11.glTranslatef(this.rotationPointX * f, this.rotationPointY * f, this.rotationPointZ * f);
        }
    }
    
    private void compileDisplayList(final float f) {
        GL11.glNewList(this.displayList = GLAllocation.generateDisplayLists(1), 4864);
        final Tessellator tessellator = Tessellator.instance;
        for (int i = 0; i < this.faces.length; ++i) {
            this.faces[i].func_808_a(tessellator, f);
        }
        GL11.glEndList();
        this.compiled = true;
    }
}
