package com.mojang.minecraft.entity.model;

public abstract class ModelBase
{
    public float onGround;
    public boolean field_1243_l;
    
    public ModelBase() {
        this.field_1243_l = false;
    }
    
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
    }
    
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
    }
}
