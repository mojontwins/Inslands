package com.mojang.minecraft.entity.model;

import com.mojang.minecraft.util.*;

public class ModelQuadraped extends ModelBase
{
    public ModelRenderer quadrapedHead;
    public ModelRenderer field_1265_e;
    public ModelRenderer field_1264_f;
    public ModelRenderer field_1263_g;
    public ModelRenderer field_1262_h;
    public ModelRenderer field_1261_i;
    
    public ModelQuadraped(final int i, final float f) {
        (this.quadrapedHead = new ModelRenderer(0, 0)).addBox(-4.0f, -4.0f, -8.0f, 8, 8, 8, f);
        this.quadrapedHead.setRotationPoint(0.0f, (float)(18 - i), -6.0f);
        (this.field_1265_e = new ModelRenderer(28, 8)).addBox(-5.0f, -10.0f, -7.0f, 10, 16, 8, f);
        this.field_1265_e.setRotationPoint(0.0f, (float)(17 - i), 2.0f);
        (this.field_1264_f = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, i, 4, f);
        this.field_1264_f.setRotationPoint(-3.0f, (float)(24 - i), 7.0f);
        (this.field_1263_g = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, i, 4, f);
        this.field_1263_g.setRotationPoint(3.0f, (float)(24 - i), 7.0f);
        (this.field_1262_h = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, i, 4, f);
        this.field_1262_h.setRotationPoint(-3.0f, (float)(24 - i), -5.0f);
        (this.field_1261_i = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, i, 4, f);
        this.field_1261_i.setRotationPoint(3.0f, (float)(24 - i), -5.0f);
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.quadrapedHead.render(f5);
        this.field_1265_e.render(f5);
        this.field_1264_f.render(f5);
        this.field_1263_g.render(f5);
        this.field_1262_h.render(f5);
        this.field_1261_i.render(f5);
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.quadrapedHead.rotateAngleX = -f4 / 57.29578f;
        this.quadrapedHead.rotateAngleY = f3 / 57.29578f;
        this.field_1265_e.rotateAngleX = 1.570796f;
        this.field_1264_f.rotateAngleX = MathHelper.cos(f * 0.6662f) * 1.4f * f1;
        this.field_1263_g.rotateAngleX = MathHelper.cos(f * 0.6662f + 3.141593f) * 1.4f * f1;
        this.field_1262_h.rotateAngleX = MathHelper.cos(f * 0.6662f + 3.141593f) * 1.4f * f1;
        this.field_1261_i.rotateAngleX = MathHelper.cos(f * 0.6662f) * 1.4f * f1;
    }
}
