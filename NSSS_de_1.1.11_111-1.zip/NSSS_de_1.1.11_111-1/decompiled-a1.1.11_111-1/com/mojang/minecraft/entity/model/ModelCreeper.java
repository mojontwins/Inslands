package com.mojang.minecraft.entity.model;

import com.mojang.minecraft.util.*;

public class ModelCreeper extends ModelBase
{
    public ModelRenderer field_1271_a;
    public ModelRenderer field_1270_b;
    public ModelRenderer field_1276_c;
    public ModelRenderer field_1275_d;
    public ModelRenderer field_1274_e;
    public ModelRenderer field_1273_f;
    public ModelRenderer field_1272_g;
    
    public ModelCreeper() {
        final float f = 0.0f;
        final int i = 4;
        (this.field_1271_a = new ModelRenderer(0, 0)).addBox(-4.0f, -8.0f, -4.0f, 8, 8, 8, f);
        this.field_1271_a.setRotationPoint(0.0f, (float)i, 0.0f);
        (this.field_1270_b = new ModelRenderer(32, 0)).addBox(-4.0f, -8.0f, -4.0f, 8, 8, 8, f + 0.5f);
        this.field_1270_b.setRotationPoint(0.0f, (float)i, 0.0f);
        (this.field_1276_c = new ModelRenderer(16, 16)).addBox(-4.0f, 0.0f, -2.0f, 8, 12, 4, f);
        this.field_1276_c.setRotationPoint(0.0f, (float)i, 0.0f);
        (this.field_1275_d = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.field_1275_d.setRotationPoint(-2.0f, (float)(12 + i), 4.0f);
        (this.field_1274_e = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.field_1274_e.setRotationPoint(2.0f, (float)(12 + i), 4.0f);
        (this.field_1273_f = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.field_1273_f.setRotationPoint(-2.0f, (float)(12 + i), -4.0f);
        (this.field_1272_g = new ModelRenderer(0, 16)).addBox(-2.0f, 0.0f, -2.0f, 4, 6, 4, f);
        this.field_1272_g.setRotationPoint(2.0f, (float)(12 + i), -4.0f);
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.field_1271_a.render(f5);
        this.field_1276_c.render(f5);
        this.field_1275_d.render(f5);
        this.field_1274_e.render(f5);
        this.field_1273_f.render(f5);
        this.field_1272_g.render(f5);
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.field_1271_a.rotateAngleY = f3 / 57.29578f;
        this.field_1271_a.rotateAngleX = -f4 / 57.29578f;
        this.field_1275_d.rotateAngleX = MathHelper.cos(f * 0.6662f) * 1.4f * f1;
        this.field_1274_e.rotateAngleX = MathHelper.cos(f * 0.6662f + 3.141593f) * 1.4f * f1;
        this.field_1273_f.rotateAngleX = MathHelper.cos(f * 0.6662f + 3.141593f) * 1.4f * f1;
        this.field_1272_g.rotateAngleX = MathHelper.cos(f * 0.6662f) * 1.4f * f1;
    }
}
