package com.mojang.minecraft.entity.model;

public class ModelCow extends ModelQuadraped
{
    ModelRenderer field_1268_a;
    ModelRenderer field_1267_b;
    ModelRenderer field_1269_c;
    
    public ModelCow() {
        super(12, 0.0f);
        (this.quadrapedHead = new ModelRenderer(0, 0)).addBox(-4.0f, -4.0f, -6.0f, 8, 8, 6, 0.0f);
        this.quadrapedHead.setRotationPoint(0.0f, 4.0f, -8.0f);
        (this.field_1267_b = new ModelRenderer(22, 0)).addBox(-5.0f, -5.0f, -4.0f, 1, 3, 1, 0.0f);
        this.field_1267_b.setRotationPoint(0.0f, 3.0f, -7.0f);
        (this.field_1269_c = new ModelRenderer(22, 0)).addBox(4.0f, -5.0f, -4.0f, 1, 3, 1, 0.0f);
        this.field_1269_c.setRotationPoint(0.0f, 3.0f, -7.0f);
        (this.field_1268_a = new ModelRenderer(52, 0)).addBox(-2.0f, -3.0f, 0.0f, 4, 6, 2, 0.0f);
        this.field_1268_a.setRotationPoint(0.0f, 14.0f, 6.0f);
        this.field_1268_a.rotateAngleX = 1.570796f;
        (this.field_1265_e = new ModelRenderer(18, 4)).addBox(-6.0f, -10.0f, -7.0f, 12, 18, 10, 0.0f);
        this.field_1265_e.setRotationPoint(0.0f, 5.0f, 2.0f);
        final ModelRenderer field_1264_f = this.field_1264_f;
        --field_1264_f.rotationPointX;
        final ModelRenderer field_1263_g = this.field_1263_g;
        ++field_1263_g.rotationPointX;
        final ModelRenderer field_1264_f2 = this.field_1264_f;
        field_1264_f2.rotationPointZ += 0.0f;
        final ModelRenderer field_1263_g2 = this.field_1263_g;
        field_1263_g2.rotationPointZ += 0.0f;
        final ModelRenderer field_1262_h = this.field_1262_h;
        --field_1262_h.rotationPointX;
        final ModelRenderer field_1261_i = this.field_1261_i;
        ++field_1261_i.rotationPointX;
        final ModelRenderer field_1262_h2 = this.field_1262_h;
        --field_1262_h2.rotationPointZ;
        final ModelRenderer field_1261_i2 = this.field_1261_i;
        --field_1261_i2.rotationPointZ;
    }
    
    @Override
    public void setRotationAnglesAndRender(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.setRotationAnglesAndRender(f, f1, f2, f3, f4, f5);
        this.field_1267_b.render(f5);
        this.field_1269_c.render(f5);
        this.field_1268_a.render(f5);
    }
    
    @Override
    public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        super.setRotationAngles(f, f1, f2, f3, f4, f5);
        this.field_1267_b.rotateAngleY = this.quadrapedHead.rotateAngleY;
        this.field_1267_b.rotateAngleX = this.quadrapedHead.rotateAngleX;
        this.field_1269_c.rotateAngleY = this.quadrapedHead.rotateAngleY;
        this.field_1269_c.rotateAngleX = this.quadrapedHead.rotateAngleX;
    }
}
