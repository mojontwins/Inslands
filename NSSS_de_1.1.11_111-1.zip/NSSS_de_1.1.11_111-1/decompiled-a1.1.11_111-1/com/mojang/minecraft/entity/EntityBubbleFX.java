package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;

public class EntityBubbleFX extends EntityFX
{
    private boolean isSpecial;
    
    public EntityBubbleFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        super(world, d, d1, d2, d3, d4, d5);
        this.isSpecial = false;
        this.particleRed = 1.0f;
        this.particleGreen = 1.0f;
        this.particleBlue = 1.0f;
        this.particleTextureIndex = 32;
        this.setSize(0.02f, 0.02f);
        this.particleScale *= this.rand.nextFloat() * 0.6f + 0.2f;
        this.motionX = d3 * 0.20000000298023224 + (float)(Math.random() * 2.0 - 1.0) * 0.02f;
        this.motionY = d4 * 0.20000000298023224 + (float)(Math.random() * 2.0 - 1.0) * 0.02f;
        this.motionZ = d5 * 0.20000000298023224 + (float)(Math.random() * 2.0 - 1.0) * 0.02f;
        this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2));
    }
    
    public EntityBubbleFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5, final boolean special) {
        this(world, d, d1, d2, d3, d4, d5);
        this.isSpecial = special;
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.motionY += 0.002;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.8500000238418579;
        this.motionY *= 0.8500000238418579;
        this.motionZ *= 0.8500000238418579;
        if (this.worldObj.getMaterialXYZ(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) != Material.water && !this.isSpecial) {
            this.setEntityDead();
        }
        if (this.particleMaxAge-- <= 0) {
            this.setEntityDead();
        }
    }
}
