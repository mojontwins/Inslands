package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.render.*;

public class EntityLavaFX extends EntityFX
{
    private float field_674_a;
    
    public EntityLavaFX(final World world, final double d, final double d1, final double d2) {
        super(world, d, d1, d2, 0.0, 0.0, 0.0);
        this.motionX *= 0.800000011920929;
        this.motionY *= 0.800000011920929;
        this.motionZ *= 0.800000011920929;
        this.motionY = this.rand.nextFloat() * 0.4f + 0.05f;
        final float particleRed = 1.0f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleScale *= this.rand.nextFloat() * 2.0f + 0.2f;
        this.field_674_a = this.particleScale;
        this.particleMaxAge = (int)(16.0 / (Math.random() * 0.8 + 0.2));
        this.noClip = false;
        this.particleTextureIndex = 49;
        final Random random = new Random();
        world.playSoundEffect((float)d + 0.5f, (float)d1 + 0.5f, (float)d2 + 0.5f, "liquid.lavapop", random.nextFloat() * 0.25f + 0.75f, random.nextFloat() * 1.0f + 0.5f);
    }
    
    @Override
    public float getEntityBrightness(final float f) {
        return 1.0f;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        final float f6 = (this.particleAge + f) / this.particleMaxAge;
        this.particleScale = this.field_674_a * (1.0f - f6 * f6);
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
        final float f = this.particleAge / (float)this.particleMaxAge;
        if (this.rand.nextFloat() > f) {
            this.worldObj.spawnParticle("smoke", this.posX, this.posY, this.posZ, this.motionX, this.motionY, this.motionZ);
        }
        this.motionY -= 0.03;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9990000128746033;
        this.motionY *= 0.9990000128746033;
        this.motionZ *= 0.9990000128746033;
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
        }
    }
}
