package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;

public class EntityStarsFX extends EntityFX
{
    float field_673_a;
    EntityPlayer boundPlayer;
    int flipflop;
    
    public EntityStarsFX(final World world, final double d, final double d1, final double d2) {
        this(world, d, d1, d2, 1.0f);
    }
    
    public EntityStarsFX(final World world, final double d, final double d1, final double d2, final float f) {
        super(world, d, d1, d2, 0.0, 0.0, 0.0);
        this.flipflop = 1;
        final float particleRed = (float)(1.0 - Math.random() * 0.1);
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleScale *= 0.75f;
        this.particleScale *= f;
        this.field_673_a = this.particleScale;
        this.particleMaxAge = (int)(1.0 / (Math.random() * 0.8 + 0.2));
        this.particleMaxAge *= (int)f;
        this.noClip = false;
    }
    
    public EntityStarsFX(final World world, final EntityPlayer player, final float f) {
        super(world, player.posX, player.posY, player.posZ, 0.0, 0.0, 0.0);
        this.flipflop = 1;
        this.boundPlayer = player;
        final float particleRed = 1.0f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleScale *= 0.75f;
        this.particleScale *= f;
        this.field_673_a = this.particleScale;
        this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2));
        this.particleMaxAge *= (int)f;
        this.noClip = false;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        float f6 = (this.particleAge + f) / this.particleMaxAge * 32.0f;
        if (f6 < 0.0f) {
            f6 = 0.0f;
        }
        if (f6 > 1.0f) {
            f6 = 1.0f;
        }
        this.particleScale = this.field_673_a * f6 * 0.25f;
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public void onUpdate() {
        this.flipflop *= -1;
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        this.posX = this.boundPlayer.posX + Math.random() * this.flipflop * 0.75;
        this.posY = this.boundPlayer.posY + Math.random() * this.flipflop * 0.75;
        this.posZ = this.boundPlayer.posZ + Math.random() * this.flipflop * 0.75;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
        this.particleTextureIndex = 0;
    }
}
