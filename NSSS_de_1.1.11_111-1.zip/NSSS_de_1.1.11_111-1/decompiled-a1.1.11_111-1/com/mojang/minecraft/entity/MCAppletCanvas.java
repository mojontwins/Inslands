package com.mojang.minecraft.entity;

import java.awt.*;
import com.mojang.minecraft.*;

public class MCAppletCanvas extends Canvas
{
    private static final long serialVersionUID = 1L;
    final MinecraftApplet field_1696_a;
    
    public MCAppletCanvas(final MinecraftApplet minecraftapplet) {
        this.field_1696_a = minecraftapplet;
    }
    
    @Override
    public synchronized void addNotify() {
        super.addNotify();
        this.field_1696_a.func_103_a();
    }
    
    @Override
    public synchronized void removeNotify() {
        this.field_1696_a.func_102_b();
        super.removeNotify();
    }
}
