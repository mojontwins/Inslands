package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.render.*;

public class EntityPickupFX extends EntityFX
{
    private Entity field_675_a;
    private Entity field_679_o;
    private int field_678_p;
    private int field_677_q;
    private float field_676_r;
    
    public EntityPickupFX(final World world, final Entity entity, final Entity entity1, final float f) {
        super(world, entity.posX, entity.posY, entity.posZ, entity.motionX, entity.motionY, entity.motionZ);
        this.field_678_p = 0;
        this.field_677_q = 0;
        this.field_675_a = entity;
        this.field_679_o = entity1;
        this.field_677_q = 3;
        this.field_676_r = f;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        float f6 = (this.field_678_p + f) / this.field_677_q;
        f6 *= f6;
        final double d = this.field_675_a.posX;
        final double d2 = this.field_675_a.posY;
        final double d3 = this.field_675_a.posZ;
        final double d4 = this.field_679_o.lastTickPosX + (this.field_679_o.posX - this.field_679_o.lastTickPosX) * f;
        final double d5 = this.field_679_o.lastTickPosY + (this.field_679_o.posY - this.field_679_o.lastTickPosY) * f + this.field_676_r;
        final double d6 = this.field_679_o.lastTickPosZ + (this.field_679_o.posZ - this.field_679_o.lastTickPosZ) * f;
        double d7 = d + (d4 - d) * f6;
        double d8 = d2 + (d5 - d2) * f6;
        double d9 = d3 + (d6 - d3) * f6;
        final int i = MathHelper.floor_double(d7);
        final int j = MathHelper.floor_double(d8 + this.yOffset / 2.0f);
        final int k = MathHelper.floor_double(d9);
        final float f7 = this.worldObj.getBrightness(i, j, k);
        d7 -= EntityPickupFX.field_660_l;
        d8 -= EntityPickupFX.field_659_m;
        d9 -= EntityPickupFX.field_658_n;
        GL11.glColor4f(f7, f7, f7, 1.0f);
        RenderManager.subManager.renderEntityWithPosYaw(this.field_675_a, (float)d7, (float)d8, (float)d9, this.field_675_a.rotationYaw, f);
    }
    
    @Override
    public void onUpdate() {
        ++this.field_678_p;
        if (this.field_678_p == this.field_677_q) {
            this.setEntityDead();
        }
    }
    
    @Override
    public int func_404_c() {
        return 3;
    }
}
