package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;

public class EntityBoat extends Entity
{
    public int boatCurrentDamage;
    public int boatTimeSinceHit;
    public int boatRockDirection;
    private int field_9394_d;
    private double field_9393_e;
    private double field_9392_f;
    private double field_9391_g;
    private double field_9390_h;
    private double field_9389_i;
    private double field_9388_j;
    private double field_9387_k;
    private double field_9386_l;
    
    public EntityBoat(final World world) {
        super(world);
        this.boatCurrentDamage = 0;
        this.boatTimeSinceHit = 0;
        this.boatRockDirection = 1;
        this.preventEntitySpawning = true;
        this.setSize(1.5f, 0.6f);
        this.yOffset = this.height / 2.0f;
        this.field_640_aG = false;
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public AxisAlignedBB getCollisionBox(final Entity entity) {
        return entity.boundingBox;
    }
    
    @Override
    public AxisAlignedBB func_372_f_() {
        return this.boundingBox;
    }
    
    @Override
    public boolean canBePushed() {
        return true;
    }
    
    public EntityBoat(final World world, final double d, final double d1, final double d2) {
        this(world);
        this.setPosition(d, d1 + this.yOffset, d2);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.prevPosX = d;
        this.prevPosY = d1;
        this.prevPosZ = d2;
    }
    
    @Override
    public double getMountedYOffset() {
        return this.height * 0.0 - 0.30000001192092896;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        if (this.worldObj.multiplayerWorld || this.isDead) {
            this.boatRockDirection = -this.boatRockDirection;
            this.boatTimeSinceHit = 10;
            this.boatCurrentDamage += i * 10;
            return true;
        }
        this.boatRockDirection = -this.boatRockDirection;
        this.boatTimeSinceHit = 10;
        this.boatCurrentDamage += i * 10;
        if (this.boatCurrentDamage > 40) {
            if (!this.worldObj.multiplayerWorld) {
                this.dropItemWithOffset(Item.boat.shiftedIndex, 1, 0.0f);
            }
            this.setEntityDead();
        }
        return true;
    }
    
    @Override
    public void performHurtAnimation() {
        this.boatRockDirection = -this.boatRockDirection;
        this.boatTimeSinceHit = 10;
        this.boatCurrentDamage += this.boatCurrentDamage * 10;
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.boatTimeSinceHit > 0) {
            --this.boatTimeSinceHit;
        }
        if (this.boatCurrentDamage > 0) {
            --this.boatCurrentDamage;
        }
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        final int i = 5;
        double d = 0.0;
        for (int j = 0; j < i; ++j) {
            final double d2 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (j + 0) / i - 0.125;
            final double d3 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (j + 1) / i - 0.125;
            final AxisAlignedBB axisalignedbb = AxisAlignedBB.getBoundingBoxFromPool(this.boundingBox.minX, d2, this.boundingBox.minZ, this.boundingBox.maxX, d3, this.boundingBox.maxZ);
            if (this.worldObj.isAABBInMaterial(axisalignedbb, Material.water)) {
                d += 1.0 / i;
            }
        }
        if (this.worldObj.multiplayerWorld && this.riddenByEntity == null) {
            if (this.field_9394_d > 0) {
                final double d4 = this.posX + (this.field_9393_e - this.posX) / this.field_9394_d;
                final double d5 = this.posY + (this.field_9392_f - this.posY) / this.field_9394_d;
                final double d6 = this.posZ + (this.field_9391_g - this.posZ) / this.field_9394_d;
                double d7;
                for (d7 = this.field_9390_h - this.rotationYaw; d7 < -180.0; d7 += 360.0) {}
                while (d7 >= 180.0) {
                    d7 -= 360.0;
                }
                this.rotationYaw += (float)(d7 / this.field_9394_d);
                this.rotationPitch += (float)((this.field_9389_i - this.rotationPitch) / this.field_9394_d);
                --this.field_9394_d;
                this.setPosition(d4, d5, d6);
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }
            else {
                final double d8 = this.posX + this.motionX;
                final double d9 = this.posY + this.motionY;
                final double d10 = this.posZ + this.motionZ;
                this.setPosition(d8, d9, d10);
                if (this.onGround) {
                    this.motionX *= 0.5;
                    this.motionY *= 0.5;
                    this.motionZ *= 0.5;
                }
                this.motionX *= 0.9900000095367432;
                this.motionY *= 0.949999988079071;
                this.motionZ *= 0.9900000095367432;
            }
            return;
        }
        final double d11 = d * 2.0 - 1.0;
        this.motionY += 0.03999999910593033 * d11;
        if (this.riddenByEntity != null) {
            this.motionX += this.riddenByEntity.motionX * 0.4;
            this.motionZ += this.riddenByEntity.motionZ * 0.4;
        }
        final double d12 = 0.4;
        if (this.motionX < -d12) {
            this.motionX = -d12;
        }
        if (this.motionX > d12) {
            this.motionX = d12;
        }
        if (this.motionZ < -d12) {
            this.motionZ = -d12;
        }
        if (this.motionZ > d12) {
            this.motionZ = d12;
        }
        if (this.onGround) {
            this.motionX *= 0.5;
            this.motionY *= 0.5;
            this.motionZ *= 0.5;
        }
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        final double d13 = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
        if (d13 > 0.15) {
            final double d14 = Math.cos(this.rotationYaw * 3.141592653589793 / 180.0);
            final double d15 = Math.sin(this.rotationYaw * 3.141592653589793 / 180.0);
            for (int i2 = 0; i2 < 1.0 + d13 * 60.0; ++i2) {
                final double d16 = this.rand.nextFloat() * 2.0f - 1.0f;
                final double d17 = (this.rand.nextInt(2) * 2 - 1) * 0.7;
                if (this.rand.nextBoolean()) {
                    final double d18 = this.posX - d14 * d16 * 0.8 + d15 * d17;
                    final double d19 = this.posZ - d15 * d16 * 0.8 - d14 * d17;
                    this.worldObj.spawnParticle("splash", d18, this.posY - 0.125, d19, this.motionX, this.motionY, this.motionZ);
                }
                else {
                    final double d20 = this.posX + d14 + d15 * d16 * 0.7;
                    final double d21 = this.posZ + d15 - d14 * d16 * 0.7;
                    this.worldObj.spawnParticle("splash", d20, this.posY - 0.125, d21, this.motionX, this.motionY, this.motionZ);
                }
            }
        }
        if (!this.isCollidedHorizionally || d13 <= 0.15) {
            this.motionX *= 0.9900000095367432;
            this.motionY *= 0.949999988079071;
            this.motionZ *= 0.9900000095367432;
        }
        this.rotationPitch = 0.0f;
        double d22 = this.rotationYaw;
        final double d23 = this.prevPosX - this.posX;
        final double d24 = this.prevPosZ - this.posZ;
        if (d23 * d23 + d24 * d24 > 0.001) {
            d22 = (float)(Math.atan2(d24, d23) * 180.0 / 3.141592653589793);
        }
        double d25;
        for (d25 = d22 - this.rotationYaw; d25 >= 180.0; d25 -= 360.0) {}
        while (d25 < -180.0) {
            d25 += 360.0;
        }
        if (d25 > 20.0) {
            d25 = 20.0;
        }
        if (d25 < -20.0) {
            d25 = -20.0;
        }
        this.setRotation(this.rotationYaw += (float)d25, this.rotationPitch);
        final List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(0.20000000298023224, 0.0, 0.20000000298023224));
        if (list != null && list.size() > 0) {
            for (int j2 = 0; j2 < list.size(); ++j2) {
                final Entity entity = list.get(j2);
                if (entity != this.riddenByEntity && entity.canBePushed() && entity instanceof EntityBoat) {
                    entity.applyEntityCollision(this);
                }
            }
        }
        for (int k1 = 0; k1 < 4; ++k1) {
            final int l1 = MathHelper.floor_double(this.posX + (k1 % 2 - 0.5) * 0.8);
            final int i3 = MathHelper.floor_double(this.posY);
            final int j3 = MathHelper.floor_double(this.posZ + (k1 / 2 - 0.5) * 0.8);
            if (this.worldObj.getBlockId(l1, i3, j3) == Block.snow.blockID) {
                this.worldObj.setBlockWithNotify(l1, i3, j3, 0);
            }
        }
        if (this.riddenByEntity != null && this.riddenByEntity.isDead) {
            this.riddenByEntity = null;
        }
    }
    
    @Override
    protected void updateRiderPosition() {
        if (this.riddenByEntity == null) {
            return;
        }
        final double d = Math.cos(this.rotationYaw * 3.141592653589793 / 180.0) * 0.4;
        final double d2 = Math.sin(this.rotationYaw * 3.141592653589793 / 180.0) * 0.4;
        this.riddenByEntity.setPosition(this.posX + d, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ + d2);
    }
    
    @Override
    protected void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    protected void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
    
    @Override
    public boolean interact(final EntityPlayer entityplayer) {
        if (!this.worldObj.multiplayerWorld) {
            entityplayer.mountEntity(this);
        }
        return true;
    }
}
