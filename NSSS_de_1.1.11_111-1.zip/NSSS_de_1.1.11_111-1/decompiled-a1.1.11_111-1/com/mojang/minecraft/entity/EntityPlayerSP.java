package com.mojang.minecraft.entity;

import com.mojang.minecraft.*;
import com.mojang.minecraft.sound.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.gui.*;
import com.mojang.minecraft.entity.item.*;

public class EntityPlayerSP extends EntityPlayer
{
    public MovementInput currentInput;
    private Minecraft mc;
    public AmbientLoopHandler loopHandler;
    private int stamina;
    private boolean exhausted;
    
    public EntityPlayerSP(final Minecraft minecraft, final World world, final Session session) {
        super(world);
        this.mc = minecraft;
        this.stamina = this.getMaxStamina();
        this.playerName = session.username;
        this.modelRene = false;
        if (session != null && session.username != null && session.username.length() > 0 && session.getProfile().getId() != null) {
            final SkinManager skins = this.mc.skins;
            SkinManager.getSkin(session.getProfile(), this);
        }
        this.loopHandler = new AmbientLoopHandler(world, this);
    }
    
    public int getMaxStamina() {
        return this.health * 20;
    }
    
    public boolean getIsExhausted() {
        return this.exhausted;
    }
    
    public int getStamina() {
        return this.stamina;
    }
    
    public void setStamina(final int stam) {
        this.stamina = stam;
        if (stam == this.getMaxStamina()) {
            this.exhausted = false;
        }
    }
    
    public Double getExhaustion() {
        return 1.0 - this.stamina / 400.0;
    }
    
    public void updateEntityActionState() {
        super.updateEntityActionState();
        this.movingLeftRight = this.currentInput.movementLeftRight;
        this.movingForwardBack = this.currentInput.movementForwardBack;
        this.isJumping = this.currentInput.movementIsJumping;
        this.setRunning(this.currentInput.movementIsRunning && !this.exhausted);
        if (this.stamina <= 0) {
            this.exhausted = true;
        }
        if (this.stamina < this.getMaxStamina() && (!this.isRunning() || this.exhausted)) {
            ++this.stamina;
            if (this.stamina >= this.getMaxStamina()) {
                this.exhausted = false;
            }
        }
        if (this.stamina > this.getMaxStamina()) {
            this.stamina = this.getMaxStamina();
        }
    }
    
    private float getDirection() {
        float yaw = this.mc.thePlayer.rotationYaw;
        final float moveForward = this.mc.thePlayer.movingForwardBack;
        final float moveStrafing = this.mc.thePlayer.movingLeftRight;
        yaw += ((moveForward < 0.0f) ? 180 : 0);
        final int yaw2 = (moveForward == 0.0f) ? 90 : ((moveForward < 0.0f) ? -45 : 45);
        if (moveStrafing < 0.0f) {
            yaw += yaw2;
        }
        if (moveStrafing > 0.0f) {
            yaw -= yaw2;
        }
        return yaw * 0.017453292f;
    }
    
    public double getSpeed() {
        return Math.sqrt(MathHelper.square(this.motionX) + MathHelper.square(this.motionZ));
    }
    
    public void setSpeed(final double speed) {
        this.mc.thePlayer.motionX = -MathHelper.sin(this.getDirection()) * speed;
        this.mc.thePlayer.motionZ = MathHelper.cos(this.getDirection()) * speed;
    }
    
    @Override
    public void onLivingUpdate() {
        this.currentInput.func_797_a(this);
        if (this.currentInput.movementIsSneaking && this.ySize < 0.2f) {
            this.ySize = 0.2f;
        }
        if (!this.exhausted && this.isRunning() && !this.isInWeb && (this.currentInput.movementForwardBack != 0.0f || this.currentInput.movementLeftRight != 0.0f) && this.worldObj.difficulty < 3 && this.entityBeingRidden == null && !this.handleWaterMovement() && !this.handleLavaMovement()) {
            if (this.worldObj.difficulty == 2 && !this.isCreative) {
                --this.stamina;
                --this.stamina;
                this.setSpeed(0.2);
            }
            else {
                this.setSpeed(0.2);
            }
        }
        if (this.isCreative && this.mc.playerController != new PlayerControllerCreative(this.mc)) {
            this.mc.playerController = new PlayerControllerCreative(this.mc);
        }
        super.onLivingUpdate();
    }
    
    public void resetPlayerKeyState() {
        this.currentInput.func_798_a();
    }
    
    @Override
    public void handleKeyPress(final int i, final boolean flag) {
        this.currentInput.func_796_a(i, flag);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setInteger("Score", this.score);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
        this.score = nbttagcompound.getInteger("Score");
    }
    
    @Override
    public void displayGUIChest(final IInventory iinventory) {
        this.mc.setCurrentScreen(new GuiChest(this.inventory, iinventory));
    }
    
    @Override
    public void displayGUIEditSign(final TileEntitySign tileentitysign) {
        this.mc.setCurrentScreen(new GuiEditSign(tileentitysign));
    }
    
    public void respawnPlayer() {
        this.mc.respawn(false, 0);
    }
    
    @Override
    public void displayWorkbenchGUI(final int i, final int j, final int k) {
        this.mc.setCurrentScreen(new GuiCrafting(this.inventory, this.worldObj, i, j, k));
    }
    
    @Override
    public void displayGUIFurnace(final TileEntityFurnace tileentityfurnace) {
        this.mc.setCurrentScreen(new GuiFurnace(this.inventory, tileentityfurnace));
    }
    
    public void attackEntity(final Entity entity) {
        final int i = this.inventory.getDamageVsEntity(entity);
        if (i > 0) {
            entity.attackEntityFrom(this, i);
            final ItemStack itemstack = this.getCurrentEquippedItem();
            if (itemstack != null && entity instanceof EntityLiving) {
                itemstack.hitEntity((EntityLiving)entity);
                if (itemstack.stackSize <= 0) {
                    itemstack.func_1097_a(this);
                    this.destroyCurrentEquippedItem();
                }
            }
        }
    }
    
    @Override
    public void onEntityUpdate() {
        super.onEntityUpdate();
        if (this.mc.soundMGR.getLoaded()) {
            this.loopHandler.update();
        }
    }
    
    @Override
    public void onItemPickup(final Entity entity, final int i) {
        this.mc.effectRenderer.addEffect(new EntityPickupFX(this.mc.mcWorld, entity, this, -0.5f));
    }
    
    public int getPlayerArmorValue() {
        return this.inventory.getTotalArmorValue();
    }
    
    @Override
    public void useCurrentItemOnEntity(final Entity entity) {
        if (entity.interact(this)) {
            return;
        }
        final ItemStack itemstack = this.getCurrentEquippedItem();
        if (itemstack != null && entity instanceof EntityLiving) {
            itemstack.useItemOnEntity((EntityLiving)entity);
            if (itemstack.stackSize <= 0) {
                itemstack.func_1097_a(this);
                this.destroyCurrentEquippedItem();
            }
        }
    }
    
    public void sendChatMessage(final String s) {
    }
    
    public void func_462_n() {
    }
    
    @Override
    public boolean getIsSneaking() {
        return this.currentInput.movementIsSneaking;
    }
    
    @Override
    public double getRealMoveSpeed() {
        if (this.isRunning()) {
            return 0.75;
        }
        return 0.5;
    }
    
    @Override
    public int posXInt() {
        return (int)Math.round(this.posX);
    }
    
    @Override
    public int posYInt() {
        return (int)Math.round(this.posY);
    }
    
    @Override
    public int posZInt() {
        return (int)Math.round(this.posZ);
    }
    
    public void setHealth(final int i) {
        final int j = this.health - i;
        if (j <= 0) {
            this.health = i;
            if (j < 0) {
                this.heartsLife = this.maxHealth / 2;
            }
        }
        else {
            this.field_701_U = j;
            this.prevHealth = this.health;
            this.heartsLife = this.maxHealth;
            this.damageEntity(j);
            final int n = 10;
            this.maxHurtTime = n;
            this.hurtTime = n;
        }
    }
    
    public void closeScreen() {
        super.closeScreen();
        this.mc.setCurrentScreen(null);
    }
}
