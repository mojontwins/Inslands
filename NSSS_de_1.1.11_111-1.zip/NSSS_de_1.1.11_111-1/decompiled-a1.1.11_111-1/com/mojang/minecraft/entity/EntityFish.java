package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.item.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;

public class EntityFish extends Entity
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private boolean inGround;
    public int shake;
    public EntityPlayer angler;
    private int ticksInGround;
    private int ticksInAir;
    private int ticksCatchable;
    public Entity bobber;
    private int field_6388_l;
    private double field_6387_m;
    private double field_6386_n;
    private double field_6385_o;
    private double field_6384_p;
    private double field_6383_q;
    private double velocityX;
    private double velocityY;
    private double velocityZ;
    
    public EntityFish(final World world) {
        super(world);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.shake = 0;
        this.ticksInAir = 0;
        this.ticksCatchable = 0;
        this.bobber = null;
        this.setSize(0.25f, 0.25f);
    }
    
    public EntityFish(final World world, final double d, final double d1, final double d2) {
        this(world);
        this.setPosition(d, d1, d2);
    }
    
    public EntityFish(final World world, final EntityPlayer entityplayer) {
        super(world);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.shake = 0;
        this.ticksInAir = 0;
        this.ticksCatchable = 0;
        this.bobber = null;
        this.angler = entityplayer;
        (this.angler.fishEntity = this).setSize(0.25f, 0.25f);
        this.setLocationAndAngles(entityplayer.posX, entityplayer.posY + 1.62 - entityplayer.yOffset, entityplayer.posZ, entityplayer.rotationYaw, entityplayer.rotationPitch);
        this.posX -= MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.posY -= 0.10000000149011612;
        this.posZ -= MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * 0.16f;
        this.setPosition(this.posX, this.posY, this.posZ);
        this.yOffset = 0.0f;
        final float f = 0.4f;
        this.motionX = -MathHelper.sin(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionZ = MathHelper.cos(this.rotationYaw / 180.0f * 3.141593f) * MathHelper.cos(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.motionY = -MathHelper.sin(this.rotationPitch / 180.0f * 3.141593f) * f;
        this.func_4042_a(this.motionX, this.motionY, this.motionZ, 1.5f, 1.0f);
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public boolean isInRangeToRenderDist(final double d) {
        double d2 = this.boundingBox.getAverageEdgeLength() * 4.0;
        d2 *= 64.0;
        return d < d2 * d2;
    }
    
    public void func_4042_a(double d, double d1, double d2, final float f, final float f1) {
        final float f2 = MathHelper.sqrt_double(d * d + d1 * d1 + d2 * d2);
        d /= f2;
        d1 /= f2;
        d2 /= f2;
        d += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d1 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d2 += this.rand.nextGaussian() * 0.007499999832361937 * f1;
        d *= f;
        d1 *= f;
        d2 *= f;
        this.motionX = d;
        this.motionY = d1;
        this.motionZ = d2;
        final float f3 = MathHelper.sqrt_double(d * d + d2 * d2);
        this.rotationYaw = (float)(Math.atan2(d, d2) * 180.0 / 3.1415927410125732);
        this.rotationPitch = (float)(Math.atan2(d1, f3) * 180.0 / 3.1415927410125732);
        this.ticksInGround = 0;
    }
    
    @Override
    public void setPositionAndRotation2(final double d, final double d1, final double d2, final float f, final float f1, final int i) {
        this.field_6387_m = d;
        this.field_6386_n = d1;
        this.field_6385_o = d2;
        this.field_6384_p = f;
        this.field_6383_q = f1;
        this.field_6388_l = i;
        this.motionX = this.velocityX;
        this.motionY = this.velocityY;
        this.motionZ = this.velocityZ;
    }
    
    @Override
    public void setVelocity(final double d, final double d1, final double d2) {
        this.motionX = d;
        this.velocityX = d;
        this.motionY = d1;
        this.velocityY = d1;
        this.motionZ = d2;
        this.velocityZ = d2;
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (this.field_6388_l > 0) {
            final double d = this.posX + (this.field_6387_m - this.posX) / this.field_6388_l;
            final double d2 = this.posY + (this.field_6386_n - this.posY) / this.field_6388_l;
            final double d3 = this.posZ + (this.field_6385_o - this.posZ) / this.field_6388_l;
            double d4;
            for (d4 = this.field_6384_p - this.rotationYaw; d4 < -180.0; d4 += 360.0) {}
            while (d4 >= 180.0) {
                d4 -= 360.0;
            }
            this.rotationYaw += (float)(d4 / this.field_6388_l);
            this.rotationPitch += (float)((this.field_6383_q - this.rotationPitch) / this.field_6388_l);
            --this.field_6388_l;
            this.setPosition(d, d2, d3);
            this.setRotation(this.rotationYaw, this.rotationPitch);
            return;
        }
        if (!this.worldObj.multiplayerWorld) {
            final ItemStack itemstack = this.angler.getCurrentEquippedItem();
            if (this.angler.isDead || !this.angler.isEntityAlive() || itemstack == null || itemstack.getItem() != Item.fishingRod || this.getDistanceSqToEntity(this.angler) > 1024.0) {
                this.setEntityDead();
                this.angler.fishEntity = null;
                return;
            }
            if (this.bobber != null) {
                if (!this.bobber.isDead) {
                    this.posX = this.bobber.posX;
                    this.posY = this.bobber.boundingBox.minY + this.bobber.height * 0.8;
                    this.posZ = this.bobber.posZ;
                    return;
                }
                this.bobber = null;
            }
        }
        if (this.shake > 0) {
            --this.shake;
        }
        if (this.inGround) {
            final int i = this.worldObj.getBlockId(this.xTile, this.yTile, this.zTile);
            if (i == this.inTile) {
                ++this.ticksInGround;
                if (this.ticksInGround == 1200) {
                    this.setEntityDead();
                }
                return;
            }
            this.inGround = false;
            this.motionX *= this.rand.nextFloat() * 0.2f;
            this.motionY *= this.rand.nextFloat() * 0.2f;
            this.motionZ *= this.rand.nextFloat() * 0.2f;
            this.ticksInGround = 0;
            this.ticksInAir = 0;
        }
        else {
            ++this.ticksInAir;
        }
        Vec3D vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        Vec3D vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        MovingObjectPosition movingobjectposition = this.worldObj.rayTraceBlocks(vec3d, vec3d2);
        vec3d = Vec3D.createVector(this.posX, this.posY, this.posZ);
        vec3d2 = Vec3D.createVector(this.posX + this.motionX, this.posY + this.motionY, this.posZ + this.motionZ);
        if (movingobjectposition != null) {
            vec3d2 = Vec3D.createVector(movingobjectposition.hitVec.xCoord, movingobjectposition.hitVec.yCoord, movingobjectposition.hitVec.zCoord);
        }
        Entity entity = null;
        final List list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0));
        double d5 = 0.0;
        for (int j = 0; j < list.size(); ++j) {
            final Entity entity2 = list.get(j);
            if (entity2.canBeCollidedWith()) {
                if (entity2 != this.angler || this.ticksInAir >= 5) {
                    final float f2 = 0.3f;
                    final AxisAlignedBB axisalignedbb = entity2.boundingBox.expand(f2, f2, f2);
                    final MovingObjectPosition movingobjectposition2 = axisalignedbb.func_1169_a(vec3d, vec3d2);
                    if (movingobjectposition2 != null) {
                        final double d6 = vec3d.distanceTo(movingobjectposition2.hitVec);
                        if (d6 < d5 || d5 == 0.0) {
                            entity = entity2;
                            d5 = d6;
                        }
                    }
                }
            }
        }
        if (entity != null) {
            movingobjectposition = new MovingObjectPosition(entity);
        }
        if (movingobjectposition != null) {
            if (movingobjectposition.entityHit != null) {
                if (movingobjectposition.entityHit.attackEntityFrom(this.angler, 0)) {
                    this.bobber = movingobjectposition.entityHit;
                }
            }
            else {
                this.inGround = true;
            }
        }
        if (this.inGround) {
            return;
        }
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        final float f3 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionZ * this.motionZ);
        this.rotationYaw = (float)(Math.atan2(this.motionX, this.motionZ) * 180.0 / 3.1415927410125732);
        this.rotationPitch = (float)(Math.atan2(this.motionY, f3) * 180.0 / 3.1415927410125732);
        while (this.rotationPitch < -180.0f) {
            this.rotationPitch -= 360.0f;
        }
        this.rotationPitch *= 0.2f;
        this.rotationYaw *= 0.2f;
        float f4 = 0.92f;
        if (this.onGround) {
            f4 = 0.5f;
        }
        final int k = 5;
        double d7 = 0.0;
        for (int l = 0; l < k; ++l) {
            final double d8 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (l + 0) / k - 0.125 + 0.125;
            final double d9 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (l + 1) / k - 0.125 + 0.125;
            final AxisAlignedBB axisalignedbb2 = AxisAlignedBB.getBoundingBoxFromPool(this.boundingBox.minX, d8, this.boundingBox.minZ, this.boundingBox.maxX, d9, this.boundingBox.maxZ);
            if (this.worldObj.isAABBInMaterial(axisalignedbb2, Material.water)) {
                d7 += 1.0 / k;
            }
        }
        if (d7 > 0.0) {
            if (this.ticksCatchable > 0) {
                --this.ticksCatchable;
            }
            else {
                final char c = '\u01f4';
                if (this.rand.nextInt(c) == 0) {
                    this.ticksCatchable = this.rand.nextInt(30) + 10;
                    this.motionY -= 0.20000000298023224;
                    this.worldObj.playSoundAtEntity(this, "random.splash", 0.25f, 1.0f + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4f);
                    final float f5 = (float)MathHelper.floor_double(this.boundingBox.minY);
                    for (int i2 = 0; i2 < 1.0f + this.width * 20.0f; ++i2) {
                        final float f6 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                        final float f7 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                        this.worldObj.spawnParticle("bubble", this.posX + f6, f5 + 1.0f, this.posZ + f7, this.motionX, this.motionY - this.rand.nextFloat() * 0.2f, this.motionZ);
                    }
                    for (int j2 = 0; j2 < 1.0f + this.width * 20.0f; ++j2) {
                        final float f8 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                        final float f9 = (this.rand.nextFloat() * 2.0f - 1.0f) * this.width;
                        this.worldObj.spawnParticle("splash", this.posX + f8, f5 + 1.0f, this.posZ + f9, this.motionX, this.motionY, this.motionZ);
                    }
                }
            }
        }
        if (this.ticksCatchable > 0) {
            this.motionY -= this.rand.nextFloat() * this.rand.nextFloat() * this.rand.nextFloat() * 0.2;
        }
        final double d10 = d7 * 2.0 - 1.0;
        this.motionY += 0.03999999910593033 * d10;
        if (d7 > 0.0) {
            f4 *= (float)0.9;
            this.motionY *= 0.8;
        }
        this.motionX *= f4;
        this.motionY *= f4;
        this.motionZ *= f4;
        this.setPosition(this.posX, this.posY, this.posZ);
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setShort("xTile", (short)this.xTile);
        nbttagcompound.setShort("yTile", (short)this.yTile);
        nbttagcompound.setShort("zTile", (short)this.zTile);
        nbttagcompound.setByte("inTile", (byte)this.inTile);
        nbttagcompound.setByte("shake", (byte)this.shake);
        nbttagcompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.xTile = nbttagcompound.getShort("xTile");
        this.yTile = nbttagcompound.getShort("yTile");
        this.zTile = nbttagcompound.getShort("zTile");
        this.inTile = (nbttagcompound.getByte("inTile") & 0xFF);
        this.shake = (nbttagcompound.getByte("shake") & 0xFF);
        this.inGround = (nbttagcompound.getByte("inGround") == 1);
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
    
    public int catchFish() {
        byte byte0 = 0;
        if (this.bobber != null) {
            final double d = this.angler.posX - this.posX;
            final double d2 = this.angler.posY - this.posY;
            final double d3 = this.angler.posZ - this.posZ;
            final double d4 = MathHelper.sqrt_double(d * d + d2 * d2 + d3 * d3);
            final double d5 = 0.1;
            final Entity bobber = this.bobber;
            bobber.motionX += d * d5;
            final Entity bobber2 = this.bobber;
            bobber2.motionY += d2 * d5 + MathHelper.sqrt_double(d4) * 0.08;
            final Entity bobber3 = this.bobber;
            bobber3.motionZ += d3 * d5;
            byte0 = 3;
        }
        else if (this.ticksCatchable > 0) {
            final EntityItem entityitem = new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Item.fishRaw));
            final double d6 = this.angler.posX - this.posX;
            final double d7 = this.angler.posY - this.posY;
            final double d8 = this.angler.posZ - this.posZ;
            final double d9 = MathHelper.sqrt_double(d6 * d6 + d7 * d7 + d8 * d8);
            final double d10 = 0.1;
            entityitem.motionX = d6 * d10;
            entityitem.motionY = d7 * d10 + MathHelper.sqrt_double(d9) * 0.08;
            entityitem.motionZ = d8 * d10;
            this.worldObj.entityJoinedWorld(entityitem);
            byte0 = 1;
        }
        if (this.inGround) {
            byte0 = 2;
        }
        this.setEntityDead();
        this.angler.fishEntity = null;
        return byte0;
    }
}
