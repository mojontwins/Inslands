package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.render.*;

public class EntityDiggingFX extends EntityFX
{
    public EntityDiggingFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5, final Block block) {
        super(world, d, d1, d2, d3, d4, d5);
        this.particleTextureIndex = block.blockIndexInTexture;
        this.field_664_h = block.field_357_bm;
        final float particleRed = 0.6f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleScale /= 2.0f;
    }
    
    @Override
    public int func_404_c() {
        return 1;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        final float f6 = (this.particleTextureIndex % 16 + this.field_669_c / 4.0f) / 16.0f;
        final float f7 = f6 + 0.01560938f;
        final float f8 = (this.particleTextureIndex / 16 + this.field_668_d / 4.0f) / 16.0f;
        final float f9 = f8 + 0.01560938f;
        final float f10 = 0.1f * this.particleScale;
        final float f11 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - EntityDiggingFX.field_660_l);
        final float f12 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - EntityDiggingFX.field_659_m);
        final float f13 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - EntityDiggingFX.field_658_n);
        final float f14 = this.getEntityBrightness(f);
        tessellator.setColorOpaque_F(f14 * this.particleRed, f14 * this.particleGreen, f14 * this.particleBlue);
        tessellator.addVertexWithUV(f11 - f1 * f10 - f4 * f10, f12 - f2 * f10, f13 - f3 * f10 - f5 * f10, f6, f9);
        tessellator.addVertexWithUV(f11 - f1 * f10 + f4 * f10, f12 + f2 * f10, f13 - f3 * f10 + f5 * f10, f6, f8);
        tessellator.addVertexWithUV(f11 + f1 * f10 + f4 * f10, f12 + f2 * f10, f13 + f3 * f10 + f5 * f10, f7, f8);
        tessellator.addVertexWithUV(f11 + f1 * f10 - f4 * f10, f12 - f2 * f10, f13 + f3 * f10 - f5 * f10, f7, f9);
    }
}
