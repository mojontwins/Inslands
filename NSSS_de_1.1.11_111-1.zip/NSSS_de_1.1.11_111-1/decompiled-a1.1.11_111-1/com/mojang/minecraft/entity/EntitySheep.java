package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;

public class EntitySheep extends EntityAnimals
{
    int field_754_i;
    
    public EntitySheep(final World world) {
        super(world);
        this.field_754_i = 0;
        this.setSheared(false);
        this.scoreYield = 10;
        this.field_754_i = 0;
        this.texture = "/mob/sheep.png";
        this.setSize(0.9f, 1.3f);
    }
    
    @Override
    protected void entityInit() {
        super.entityInit();
        this.dataWatcher.addObject(16, new Byte((byte)0));
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        if (!this.getSheared() && entity instanceof EntityLiving && !(this.worldObj instanceof WorldClient)) {
            this.setSheared(true);
            for (int j = 1 + this.rand.nextInt(3), k = 0; k < j; ++k) {
                final EntityItem dropItemWithOffset;
                final EntityItem entityitem = dropItemWithOffset = this.dropItemWithOffset(Block.cloth.blockID, 1, 1.0f);
                dropItemWithOffset.motionY += this.rand.nextFloat() * 0.05f;
                final EntityItem entityItem = entityitem;
                entityItem.motionX += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1f;
                final EntityItem entityItem2 = entityitem;
                entityItem2.motionZ += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.1f;
                this.field_754_i = this.rand.nextInt(1200);
            }
        }
        return super.attackEntityFrom(entity, i);
    }
    
    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (this.getSheared() && --this.field_754_i <= 0 && !this.worldObj.multiplayerWorld) {
            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0f, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2f + 1.0f);
            this.setSheared(false);
        }
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
        nbttagcompound.setBool("Sheared", this.getSheared());
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
        this.setSheared(nbttagcompound.getBoolean("Sheared"));
    }
    
    @Override
    protected String idleSound() {
        return "mob.sheep";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.sheep";
    }
    
    @Override
    protected String deathSound() {
        return "mob.sheep";
    }
    
    public boolean getSheared() {
        return (this.dataWatcher.getWatchableObjectByte(16) & 0x10) != 0x0;
    }
    
    public void setSheared(final boolean flag) {
        final byte byte0 = this.dataWatcher.getWatchableObjectByte(16);
        if (flag) {
            this.dataWatcher.updateObject(16, (byte)(byte0 | 0x10));
        }
        else {
            this.dataWatcher.updateObject(16, (byte)(byte0 & 0xFFFFFFEF));
        }
    }
}
