package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.util.*;

public abstract class EntityAnimals extends EntityCreature
{
    public EntityAnimals(final World world) {
        super(world);
        this.indevai = false;
    }
    
    @Override
    protected float getBlockPathWeight(final int i, final int j, final int k) {
        if (this.worldObj.getBlockId(i, j - 1, k) == Block.grass.blockID) {
            return 10.0f;
        }
        return this.worldObj.getBrightness(i, j, k) - 0.5f;
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    public boolean shouldSpawnOnTile() {
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.boundingBox.minY);
        final int k = MathHelper.floor_double(this.posZ);
        return this.worldObj.getBlockId(i, j - 1, k) == Block.grass.blockID && this.worldObj.getBlockLightValue(i, j, k) > 8 && super.shouldSpawnOnTile();
    }
    
    @Override
    public int func_421_b() {
        return 120;
    }
}
