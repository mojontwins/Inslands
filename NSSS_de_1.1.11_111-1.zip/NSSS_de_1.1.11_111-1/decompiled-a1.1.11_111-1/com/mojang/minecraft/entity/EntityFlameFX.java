package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;

public class EntityFlameFX extends EntityFX
{
    private float field_672_a;
    
    public EntityFlameFX(final World world, double d, double d1, double d2, final double d3, final double d4, final double d5) {
        super(world, d, d1, d2, d3, d4, d5);
        this.motionX = this.motionX * 0.009999999776482582 + d3;
        this.motionY = this.motionY * 0.009999999776482582 + d4;
        this.motionZ = this.motionZ * 0.009999999776482582 + d5;
        d += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.05f;
        d1 += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.05f;
        d2 += (this.rand.nextFloat() - this.rand.nextFloat()) * 0.05f;
        this.field_672_a = this.particleScale;
        final float particleRed = 1.0f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2)) + 4;
        this.noClip = true;
        this.particleTextureIndex = 48;
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        final float f6 = (this.particleAge + f) / this.particleMaxAge;
        this.particleScale = this.field_672_a * (1.0f - f6 * f6 * 0.5f);
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public float getEntityBrightness(final float f) {
        float f2 = (this.particleAge + f) / this.particleMaxAge;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        final float f3 = super.getEntityBrightness(f);
        return f3 * f2 + (1.0f - f2);
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9599999785423279;
        this.motionY *= 0.9599999785423279;
        this.motionZ *= 0.9599999785423279;
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
        }
    }
}
