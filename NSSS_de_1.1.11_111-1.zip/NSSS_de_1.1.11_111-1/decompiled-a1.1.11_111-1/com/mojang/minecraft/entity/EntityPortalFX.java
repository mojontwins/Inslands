package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.render.*;

public class EntityPortalFX extends EntityFX
{
    private float field_4083_a;
    private double field_4086_p;
    private double field_4085_q;
    private double field_4084_r;
    
    public EntityPortalFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        super(world, d, d1, d2, d3, d4, d5);
        this.motionX = d3;
        this.motionY = d4;
        this.motionZ = d5;
        this.posX = d;
        this.field_4086_p = d;
        this.posY = d1;
        this.field_4085_q = d1;
        this.posZ = d2;
        this.field_4084_r = d2;
        final float f = this.rand.nextFloat() * 0.6f + 0.4f;
        final float n = this.rand.nextFloat() * 0.2f + 0.5f;
        this.particleScale = n;
        this.field_4083_a = n;
        final float particleRed = 1.0f * f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.particleGreen *= 0.3f;
        this.particleRed *= 0.9f;
        this.particleMaxAge = (int)(Math.random() * 10.0) + 40;
        this.noClip = true;
        this.particleTextureIndex = (int)(Math.random() * 8.0);
    }
    
    @Override
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        float f6 = (this.particleAge + f) / this.particleMaxAge;
        f6 = 1.0f - f6;
        f6 *= f6;
        f6 = 1.0f - f6;
        this.particleScale = this.field_4083_a * f6;
        super.renderParticle(tessellator, f, f1, f2, f3, f4, f5);
    }
    
    @Override
    public float getEntityBrightness(final float f) {
        final float f2 = super.getEntityBrightness(f);
        float f3 = this.particleAge / (float)this.particleMaxAge;
        f3 *= f3;
        f3 *= f3;
        return f2 * (1.0f - f3) + f3;
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        final float f2;
        float f = f2 = this.particleAge / (float)this.particleMaxAge;
        f = -f + f * f * 2.0f;
        f = 1.0f - f;
        this.posX = this.field_4086_p + this.motionX * f;
        this.posY = this.field_4085_q + this.motionY * f + (1.0f - f2);
        this.posZ = this.field_4084_r + this.motionZ * f;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
    }
}
