package com.mojang.minecraft.entity;

import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;
import java.util.*;
import com.mojang.minecraft.nbt.*;

public class EntityPainting extends Entity
{
    private int field_695_c;
    public int direction;
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public EnumArt art;
    
    public EntityPainting(final World world) {
        super(world);
        this.field_695_c = 0;
        this.direction = 0;
        this.yOffset = 0.0f;
        this.setSize(0.5f, 0.5f);
    }
    
    public EntityPainting(final World world, final int i, final int j, final int k, final int l) {
        this(world);
        this.xPosition = i;
        this.yPosition = j;
        this.zPosition = k;
        final ArrayList<EnumArt> arraylist = new ArrayList<EnumArt>();
        for (final EnumArt enumart : EnumArt.values()) {
            this.art = enumart;
            this.func_412_b(l);
            if (this.func_410_i()) {
                arraylist.add(enumart);
            }
        }
        if (arraylist.size() > 0) {
            this.art = arraylist.get(this.rand.nextInt(arraylist.size()));
        }
        this.func_412_b(l);
    }
    
    public EntityPainting(final World world, final int i, final int j, final int k, final int l, final String s) {
        this(world);
        this.xPosition = i;
        this.yPosition = j;
        this.zPosition = k;
        while (true) {
            for (final EnumArt enumart : EnumArt.values()) {
                if (enumart.title.equals(s)) {
                    this.art = enumart;
                    this.func_412_b(l);
                    return;
                }
            }
            continue;
        }
    }
    
    public void func_412_b(final int i) {
        this.direction = i;
        final float n = (float)(i * 90);
        this.rotationYaw = n;
        this.prevRotationYaw = n;
        if (this.art == null) {
            return;
        }
        float f = (float)this.art.sizeX;
        float f2 = (float)this.art.sizeY;
        float f3 = (float)this.art.sizeX;
        if (i == 0 || i == 2) {
            f3 = 0.5f;
        }
        else {
            f = 0.5f;
        }
        f /= 32.0f;
        f2 /= 32.0f;
        f3 /= 32.0f;
        float f4 = this.xPosition + 0.5f;
        float f5 = this.yPosition + 0.5f;
        float f6 = this.zPosition + 0.5f;
        final float f7 = 0.5625f;
        if (i == 0) {
            f6 -= f7;
        }
        if (i == 1) {
            f4 -= f7;
        }
        if (i == 2) {
            f6 += f7;
        }
        if (i == 3) {
            f4 += f7;
        }
        if (i == 0) {
            f4 -= this.func_411_c(this.art.sizeX);
        }
        if (i == 1) {
            f6 += this.func_411_c(this.art.sizeX);
        }
        if (i == 2) {
            f4 += this.func_411_c(this.art.sizeX);
        }
        if (i == 3) {
            f6 -= this.func_411_c(this.art.sizeX);
        }
        f5 += this.func_411_c(this.art.sizeY);
        this.setPosition(f4, f5, f6);
        final float f8 = -0.00625f;
        this.boundingBox.setBounds(f4 - f - f8, f5 - f2 - f8, f6 - f3 - f8, f4 + f + f8, f5 + f2 + f8, f6 + f3 + f8);
    }
    
    @Override
    protected void entityInit() {
    }
    
    private float func_411_c(final int i) {
        if (i == 32) {
            return 0.5f;
        }
        return (i != 64) ? 0.0f : 0.5f;
    }
    
    @Override
    public void onUpdate() {
        if (this.worldObj.multiplayerWorld) {
            return;
        }
        if (this.field_695_c++ == 100 && !this.func_410_i()) {
            this.field_695_c = 0;
            this.setEntityDead();
            this.worldObj.entityJoinedWorld(new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Item.painting)));
        }
    }
    
    public boolean func_410_i() {
        if (this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() > 0) {
            return false;
        }
        final int i = this.art.sizeX / 16;
        final int j = this.art.sizeY / 16;
        int k = this.xPosition;
        int l = this.yPosition;
        int i2 = this.zPosition;
        if (this.direction == 0) {
            k = MathHelper.floor_double(this.posX - this.art.sizeX / 32.0f);
        }
        if (this.direction == 1) {
            i2 = MathHelper.floor_double(this.posZ - this.art.sizeX / 32.0f);
        }
        if (this.direction == 2) {
            k = MathHelper.floor_double(this.posX - this.art.sizeX / 32.0f);
        }
        if (this.direction == 3) {
            i2 = MathHelper.floor_double(this.posZ - this.art.sizeX / 32.0f);
        }
        l = MathHelper.floor_double(this.posY - this.art.sizeY / 32.0f);
        for (int j2 = 0; j2 < i; ++j2) {
            for (int k2 = 0; k2 < j; ++k2) {
                Material material;
                if (this.direction == 0 || this.direction == 2) {
                    material = this.worldObj.getMaterialXYZ(k + j2, l + k2, this.zPosition);
                }
                else {
                    material = this.worldObj.getMaterialXYZ(this.xPosition, l + k2, i2 + j2);
                }
                if (!material.isSolidMaterial()) {
                    return false;
                }
            }
        }
        final List<?> list = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox);
        for (int l2 = 0; l2 < list.size(); ++l2) {
            if (list.get(l2) instanceof EntityPainting) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return true;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        if (this.worldObj.multiplayerWorld || this.isDead) {
            return true;
        }
        this.setEntityDead();
        this.worldObj.entityJoinedWorld(new EntityItem(this.worldObj, this.posX, this.posY, this.posZ, new ItemStack(Item.painting)));
        return true;
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setByte("Dir", (byte)this.direction);
        nbttagcompound.setString("Motive", this.art.title);
        nbttagcompound.setInteger("TileX", this.xPosition);
        nbttagcompound.setInteger("TileY", this.yPosition);
        nbttagcompound.setInteger("TileZ", this.zPosition);
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.direction = nbttagcompound.getByte("Dir");
        this.xPosition = nbttagcompound.getInteger("TileX");
        this.yPosition = nbttagcompound.getInteger("TileY");
        this.zPosition = nbttagcompound.getInteger("TileZ");
        final String s = nbttagcompound.getString("Motive");
        for (final EnumArt enumart : EnumArt.values()) {
            if (enumart.title.equals(s)) {
                this.art = enumart;
            }
        }
        if (this.art == null) {
            this.art = EnumArt.Kebab;
        }
        this.func_412_b(this.direction);
    }
}
