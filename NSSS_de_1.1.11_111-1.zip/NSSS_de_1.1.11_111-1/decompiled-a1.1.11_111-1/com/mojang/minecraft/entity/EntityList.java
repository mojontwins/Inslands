package com.mojang.minecraft.entity;

import java.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;

public class EntityList
{
    private static Map<String, Class<?>> stringClassHash;
    private static Map<Class<?>, String> field_1610_b;
    private static Map<Integer, Class<?>> field_1613_c;
    private static Map<Class<?>, Integer> field_1612_d;
    
    static {
        EntityList.stringClassHash = new HashMap<String, Class<?>>();
        EntityList.field_1610_b = new HashMap<Class<?>, String>();
        EntityList.field_1613_c = new HashMap<Integer, Class<?>>();
        EntityList.field_1612_d = new HashMap<Class<?>, Integer>();
        func_1080_a(EntityArrow.class, "Arrow", 10);
        func_1080_a(EntitySnowball.class, "Snowball", 11);
        func_1080_a(EntityItem.class, "Item", 1);
        func_1080_a(EntityPainting.class, "Painting", 9);
        func_1080_a(EntityLiving.class, "Mob", 48);
        func_1080_a(EntityMobs.class, "Monster", 49);
        func_1080_a(EntityCreeper.class, "Creeper", 50);
        func_1080_a(EntitySkeleton.class, "Skeleton", 51);
        func_1080_a(EntitySpider.class, "Spider", 52);
        func_1080_a(EntityGiant.class, "Giant", 53);
        func_1080_a(EntityZombie.class, "Zombie", 54);
        func_1080_a(EntitySlime.class, "Slime", 55);
        func_1080_a(EntityPig.class, "Pig", 90);
        func_1080_a(EntitySheep.class, "Sheep", 91);
        func_1080_a(EntityCow.class, "Cow", 92);
        func_1080_a(EntityChicken.class, "Chicken", 93);
        func_1080_a(EntityTNTPrimed.class, "PrimedTnt", 20);
        func_1080_a(EntityFallingSand.class, "FallingSand", 21);
        func_1080_a(EntityMinecart.class, "Minecart", 40);
        func_1080_a(EntityBoat.class, "Boat", 41);
    }
    
    private static void func_1080_a(final Class<?> class1, final String s, final int i) {
        EntityList.stringClassHash.put(s, class1);
        EntityList.field_1610_b.put(class1, s);
        EntityList.field_1613_c.put(i, class1);
        EntityList.field_1612_d.put(class1, i);
    }
    
    public static Entity createEntityByIdFromName(final String s, final World world) {
        Entity entity = null;
        try {
            final Class class1 = EntityList.stringClassHash.get(s);
            if (class1 != null) {
                entity = class1.getConstructor(World.class).newInstance(world);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return entity;
    }
    
    public static Entity createEntityFromNBT(final NBTTagCompound nbttagcompound, final World world) {
        Entity entity = null;
        try {
            final Class<?> class1 = EntityList.stringClassHash.get(nbttagcompound.getString("id"));
            if (class1 != null) {
                entity = (Entity)class1.getConstructor(World.class).newInstance(world);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (entity != null) {
            entity.readFromNBT(nbttagcompound);
        }
        else {
            System.out.println("Skipping Entity with id " + nbttagcompound.getString("id"));
        }
        return entity;
    }
    
    public static Entity createEntity(final int i, final World world) {
        Entity entity = null;
        try {
            final Class<?> class1 = EntityList.field_1613_c.get(i);
            if (class1 != null) {
                entity = (Entity)class1.getConstructor(World.class).newInstance(world);
                entity.entityId = i;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (entity == null) {
            System.out.println("Skipping Entity with id " + i);
        }
        return entity;
    }
    
    public static int getEntityID(final Entity entity) {
        return EntityList.field_1612_d.get(entity.getClass());
    }
    
    public static String getEntityString(final Entity entity) {
        return EntityList.field_1610_b.get(entity.getClass());
    }
}
