package com.mojang.minecraft.entity.spawn;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.gui.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.*;
import java.util.*;

public class SpawnerAnimals
{
    private int maxSpawns;
    private Class<?> spawnBaseClass;
    private Class<?>[] spawnSubclasses;
    private Set<ChunkCoordIntPair> nearbyChunkSet;
    
    public SpawnerAnimals(final int i, final Class<?> class1, final Class<?>[] aclass) {
        this.nearbyChunkSet = new HashSet<ChunkCoordIntPair>();
        this.maxSpawns = i;
        this.spawnBaseClass = class1;
        this.spawnSubclasses = aclass;
    }
    
    public void func_1150_a(final World world) {
        final int i = world.func_621_b(this.spawnBaseClass);
        if (i < this.maxSpawns) {
            for (int j = 0; j < 3; ++j) {
                this.func_1149_a(world, 1, null);
            }
        }
    }
    
    protected ChunkPosition func_1151_a(final World world, final int i, final int j) {
        final int k = i + world.rand.nextInt(16);
        final int l = world.rand.nextInt(128);
        final int i2 = j + world.rand.nextInt(16);
        return new ChunkPosition(k, l, i2);
    }
    
    private int func_1149_a(final World world, final int i, final IProgressUpdate iprogressupdate) {
        this.nearbyChunkSet.clear();
        for (int j = 0; j < world.playerEntities.size(); ++j) {
            final EntityPlayer entityplayer = world.playerEntities.get(j);
            final int l = MathHelper.floor_double(entityplayer.posX / 16.0);
            final int i2 = MathHelper.floor_double(entityplayer.posZ / 16.0);
            final byte byte0 = 4;
            for (int k1 = -byte0; k1 <= byte0; ++k1) {
                for (int i3 = -byte0; i3 <= byte0; ++i3) {
                    this.nearbyChunkSet.add(new ChunkCoordIntPair(k1 + l, i3 + i2));
                }
            }
        }
        int m = 0;
        for (final ChunkCoordIntPair chunkcoordintpair : this.nearbyChunkSet) {
            if (world.rand.nextInt(10) == 0) {
                final int j2 = world.rand.nextInt(this.spawnSubclasses.length);
                final ChunkPosition chunkposition = this.func_1151_a(world, chunkcoordintpair.chunkX * 16, chunkcoordintpair.chunkZ * 16);
                final int l2 = chunkposition.x;
                final int j3 = chunkposition.y;
                final int k2 = chunkposition.z;
                if (world.isBlockNormalCube(l2, j3, k2)) {
                    return 0;
                }
                if (world.getMaterialXYZ(l2, j3, k2) != Material.air) {
                    return 0;
                }
                for (int l3 = 0; l3 < 3; ++l3) {
                    int i4 = l2;
                    int j4 = j3;
                    int k3 = k2;
                    final byte byte2 = 6;
                    for (int l4 = 0; l4 < 2; ++l4) {
                        i4 += world.rand.nextInt(byte2) - world.rand.nextInt(byte2);
                        j4 += world.rand.nextInt(1) - world.rand.nextInt(1);
                        k3 += world.rand.nextInt(byte2) - world.rand.nextInt(byte2);
                        if (world.isBlockNormalCube(i4, j4 - 1, k3) && !world.isBlockNormalCube(i4, j4, k3) && !world.getMaterialXYZ(i4, j4, k3).getIsGroundCover()) {
                            if (!world.isBlockNormalCube(i4, j4 + 1, k3)) {
                                final float f = i4 + 0.5f;
                                final float f2 = (float)j4;
                                final float f3 = k3 + 0.5f;
                                if (world.getClosestPlayer(f, f2, f3, 24.0) == null) {
                                    final float f4 = f - world.spawnX;
                                    final float f5 = f2 - world.spawnY;
                                    final float f6 = f3 - world.spawnZ;
                                    final float f7 = f4 * f4 + f5 * f5 + f6 * f6;
                                    if (f7 >= 576.0f) {
                                        EntityLiving entityliving;
                                        try {
                                            entityliving = (EntityLiving)this.spawnSubclasses[j2].getConstructor(World.class).newInstance(world);
                                        }
                                        catch (Exception exception) {
                                            exception.printStackTrace();
                                            return m;
                                        }
                                        entityliving.setLocationAndAngles(f, f2, f3, world.rand.nextFloat() * 360.0f, 0.0f);
                                        if (entityliving.shouldSpawnOnTile()) {
                                            ++m;
                                            world.entityJoinedWorld(entityliving);
                                            if (entityliving instanceof EntitySpider && world.rand.nextInt(100) == 0) {
                                                final EntitySkeleton entityskeleton = new EntitySkeleton(world);
                                                entityskeleton.setLocationAndAngles(f, f2, f3, entityliving.rotationYaw, 0.0f);
                                                world.entityJoinedWorld(entityskeleton);
                                                entityskeleton.mountEntity(entityliving);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return m;
    }
}
