package com.mojang.minecraft.entity.spawn;

import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.chunk.*;

public class SpawnerMonsters extends SpawnerAnimals
{
    final PlayerController unused;
    
    public SpawnerMonsters(final PlayerControllerSP playercontrollersp, final int i, final Class<?> class1, final Class<?>[] aclass) {
        super(i, class1, aclass);
        this.unused = playercontrollersp;
    }
    
    public SpawnerMonsters(final PlayerControllerCreative playerControllerCreative, final int i, final Class<IMobs> class1, final Class[] aclass) {
        super(i, class1, aclass);
        this.unused = playerControllerCreative;
    }
    
    @Override
    protected ChunkPosition func_1151_a(final World world, final int i, final int j) {
        final int k = i + world.rand.nextInt(16);
        final int l = world.rand.nextInt(world.rand.nextInt(120) + 8);
        final int i2 = j + world.rand.nextInt(16);
        return new ChunkPosition(k, l, i2);
    }
}
