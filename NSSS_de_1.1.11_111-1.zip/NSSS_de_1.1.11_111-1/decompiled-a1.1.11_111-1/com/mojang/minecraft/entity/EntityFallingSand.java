package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.nbt.*;

public class EntityFallingSand extends Entity
{
    public int field_799_a;
    public int field_798_b;
    
    public EntityFallingSand(final World world) {
        super(world);
        this.field_798_b = 0;
    }
    
    public EntityFallingSand(final World world, final float f, final float f1, final float f2, final int i) {
        super(world);
        this.field_798_b = 0;
        this.field_799_a = i;
        this.preventEntitySpawning = true;
        this.setSize(0.98f, 0.98f);
        this.yOffset = this.height / 2.0f;
        this.setPosition(f, f1, f2);
        this.motionX = 0.0;
        this.motionY = 0.0;
        this.motionZ = 0.0;
        this.field_640_aG = false;
        this.prevPosX = f;
        this.prevPosY = f1;
        this.prevPosZ = f2;
    }
    
    public EntityFallingSand(final WorldClient worldClient, final double d, final double d1, final double d2, final int blockID) {
        this((World)worldClient, (float)d, (float)d1, (float)d2, blockID);
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public boolean canBeCollidedWith() {
        return !this.isDead;
    }
    
    @Override
    public void onUpdate() {
        if (this.field_799_a == 0) {
            this.setEntityDead();
            return;
        }
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        ++this.field_798_b;
        this.motionY -= 0.03999999910593033;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9800000190734863;
        this.motionY *= 0.9800000190734863;
        this.motionZ *= 0.9800000190734863;
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.posY);
        final int k = MathHelper.floor_double(this.posZ);
        if (this.worldObj.getBlockId(i, j, k) == this.field_799_a) {
            this.worldObj.setBlockWithNotify(i, j, k, 0);
        }
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
            this.motionY *= -0.5;
            this.setEntityDead();
            if ((!this.worldObj.func_695_a(this.field_799_a, i, j, k, true) || !this.worldObj.setBlockWithNotify(i, j, k, this.field_799_a)) && !this.worldObj.multiplayerWorld) {
                this.dropItem(this.field_799_a, 1);
            }
        }
        else if (this.field_798_b > 100 && !this.worldObj.multiplayerWorld) {
            this.dropItem(this.field_799_a, 1);
            this.setEntityDead();
        }
    }
    
    @Override
    protected void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        nbttagcompound.setByte("Tile", (byte)this.field_799_a);
    }
    
    @Override
    protected void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        this.field_799_a = (nbttagcompound.getByte("Tile") & 0xFF);
    }
    
    @Override
    public float getShadowSize() {
        return 0.0f;
    }
    
    public World func_465_i() {
        return this.worldObj;
    }
}
