package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.enums.*;

public class EntityMobs extends EntityCreature implements IMobs
{
    protected int maxHealth;
    public double currentSpeed;
    public boolean field_773_g;
    public int field_772_h;
    
    public EntityMobs(final World world) {
        super(world);
        this.maxHealth = 2;
        this.health = 20;
        this.currentSpeed = 0.5;
        this.isRunning = true;
        this.field_773_g = false;
        this.field_772_h = 0;
    }
    
    public void swingItem() {
        this.field_772_h = -1;
        this.field_773_g = true;
    }
    
    @Override
    protected void updateEntityActionState() {
        super.updateEntityActionState();
        if (this.field_773_g) {
            ++this.field_772_h;
            if (this.field_772_h == 8) {
                this.field_772_h = 0;
                this.field_773_g = false;
            }
        }
        else {
            this.field_772_h = 0;
        }
        this.swingProgress = this.field_772_h / 8.0f;
    }
    
    @Override
    public void onLivingUpdate() {
        final float f = this.getEntityBrightness(1.0f);
        if (f > 0.5f) {
            this.field_701_U += 2;
        }
        super.onLivingUpdate();
    }
    
    @Override
    public void onUpdate() {
        super.onUpdate();
        if (!this.worldObj.multiplayerWorld && this.worldObj.difficulty == 0) {
            this.setEntityDead();
        }
    }
    
    @Override
    protected Entity findPlayerToAttack() {
        final EntityPlayer entityplayer = this.worldObj.getClosestPlayerToEntity(this, 16.0);
        if (entityplayer != null && this.canEntityBeSeen(entityplayer) && !entityplayer.isCreative) {
            return entityplayer;
        }
        return null;
    }
    
    @Override
    public boolean attackEntityFrom(final Entity entity, final int i) {
        if (!super.attackEntityFrom(entity, i)) {
            return false;
        }
        if (this.riddenByEntity == entity || this.entityBeingRidden == entity) {
            return true;
        }
        if (entity != this) {
            this.entityToAttack = entity;
        }
        return true;
    }
    
    @Override
    protected void attackEntity(final Entity entity, final float f) {
        if (f < 2.5 && entity.boundingBox.maxY > this.boundingBox.minY && entity.boundingBox.minY < this.boundingBox.maxY) {
            this.attackTime = 20;
            if (this.fire > 0 && this instanceof EntityZombie) {
                entity.fire = 100;
            }
            this.swingItem();
            entity.attackEntityFrom(this, this.maxHealth - (entity.chainArmor + entity.diamondArmor) / 2);
        }
    }
    
    @Override
    protected float getBlockPathWeight(final int i, final int j, final int k) {
        return 0.5f - this.worldObj.getBrightness(i, j, k);
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    public boolean shouldSpawnOnTile() {
        final int i = MathHelper.floor_double(this.posX);
        final int j = MathHelper.floor_double(this.boundingBox.minY);
        final int k = MathHelper.floor_double(this.posZ);
        if (this.worldObj.getBlockLighting(EnumSkyBlock.Sky, i, j, k) > this.rand.nextInt(32)) {
            return false;
        }
        final int l = this.worldObj.getBlockLightValue(i, j, k);
        return l <= this.rand.nextInt(8) && super.shouldSpawnOnTile();
    }
    
    @Override
    public double getRealMoveSpeed() {
        return this.currentSpeed;
    }
}
