package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.nbt.*;

public class EntityFX extends Entity
{
    protected int particleTextureIndex;
    protected float field_669_c;
    protected float field_668_d;
    protected int particleAge;
    protected int particleMaxAge;
    protected float particleScale;
    protected float field_664_h;
    protected float particleRed;
    protected float particleGreen;
    protected float particleBlue;
    public static double field_660_l;
    public static double field_659_m;
    public static double field_658_n;
    
    public EntityFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        super(world);
        this.worldObj = world;
        this.particleAge = 0;
        this.particleMaxAge = 0;
        this.setSize(0.2f, 0.2f);
        this.yOffset = this.height / 2.0f;
        this.setPosition(d, d1, d2);
        final float particleRed = 1.0f;
        this.particleBlue = particleRed;
        this.particleGreen = particleRed;
        this.particleRed = particleRed;
        this.motionX = d3 + (float)(Math.random() * 2.0 - 1.0) * 0.4f;
        this.motionY = d4 + (float)(Math.random() * 2.0 - 1.0) * 0.4f;
        this.motionZ = d5 + (float)(Math.random() * 2.0 - 1.0) * 0.4f;
        final float f = (float)(Math.random() + Math.random() + 1.0) * 0.15f;
        final float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
        this.motionX = this.motionX / f2 * f * 0.4000000059604645;
        this.motionY = this.motionY / f2 * f * 0.4000000059604645 + 0.10000000149011612;
        this.motionZ = this.motionZ / f2 * f * 0.4000000059604645;
        this.field_669_c = this.rand.nextFloat() * 3.0f;
        this.field_668_d = this.rand.nextFloat() * 3.0f;
        this.particleScale = (this.rand.nextFloat() * 0.5f + 0.5f) * 2.0f;
        this.particleMaxAge = (int)(4.0f / (this.rand.nextFloat() * 0.9f + 0.1f));
        this.particleAge = 0;
        this.field_640_aG = false;
    }
    
    public EntityFX func_407_b(final float f) {
        this.motionX *= f;
        this.motionY = (this.motionY - 0.10000000149011612) * f + 0.10000000149011612;
        this.motionZ *= f;
        return this;
    }
    
    public EntityFX func_405_d(final float f) {
        this.setSize(0.2f * f, 0.2f * f);
        this.particleScale *= f;
        return this;
    }
    
    @Override
    protected void entityInit() {
    }
    
    @Override
    public void onUpdate() {
        this.prevPosX = this.posX;
        this.prevPosY = this.posY;
        this.prevPosZ = this.posZ;
        if (this.particleAge++ >= this.particleMaxAge) {
            this.setEntityDead();
        }
        this.motionY -= 0.04 * this.field_664_h;
        this.moveEntity(this.motionX, this.motionY, this.motionZ);
        this.motionX *= 0.9800000190734863;
        this.motionY *= 0.9800000190734863;
        this.motionZ *= 0.9800000190734863;
        if (this.onGround) {
            this.motionX *= 0.699999988079071;
            this.motionZ *= 0.699999988079071;
        }
    }
    
    public void renderParticle(final Tessellator tessellator, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        final float f6 = this.particleTextureIndex % 16 / 16.0f;
        final float f7 = f6 + 0.0624375f;
        final float f8 = this.particleTextureIndex / 16 / 16.0f;
        final float f9 = f8 + 0.0624375f;
        final float f10 = 0.1f * this.particleScale;
        final float f11 = (float)(this.prevPosX + (this.posX - this.prevPosX) * f - EntityFX.field_660_l);
        final float f12 = (float)(this.prevPosY + (this.posY - this.prevPosY) * f - EntityFX.field_659_m);
        final float f13 = (float)(this.prevPosZ + (this.posZ - this.prevPosZ) * f - EntityFX.field_658_n);
        final float f14 = this.getEntityBrightness(f);
        tessellator.setColorOpaque_F(this.particleRed * f14, this.particleGreen * f14, this.particleBlue * f14);
        tessellator.addVertexWithUV(f11 - f1 * f10 - f4 * f10, f12 - f2 * f10, f13 - f3 * f10 - f5 * f10, f6, f9);
        tessellator.addVertexWithUV(f11 - f1 * f10 + f4 * f10, f12 + f2 * f10, f13 - f3 * f10 + f5 * f10, f6, f8);
        tessellator.addVertexWithUV(f11 + f1 * f10 + f4 * f10, f12 + f2 * f10, f13 + f3 * f10 + f5 * f10, f7, f8);
        tessellator.addVertexWithUV(f11 + f1 * f10 - f4 * f10, f12 - f2 * f10, f13 + f3 * f10 - f5 * f10, f7, f9);
    }
    
    public int func_404_c() {
        return 0;
    }
    
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
    }
    
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
    }
}
