package com.mojang.minecraft.entity;

import java.util.*;
import com.mojang.minecraft.render.*;

public class EntitySorter implements Comparator<Object>
{
    private Entity field_1594_a;
    
    public EntitySorter(final Entity entity) {
        this.field_1594_a = entity;
    }
    
    public int func_1063_a(final WorldRenderer worldrenderer, final WorldRenderer worldrenderer1) {
        return (worldrenderer.distanceToEntitySquared(this.field_1594_a) >= worldrenderer1.distanceToEntitySquared(this.field_1594_a)) ? 1 : -1;
    }
    
    public int compare(final Object obj, final Object obj1) {
        return this.func_1063_a((WorldRenderer)obj, (WorldRenderer)obj1);
    }
}
