package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;

public class EntitySplashFX extends EntityRainFX
{
    public EntitySplashFX(final World world, final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        super(world, d, d1, d2);
        this.field_664_h = 0.04f;
        this.particleTextureIndex = 17 + this.rand.nextInt(4);
        if (d4 == 0.0 && (d3 != 0.0 || d5 != 0.0)) {
            this.motionX = d3;
            this.motionY = d4 + 0.1;
            this.motionZ = d5;
        }
    }
    
    public EntitySplashFX(final World worldObj, final double d, final double d1, final double d2, final double d3, final double d4, final double d5, final float f) {
        this(worldObj, d, d1, d2, d3, d4, d5);
        this.particleScale *= f;
    }
}
