package com.mojang.minecraft.entity;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.item.*;

public class EntitySpider extends EntityMobs
{
    public EntitySpider(final World world) {
        super(world);
        this.scoreYield = 30;
        this.texture = "/mob/spider.png";
        this.setSize(1.4f, 0.9f);
        this.move_speed = 0.8f;
        this.currentSpeed = 0.5;
    }
    
    @Override
    public double getMountedYOffset() {
        return this.height * 0.75 - 0.5;
    }
    
    @Override
    protected Entity findPlayerToAttack() {
        final float f = this.getEntityBrightness(1.0f);
        if (f < 0.5f) {
            final double d = 16.0;
            this.currentSpeed = 1.0;
            return this.worldObj.getClosestPlayerToEntity(this, d);
        }
        return null;
    }
    
    @Override
    public boolean onLadder() {
        return this.worldObj.difficulty == 3 || super.onLadder();
    }
    
    @Override
    protected String idleSound() {
        return "mob.spider";
    }
    
    @Override
    protected String hurtSound() {
        return "mob.spider";
    }
    
    @Override
    protected String deathSound() {
        return "mob.spiderdeath";
    }
    
    @Override
    protected void attackEntity(final Entity entity, final float f) {
        final float f2 = this.getEntityBrightness(1.0f);
        if (f2 > 0.5f && this.rand.nextInt(100) == 0) {
            this.entityToAttack = null;
            return;
        }
        if (f > 2.0f && f < 6.0f && this.rand.nextInt(10) == 0) {
            if (this.onGround) {
                final double d = entity.posX - this.posX;
                final double d2 = entity.posZ - this.posZ;
                final float f3 = MathHelper.sqrt_double(d * d + d2 * d2);
                this.motionX = d / f3 * 0.5 * 0.800000011920929 + this.motionX * 0.20000000298023224;
                this.motionZ = d2 / f3 * 0.5 * 0.800000011920929 + this.motionZ * 0.20000000298023224;
                this.motionY = 0.4000000059604645;
            }
        }
        else {
            super.attackEntity(entity, f);
        }
    }
    
    @Override
    public void writeEntityToNBT(final NBTTagCompound nbttagcompound) {
        super.writeEntityToNBT(nbttagcompound);
    }
    
    @Override
    public void readEntityFromNBT(final NBTTagCompound nbttagcompound) {
        super.readEntityFromNBT(nbttagcompound);
    }
    
    @Override
    protected int deathDropItem() {
        return Item.silk.shiftedIndex;
    }
    
    @Override
    public double getRealMoveSpeed() {
        return this.currentSpeed;
    }
}
