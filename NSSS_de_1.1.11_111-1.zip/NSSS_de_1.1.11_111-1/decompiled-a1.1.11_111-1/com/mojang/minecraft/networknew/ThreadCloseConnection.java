package com.mojang.minecraft.networknew;

class ThreadCloseConnection extends Thread
{
    final NetworkManager field_28109_a;
    
    ThreadCloseConnection(final NetworkManager networkmanager) {
        this.field_28109_a = networkmanager;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(2000L);
            if (NetworkManager.isRunning(this.field_28109_a)) {
                NetworkManager.getWriteThread(this.field_28109_a).interrupt();
                this.field_28109_a.networkShutdown("Connection Closed", new Object[0]);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}
