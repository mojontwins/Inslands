package com.mojang.minecraft.networknew;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.networknew.packet.*;
import java.io.*;
import java.util.*;

public class DataWatcher
{
    private static final HashMap dataTypes;
    private final Map watchedObjects;
    private boolean objectChanged;
    
    static {
        (dataTypes = new HashMap()).put(Byte.class, 0);
        DataWatcher.dataTypes.put(Short.class, 1);
        DataWatcher.dataTypes.put(Integer.class, 2);
        DataWatcher.dataTypes.put(Float.class, 3);
        DataWatcher.dataTypes.put(String.class, 4);
        DataWatcher.dataTypes.put(ItemStack.class, 5);
        DataWatcher.dataTypes.put(ChunkCoordinates.class, 6);
    }
    
    public DataWatcher() {
        this.watchedObjects = new HashMap();
    }
    
    public void addObject(final int i, final Object obj) {
        final Integer integer = DataWatcher.dataTypes.get(obj.getClass());
        if (integer == null) {
            throw new IllegalArgumentException("Unknown data type: " + obj.getClass());
        }
        if (i > 31) {
            throw new IllegalArgumentException("Data value id is too big with " + i + "! (Max is " + 31 + ")");
        }
        if (this.watchedObjects.containsKey(i)) {
            throw new IllegalArgumentException("Duplicate id value for " + i + "!");
        }
        final WatchableObject watchableobject = new WatchableObject(integer, i, obj);
        this.watchedObjects.put(i, watchableobject);
    }
    
    public byte getWatchableObjectByte(final int i) {
        return (byte)this.watchedObjects.get(i).getObject();
    }
    
    public int getWatchableObjectInt(final int i) {
        return (int)this.watchedObjects.get(i).getObject();
    }
    
    public String getWatchableObjectString(final int i) {
        return (String)this.watchedObjects.get(i).getObject();
    }
    
    public void updateObject(final int i, final Object obj) {
        final WatchableObject watchableobject = this.watchedObjects.get(i);
        if (!obj.equals(watchableobject.getObject())) {
            watchableobject.setObject(obj);
            watchableobject.setWatching(true);
            this.objectChanged = true;
        }
    }
    
    public static void writeObjectsInListToStream(final List list, final DataOutputStream dataoutputstream) throws IOException {
        if (list != null) {
            for (final WatchableObject watchableobject : list) {
                writeWatchableObject(dataoutputstream, watchableobject);
            }
        }
        dataoutputstream.writeByte(127);
    }
    
    public void writeWatchableObjects(final DataOutputStream dataoutputstream) throws IOException {
        for (final WatchableObject watchableobject : this.watchedObjects.values()) {
            writeWatchableObject(dataoutputstream, watchableobject);
        }
        dataoutputstream.writeByte(127);
    }
    
    private static void writeWatchableObject(final DataOutputStream dataoutputstream, final WatchableObject watchableobject) throws IOException {
        final int i = (watchableobject.getObjectType() << 5 | (watchableobject.getDataValueId() & 0x1F)) & 0xFF;
        dataoutputstream.writeByte(i);
        switch (watchableobject.getObjectType()) {
            case 0: {
                dataoutputstream.writeByte((byte)watchableobject.getObject());
                break;
            }
            case 1: {
                dataoutputstream.writeShort((short)watchableobject.getObject());
                break;
            }
            case 2: {
                dataoutputstream.writeInt((int)watchableobject.getObject());
                break;
            }
            case 3: {
                dataoutputstream.writeFloat((float)watchableobject.getObject());
                break;
            }
            case 4: {
                Packet.writeString((String)watchableobject.getObject(), dataoutputstream);
                break;
            }
            case 5: {
                final ItemStack itemstack = (ItemStack)watchableobject.getObject();
                dataoutputstream.writeShort(itemstack.itemID);
                dataoutputstream.writeByte(itemstack.stackSize);
                dataoutputstream.writeShort(itemstack.itemDamage);
                break;
            }
            case 6: {
                final ChunkCoordinates chunkcoordinates = (ChunkCoordinates)watchableobject.getObject();
                dataoutputstream.writeInt(chunkcoordinates.x);
                dataoutputstream.writeInt(chunkcoordinates.z);
                break;
            }
        }
    }
    
    public static List readWatchableObjects(final DataInputStream datainputstream) throws IOException {
        ArrayList arraylist = null;
        for (byte byte0 = datainputstream.readByte(); byte0 != 127; byte0 = datainputstream.readByte()) {
            if (arraylist == null) {
                arraylist = new ArrayList();
            }
            final int i = (byte0 & 0xE0) >> 5;
            final int j = byte0 & 0x1F;
            WatchableObject watchableobject = null;
            switch (i) {
                case 0: {
                    watchableobject = new WatchableObject(i, j, datainputstream.readByte());
                    break;
                }
                case 1: {
                    watchableobject = new WatchableObject(i, j, datainputstream.readShort());
                    break;
                }
                case 2: {
                    watchableobject = new WatchableObject(i, j, datainputstream.readInt());
                    break;
                }
                case 3: {
                    watchableobject = new WatchableObject(i, j, datainputstream.readFloat());
                    break;
                }
                case 4: {
                    watchableobject = new WatchableObject(i, j, Packet.readString(datainputstream, 64));
                    break;
                }
                case 5: {
                    final short word0 = datainputstream.readShort();
                    final byte byte2 = datainputstream.readByte();
                    final short word2 = datainputstream.readShort();
                    watchableobject = new WatchableObject(i, j, new ItemStack(word0, byte2, word2));
                    break;
                }
                case 6: {
                    final int k = datainputstream.readInt();
                    final int l = datainputstream.readInt();
                    final int i2 = datainputstream.readInt();
                    watchableobject = new WatchableObject(i, j, new ChunkCoordinates(k, i2));
                    break;
                }
            }
            arraylist.add(watchableobject);
        }
        return arraylist;
    }
    
    public void updateWatchedObjectsFromList(final List list) {
        for (final WatchableObject watchableobject : list) {
            final WatchableObject watchableobject2 = this.watchedObjects.get(watchableobject.getDataValueId());
            if (watchableobject2 != null) {
                watchableobject2.setObject(watchableobject.getObject());
            }
        }
    }
    
    static Class _mthclass$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException classnotfoundexception) {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }
}
