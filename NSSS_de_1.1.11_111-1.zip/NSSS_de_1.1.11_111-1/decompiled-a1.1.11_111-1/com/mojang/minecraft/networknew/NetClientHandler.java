package com.mojang.minecraft.networknew;

import com.mojang.minecraft.*;
import com.mojang.minecraft.player.controller.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.gui.*;
import java.net.*;
import java.io.*;
import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.networknew.packet.*;

public class NetClientHandler extends NetHandler
{
    private boolean disconnected;
    private NetworkManager netManager;
    public String field_1209_a;
    private Minecraft mc;
    private WorldClient worldClient;
    private boolean field_1210_g;
    Random rand;
    public ArrayList<PlayerScore> players;
    
    public NetClientHandler(final Minecraft minecraft, final String s, final int i) throws UnknownHostException, IOException {
        this.disconnected = false;
        this.field_1210_g = false;
        this.rand = new Random();
        this.mc = minecraft;
        final Socket socket = new Socket(InetAddress.getByName(s), i);
        this.netManager = new NetworkManager(socket, "Client", this);
        this.players = new ArrayList<PlayerScore>();
    }
    
    public void addToPlayerList(final String name, final int score) {
        this.players.add(new PlayerScore(name, score));
    }
    
    public int getIndexInPlayerList(final String name) {
        for (int i = 0; i < this.players.size(); ++i) {
            if (this.players.get(i).playerName.equals(name)) {
                return i;
            }
        }
        return -1;
    }
    
    public void updatePlayerScore(final String name, final int score) {
        if (this.getIndexInPlayerList(name) != -1) {
            this.players.get(this.getIndexInPlayerList(name)).setScore(score);
        }
    }
    
    public void removeFromPlayerList(final String name) {
        if (this.getIndexInPlayerList(name) != -1) {
            this.players.remove(this.getIndexInPlayerList(name));
        }
    }
    
    public void processReadPackets() {
        if (!this.disconnected) {
            this.netManager.processReadPackets();
        }
        this.netManager.wakeThreads();
    }
    
    @Override
    public void handleLogin(final Packet1Login packet1login) {
        this.mc.playerController = new PlayerControllerMP(this.mc, this);
        this.worldClient = new WorldClient(this, this.mc);
        this.worldClient.multiplayerWorld = true;
        this.mc.changeWorld1(this.worldClient);
        this.worldClient.multiplayerDifficulty = packet1login.difficulty;
        this.mc.setCurrentScreen(new GuiDownloadTerrain(this));
        this.mc.thePlayer.entityId = packet1login.protocolVersion;
        System.out.println(String.valueOf(packet1login.protocolVersion) + packet1login.username + packet1login.mapSeed + packet1login.difficulty);
    }
    
    @Override
    public void handlePlayerScore(final Packet69PlayerScore packet69PlayerScore) {
        if (packet69PlayerScore.inServer) {
            if (this.getIndexInPlayerList(packet69PlayerScore.username) == -1) {
                this.addToPlayerList(packet69PlayerScore.username, packet69PlayerScore.playerScore);
            }
            else {
                this.updatePlayerScore(packet69PlayerScore.username, packet69PlayerScore.playerScore);
            }
        }
        else if (this.getIndexInPlayerList(packet69PlayerScore.username) != -1) {
            this.removeFromPlayerList(packet69PlayerScore.username);
        }
    }
    
    @Override
    public void handlePickupSpawn(final Packet21PickupSpawn packet21pickupspawn) {
        final double d = packet21pickupspawn.xPosition / 32.0;
        final double d2 = packet21pickupspawn.yPosition / 32.0;
        final double d3 = packet21pickupspawn.zPosition / 32.0;
        final EntityItem entityitem = new EntityItem(this.worldClient, d, d2, d3, new ItemStack(packet21pickupspawn.itemID, packet21pickupspawn.count, packet21pickupspawn.itemDamage));
        entityitem.motionX = packet21pickupspawn.rotation / 128.0;
        entityitem.motionY = packet21pickupspawn.pitch / 128.0;
        entityitem.motionZ = packet21pickupspawn.roll / 128.0;
        entityitem.serverPosX = packet21pickupspawn.xPosition;
        entityitem.serverPosY = packet21pickupspawn.yPosition;
        entityitem.serverPosZ = packet21pickupspawn.zPosition;
        this.worldClient.func_712_a(packet21pickupspawn.entityId, entityitem);
    }
    
    @Override
    public void handleVehicleSpawn(final Packet23VehicleSpawn packet23vehiclespawn) {
        final double d = packet23vehiclespawn.xPosition / 32.0;
        final double d2 = packet23vehiclespawn.yPosition / 32.0;
        final double d3 = packet23vehiclespawn.zPosition / 32.0;
        Entity obj = null;
        if (packet23vehiclespawn.type == 10) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 0);
        }
        if (packet23vehiclespawn.type == 11) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 1);
        }
        if (packet23vehiclespawn.type == 12) {
            obj = new EntityMinecart(this.worldClient, d, d2, d3, 2);
        }
        if (packet23vehiclespawn.type == 90) {
            obj = new EntityFish(this.worldClient, d, d2, d3);
        }
        if (packet23vehiclespawn.type == 60) {
            obj = new EntityArrow(this.worldClient, d, d2, d3);
        }
        if (packet23vehiclespawn.type == 61) {
            obj = new EntitySnowball(this.worldClient, d, d2, d3);
        }
        if (packet23vehiclespawn.type == 1) {
            obj = new EntityBoat(this.worldClient, d, d2, d3);
        }
        if (packet23vehiclespawn.type == 50) {
            obj = new EntityTNTPrimed(this.worldClient, d, d2, d3);
        }
        if (packet23vehiclespawn.type == 70) {
            obj = new EntityFallingSand(this.worldClient, d, d2, d3, Block.sand.blockID);
        }
        if (packet23vehiclespawn.type == 71) {
            obj = new EntityFallingSand(this.worldClient, d, d2, d3, Block.gravel.blockID);
        }
        if (obj != null) {
            obj.serverPosX = packet23vehiclespawn.xPosition;
            obj.serverPosY = packet23vehiclespawn.yPosition;
            obj.serverPosZ = packet23vehiclespawn.zPosition;
            obj.rotationYaw = 0.0f;
            obj.rotationPitch = 0.0f;
            obj.entityId = packet23vehiclespawn.entityId;
            this.worldClient.func_712_a(packet23vehiclespawn.entityId, obj);
            if (packet23vehiclespawn.field_28044_i > 0) {
                if (packet23vehiclespawn.type == 60) {
                    final Entity entity = this.getEntityByID(packet23vehiclespawn.field_28044_i);
                    if (entity instanceof EntityLiving) {
                        ((EntityArrow)obj).owner = (EntityLiving)entity;
                    }
                }
                obj.setVelocity(packet23vehiclespawn.field_28047_e / 8000.0, packet23vehiclespawn.field_28046_f / 8000.0, packet23vehiclespawn.field_28045_g / 8000.0);
            }
        }
    }
    
    @Override
    public void handleWeather(final Packet71Weather packet71weather) {
        final double d = packet71weather.field_27053_b / 32.0;
        final double d2 = packet71weather.field_27057_c / 32.0;
        final double d3 = packet71weather.field_27056_d / 32.0;
        EntityLightningBolt entitylightningbolt = null;
        if (packet71weather.field_27055_e == 1) {
            entitylightningbolt = new EntityLightningBolt(this.worldClient, d, d2, d3);
        }
        if (entitylightningbolt != null) {
            entitylightningbolt.serverPosX = packet71weather.field_27053_b;
            entitylightningbolt.serverPosY = packet71weather.field_27057_c;
            entitylightningbolt.serverPosZ = packet71weather.field_27056_d;
            entitylightningbolt.rotationYaw = 0.0f;
            entitylightningbolt.rotationPitch = 0.0f;
            entitylightningbolt.entityId = packet71weather.field_27054_a;
            this.worldClient.addWeatherEffect(entitylightningbolt);
        }
    }
    
    @Override
    public void func_21146_a(final Packet25EntityPainting packet25entitypainting) {
        final EntityPainting entitypainting = new EntityPainting(this.worldClient, packet25entitypainting.xPosition, packet25entitypainting.yPosition, packet25entitypainting.zPosition, packet25entitypainting.direction, packet25entitypainting.title);
        this.worldClient.func_712_a(packet25entitypainting.entityId, entitypainting);
    }
    
    @Override
    public void func_6498_a(final Packet28EntityVelocity packet28entityvelocity) {
        final Entity entity = this.getEntityByID(packet28entityvelocity.entityId);
        if (entity == null) {
            return;
        }
        entity.setVelocity(packet28entityvelocity.motionX / 8000.0, packet28entityvelocity.motionY / 8000.0, packet28entityvelocity.motionZ / 8000.0);
    }
    
    @Override
    public void func_21148_a(final Packet40EntityMetadata packet40entitymetadata) {
        final Entity entity = this.getEntityByID(packet40entitymetadata.entityId);
        if (entity != null && packet40entitymetadata.func_21047_b() != null) {
            entity.getDataWatcher().updateWatchedObjectsFromList(packet40entitymetadata.func_21047_b());
        }
    }
    
    @Override
    public void handleNamedEntitySpawn(final Packet20NamedEntitySpawn packet20namedentityspawn) {
        final double d = packet20namedentityspawn.xPosition / 32.0;
        final double d2 = packet20namedentityspawn.yPosition / 32.0;
        final double d3 = packet20namedentityspawn.zPosition / 32.0;
        final float f = packet20namedentityspawn.rotation * 360 / 256.0f;
        final float f2 = packet20namedentityspawn.pitch * 360 / 256.0f;
        final EntityOtherPlayerMP entityOtherPlayerMP3;
        final EntityOtherPlayerMP entityOtherPlayerMP2;
        final EntityOtherPlayerMP entityOtherPlayerMP;
        final EntityOtherPlayerMP entityotherplayermp = entityOtherPlayerMP = (entityOtherPlayerMP2 = (entityOtherPlayerMP3 = new EntityOtherPlayerMP(this.mc.mcWorld, packet20namedentityspawn.name)));
        final int xPosition = packet20namedentityspawn.xPosition;
        entityOtherPlayerMP.serverPosX = xPosition;
        final double n = xPosition;
        entityOtherPlayerMP2.lastTickPosX = n;
        entityOtherPlayerMP3.prevPosX = n;
        final EntityOtherPlayerMP entityOtherPlayerMP4 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP5 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP6 = entityotherplayermp;
        final int yPosition = packet20namedentityspawn.yPosition;
        entityOtherPlayerMP6.serverPosY = yPosition;
        final double n2 = yPosition;
        entityOtherPlayerMP5.lastTickPosY = n2;
        entityOtherPlayerMP4.prevPosY = n2;
        final EntityOtherPlayerMP entityOtherPlayerMP7 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP8 = entityotherplayermp;
        final EntityOtherPlayerMP entityOtherPlayerMP9 = entityotherplayermp;
        final int zPosition = packet20namedentityspawn.zPosition;
        entityOtherPlayerMP9.serverPosZ = zPosition;
        final double n3 = zPosition;
        entityOtherPlayerMP8.lastTickPosZ = n3;
        entityOtherPlayerMP7.prevPosZ = n3;
        final int i = packet20namedentityspawn.currentItem;
        if (i == 0) {
            entityotherplayermp.inventory.mainInventory[entityotherplayermp.inventory.currentItem] = null;
        }
        else {
            entityotherplayermp.inventory.mainInventory[entityotherplayermp.inventory.currentItem] = new ItemStack(i, 1, 0);
        }
        entityotherplayermp.setPositionAndRotation(d, d2, d3, f, f2);
        this.worldClient.func_712_a(packet20namedentityspawn.entityId, entityotherplayermp);
    }
    
    @Override
    public void handleEntityTeleport(final Packet34EntityTeleport packet34entityteleport) {
        final Entity entity = this.getEntityByID(packet34entityteleport.entityId);
        if (entity == null) {
            return;
        }
        entity.serverPosX = packet34entityteleport.xPosition;
        entity.serverPosY = packet34entityteleport.yPosition;
        entity.serverPosZ = packet34entityteleport.zPosition;
        final double d = entity.serverPosX / 32.0;
        final double d2 = entity.serverPosY / 32.0 + 0.015625;
        final double d3 = entity.serverPosZ / 32.0;
        final float f = packet34entityteleport.yaw * 360 / 256.0f;
        final float f2 = packet34entityteleport.pitch * 360 / 256.0f;
        entity.setPositionAndRotation2(d, d2, d3, f, f2, 3);
    }
    
    @Override
    public void handleEntity(final Packet30Entity packet30entity) {
        final Entity entity = this.getEntityByID(packet30entity.entityId);
        if (entity == null) {
            return;
        }
        final Entity entity2 = entity;
        entity2.serverPosX += packet30entity.xPosition;
        final Entity entity3 = entity;
        entity3.serverPosY += packet30entity.yPosition;
        final Entity entity4 = entity;
        entity4.serverPosZ += packet30entity.zPosition;
        final double d = entity.serverPosX / 32.0;
        final double d2 = entity.serverPosY / 32.0;
        final double d3 = entity.serverPosZ / 32.0;
        final float f = packet30entity.rotating ? (packet30entity.yaw * 360 / 256.0f) : entity.rotationYaw;
        final float f2 = packet30entity.rotating ? (packet30entity.pitch * 360 / 256.0f) : entity.rotationPitch;
        entity.setPositionAndRotation2(d, d2, d3, f, f2, 3);
    }
    
    @Override
    public void handleDestroyEntity(final Packet29DestroyEntity packet29destroyentity) {
        this.worldClient.removeEntityFromWorld(packet29destroyentity.entityId);
    }
    
    @Override
    public void handleFlying(final Packet10Flying packet10flying) {
        final EntityPlayerSP entityplayersp = this.mc.thePlayer;
        double d = entityplayersp.posX;
        double d2 = entityplayersp.posY;
        double d3 = entityplayersp.posZ;
        float f = entityplayersp.rotationYaw;
        float f2 = entityplayersp.rotationPitch;
        if (packet10flying.moving) {
            d = packet10flying.xPosition;
            d2 = packet10flying.yPosition;
            d3 = packet10flying.zPosition;
        }
        if (packet10flying.rotating) {
            f = packet10flying.yaw;
            f2 = packet10flying.pitch;
        }
        entityplayersp.ySize = 0.0f;
        final EntityPlayerSP entityPlayerSP = entityplayersp;
        final EntityPlayerSP entityPlayerSP2 = entityplayersp;
        final EntityPlayerSP entityPlayerSP3 = entityplayersp;
        final double motionX = 0.0;
        entityPlayerSP3.motionZ = motionX;
        entityPlayerSP2.motionY = motionX;
        entityPlayerSP.motionX = motionX;
        entityplayersp.setPositionAndRotation(d, d2, d3, f, f2);
        packet10flying.xPosition = entityplayersp.posX;
        packet10flying.yPosition = entityplayersp.boundingBox.minY;
        packet10flying.zPosition = entityplayersp.posZ;
        packet10flying.stance = entityplayersp.posY;
        this.netManager.addToSendQueue(packet10flying);
        if (!this.field_1210_g) {
            this.mc.thePlayer.prevPosX = this.mc.thePlayer.posX;
            this.mc.thePlayer.prevPosY = this.mc.thePlayer.posY;
            this.mc.thePlayer.prevPosZ = this.mc.thePlayer.posZ;
            this.field_1210_g = true;
            this.mc.setCurrentScreen(null);
        }
    }
    
    @Override
    public void handlePreChunk(final Packet50PreChunk packet50prechunk) {
        this.worldClient.doPreChunk(packet50prechunk.xPosition, packet50prechunk.yPosition, packet50prechunk.mode);
    }
    
    @Override
    public void handleMultiBlockChange(final Packet52MultiBlockChange packet52multiblockchange) {
        final Chunk chunk = this.worldClient.getChunkFromChunkCoords(packet52multiblockchange.xPosition, packet52multiblockchange.zPosition);
        final int i = packet52multiblockchange.xPosition * 16;
        final int j = packet52multiblockchange.zPosition * 16;
        for (int k = 0; k < packet52multiblockchange.size; ++k) {
            final short word0 = packet52multiblockchange.coordinateArray[k];
            final int l = packet52multiblockchange.typeArray[k] & 0xFF;
            final byte byte0 = packet52multiblockchange.metadataArray[k];
            final int i2 = word0 >> 12 & 0xF;
            final int j2 = word0 >> 8 & 0xF;
            final int k2 = word0 & 0xFF;
            chunk.setBlockIDWithMetadata(i2, k2, j2, l, byte0);
            this.worldClient.markRangeForUpdate(i2 + i, k2, j2 + j, i2 + i, k2, j2 + j);
            this.worldClient.markBlocksDirty(i2 + i, k2, j2 + j, i2 + i, k2, j2 + j);
        }
    }
    
    @Override
    public void handleMapChunk(final Packet51MapChunk packet51mapchunk) {
        this.worldClient.markRangeForUpdate(packet51mapchunk.xPosition, packet51mapchunk.yPosition, packet51mapchunk.zPosition, packet51mapchunk.xPosition + packet51mapchunk.xSize - 1, packet51mapchunk.yPosition + packet51mapchunk.ySize - 1, packet51mapchunk.zPosition + packet51mapchunk.zSize - 1);
        this.worldClient.setChunkData(packet51mapchunk.xPosition, packet51mapchunk.yPosition, packet51mapchunk.zPosition, packet51mapchunk.xSize, packet51mapchunk.ySize, packet51mapchunk.zSize, packet51mapchunk.chunk);
    }
    
    @Override
    public void handleBlockChange(final Packet53BlockChange packet53blockchange) {
        this.worldClient.func_714_c(packet53blockchange.xPosition, packet53blockchange.yPosition, packet53blockchange.zPosition, packet53blockchange.type, packet53blockchange.metadata);
    }
    
    @Override
    public void handleKickDisconnect(final Packet255KickDisconnect packet255kickdisconnect) {
        this.netManager.networkShutdown("Kicked from Server", new Object[0]);
        this.disconnected = true;
        this.mc.changeWorld1(null);
        this.players = new ArrayList<PlayerScore>();
        this.mc.setCurrentScreen(new GuiConnectFailed("Disconnected", "You've been kicked from the server:\n" + packet255kickdisconnect.reason));
    }
    
    @Override
    public void handleErrorMessage(final String s, final Object[] aobj) {
        this.players = new ArrayList<PlayerScore>();
        if (this.disconnected) {
            return;
        }
        this.disconnected = true;
        this.mc.changeWorld1(null);
        this.mc.setCurrentScreen(new GuiConnectFailed("Connection Failed", s));
    }
    
    public void func_28117_a(final Packet packet) {
        if (this.disconnected) {
            return;
        }
        this.netManager.addToSendQueue(packet);
        this.netManager.func_28142_c();
    }
    
    public void addToSendQueue(final Packet packet) {
        if (this.disconnected) {
            return;
        }
        this.netManager.addToSendQueue(packet);
    }
    
    @Override
    public void handleCollect(final Packet22Collect packet22collect) {
        final Entity entity = this.getEntityByID(packet22collect.collectedEntityId);
        Object obj = this.getEntityByID(packet22collect.collectorEntityId);
        if (obj == null) {
            obj = this.mc.thePlayer;
        }
        if (entity != null) {
            this.worldClient.playSoundAtEntity(entity, "random.pop", 0.2f, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            this.mc.effectRenderer.addEffect(new EntityPickupFX(this.mc.mcWorld, entity, (Entity)obj, -0.5f));
            this.worldClient.removeEntityFromWorld(packet22collect.collectedEntityId);
        }
    }
    
    @Override
    public void handleChat(final Packet3Chat packet3chat) {
        this.mc.ingameGUI.addChatMessage(packet3chat.message);
    }
    
    @Override
    public void handleArmAnimation(final Packet18Animation packet18animation) {
        final Entity entity = this.getEntityByID(packet18animation.entityId);
        if (entity == null) {
            return;
        }
        if (packet18animation.animate == 1) {
            final EntityPlayer entityplayer = (EntityPlayer)entity;
            entityplayer.swingItem();
        }
        else if (packet18animation.animate == 2) {
            entity.performHurtAnimation();
        }
        else if (packet18animation.animate == 3) {
            final EntityPlayer entityPlayer = (EntityPlayer)entity;
        }
        else if (packet18animation.animate == 4) {
            final EntityPlayer entityplayer2 = (EntityPlayer)entity;
            entityplayer2.func_6420_o();
        }
    }
    
    @Override
    public void handleEntityAction(final Packet19EntityAction packet19entityaction) {
        final EntityOtherPlayerMP playerEntity = (EntityOtherPlayerMP)this.getEntityByID(packet19entityaction.entityId);
        if (packet19entityaction.state == 1) {
            playerEntity.setSneaking(true);
        }
        else if (packet19entityaction.state == 2) {
            playerEntity.setSneaking(false);
        }
        else if (packet19entityaction.state == 3) {
            playerEntity.setRunning(true);
        }
        else if (packet19entityaction.state == 4) {
            playerEntity.setRunning(false);
        }
    }
    
    @Override
    public void func_22186_a(final Packet17Sleep packet17sleep) {
    }
    
    @Override
    public void handleHandshake(final Packet2Handshake packet2handshake) {
        if (packet2handshake.username.equals("-")) {
            this.addToSendQueue(new Packet1Login(this.mc.session.username, 1111));
        }
        else {
            try {
                final URL url = new URL("http://session.minecraft.net/game/joinserver.jsp?user=" + this.mc.session.username + "&sessionId=" + this.mc.session.token + "&serverId=" + packet2handshake.username);
                final BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(url.openStream()));
                final String s = bufferedreader.readLine();
                bufferedreader.close();
                if (s.equalsIgnoreCase("ok")) {
                    this.addToSendQueue(new Packet1Login(this.mc.session.username, 1111));
                }
                else {
                    this.netManager.networkShutdown("Login Failed", new Object[] { s });
                }
            }
            catch (Exception exception) {
                exception.printStackTrace();
                this.netManager.networkShutdown("Disconnected", new Object[] { "Internal client error: " + exception.toString() });
            }
        }
    }
    
    public void disconnect() {
        this.players = new ArrayList<PlayerScore>();
        this.disconnected = true;
        this.netManager.wakeThreads();
        this.netManager.networkShutdown("Connection Closed", new Object[0]);
    }
    
    @Override
    public void handleBlockItemSwitch(final Packet16BlockItemSwitch packet16blockitemswitch) {
        final Entity entity = this.worldClient.func_709_b(packet16blockitemswitch.id);
        if (entity == null) {
            return;
        }
        final EntityPlayer entityplayer = (EntityPlayer)entity;
        final int i = packet16blockitemswitch.id;
        if (i == 0) {
            entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = null;
        }
        else {
            entityplayer.inventory.mainInventory[entityplayer.inventory.currentItem] = new ItemStack(i);
        }
    }
    
    @Override
    public void handleMobSpawn(final Packet24MobSpawn packet24mobspawn) {
        final double d = packet24mobspawn.xPosition / 32.0;
        final double d2 = packet24mobspawn.yPosition / 32.0;
        final double d3 = packet24mobspawn.zPosition / 32.0;
        final float f = packet24mobspawn.yaw * 360 / 256.0f;
        final float f2 = packet24mobspawn.pitch * 360 / 256.0f;
        final EntityLiving entityliving = (EntityLiving)EntityList.createEntity(packet24mobspawn.type, this.mc.mcWorld);
        if (entityliving != null) {
            entityliving.serverPosX = packet24mobspawn.xPosition;
            entityliving.serverPosY = packet24mobspawn.yPosition;
            entityliving.serverPosZ = packet24mobspawn.zPosition;
            entityliving.entityId = packet24mobspawn.entityId;
            entityliving.setPositionAndRotation(d, d2, d3, f, f2);
            entityliving.isMultiplayerEntity = true;
            this.worldClient.func_712_a(packet24mobspawn.entityId, entityliving);
            final List list = packet24mobspawn.getMetadata();
            if (list != null) {
                entityliving.getDataWatcher().updateWatchedObjectsFromList(list);
            }
        }
    }
    
    @Override
    public void handleUpdateTime(final Packet4UpdateTime packet4updatetime) {
        this.mc.mcWorld.setWorldTime(packet4updatetime.time);
    }
    
    @Override
    public void handleSpawnPosition(final Packet6SpawnPosition packet6spawnposition) {
        this.worldClient.spawnX = packet6spawnposition.xPosition;
        this.worldClient.spawnY = packet6spawnposition.yPosition;
        this.worldClient.spawnZ = packet6spawnposition.zPosition;
    }
    
    @Override
    public void func_6497_a(final Packet39AttachEntity packet39attachentity) {
        Entity obj = this.getEntityByID(packet39attachentity.entityId);
        final Entity entity = this.getEntityByID(packet39attachentity.vehicleEntityId);
        if (packet39attachentity.entityId == this.mc.thePlayer.entityId) {
            obj = this.mc.thePlayer;
        }
        if (obj == null) {
            return;
        }
        obj.mountEntity(entity);
    }
    
    @Override
    public void func_9447_a(final Packet38EntityStatus packet38entitystatus) {
        final Entity entity = this.getEntityByID(packet38entitystatus.entityId);
        if (entity != null) {
            entity.handleHealthUpdate(packet38entitystatus.entityStatus);
        }
    }
    
    private Entity getEntityByID(final int i) {
        if (i == this.mc.thePlayer.entityId) {
            return this.mc.thePlayer;
        }
        return this.worldClient.func_709_b(i);
    }
    
    @Override
    public void handleHealth(final Packet8UpdateHealth packet8updatehealth) {
        this.mc.thePlayer.setHealth(packet8updatehealth.healthMP);
    }
    
    @Override
    public void func_9448_a(final Packet9Respawn packet9respawn) {
        this.mc.respawn(true, packet9respawn.field_28048_a);
    }
    
    @Override
    public void func_12245_a(final Packet60Explosion packet60explosion) {
        final Explosion explosion = new Explosion(this.mc.mcWorld, null, packet60explosion.explosionX, packet60explosion.explosionY, packet60explosion.explosionZ, packet60explosion.explosionSize);
        explosion.destroyedBlockPositions = packet60explosion.destroyedBlockPositions;
        explosion.doExplosionB(true);
    }
    
    @Override
    public void func_20087_a(final Packet100OpenWindow packet100openwindow) {
        if (packet100openwindow.inventoryType == 0) {
            final InventoryBasic inventorybasic = new InventoryBasic(packet100openwindow.windowTitle, packet100openwindow.slotsCount);
            this.mc.thePlayer.displayGUIChest(inventorybasic);
            this.mc.thePlayer.craftingInventory.windowId = packet100openwindow.windowId;
        }
        else if (packet100openwindow.inventoryType == 2) {
            final TileEntityFurnace tileentityfurnace = new TileEntityFurnace();
            this.mc.thePlayer.displayGUIFurnace(tileentityfurnace);
            this.mc.thePlayer.craftingInventory.windowId = packet100openwindow.windowId;
        }
        else if (packet100openwindow.inventoryType == 3) {
            this.mc.thePlayer.craftingInventory.windowId = packet100openwindow.windowId;
        }
        else if (packet100openwindow.inventoryType == 1) {
            final EntityPlayerSP entityplayersp = this.mc.thePlayer;
            this.mc.thePlayer.displayWorkbenchGUI(MathHelper.floor_double(entityplayersp.posX), MathHelper.floor_double(entityplayersp.posY), MathHelper.floor_double(entityplayersp.posZ));
            this.mc.thePlayer.craftingInventory.windowId = packet100openwindow.windowId;
        }
    }
    
    @Override
    public void func_20088_a(final Packet103SetSlot packet103setslot) {
        if (packet103setslot.windowId == -1) {
            this.mc.thePlayer.inventory.setItemStack(packet103setslot.myItemStack);
        }
        else if (packet103setslot.windowId == 0 && packet103setslot.itemSlot >= 36 && packet103setslot.itemSlot < 45) {
            System.out.println(String.valueOf(packet103setslot.itemSlot) + ", " + packet103setslot.myItemStack);
            final ItemStack itemstack = this.mc.thePlayer.inventorySlots.getSlot(packet103setslot.itemSlot).getStack();
            if (packet103setslot.myItemStack != null && (itemstack == null || itemstack.stackSize < packet103setslot.myItemStack.stackSize)) {
                packet103setslot.myItemStack.animationsToGo = 5;
            }
            this.mc.thePlayer.inventorySlots.putStackInSlot(packet103setslot.itemSlot, packet103setslot.myItemStack);
        }
        else if (packet103setslot.windowId == this.mc.thePlayer.craftingInventory.windowId) {
            this.mc.thePlayer.craftingInventory.putStackInSlot(packet103setslot.itemSlot, packet103setslot.myItemStack);
        }
    }
    
    @Override
    public void func_20089_a(final Packet106Transaction packet106transaction) {
        Container container = null;
        if (packet106transaction.windowId == 0) {
            container = this.mc.thePlayer.inventorySlots;
        }
        else if (packet106transaction.windowId == this.mc.thePlayer.craftingInventory.windowId) {
            container = this.mc.thePlayer.craftingInventory;
        }
        if (container != null) {
            if (packet106transaction.field_20030_c) {
                container.func_20113_a(packet106transaction.field_20028_b);
            }
            else {
                container.func_20110_b(packet106transaction.field_20028_b);
                this.addToSendQueue(new Packet106Transaction(packet106transaction.windowId, packet106transaction.field_20028_b, true));
            }
        }
    }
    
    @Override
    public void func_20094_a(final Packet104WindowItems packet104windowitems) {
        if (packet104windowitems.windowId == 0) {
            this.mc.thePlayer.inventorySlots.putStacksInSlots(packet104windowitems.itemStack);
        }
        else if (packet104windowitems.windowId == this.mc.thePlayer.craftingInventory.windowId) {
            this.mc.thePlayer.craftingInventory.putStacksInSlots(packet104windowitems.itemStack);
        }
    }
    
    @Override
    public void handleSignUpdate(final Packet130UpdateSign packet130updatesign) {
        if (this.mc.mcWorld.blockExists(packet130updatesign.xPosition, packet130updatesign.yPosition, packet130updatesign.zPosition)) {
            final TileEntity tileentity = this.mc.mcWorld.getBlockTileEntity(packet130updatesign.xPosition, packet130updatesign.yPosition, packet130updatesign.zPosition);
            if (tileentity instanceof TileEntitySign) {
                final TileEntitySign tileentitysign = (TileEntitySign)tileentity;
                for (int i = 0; i < 4; ++i) {
                    tileentitysign.signText[i] = packet130updatesign.signLines[i];
                }
                tileentitysign.onInventoryChanged();
            }
            if (tileentity instanceof TileEntityMobSpawner) {
                final TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)tileentity;
                tileentitymobspawner.entityID = packet130updatesign.signLines[0];
                tileentitymobspawner.onInventoryChanged();
            }
        }
    }
    
    @Override
    public void func_20090_a(final Packet105UpdateProgressbar packet105updateprogressbar) {
        this.registerPacket(packet105updateprogressbar);
        if (this.mc.thePlayer.craftingInventory != null && this.mc.thePlayer.craftingInventory.windowId == packet105updateprogressbar.windowId) {
            this.mc.thePlayer.craftingInventory.func_20112_a(packet105updateprogressbar.progressBar, packet105updateprogressbar.progressBarValue);
        }
    }
    
    @Override
    public void handlePlayerInventory(final Packet5PlayerInventory packet5playerinventory) {
        final Entity entity = this.getEntityByID(packet5playerinventory.entityID);
        if (entity != null) {
            entity.outfitWithItem(packet5playerinventory.slot, packet5playerinventory.itemID, packet5playerinventory.itemDamage);
        }
    }
    
    @Override
    public void func_20092_a(final Packet101CloseWindow packet101closewindow) {
        this.mc.thePlayer.closeScreen();
    }
    
    @Override
    public void handleNotePlay(final Packet54PlayNoteBlock packet54playnoteblock) {
    }
    
    @Override
    public void func_25118_a(final Packet70Bed packet70bed) {
    }
    
    @Override
    public void func_28116_a(final Packet131MapData packet131mapdata) {
    }
    
    @Override
    public void func_28115_a(final Packet61DoorChange packet61doorchange) {
        this.mc.mcWorld.func_28106_e(packet61doorchange.field_28050_a, packet61doorchange.field_28053_c, packet61doorchange.field_28052_d, packet61doorchange.field_28051_e, packet61doorchange.field_28049_b);
    }
    
    @Override
    public void func_27245_a(final Packet200Statistic packet200statistic) {
    }
    
    @Override
    public boolean isServerHandler() {
        return false;
    }
}
