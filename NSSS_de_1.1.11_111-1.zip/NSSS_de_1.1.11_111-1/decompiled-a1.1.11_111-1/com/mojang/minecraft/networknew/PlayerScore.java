package com.mojang.minecraft.networknew;

public class PlayerScore
{
    public String playerName;
    public int playerScore;
    
    public PlayerScore(final String name, final int score) {
        this.playerName = name;
        this.playerScore = score;
    }
    
    public void setScore(final int score) {
        this.playerScore = score;
    }
}
