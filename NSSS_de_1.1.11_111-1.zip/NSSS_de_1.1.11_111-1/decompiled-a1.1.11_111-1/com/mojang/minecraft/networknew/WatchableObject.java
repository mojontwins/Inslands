package com.mojang.minecraft.networknew;

public class WatchableObject
{
    private final int objectType;
    private final int dataValueId;
    private Object watchedObject;
    private boolean isWatching;
    
    public WatchableObject(final int i, final int j, final Object obj) {
        this.dataValueId = j;
        this.watchedObject = obj;
        this.objectType = i;
        this.isWatching = true;
    }
    
    public int getDataValueId() {
        return this.dataValueId;
    }
    
    public void setObject(final Object obj) {
        this.watchedObject = obj;
    }
    
    public Object getObject() {
        return this.watchedObject;
    }
    
    public int getObjectType() {
        return this.objectType;
    }
    
    public void setWatching(final boolean flag) {
        this.isWatching = flag;
    }
}
