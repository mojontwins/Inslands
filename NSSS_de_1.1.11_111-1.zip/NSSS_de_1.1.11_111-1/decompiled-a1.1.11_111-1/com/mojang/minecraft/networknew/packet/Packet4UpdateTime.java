package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet4UpdateTime extends Packet
{
    public long time;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.time = datainputstream.readLong();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeLong(this.time);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleUpdateTime(this);
    }
    
    @Override
    public int getPacketSize() {
        return 8;
    }
}
