package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet29DestroyEntity extends Packet
{
    public int entityId;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleDestroyEntity(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4;
    }
}
