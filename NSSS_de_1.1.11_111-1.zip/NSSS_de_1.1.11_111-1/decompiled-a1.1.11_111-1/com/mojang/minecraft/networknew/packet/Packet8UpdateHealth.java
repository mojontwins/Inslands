package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet8UpdateHealth extends Packet
{
    public int healthMP;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.healthMP = datainputstream.readShort();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeShort(this.healthMP);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleHealth(this);
    }
    
    @Override
    public int getPacketSize() {
        return 2;
    }
}
