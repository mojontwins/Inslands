package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet54PlayNoteBlock extends Packet
{
    public int xLocation;
    public int yLocation;
    public int zLocation;
    public int instrumentType;
    public int pitch;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xLocation = datainputstream.readInt();
        this.yLocation = datainputstream.readShort();
        this.zLocation = datainputstream.readInt();
        this.instrumentType = datainputstream.read();
        this.pitch = datainputstream.read();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xLocation);
        dataoutputstream.writeShort(this.yLocation);
        dataoutputstream.writeInt(this.zLocation);
        dataoutputstream.write(this.instrumentType);
        dataoutputstream.write(this.pitch);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleNotePlay(this);
    }
    
    @Override
    public int getPacketSize() {
        return 12;
    }
}
