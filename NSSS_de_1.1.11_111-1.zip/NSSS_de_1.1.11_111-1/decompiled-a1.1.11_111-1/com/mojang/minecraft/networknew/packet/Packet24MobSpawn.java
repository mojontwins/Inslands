package com.mojang.minecraft.networknew.packet;

import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet24MobSpawn extends Packet
{
    public int entityId;
    public byte type;
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public byte yaw;
    public byte pitch;
    private DataWatcher metaData;
    private List receivedMetadata;
    
    public Packet24MobSpawn() {
    }
    
    public Packet24MobSpawn(final EntityLiving entityliving) {
        this.entityId = entityliving.entityId;
        this.type = (byte)EntityList.getEntityID(entityliving);
        this.xPosition = MathHelper.floor_double(entityliving.posX * 32.0);
        this.yPosition = MathHelper.floor_double(entityliving.posY * 32.0);
        this.zPosition = MathHelper.floor_double(entityliving.posZ * 32.0);
        this.yaw = (byte)(entityliving.rotationYaw * 256.0f / 360.0f);
        this.pitch = (byte)(entityliving.rotationPitch * 256.0f / 360.0f);
        this.metaData = entityliving.getDataWatcher();
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.type = datainputstream.readByte();
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
        this.yaw = datainputstream.readByte();
        this.pitch = datainputstream.readByte();
        this.receivedMetadata = DataWatcher.readWatchableObjects(datainputstream);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeByte(this.type);
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.writeByte(this.yaw);
        dataoutputstream.writeByte(this.pitch);
        this.metaData.writeWatchableObjects(dataoutputstream);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleMobSpawn(this);
    }
    
    @Override
    public int getPacketSize() {
        return 20;
    }
    
    public List getMetadata() {
        return this.receivedMetadata;
    }
}
