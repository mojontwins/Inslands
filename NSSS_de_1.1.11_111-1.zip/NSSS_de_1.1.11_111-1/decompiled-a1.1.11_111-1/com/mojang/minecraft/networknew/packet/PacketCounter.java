package com.mojang.minecraft.networknew.packet;

class PacketCounter
{
    private int totalPackets;
    private long totalBytes;
    
    private PacketCounter() {
    }
    
    public void addPacket(final int i) {
        ++this.totalPackets;
        this.totalBytes += i;
    }
    
    PacketCounter(final Empty1 empty1) {
        this();
    }
}
