package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet53BlockChange extends Packet
{
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public int type;
    public int metadata;
    
    public Packet53BlockChange() {
        this.isChunkDataPacket = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.read();
        this.zPosition = datainputstream.readInt();
        this.type = datainputstream.read();
        this.metadata = datainputstream.read();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.write(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.write(this.type);
        dataoutputstream.write(this.metadata);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleBlockChange(this);
    }
    
    @Override
    public int getPacketSize() {
        return 11;
    }
}
