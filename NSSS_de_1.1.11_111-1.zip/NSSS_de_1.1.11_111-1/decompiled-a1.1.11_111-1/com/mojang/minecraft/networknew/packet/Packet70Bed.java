package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet70Bed extends Packet
{
    public static final String[] field_25020_a;
    public int field_25019_b;
    
    static {
        field_25020_a = new String[] { "tile.bed.notValid", null, null };
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_25019_b = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.field_25019_b);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_25118_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 1;
    }
}
