package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet2Handshake extends Packet
{
    public String username;
    
    public Packet2Handshake() {
    }
    
    public Packet2Handshake(final String s) {
        this.username = s;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.username = Packet.readString(datainputstream, 32);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        Packet.writeString(this.username, dataoutputstream);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleHandshake(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4 + this.username.length() + 4;
    }
}
