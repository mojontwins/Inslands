package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet200Statistic extends Packet
{
    public int field_27052_a;
    public int field_27051_b;
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_27245_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_27052_a = datainputstream.readInt();
        this.field_27051_b = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_27052_a);
        dataoutputstream.writeByte(this.field_27051_b);
    }
    
    @Override
    public int getPacketSize() {
        return 6;
    }
}
