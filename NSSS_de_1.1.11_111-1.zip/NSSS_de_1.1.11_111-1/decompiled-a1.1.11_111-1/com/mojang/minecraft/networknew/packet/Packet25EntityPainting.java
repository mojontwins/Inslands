package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.enums.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet25EntityPainting extends Packet
{
    public int entityId;
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public int direction;
    public String title;
    
    public Packet25EntityPainting() {
    }
    
    public Packet25EntityPainting(final EntityPainting entitypainting) {
        this.entityId = entitypainting.entityId;
        this.xPosition = entitypainting.xPosition;
        this.yPosition = entitypainting.yPosition;
        this.zPosition = entitypainting.zPosition;
        this.direction = entitypainting.direction;
        this.title = entitypainting.art.title;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.title = Packet.readString(datainputstream, EnumArt.maxArtTitleLength);
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
        this.direction = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        Packet.writeString(this.title, dataoutputstream);
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.writeInt(this.direction);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_21146_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 24;
    }
}
