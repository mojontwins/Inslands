package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet106Transaction extends Packet
{
    public int windowId;
    public short field_20028_b;
    public boolean field_20030_c;
    
    public Packet106Transaction() {
    }
    
    public Packet106Transaction(final int i, final short word0, final boolean flag) {
        this.windowId = i;
        this.field_20028_b = word0;
        this.field_20030_c = flag;
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20089_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
        this.field_20028_b = datainputstream.readShort();
        this.field_20030_c = (datainputstream.readByte() != 0);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
        dataoutputstream.writeShort(this.field_20028_b);
        dataoutputstream.writeByte(this.field_20030_c ? 1 : 0);
    }
    
    @Override
    public int getPacketSize() {
        return 4;
    }
}
