package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet71Weather extends Packet
{
    public int field_27054_a;
    public int field_27053_b;
    public int field_27057_c;
    public int field_27056_d;
    public int field_27055_e;
    
    public Packet71Weather() {
    }
    
    public Packet71Weather(final Entity entity) {
        this.field_27054_a = entity.entityId;
        this.field_27053_b = MathHelper.floor_double(entity.posX * 32.0);
        this.field_27057_c = MathHelper.floor_double(entity.posY * 32.0);
        this.field_27056_d = MathHelper.floor_double(entity.posZ * 32.0);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_27054_a = datainputstream.readInt();
        this.field_27055_e = datainputstream.readByte();
        this.field_27053_b = datainputstream.readInt();
        this.field_27057_c = datainputstream.readInt();
        this.field_27056_d = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_27054_a);
        dataoutputstream.writeByte(this.field_27055_e);
        dataoutputstream.writeInt(this.field_27053_b);
        dataoutputstream.writeInt(this.field_27057_c);
        dataoutputstream.writeInt(this.field_27056_d);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleWeather(this);
    }
    
    @Override
    public int getPacketSize() {
        return 17;
    }
}
