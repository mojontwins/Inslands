package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet7UseEntity extends Packet
{
    public int playerEntityId;
    public int targetEntity;
    public int isLeftClick;
    
    public Packet7UseEntity() {
    }
    
    public Packet7UseEntity(final int i, final int j, final int k) {
        this.playerEntityId = i;
        this.targetEntity = j;
        this.isLeftClick = k;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.playerEntityId = datainputstream.readInt();
        this.targetEntity = datainputstream.readInt();
        this.isLeftClick = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.playerEntityId);
        dataoutputstream.writeInt(this.targetEntity);
        dataoutputstream.writeByte(this.isLeftClick);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleUseEntity(this);
    }
    
    @Override
    public int getPacketSize() {
        return 9;
    }
}
