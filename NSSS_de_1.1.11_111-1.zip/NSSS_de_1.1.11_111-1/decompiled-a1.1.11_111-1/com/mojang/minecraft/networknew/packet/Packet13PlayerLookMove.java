package com.mojang.minecraft.networknew.packet;

import java.io.*;

public class Packet13PlayerLookMove extends Packet10Flying
{
    public Packet13PlayerLookMove() {
        this.rotating = true;
        this.moving = true;
    }
    
    public Packet13PlayerLookMove(final double d, final double d1, final double d2, final double d3, final float f, final float f1, final boolean flag) {
        this.xPosition = d;
        this.yPosition = d1;
        this.stance = d2;
        this.zPosition = d3;
        this.yaw = f;
        this.pitch = f1;
        this.onGround = flag;
        this.rotating = true;
        this.moving = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readDouble();
        this.yPosition = datainputstream.readDouble();
        this.stance = datainputstream.readDouble();
        this.zPosition = datainputstream.readDouble();
        this.yaw = datainputstream.readFloat();
        this.pitch = datainputstream.readFloat();
        super.readPacketData(datainputstream);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeDouble(this.xPosition);
        dataoutputstream.writeDouble(this.yPosition);
        dataoutputstream.writeDouble(this.stance);
        dataoutputstream.writeDouble(this.zPosition);
        dataoutputstream.writeFloat(this.yaw);
        dataoutputstream.writeFloat(this.pitch);
        super.writePacketData(dataoutputstream);
    }
    
    @Override
    public int getPacketSize() {
        return 41;
    }
}
