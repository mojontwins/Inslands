package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet52MultiBlockChange extends Packet
{
    public int xPosition;
    public int zPosition;
    public short[] coordinateArray;
    public byte[] typeArray;
    public byte[] metadataArray;
    public int size;
    
    public Packet52MultiBlockChange() {
        this.isChunkDataPacket = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
        this.size = (datainputstream.readShort() & 0xFFFF);
        this.coordinateArray = new short[this.size];
        this.typeArray = new byte[this.size];
        this.metadataArray = new byte[this.size];
        for (int i = 0; i < this.size; ++i) {
            this.coordinateArray[i] = datainputstream.readShort();
        }
        datainputstream.readFully(this.typeArray);
        datainputstream.readFully(this.metadataArray);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.writeShort((short)this.size);
        for (int i = 0; i < this.size; ++i) {
            dataoutputstream.writeShort(this.coordinateArray[i]);
        }
        dataoutputstream.write(this.typeArray);
        dataoutputstream.write(this.metadataArray);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleMultiBlockChange(this);
    }
    
    @Override
    public int getPacketSize() {
        return 10 + this.size * 4;
    }
}
