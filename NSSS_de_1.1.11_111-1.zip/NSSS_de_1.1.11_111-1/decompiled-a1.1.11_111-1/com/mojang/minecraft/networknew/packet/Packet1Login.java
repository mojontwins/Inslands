package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet1Login extends Packet
{
    public int protocolVersion;
    public String username;
    public long mapSeed;
    public byte difficulty;
    
    public Packet1Login() {
    }
    
    public Packet1Login(final String s, final int i) {
        this.username = s;
        this.protocolVersion = i;
        this.difficulty = 0;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.protocolVersion = datainputstream.readInt();
        this.username = Packet.readString(datainputstream, 16);
        this.mapSeed = datainputstream.readLong();
        this.difficulty = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.protocolVersion);
        Packet.writeString(this.username, dataoutputstream);
        dataoutputstream.writeLong(this.mapSeed);
        dataoutputstream.writeByte(this.difficulty);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleLogin(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4 + this.username.length() + 4 + 5;
    }
}
