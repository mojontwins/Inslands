package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet39AttachEntity extends Packet
{
    public int entityId;
    public int vehicleEntityId;
    
    @Override
    public int getPacketSize() {
        return 8;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.vehicleEntityId = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeInt(this.vehicleEntityId);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_6497_a(this);
    }
}
