package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet3Chat extends Packet
{
    public String message;
    
    public Packet3Chat() {
    }
    
    public Packet3Chat(String s) {
        if (s.length() > 275) {
            s = s.substring(0, 275);
        }
        this.message = s;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.message = Packet.readString(datainputstream, 275);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        Packet.writeString(this.message, dataoutputstream);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleChat(this);
    }
    
    @Override
    public int getPacketSize() {
        return this.message.length();
    }
}
