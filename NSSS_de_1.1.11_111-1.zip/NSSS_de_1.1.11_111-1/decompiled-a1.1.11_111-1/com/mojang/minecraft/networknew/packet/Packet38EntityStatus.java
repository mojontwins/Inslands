package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet38EntityStatus extends Packet
{
    public int entityId;
    public byte entityStatus;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.entityStatus = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeByte(this.entityStatus);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_9447_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 5;
    }
}
