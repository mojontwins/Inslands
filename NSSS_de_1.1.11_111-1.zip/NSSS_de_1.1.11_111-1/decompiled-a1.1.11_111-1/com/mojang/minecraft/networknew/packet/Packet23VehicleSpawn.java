package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet23VehicleSpawn extends Packet
{
    public int entityId;
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public int field_28047_e;
    public int field_28046_f;
    public int field_28045_g;
    public int type;
    public int field_28044_i;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.type = datainputstream.readByte();
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
        this.field_28044_i = datainputstream.readInt();
        if (this.field_28044_i > 0) {
            this.field_28047_e = datainputstream.readShort();
            this.field_28046_f = datainputstream.readShort();
            this.field_28045_g = datainputstream.readShort();
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeByte(this.type);
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.writeInt(this.field_28044_i);
        if (this.field_28044_i > 0) {
            dataoutputstream.writeShort(this.field_28047_e);
            dataoutputstream.writeShort(this.field_28046_f);
            dataoutputstream.writeShort(this.field_28045_g);
        }
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleVehicleSpawn(this);
    }
    
    @Override
    public int getPacketSize() {
        return (21 + this.field_28044_i <= 0) ? 0 : 6;
    }
}
