package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet16BlockItemSwitch extends Packet
{
    public int id;
    
    public Packet16BlockItemSwitch() {
    }
    
    public Packet16BlockItemSwitch(final int i) {
        this.id = i;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.id = datainputstream.readShort();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeShort(this.id);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleBlockItemSwitch(this);
    }
    
    @Override
    public int getPacketSize() {
        return 2;
    }
}
