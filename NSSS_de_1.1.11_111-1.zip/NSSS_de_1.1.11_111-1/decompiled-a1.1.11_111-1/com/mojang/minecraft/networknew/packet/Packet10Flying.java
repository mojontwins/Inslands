package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet10Flying extends Packet
{
    public double xPosition;
    public double yPosition;
    public double zPosition;
    public double stance;
    public float yaw;
    public float pitch;
    public boolean onGround;
    public boolean moving;
    public boolean rotating;
    
    public Packet10Flying() {
    }
    
    public Packet10Flying(final boolean flag) {
        this.onGround = flag;
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleFlying(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.onGround = (datainputstream.read() != 0);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.write(this.onGround ? 1 : 0);
    }
    
    @Override
    public int getPacketSize() {
        return 1;
    }
}
