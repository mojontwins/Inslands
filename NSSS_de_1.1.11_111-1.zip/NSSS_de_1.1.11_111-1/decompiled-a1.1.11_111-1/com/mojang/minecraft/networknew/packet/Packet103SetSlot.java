package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet103SetSlot extends Packet
{
    public int windowId;
    public int itemSlot;
    public ItemStack myItemStack;
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20088_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
        this.itemSlot = datainputstream.readShort();
        final short word0 = datainputstream.readShort();
        if (word0 >= 0) {
            final byte byte0 = datainputstream.readByte();
            final short word2 = datainputstream.readShort();
            this.myItemStack = new ItemStack(word0, byte0, word2);
        }
        else {
            this.myItemStack = null;
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
        dataoutputstream.writeShort(this.itemSlot);
        if (this.myItemStack == null) {
            dataoutputstream.writeShort(-1);
        }
        else {
            dataoutputstream.writeShort(this.myItemStack.itemID);
            dataoutputstream.writeByte(this.myItemStack.stackSize);
            dataoutputstream.writeShort(this.myItemStack.itemDamage);
        }
    }
    
    @Override
    public int getPacketSize() {
        return 8;
    }
}
