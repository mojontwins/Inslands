package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet30Entity extends Packet
{
    public int entityId;
    public byte xPosition;
    public byte yPosition;
    public byte zPosition;
    public byte yaw;
    public byte pitch;
    public boolean rotating;
    
    public Packet30Entity() {
        this.rotating = false;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleEntity(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4;
    }
}
