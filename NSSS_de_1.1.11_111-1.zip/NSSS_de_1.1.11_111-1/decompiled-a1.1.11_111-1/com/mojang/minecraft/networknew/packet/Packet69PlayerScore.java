package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet69PlayerScore extends Packet
{
    public int playerScore;
    public String username;
    public boolean inServer;
    
    public Packet69PlayerScore() {
    }
    
    public Packet69PlayerScore(final String s, final int i, final boolean inserv) {
        this.username = s;
        this.playerScore = i;
        this.inServer = inserv;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.playerScore = datainputstream.readInt();
        this.username = Packet.readString(datainputstream, 16);
        this.inServer = datainputstream.readBoolean();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.playerScore);
        Packet.writeString(this.username, dataoutputstream);
        dataoutputstream.writeBoolean(this.inServer);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handlePlayerScore(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4 + this.username.length() + 4 + 5;
    }
}
