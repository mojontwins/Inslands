package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet17Sleep extends Packet
{
    public int field_22045_a;
    public int field_22044_b;
    public int field_22048_c;
    public int field_22047_d;
    public int field_22046_e;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_22045_a = datainputstream.readInt();
        this.field_22046_e = datainputstream.readByte();
        this.field_22044_b = datainputstream.readInt();
        this.field_22048_c = datainputstream.readByte();
        this.field_22047_d = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_22045_a);
        dataoutputstream.writeByte(this.field_22046_e);
        dataoutputstream.writeInt(this.field_22044_b);
        dataoutputstream.writeByte(this.field_22048_c);
        dataoutputstream.writeInt(this.field_22047_d);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_22186_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 14;
    }
}
