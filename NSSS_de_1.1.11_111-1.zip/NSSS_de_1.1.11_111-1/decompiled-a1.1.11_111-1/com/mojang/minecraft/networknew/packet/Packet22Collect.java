package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet22Collect extends Packet
{
    public int collectedEntityId;
    public int collectorEntityId;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.collectedEntityId = datainputstream.readInt();
        this.collectorEntityId = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.collectedEntityId);
        dataoutputstream.writeInt(this.collectorEntityId);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleCollect(this);
    }
    
    @Override
    public int getPacketSize() {
        return 8;
    }
}
