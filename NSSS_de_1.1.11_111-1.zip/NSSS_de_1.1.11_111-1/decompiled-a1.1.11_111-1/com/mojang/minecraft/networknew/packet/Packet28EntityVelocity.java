package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet28EntityVelocity extends Packet
{
    public int entityId;
    public int motionX;
    public int motionY;
    public int motionZ;
    
    public Packet28EntityVelocity() {
    }
    
    public Packet28EntityVelocity(final Entity entity) {
        this(entity.entityId, entity.motionX, entity.motionY, entity.motionZ);
    }
    
    public Packet28EntityVelocity(final int i, double d, double d1, double d2) {
        this.entityId = i;
        final double d3 = 3.9;
        if (d < -d3) {
            d = -d3;
        }
        if (d1 < -d3) {
            d1 = -d3;
        }
        if (d2 < -d3) {
            d2 = -d3;
        }
        if (d > d3) {
            d = d3;
        }
        if (d1 > d3) {
            d1 = d3;
        }
        if (d2 > d3) {
            d2 = d3;
        }
        this.motionX = (int)(d * 8000.0);
        this.motionY = (int)(d1 * 8000.0);
        this.motionZ = (int)(d2 * 8000.0);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.motionX = datainputstream.readShort();
        this.motionY = datainputstream.readShort();
        this.motionZ = datainputstream.readShort();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeShort(this.motionX);
        dataoutputstream.writeShort(this.motionY);
        dataoutputstream.writeShort(this.motionZ);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_6498_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 10;
    }
}
