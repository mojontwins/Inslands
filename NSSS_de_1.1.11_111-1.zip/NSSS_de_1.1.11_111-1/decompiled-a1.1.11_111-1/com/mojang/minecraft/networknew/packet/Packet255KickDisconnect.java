package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet255KickDisconnect extends Packet
{
    public String reason;
    
    public Packet255KickDisconnect() {
    }
    
    public Packet255KickDisconnect(final String s) {
        this.reason = s;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.reason = Packet.readString(datainputstream, 100);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        Packet.writeString(this.reason, dataoutputstream);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleKickDisconnect(this);
    }
    
    @Override
    public int getPacketSize() {
        return this.reason.length();
    }
}
