package com.mojang.minecraft.networknew.packet;

import java.io.*;

public class Packet11PlayerPosition extends Packet10Flying
{
    public Packet11PlayerPosition() {
        this.moving = true;
    }
    
    public Packet11PlayerPosition(final double d, final double d1, final double d2, final double d3, final boolean flag) {
        this.xPosition = d;
        this.yPosition = d1;
        this.stance = d2;
        this.zPosition = d3;
        this.onGround = flag;
        this.moving = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readDouble();
        this.yPosition = datainputstream.readDouble();
        this.stance = datainputstream.readDouble();
        this.zPosition = datainputstream.readDouble();
        super.readPacketData(datainputstream);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeDouble(this.xPosition);
        dataoutputstream.writeDouble(this.yPosition);
        dataoutputstream.writeDouble(this.stance);
        dataoutputstream.writeDouble(this.zPosition);
        super.writePacketData(dataoutputstream);
    }
    
    @Override
    public int getPacketSize() {
        return 33;
    }
}
