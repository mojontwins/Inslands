package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet0KeepAlive extends Packet
{
    @Override
    public void processPacket(final NetHandler nethandler) {
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
    }
    
    @Override
    public int getPacketSize() {
        return 0;
    }
}
