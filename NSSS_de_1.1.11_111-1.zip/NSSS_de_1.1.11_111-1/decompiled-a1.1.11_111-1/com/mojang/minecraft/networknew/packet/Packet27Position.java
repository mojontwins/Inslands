package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet27Position extends Packet
{
    private float field_22039_a;
    private float field_22038_b;
    private boolean field_22043_c;
    private boolean field_22042_d;
    private float field_22041_e;
    private float field_22040_f;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_22039_a = datainputstream.readFloat();
        this.field_22038_b = datainputstream.readFloat();
        this.field_22041_e = datainputstream.readFloat();
        this.field_22040_f = datainputstream.readFloat();
        this.field_22043_c = datainputstream.readBoolean();
        this.field_22042_d = datainputstream.readBoolean();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeFloat(this.field_22039_a);
        dataoutputstream.writeFloat(this.field_22038_b);
        dataoutputstream.writeFloat(this.field_22041_e);
        dataoutputstream.writeFloat(this.field_22040_f);
        dataoutputstream.writeBoolean(this.field_22043_c);
        dataoutputstream.writeBoolean(this.field_22042_d);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_22185_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 18;
    }
}
