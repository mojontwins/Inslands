package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet102WindowClick extends Packet
{
    public int window_Id;
    public int inventorySlot;
    public int mouseClick;
    public short action;
    public ItemStack itemStack;
    public boolean field_27050_f;
    
    public Packet102WindowClick() {
    }
    
    public Packet102WindowClick(final int window, final int slot, final int click, final boolean flag, final ItemStack itemstack, final short act) {
        this.window_Id = window;
        this.inventorySlot = slot;
        this.mouseClick = click;
        this.itemStack = itemstack;
        this.action = act;
        this.field_27050_f = flag;
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20091_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.window_Id = datainputstream.readByte();
        this.inventorySlot = datainputstream.readShort();
        this.mouseClick = datainputstream.readByte();
        this.action = datainputstream.readShort();
        this.field_27050_f = datainputstream.readBoolean();
        final short word0 = datainputstream.readShort();
        if (word0 >= 0) {
            final byte byte0 = datainputstream.readByte();
            final short word2 = datainputstream.readShort();
            this.itemStack = new ItemStack(word0, byte0, word2);
        }
        else {
            this.itemStack = null;
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.window_Id);
        dataoutputstream.writeShort(this.inventorySlot);
        dataoutputstream.writeByte(this.mouseClick);
        dataoutputstream.writeShort(this.action);
        dataoutputstream.writeBoolean(this.field_27050_f);
        if (this.itemStack == null) {
            dataoutputstream.writeShort(-1);
        }
        else {
            dataoutputstream.writeShort(this.itemStack.itemID);
            dataoutputstream.writeByte(this.itemStack.stackSize);
            dataoutputstream.writeShort(this.itemStack.itemDamage);
        }
    }
    
    @Override
    public int getPacketSize() {
        return 11;
    }
}
