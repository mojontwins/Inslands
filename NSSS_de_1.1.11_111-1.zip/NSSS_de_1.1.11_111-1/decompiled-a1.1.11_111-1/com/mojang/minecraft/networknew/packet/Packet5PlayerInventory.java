package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet5PlayerInventory extends Packet
{
    public int entityID;
    public int slot;
    public int itemID;
    public int itemDamage;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityID = datainputstream.readInt();
        this.slot = datainputstream.readShort();
        this.itemID = datainputstream.readShort();
        this.itemDamage = datainputstream.readShort();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityID);
        dataoutputstream.writeShort(this.slot);
        dataoutputstream.writeShort(this.itemID);
        dataoutputstream.writeShort(this.itemDamage);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handlePlayerInventory(this);
    }
    
    @Override
    public int getPacketSize() {
        return 8;
    }
}
