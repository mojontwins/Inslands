package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet6SpawnPosition extends Packet
{
    public int xPosition;
    public int yPosition;
    public int zPosition;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleSpawnPosition(this);
    }
    
    @Override
    public int getPacketSize() {
        return 12;
    }
}
