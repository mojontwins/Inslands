package com.mojang.minecraft.networknew.packet;

import java.io.*;

public class Packet31RelEntityMove extends Packet30Entity
{
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        super.readPacketData(datainputstream);
        this.xPosition = datainputstream.readByte();
        this.yPosition = datainputstream.readByte();
        this.zPosition = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        super.writePacketData(dataoutputstream);
        dataoutputstream.writeByte(this.xPosition);
        dataoutputstream.writeByte(this.yPosition);
        dataoutputstream.writeByte(this.zPosition);
    }
    
    @Override
    public int getPacketSize() {
        return 7;
    }
}
