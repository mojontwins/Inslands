package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet14BlockDig extends Packet
{
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public int face;
    public int status;
    
    public Packet14BlockDig() {
    }
    
    public Packet14BlockDig(final int i, final int j, final int k, final int l, final int i1) {
        this.status = i;
        this.xPosition = j;
        this.yPosition = k;
        this.zPosition = l;
        this.face = i1;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.status = datainputstream.read();
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.read();
        this.zPosition = datainputstream.readInt();
        this.face = datainputstream.read();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.write(this.status);
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.write(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.write(this.face);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleBlockDig(this);
    }
    
    @Override
    public int getPacketSize() {
        return 11;
    }
}
