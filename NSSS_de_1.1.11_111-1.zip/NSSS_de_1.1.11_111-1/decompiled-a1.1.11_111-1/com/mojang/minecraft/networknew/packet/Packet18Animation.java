package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet18Animation extends Packet
{
    public int entityId;
    public int animate;
    
    public Packet18Animation() {
    }
    
    public Packet18Animation(final Entity entity, final int i) {
        this.entityId = entity.entityId;
        this.animate = i;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.animate = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeByte(this.animate);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleArmAnimation(this);
    }
    
    @Override
    public int getPacketSize() {
        return 5;
    }
}
