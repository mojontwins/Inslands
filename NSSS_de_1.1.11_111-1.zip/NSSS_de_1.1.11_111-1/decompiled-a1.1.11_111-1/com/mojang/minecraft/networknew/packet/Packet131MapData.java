package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet131MapData extends Packet
{
    public short field_28055_a;
    public short field_28054_b;
    public byte[] field_28056_c;
    
    public Packet131MapData() {
        this.isChunkDataPacket = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_28055_a = datainputstream.readShort();
        this.field_28054_b = datainputstream.readShort();
        datainputstream.readFully(this.field_28056_c = new byte[datainputstream.readByte() & 0xFF]);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeShort(this.field_28055_a);
        dataoutputstream.writeShort(this.field_28054_b);
        dataoutputstream.writeByte(this.field_28056_c.length);
        dataoutputstream.write(this.field_28056_c);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_28116_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 4 + this.field_28056_c.length;
    }
}
