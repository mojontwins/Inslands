package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.item.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet15Place extends Packet
{
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public int direction;
    public ItemStack itemStack;
    
    public Packet15Place() {
    }
    
    public Packet15Place(final int i, final int j, final int k, final int l, final ItemStack itemstack) {
        this.xPosition = i;
        this.yPosition = j;
        this.zPosition = k;
        this.direction = l;
        this.itemStack = itemstack;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.read();
        this.zPosition = datainputstream.readInt();
        this.direction = datainputstream.read();
        final short word0 = datainputstream.readShort();
        if (word0 >= 0) {
            final byte byte0 = datainputstream.readByte();
            final short word2 = datainputstream.readShort();
            this.itemStack = new ItemStack(word0, byte0, word2);
        }
        else {
            this.itemStack = null;
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.write(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.write(this.direction);
        if (this.itemStack == null) {
            dataoutputstream.writeShort(-1);
        }
        else {
            dataoutputstream.writeShort(this.itemStack.itemID);
            dataoutputstream.writeByte(this.itemStack.stackSize);
            dataoutputstream.writeShort(this.itemStack.itemDamage);
        }
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handlePlace(this);
    }
    
    @Override
    public int getPacketSize() {
        return 15;
    }
}
