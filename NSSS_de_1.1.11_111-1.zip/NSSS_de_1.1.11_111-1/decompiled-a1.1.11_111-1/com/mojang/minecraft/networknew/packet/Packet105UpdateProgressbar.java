package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet105UpdateProgressbar extends Packet
{
    public int windowId;
    public int progressBar;
    public int progressBarValue;
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20090_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
        this.progressBar = datainputstream.readShort();
        this.progressBarValue = datainputstream.readShort();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
        dataoutputstream.writeShort(this.progressBar);
        dataoutputstream.writeShort(this.progressBarValue);
    }
    
    @Override
    public int getPacketSize() {
        return 5;
    }
}
