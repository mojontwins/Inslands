package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet9Respawn extends Packet
{
    public byte field_28048_a;
    
    public Packet9Respawn() {
    }
    
    public Packet9Respawn(final byte byte0) {
        this.field_28048_a = byte0;
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_9448_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_28048_a = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.field_28048_a);
    }
    
    @Override
    public int getPacketSize() {
        return 1;
    }
}
