package com.mojang.minecraft.networknew.packet;

class Empty2
{
}
