package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet34EntityTeleport extends Packet
{
    public int entityId;
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public byte yaw;
    public byte pitch;
    
    public Packet34EntityTeleport() {
    }
    
    public Packet34EntityTeleport(final Entity entity) {
        this.entityId = entity.entityId;
        this.xPosition = MathHelper.floor_double(entity.posX * 32.0);
        this.yPosition = MathHelper.floor_double(entity.posY * 32.0);
        this.zPosition = MathHelper.floor_double(entity.posZ * 32.0);
        this.yaw = (byte)(entity.rotationYaw * 256.0f / 360.0f);
        this.pitch = (byte)(entity.rotationPitch * 256.0f / 360.0f);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.zPosition = datainputstream.readInt();
        this.yaw = (byte)datainputstream.read();
        this.pitch = (byte)datainputstream.read();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        dataoutputstream.write(this.yaw);
        dataoutputstream.write(this.pitch);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleEntityTeleport(this);
    }
    
    @Override
    public int getPacketSize() {
        return 34;
    }
}
