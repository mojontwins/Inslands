package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet61DoorChange extends Packet
{
    public int field_28050_a;
    public int field_28049_b;
    public int field_28053_c;
    public int field_28052_d;
    public int field_28051_e;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.field_28050_a = datainputstream.readInt();
        this.field_28053_c = datainputstream.readInt();
        this.field_28052_d = datainputstream.readByte();
        this.field_28051_e = datainputstream.readInt();
        this.field_28049_b = datainputstream.readInt();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.field_28050_a);
        dataoutputstream.writeInt(this.field_28053_c);
        dataoutputstream.writeByte(this.field_28052_d);
        dataoutputstream.writeInt(this.field_28051_e);
        dataoutputstream.writeInt(this.field_28049_b);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_28115_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 20;
    }
}
