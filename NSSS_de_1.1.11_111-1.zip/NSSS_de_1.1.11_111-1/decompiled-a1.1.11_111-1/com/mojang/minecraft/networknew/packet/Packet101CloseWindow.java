package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet101CloseWindow extends Packet
{
    public int windowId;
    
    public Packet101CloseWindow() {
    }
    
    public Packet101CloseWindow(final int i) {
        this.windowId = i;
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20092_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
    }
    
    @Override
    public int getPacketSize() {
        return 1;
    }
}
