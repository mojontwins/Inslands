package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet50PreChunk extends Packet
{
    public int xPosition;
    public int yPosition;
    public boolean mode;
    
    public Packet50PreChunk() {
        this.isChunkDataPacket = false;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readInt();
        this.mode = (datainputstream.read() != 0);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeInt(this.yPosition);
        dataoutputstream.write(this.mode ? 1 : 0);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handlePreChunk(this);
    }
    
    @Override
    public int getPacketSize() {
        return 9;
    }
}
