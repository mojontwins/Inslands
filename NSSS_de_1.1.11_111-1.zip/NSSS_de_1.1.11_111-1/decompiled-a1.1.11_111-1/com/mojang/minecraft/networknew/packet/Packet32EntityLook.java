package com.mojang.minecraft.networknew.packet;

import java.io.*;

public class Packet32EntityLook extends Packet30Entity
{
    public Packet32EntityLook() {
        this.rotating = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        super.readPacketData(datainputstream);
        this.yaw = datainputstream.readByte();
        this.pitch = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        super.writePacketData(dataoutputstream);
        dataoutputstream.writeByte(this.yaw);
        dataoutputstream.writeByte(this.pitch);
    }
    
    @Override
    public int getPacketSize() {
        return 6;
    }
}
