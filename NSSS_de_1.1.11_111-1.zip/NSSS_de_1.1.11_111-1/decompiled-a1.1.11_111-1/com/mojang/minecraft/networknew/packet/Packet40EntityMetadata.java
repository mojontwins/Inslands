package com.mojang.minecraft.networknew.packet;

import java.util.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet40EntityMetadata extends Packet
{
    public int entityId;
    private List field_21048_b;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.field_21048_b = DataWatcher.readWatchableObjects(datainputstream);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        DataWatcher.writeObjectsInListToStream(this.field_21048_b, dataoutputstream);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_21148_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 5;
    }
    
    public List func_21047_b() {
        return this.field_21048_b;
    }
}
