package com.mojang.minecraft.networknew.packet;

import java.io.*;

public class Packet12PlayerLook extends Packet10Flying
{
    public Packet12PlayerLook() {
        this.rotating = true;
    }
    
    public Packet12PlayerLook(final float f, final float f1, final boolean flag) {
        this.yaw = f;
        this.pitch = f1;
        this.onGround = flag;
        this.rotating = true;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.yaw = datainputstream.readFloat();
        this.pitch = datainputstream.readFloat();
        super.readPacketData(datainputstream);
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeFloat(this.yaw);
        dataoutputstream.writeFloat(this.pitch);
        super.writePacketData(dataoutputstream);
    }
    
    @Override
    public int getPacketSize() {
        return 9;
    }
}
