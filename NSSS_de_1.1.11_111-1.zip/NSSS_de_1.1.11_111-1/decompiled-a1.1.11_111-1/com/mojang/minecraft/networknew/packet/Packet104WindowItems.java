package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.item.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet104WindowItems extends Packet
{
    public int windowId;
    public ItemStack[] itemStack;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
        final short word0 = datainputstream.readShort();
        this.itemStack = new ItemStack[word0];
        for (int i = 0; i < word0; ++i) {
            final short word2 = datainputstream.readShort();
            if (word2 >= 0) {
                final byte byte0 = datainputstream.readByte();
                final short word3 = datainputstream.readShort();
                this.itemStack[i] = new ItemStack(word2, byte0, word3);
            }
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
        dataoutputstream.writeShort(this.itemStack.length);
        for (int i = 0; i < this.itemStack.length; ++i) {
            if (this.itemStack[i] == null) {
                dataoutputstream.writeShort(-1);
            }
            else {
                dataoutputstream.writeShort((short)this.itemStack[i].itemID);
                dataoutputstream.writeByte((byte)this.itemStack[i].stackSize);
                dataoutputstream.writeShort((short)this.itemStack[i].itemDamage);
            }
        }
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20094_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 3 + this.itemStack.length * 5;
    }
}
