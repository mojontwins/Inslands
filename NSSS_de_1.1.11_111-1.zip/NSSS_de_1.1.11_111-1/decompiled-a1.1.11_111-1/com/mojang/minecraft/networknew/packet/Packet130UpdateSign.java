package com.mojang.minecraft.networknew.packet;

import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet130UpdateSign extends Packet
{
    public int xPosition;
    public int yPosition;
    public int zPosition;
    public String[] signLines;
    
    public Packet130UpdateSign() {
        this.isChunkDataPacket = true;
    }
    
    public Packet130UpdateSign(final int i, final int j, final int k, final String[] as) {
        this.isChunkDataPacket = true;
        this.xPosition = i;
        this.yPosition = j;
        this.zPosition = k;
        this.signLines = as;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.xPosition = datainputstream.readInt();
        this.yPosition = datainputstream.readShort();
        this.zPosition = datainputstream.readInt();
        this.signLines = new String[4];
        for (int i = 0; i < 4; ++i) {
            this.signLines[i] = Packet.readString(datainputstream, 15);
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.xPosition);
        dataoutputstream.writeShort(this.yPosition);
        dataoutputstream.writeInt(this.zPosition);
        for (int i = 0; i < 4; ++i) {
            Packet.writeString(this.signLines[i], dataoutputstream);
        }
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleSignUpdate(this);
    }
    
    @Override
    public int getPacketSize() {
        int i = 0;
        for (int j = 0; j < 4; ++j) {
            i += this.signLines[j].length();
        }
        return i;
    }
}
