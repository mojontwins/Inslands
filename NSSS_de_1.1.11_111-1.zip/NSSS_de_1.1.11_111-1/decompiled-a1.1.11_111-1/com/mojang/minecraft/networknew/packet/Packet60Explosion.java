package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.level.chunk.*;
import java.io.*;
import java.util.*;
import com.mojang.minecraft.networknew.*;

public class Packet60Explosion extends Packet
{
    public double explosionX;
    public double explosionY;
    public double explosionZ;
    public float explosionSize;
    public Set destroyedBlockPositions;
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.explosionX = datainputstream.readDouble();
        this.explosionY = datainputstream.readDouble();
        this.explosionZ = datainputstream.readDouble();
        this.explosionSize = datainputstream.readFloat();
        final int i = datainputstream.readInt();
        this.destroyedBlockPositions = new HashSet();
        final int j = (int)this.explosionX;
        final int k = (int)this.explosionY;
        final int l = (int)this.explosionZ;
        for (int i2 = 0; i2 < i; ++i2) {
            final int j2 = datainputstream.readByte() + j;
            final int k2 = datainputstream.readByte() + k;
            final int l2 = datainputstream.readByte() + l;
            this.destroyedBlockPositions.add(new ChunkPosition(j2, k2, l2));
        }
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeDouble(this.explosionX);
        dataoutputstream.writeDouble(this.explosionY);
        dataoutputstream.writeDouble(this.explosionZ);
        dataoutputstream.writeFloat(this.explosionSize);
        dataoutputstream.writeInt(this.destroyedBlockPositions.size());
        final int i = (int)this.explosionX;
        final int j = (int)this.explosionY;
        final int k = (int)this.explosionZ;
        for (final ChunkPosition chunkposition : this.destroyedBlockPositions) {
            final int l = chunkposition.x - i;
            final int i2 = chunkposition.y - j;
            final int j2 = chunkposition.z - k;
            dataoutputstream.writeByte(l);
            dataoutputstream.writeByte(i2);
            dataoutputstream.writeByte(j2);
        }
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_12245_a(this);
    }
    
    @Override
    public int getPacketSize() {
        return 32 + this.destroyedBlockPositions.size() * 3;
    }
}
