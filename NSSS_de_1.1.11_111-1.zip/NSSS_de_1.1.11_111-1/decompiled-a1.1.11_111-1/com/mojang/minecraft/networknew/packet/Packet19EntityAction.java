package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.entity.*;
import java.io.*;
import com.mojang.minecraft.networknew.*;

public class Packet19EntityAction extends Packet
{
    public int entityId;
    public int state;
    
    public Packet19EntityAction() {
    }
    
    public Packet19EntityAction(final Entity entity, final int i) {
        this.entityId = entity.entityId;
        this.state = i;
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.entityId = datainputstream.readInt();
        this.state = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeInt(this.entityId);
        dataoutputstream.writeByte(this.state);
    }
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.handleEntityAction(this);
    }
    
    @Override
    public int getPacketSize() {
        return 5;
    }
}
