package com.mojang.minecraft.networknew.packet;

import com.mojang.minecraft.networknew.*;
import java.io.*;

public class Packet100OpenWindow extends Packet
{
    public int windowId;
    public int inventoryType;
    public String windowTitle;
    public int slotsCount;
    
    @Override
    public void processPacket(final NetHandler nethandler) {
        nethandler.func_20087_a(this);
    }
    
    @Override
    public void readPacketData(final DataInputStream datainputstream) throws IOException {
        this.windowId = datainputstream.readByte();
        this.inventoryType = datainputstream.readByte();
        this.windowTitle = datainputstream.readUTF();
        this.slotsCount = datainputstream.readByte();
    }
    
    @Override
    public void writePacketData(final DataOutputStream dataoutputstream) throws IOException {
        dataoutputstream.writeByte(this.windowId);
        dataoutputstream.writeByte(this.inventoryType);
        dataoutputstream.writeUTF(this.windowTitle);
        dataoutputstream.writeByte(this.slotsCount);
    }
    
    @Override
    public int getPacketSize() {
        return 3 + this.windowTitle.length();
    }
}
