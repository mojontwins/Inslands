package com.mojang.minecraft.networknew;

import java.util.*;
import java.net.*;
import java.io.*;
import com.mojang.minecraft.networknew.packet.*;

public class NetworkManager
{
    public static final Object threadSyncObject;
    public static int numReadThreads;
    public static int numWriteThreads;
    private Object sendQueueLock;
    private Socket networkSocket;
    private final SocketAddress remoteSocketAddress;
    private DataInputStream socketInputStream;
    private DataOutputStream socketOutputStream;
    private boolean isRunning;
    private List readPackets;
    private List dataPackets;
    private List chunkDataPackets;
    private NetHandler netHandler;
    private boolean isServerTerminating;
    private Thread writeThread;
    private Thread readThread;
    private boolean isTerminating;
    private String terminationReason;
    private Object[] field_20101_t;
    private int timeSinceLastRead;
    private int sendQueueByteLength;
    public static int[] field_28145_d;
    public static int[] field_28144_e;
    public int chunkDataSendCounter;
    private int field_20100_w;
    
    static {
        threadSyncObject = new Object();
        NetworkManager.field_28145_d = new int[256];
        NetworkManager.field_28144_e = new int[256];
    }
    
    public NetworkManager(final Socket socket, final String s, final NetHandler nethandler) throws IOException {
        this.sendQueueLock = new Object();
        this.isRunning = true;
        this.readPackets = Collections.synchronizedList(new ArrayList<Object>());
        this.dataPackets = Collections.synchronizedList(new ArrayList<Object>());
        this.chunkDataPackets = Collections.synchronizedList(new ArrayList<Object>());
        this.isServerTerminating = false;
        this.isTerminating = false;
        this.terminationReason = "";
        this.timeSinceLastRead = 0;
        this.sendQueueByteLength = 0;
        this.chunkDataSendCounter = 0;
        this.field_20100_w = 50;
        this.networkSocket = socket;
        this.remoteSocketAddress = socket.getRemoteSocketAddress();
        this.netHandler = nethandler;
        try {
            socket.setSoTimeout(30000);
            socket.setTrafficClass(24);
        }
        catch (SocketException socketexception) {
            System.err.println(socketexception.getMessage());
        }
        this.socketInputStream = new DataInputStream(socket.getInputStream());
        this.socketOutputStream = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream(), 5120));
        this.readThread = new NetworkReaderThread(this, s + " read thread");
        this.writeThread = new NetworkWriterThread(this, s + " write thread");
        this.readThread.start();
        this.writeThread.start();
    }
    
    public void addToSendQueue(final Packet packet) {
        if (this.isServerTerminating) {
            return;
        }
        synchronized (this.sendQueueLock) {
            this.sendQueueByteLength += packet.getPacketSize() + 1;
            if (packet.isChunkDataPacket) {
                this.chunkDataPackets.add(packet);
            }
            else {
                this.dataPackets.add(packet);
            }
        }
        // monitorexit(this.sendQueueLock)
    }
    
    private boolean sendPacket() {
        boolean flag = false;
        try {
            if (!this.dataPackets.isEmpty() && (this.chunkDataSendCounter == 0 || System.currentTimeMillis() - this.dataPackets.get(0).creationTimeMillis >= this.chunkDataSendCounter)) {
                final Packet packet;
                synchronized (this.sendQueueLock) {
                    packet = this.dataPackets.remove(0);
                    this.sendQueueByteLength -= packet.getPacketSize() + 1;
                }
                // monitorexit(this.sendQueueLock)
                Packet.writePacket(packet, this.socketOutputStream);
                final int[] field_28144_e = NetworkManager.field_28144_e;
                final int packetId = packet.getPacketId();
                field_28144_e[packetId] += packet.getPacketSize() + 1;
                flag = true;
            }
            if (this.field_20100_w-- <= 0 && !this.chunkDataPackets.isEmpty() && (this.chunkDataSendCounter == 0 || System.currentTimeMillis() - this.chunkDataPackets.get(0).creationTimeMillis >= this.chunkDataSendCounter)) {
                final Packet packet2;
                synchronized (this.sendQueueLock) {
                    packet2 = this.chunkDataPackets.remove(0);
                    this.sendQueueByteLength -= packet2.getPacketSize() + 1;
                }
                // monitorexit(this.sendQueueLock)
                Packet.writePacket(packet2, this.socketOutputStream);
                final int[] field_28144_e2 = NetworkManager.field_28144_e;
                final int packetId2 = packet2.getPacketId();
                field_28144_e2[packetId2] += packet2.getPacketSize() + 1;
                this.field_20100_w = 0;
                flag = true;
            }
        }
        catch (Exception exception) {
            if (!this.isTerminating) {
                this.onNetworkError(exception);
            }
            return false;
        }
        return flag;
    }
    
    public void wakeThreads() {
        this.readThread.interrupt();
        this.writeThread.interrupt();
    }
    
    private boolean readPacket() {
        boolean flag = false;
        try {
            final Packet packet = Packet.readPacket(this.socketInputStream, this.netHandler.isServerHandler());
            if (packet != null) {
                final int[] field_28145_d = NetworkManager.field_28145_d;
                final int packetId = packet.getPacketId();
                field_28145_d[packetId] += packet.getPacketSize() + 1;
                this.readPackets.add(packet);
                flag = true;
            }
            else {
                this.networkShutdown("End of Stream", new Object[0]);
            }
        }
        catch (Exception exception) {
            if (!this.isTerminating) {
                this.onNetworkError(exception);
            }
            return false;
        }
        return flag;
    }
    
    private void onNetworkError(final Exception exception) {
        exception.printStackTrace();
        this.networkShutdown("Disconnected: " + exception, new Object[] { "Internal exception: " + exception.toString() });
    }
    
    public void networkShutdown(final String s, final Object[] aobj) {
        if (!this.isRunning) {
            return;
        }
        this.isTerminating = true;
        this.terminationReason = s;
        this.field_20101_t = aobj;
        new NetworkMasterThread(this).start();
        this.isRunning = false;
        try {
            this.socketInputStream.close();
            this.socketInputStream = null;
        }
        catch (Throwable t) {}
        try {
            this.socketOutputStream.close();
            this.socketOutputStream = null;
        }
        catch (Throwable t2) {}
        try {
            this.networkSocket.close();
            this.networkSocket = null;
        }
        catch (Throwable t3) {}
    }
    
    public void processReadPackets() {
        if (this.sendQueueByteLength > 1048576) {
            this.networkShutdown("Packet Overflow", new Object[0]);
        }
        if (this.readPackets.isEmpty()) {
            if (this.timeSinceLastRead++ == 1200) {
                this.networkShutdown("Packet Timeout", new Object[0]);
            }
        }
        else {
            this.timeSinceLastRead = 0;
        }
        int i = 100;
        while (!this.readPackets.isEmpty() && i-- >= 0) {
            final Packet packet = this.readPackets.remove(0);
            packet.processPacket(this.netHandler);
        }
        this.wakeThreads();
        if (this.isTerminating && this.readPackets.isEmpty()) {
            this.netHandler.handleErrorMessage(this.terminationReason, this.field_20101_t);
        }
    }
    
    public void func_28142_c() {
        this.wakeThreads();
        this.isServerTerminating = true;
        this.readThread.interrupt();
        new ThreadCloseConnection(this).start();
    }
    
    static boolean isRunning(final NetworkManager networkmanager) {
        return networkmanager.isRunning;
    }
    
    static boolean isServerTerminating(final NetworkManager networkmanager) {
        return networkmanager.isServerTerminating;
    }
    
    static boolean readNetworkPacket(final NetworkManager networkmanager) {
        return networkmanager.readPacket();
    }
    
    static boolean sendNetworkPacket(final NetworkManager networkmanager) {
        return networkmanager.sendPacket();
    }
    
    static DataOutputStream func_28140_f(final NetworkManager networkmanager) {
        return networkmanager.socketOutputStream;
    }
    
    static boolean func_28138_e(final NetworkManager networkmanager) {
        return networkmanager.isTerminating;
    }
    
    static void func_30005_a(final NetworkManager networkmanager, final Exception exception) {
        networkmanager.onNetworkError(exception);
    }
    
    static Thread getReadThread(final NetworkManager networkmanager) {
        return networkmanager.readThread;
    }
    
    static Thread getWriteThread(final NetworkManager networkmanager) {
        return networkmanager.writeThread;
    }
}
