package com.mojang.minecraft.networknew;

import com.mojang.minecraft.networknew.packet.*;

public abstract class NetHandler
{
    public abstract boolean isServerHandler();
    
    public void handleMapChunk(final Packet51MapChunk packet51mapchunk) {
    }
    
    public void registerPacket(final Packet packet) {
    }
    
    public void handleErrorMessage(final String s, final Object[] aobj) {
    }
    
    public void handleKickDisconnect(final Packet255KickDisconnect packet255kickdisconnect) {
        this.registerPacket(packet255kickdisconnect);
    }
    
    public void handleLogin(final Packet1Login packet1login) {
        this.registerPacket(packet1login);
    }
    
    public void handleFlying(final Packet10Flying packet10flying) {
        this.registerPacket(packet10flying);
    }
    
    public void handleMultiBlockChange(final Packet52MultiBlockChange packet52multiblockchange) {
        this.registerPacket(packet52multiblockchange);
    }
    
    public void handleBlockDig(final Packet14BlockDig packet14blockdig) {
        this.registerPacket(packet14blockdig);
    }
    
    public void handleBlockChange(final Packet53BlockChange packet53blockchange) {
        this.registerPacket(packet53blockchange);
    }
    
    public void handlePreChunk(final Packet50PreChunk packet50prechunk) {
        this.registerPacket(packet50prechunk);
    }
    
    public void handleNamedEntitySpawn(final Packet20NamedEntitySpawn packet20namedentityspawn) {
        this.registerPacket(packet20namedentityspawn);
    }
    
    public void handleEntity(final Packet30Entity packet30entity) {
        this.registerPacket(packet30entity);
    }
    
    public void handleEntityTeleport(final Packet34EntityTeleport packet34entityteleport) {
        this.registerPacket(packet34entityteleport);
    }
    
    public void handlePlace(final Packet15Place packet15place) {
        this.registerPacket(packet15place);
    }
    
    public void handleBlockItemSwitch(final Packet16BlockItemSwitch packet16blockitemswitch) {
        this.registerPacket(packet16blockitemswitch);
    }
    
    public void handleDestroyEntity(final Packet29DestroyEntity packet29destroyentity) {
        this.registerPacket(packet29destroyentity);
    }
    
    public void handlePickupSpawn(final Packet21PickupSpawn packet21pickupspawn) {
        this.registerPacket(packet21pickupspawn);
    }
    
    public void handleCollect(final Packet22Collect packet22collect) {
        this.registerPacket(packet22collect);
    }
    
    public void handleChat(final Packet3Chat packet3chat) {
        this.registerPacket(packet3chat);
    }
    
    public void handleVehicleSpawn(final Packet23VehicleSpawn packet23vehiclespawn) {
        this.registerPacket(packet23vehiclespawn);
    }
    
    public void handleArmAnimation(final Packet18Animation packet18animation) {
        this.registerPacket(packet18animation);
    }
    
    public void handleEntityAction(final Packet19EntityAction packet19entityaction) {
        this.registerPacket(packet19entityaction);
    }
    
    public void handleHandshake(final Packet2Handshake packet2handshake) {
        this.registerPacket(packet2handshake);
    }
    
    public void handleMobSpawn(final Packet24MobSpawn packet24mobspawn) {
        this.registerPacket(packet24mobspawn);
    }
    
    public void handleUpdateTime(final Packet4UpdateTime packet4updatetime) {
        this.registerPacket(packet4updatetime);
    }
    
    public void handleSpawnPosition(final Packet6SpawnPosition packet6spawnposition) {
        this.registerPacket(packet6spawnposition);
    }
    
    public void func_6498_a(final Packet28EntityVelocity packet28entityvelocity) {
        this.registerPacket(packet28entityvelocity);
    }
    
    public void func_21148_a(final Packet40EntityMetadata packet40entitymetadata) {
        this.registerPacket(packet40entitymetadata);
    }
    
    public void func_6497_a(final Packet39AttachEntity packet39attachentity) {
        this.registerPacket(packet39attachentity);
    }
    
    public void handleUseEntity(final Packet7UseEntity packet7useentity) {
        this.registerPacket(packet7useentity);
    }
    
    public void func_9447_a(final Packet38EntityStatus packet38entitystatus) {
        this.registerPacket(packet38entitystatus);
    }
    
    public void handleHealth(final Packet8UpdateHealth packet8updatehealth) {
        this.registerPacket(packet8updatehealth);
    }
    
    public void func_9448_a(final Packet9Respawn packet9respawn) {
        this.registerPacket(packet9respawn);
    }
    
    public void func_12245_a(final Packet60Explosion packet60explosion) {
        this.registerPacket(packet60explosion);
    }
    
    public void func_20087_a(final Packet100OpenWindow packet100openwindow) {
        this.registerPacket(packet100openwindow);
    }
    
    public void func_20092_a(final Packet101CloseWindow packet101closewindow) {
        this.registerPacket(packet101closewindow);
    }
    
    public void func_20091_a(final Packet102WindowClick packet102windowclick) {
        this.registerPacket(packet102windowclick);
    }
    
    public void func_20088_a(final Packet103SetSlot packet103setslot) {
        this.registerPacket(packet103setslot);
    }
    
    public void func_20094_a(final Packet104WindowItems packet104windowitems) {
        this.registerPacket(packet104windowitems);
    }
    
    public void handleSignUpdate(final Packet130UpdateSign packet130updatesign) {
        this.registerPacket(packet130updatesign);
    }
    
    public void func_20090_a(final Packet105UpdateProgressbar packet105updateprogressbar) {
        this.registerPacket(packet105updateprogressbar);
    }
    
    public void handlePlayerInventory(final Packet5PlayerInventory packet5playerinventory) {
        this.registerPacket(packet5playerinventory);
    }
    
    public void func_20089_a(final Packet106Transaction packet106transaction) {
        this.registerPacket(packet106transaction);
    }
    
    public void func_21146_a(final Packet25EntityPainting packet25entitypainting) {
        this.registerPacket(packet25entitypainting);
    }
    
    public void handleNotePlay(final Packet54PlayNoteBlock packet54playnoteblock) {
        this.registerPacket(packet54playnoteblock);
    }
    
    public void func_27245_a(final Packet200Statistic packet200statistic) {
        this.registerPacket(packet200statistic);
    }
    
    public void func_22186_a(final Packet17Sleep packet17sleep) {
        this.registerPacket(packet17sleep);
    }
    
    public void func_22185_a(final Packet27Position packet27position) {
        this.registerPacket(packet27position);
    }
    
    public void func_25118_a(final Packet70Bed packet70bed) {
        this.registerPacket(packet70bed);
    }
    
    public void handleWeather(final Packet71Weather packet71weather) {
        this.registerPacket(packet71weather);
    }
    
    public void func_28116_a(final Packet131MapData packet131mapdata) {
        this.registerPacket(packet131mapdata);
    }
    
    public void func_28115_a(final Packet61DoorChange packet61doorchange) {
        this.registerPacket(packet61doorchange);
    }
    
    public void handlePlayerScore(final Packet69PlayerScore packet69PlayerScore) {
        this.registerPacket(packet69PlayerScore);
    }
}
