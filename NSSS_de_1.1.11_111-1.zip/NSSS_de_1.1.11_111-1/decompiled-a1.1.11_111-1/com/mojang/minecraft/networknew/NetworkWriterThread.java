package com.mojang.minecraft.networknew;

import java.io.*;

class NetworkWriterThread extends Thread
{
    final NetworkManager netManager;
    
    NetworkWriterThread(final NetworkManager networkmanager, final String s) {
        super(s);
        this.netManager = networkmanager;
    }
    
    @Override
    public void run() {
        synchronized (NetworkManager.threadSyncObject) {
            ++NetworkManager.numWriteThreads;
        }
        // monitorexit(NetworkManager.threadSyncObject)
        try {
            while (NetworkManager.isRunning(this.netManager)) {
                while (NetworkManager.sendNetworkPacket(this.netManager)) {}
                try {
                    Thread.sleep(2L);
                }
                catch (InterruptedException ex) {}
                try {
                    if (NetworkManager.func_28140_f(this.netManager) == null) {
                        continue;
                    }
                    NetworkManager.func_28140_f(this.netManager).flush();
                }
                catch (IOException ioexception) {
                    if (!NetworkManager.func_28138_e(this.netManager)) {
                        NetworkManager.func_30005_a(this.netManager, ioexception);
                    }
                    ioexception.printStackTrace();
                }
            }
        }
        finally {
            synchronized (NetworkManager.threadSyncObject) {
                --NetworkManager.numWriteThreads;
            }
            // monitorexit(NetworkManager.threadSyncObject)
        }
        synchronized (NetworkManager.threadSyncObject) {
            --NetworkManager.numWriteThreads;
        }
        // monitorexit(NetworkManager.threadSyncObject)
    }
}
