package com.mojang.minecraft;

public class MinecraftError extends Error
{
    private static final long serialVersionUID = 1L;
}
