package com.mojang.minecraft;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.model.*;
import com.mojang.minecraft.sound.*;
import java.io.*;
import org.lwjgl.*;
import org.lwjgl.input.*;
import org.lwjgl.opengl.*;
import com.mojang.minecraft.level.tile.fx.*;
import com.mojang.minecraft.enums.*;
import org.lwjgl.util.glu.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.tile.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.gui.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.level.generate.*;
import java.awt.*;
import com.mojang.minecraft.player.controller.*;
import java.awt.event.*;
import com.mojang.minecraft.networknew.*;

public abstract class Minecraft implements Runnable
{
    private static Minecraft theMinecraft;
    public PlayerController playerController;
    private boolean isFullscreen;
    public int displayWidth;
    public int displayHeight;
    private OpenGlCapsChecker glCapabilities;
    private Timer timer;
    public World mcWorld;
    public RenderGlobal renderGlobal;
    public EntityPlayerSP thePlayer;
    public EntityLiving renderViewEntity;
    public EffectRenderer effectRenderer;
    public Session session;
    public String field_175_j;
    public Canvas mcCanvas;
    public boolean field_173_l;
    public volatile boolean isGamePaused;
    public RenderEngine renderEngine;
    public FontRenderer fontRender;
    public GuiScreen currentScreen;
    public LoadingScreenRenderer loadScreen;
    public EntityRenderer entityRenderer;
    private ThreadDownloadResources downloadResourcesThread;
    private int ticksRan;
    private int leftClickCounter;
    private int field_142_Q;
    private int field_141_R;
    public String field_166_s;
    public int field_165_t;
    public GuiIngame ingameGUI;
    public boolean skipRenderWorld;
    public ModelBiped field_162_w;
    public MovingObjectPosition objectMouseOver;
    public GameSettings options;
    protected MinecraftApplet mcApplet;
    public SoundManager soundMGR;
    public MouseHelper mouseHelper;
    public File mcDataDir;
    public static long[] field_155_D;
    public static int field_154_E;
    private String serverName;
    private int serverPort;
    private TextureWaterFX textureWaterFX;
    private TextureLavaFX textureLavaFX;
    private TextureWaterOverlayFX waterOverlay;
    private static File dataFolder;
    public volatile boolean running;
    public String debug;
    boolean isTakingScreenshot;
    long field_151_H;
    public boolean inGameHasFocus;
    private int mouseTicksRan;
    public boolean enableRain;
    long systemTime;
    private int joinPlayerCounter;
    private Vec3D savedPlayerPos;
    public static boolean isIRIX;
    public static boolean isMACOS;
    public boolean hasChimed;
    public static String chime;
    public static String versionNumber;
    public static String version;
    public SkinManager skins;
    
    static {
        Minecraft.field_155_D = new long[512];
        Minecraft.field_154_E = 0;
        Minecraft.dataFolder = null;
        Minecraft.chime = "";
        Minecraft.versionNumber = "v1.1.11_111-1";
        Minecraft.version = "Minecraft Alpha " + Minecraft.versionNumber;
    }
    
    public Minecraft(final Component component, final Canvas canvas, final MinecraftApplet minecraftapplet, final int i, final int j, final boolean flag) {
        this.hasChimed = false;
        this.isFullscreen = false;
        this.timer = new Timer(20.0f);
        this.session = null;
        this.field_173_l = true;
        this.isGamePaused = false;
        this.currentScreen = null;
        this.loadScreen = new LoadingScreenRenderer(this);
        this.entityRenderer = new EntityRenderer(this);
        this.ticksRan = 0;
        this.leftClickCounter = 0;
        this.field_166_s = null;
        this.field_165_t = 0;
        this.skipRenderWorld = false;
        this.field_162_w = new ModelBiped(0.0f);
        this.objectMouseOver = null;
        this.soundMGR = new SoundManager();
        this.textureWaterFX = new TextureWaterFX();
        this.textureLavaFX = new TextureLavaFX();
        this.waterOverlay = new TextureWaterOverlayFX();
        this.running = true;
        this.debug = "";
        this.field_151_H = -1L;
        this.inGameHasFocus = false;
        this.mouseTicksRan = 0;
        this.enableRain = false;
        this.systemTime = System.currentTimeMillis();
        this.joinPlayerCounter = 0;
        this.field_142_Q = i;
        this.field_141_R = j;
        this.isFullscreen = flag;
        this.mcApplet = minecraftapplet;
        new ThreadSleepForever(this, "Timer hack thread");
        this.mcCanvas = canvas;
        this.displayWidth = i;
        this.displayHeight = j;
        this.isFullscreen = flag;
        this.savedPlayerPos = Vec3D.createVectorHelper(0.0, 128.0, 0.0);
        Minecraft.isIRIX = false;
        Minecraft.isMACOS = false;
        Minecraft.theMinecraft = this;
    }
    
    public abstract void onMinecraftCrash(final UnexpectedThrowable p0);
    
    public void setServer(final String s, final int i) {
        this.serverName = s;
        this.serverPort = i;
    }
    
    public void startupScreen() throws LWJGLException {
        System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
        if (this.mcCanvas != null) {
            final Graphics g = this.mcCanvas.getGraphics();
            if (g != null) {
                g.setColor(Color.BLACK);
                g.fillRect(0, 0, this.displayWidth, this.displayHeight);
                g.dispose();
            }
            Display.setParent(this.mcCanvas);
        }
        else if (this.isFullscreen) {
            Display.setFullscreen(true);
            this.displayWidth = Display.getDisplayMode().getWidth();
            this.displayHeight = Display.getDisplayMode().getHeight();
            if (this.displayWidth <= 0) {
                this.displayWidth = 1;
            }
            if (this.displayHeight <= 0) {
                this.displayHeight = 1;
            }
        }
        else {
            Display.setDisplayMode(new DisplayMode(this.displayWidth, this.displayHeight));
        }
        Display.setTitle(Minecraft.version);
        try {
            Display.create(new PixelFormat().withDepthBits(24));
        }
        catch (LWJGLException lwjglexception) {
            lwjglexception.printStackTrace();
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException ex) {}
            Display.create();
        }
        RenderManager.subManager.itemRenderer = new ItemRenderer(this);
        this.mcDataDir = getMinecraftDir();
        this.options = new GameSettings(this, this.mcDataDir);
        this.renderEngine = new RenderEngine(this.options);
        this.fontRender = new FontRenderer(this.options, "/default.png", this.renderEngine);
        this.showMahjong();
        Keyboard.create();
        Mouse.create();
        this.mouseHelper = new MouseHelper(this.mcCanvas);
        try {
            Controllers.create();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.checkGLError("Pre startup");
        GL11.glEnable(3553);
        GL11.glShadeModel(7425);
        GL11.glClearDepth(1.0);
        GL11.glEnable(2929);
        GL11.glDepthFunc(515);
        GL11.glEnable(3008);
        GL11.glAlphaFunc(516, 0.1f);
        GL11.glCullFace(1029);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glMatrixMode(5888);
        this.checkGLError("Startup");
        this.glCapabilities = new OpenGlCapsChecker();
        this.soundMGR.initialize(this.options);
        this.renderEngine.bindTextureFX(this.textureLavaFX);
        this.renderEngine.bindTextureFX(this.textureWaterFX);
        this.renderEngine.bindTextureFX(this.waterOverlay);
        this.renderEngine.bindTextureFX(new TextureCompassFX(this));
        this.renderEngine.bindTextureFX(new TexureWaterFlowFX());
        this.renderEngine.bindTextureFX(new TextureLavaFlowFX());
        this.renderEngine.bindTextureFX(new TextureFlamesFX(0));
        this.renderEngine.bindTextureFX(new TextureFlamesFX(1));
        this.renderEngine.bindTextureFX(new TextureGearFX(16));
        this.renderEngine.bindTextureFX(new TextureGearFX(17));
        this.renderEngine.bindTextureFX(new TextureGearIdleFX(0));
        this.renderEngine.bindTextureFX(new TextureGearIdleFX(1));
        this.renderGlobal = new RenderGlobal(this, this.renderEngine);
        GL11.glViewport(0, 0, this.displayWidth, this.displayHeight);
        this.effectRenderer = new EffectRenderer(this.mcWorld, this.renderEngine, this);
        try {
            (this.downloadResourcesThread = new ThreadDownloadResources(this.mcDataDir, this)).start();
        }
        catch (Exception ex2) {}
        this.checkGLError("Post startup");
        this.ingameGUI = new GuiIngame(this);
        this.skins = new SkinManager(this);
        if (this.serverName != null) {
            this.setCurrentScreen(new GuiConnecting(this, this.serverName, this.serverPort));
        }
        else {
            while (this.options.soundVolume != 0.0f && !this.soundMGR.getLoaded()) {}
            this.setCurrentScreen(new GuiGrayScreen());
        }
    }
    
    private void showMahjong() throws LWJGLException {
        final int oldScale = this.options.guiScale;
        this.options.guiScale = 0;
        final ScaledResolution scaledresolution = new ScaledResolution(this.displayWidth, this.displayHeight, this);
        final int i = scaledresolution.getScaledWidth();
        final int j = scaledresolution.getScaledHeight();
        GL11.glClear(16640);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)i, (double)j, 0.0, 1000.0, 3000.0);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, -2000.0f);
        GL11.glViewport(0, 0, this.displayWidth, this.displayHeight);
        GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        final Tessellator tessellator = Tessellator.instance;
        GL11.glDisable(2896);
        GL11.glEnable(3553);
        GL11.glDisable(2912);
        final char c = '\u0100';
        final char c2 = '\u0100';
        if (!Minecraft.isMACOS && !Minecraft.isIRIX) {
            GL11.glBindTexture(3553, this.renderEngine.getTex("/title/mojang.png"));
            tessellator.startDrawingQuads();
            tessellator.setColorOpaque_I(16777215);
            tessellator.addVertexWithUV(0.0, this.displayHeight, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(this.displayWidth, this.displayHeight, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(this.displayWidth, 0.0, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0, 0.0, 0.0);
            tessellator.draw();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            tessellator.setColorOpaque_I(16777215);
            this.drawPng((this.displayWidth / 2 - c) / 2, (this.displayHeight / 2 - c2) / 2, 0, 0, c, c2);
        }
        else if (Minecraft.isIRIX) {
            GL11.glBindTexture(3553, this.renderEngine.getTex("/title/sgi_grad.png"));
            tessellator.startDrawingQuads();
            tessellator.setColorOpaque_I(16777215);
            tessellator.addVertexWithUV(0.0, this.displayHeight, 0.0, 0.0, 2.0);
            tessellator.addVertexWithUV(this.displayWidth, this.displayHeight, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(this.displayWidth, 0.0, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0, 0.0, 0.0);
            tessellator.draw();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            tessellator.setColorOpaque_I(16777215);
            GL11.glBindTexture(3553, this.renderEngine.getTex("/title/mojang_silicongraphics.png"));
            tessellator.startDrawingQuads();
            tessellator.draw();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            tessellator.setColorOpaque_I(16777215);
            this.drawPng2((this.displayWidth / 2 - 112) / 2, (this.displayHeight / 4 - 22) / 2, 0, 0, 112, 22);
        }
        else {
            GL11.glBindTexture(3553, this.renderEngine.getTex("/title/mojang_apple.png"));
            tessellator.startDrawingQuads();
            tessellator.setColorOpaque_I(16777215);
            tessellator.addVertexWithUV(0.0, this.displayHeight, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(this.displayWidth, this.displayHeight, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(this.displayWidth, 0.0, 0.0, 0.0, 0.0);
            tessellator.addVertexWithUV(0.0, 0.0, 0.0, 0.0, 0.0);
            tessellator.draw();
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            tessellator.setColorOpaque_I(16777215);
            this.drawPng((this.displayWidth / 2 - c) / 2, (this.displayHeight / 2 - c2) / 2, 0, 0, c, c2);
        }
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        GL11.glEnable(3008);
        GL11.glAlphaFunc(516, 0.1f);
        Display.swapBuffers();
        this.options.guiScale = oldScale;
        this.options.getDisplayModes();
    }
    
    public void drawPng(final int x, final int y, final int u, final int v, final int u2, final int v2) {
        final float f = 0.00390625f;
        final float f2 = 0.00390625f;
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(x + 0, y + v2, 0.0, (u + 0) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + v2, 0.0, (u + u2) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + 0, 0.0, (u + u2) * f, (v + 0) * f2);
        tessellator.addVertexWithUV(x + 0, y + 0, 0.0, (u + 0) * f, (v + 0) * f2);
        tessellator.draw();
    }
    
    public void drawPng2(final int x, final int y, final int u, final int v, final int u2, final int v2) {
        final float f = 0.00891f;
        final float f2 = 0.045f;
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawingQuads();
        tessellator.addVertexWithUV(x + 0, y + v2, 0.0, (u + 0) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + v2, 0.0, (u + u2) * f, (v + v2) * f2);
        tessellator.addVertexWithUV(x + u2, y + 0, 0.0, (u + u2) * f, (v + 0) * f2);
        tessellator.addVertexWithUV(x + 0, y + 0, 0.0, (u + 0) * f, (v + 0) * f2);
        tessellator.draw();
    }
    
    public static File getMinecraftDir() {
        if (Minecraft.dataFolder == null) {
            Minecraft.dataFolder = getAppDir("minecraft");
        }
        return Minecraft.dataFolder;
    }
    
    public static File getAppDir(final String s) {
        final String s2 = System.getProperty("user.home", ".");
        File file = null;
        switch (EnumOSMappingHelper.osEnums[getCurrentOS().ordinal()]) {
            case 1:
            case 2: {
                file = new File(s2, '.' + s + '/');
                break;
            }
            case 3: {
                final String s3 = System.getenv("APPDATA");
                if (s3 != null) {
                    file = new File(s3, "." + s + '/');
                    break;
                }
                file = new File(s2, '.' + s + '/');
                break;
            }
            case 4: {
                file = new File(s2, "Library/Application Support/" + s);
                break;
            }
            default: {
                file = new File(s2, s + '/');
                break;
            }
        }
        if (!file.exists() && !file.mkdirs()) {
            throw new RuntimeException("The working directory could not be created: " + file);
        }
        return file;
    }
    
    private static EnumOS2 getCurrentOS() {
        final String s = System.getProperty("os.name").toLowerCase();
        if (s.contains("win")) {
            return EnumOS2.windows;
        }
        if (s.contains("mac")) {
            Minecraft.isMACOS = true;
            Minecraft.chime = "random.bong";
            if (s.contains("os 9")) {
                return EnumOS2.macos9;
            }
            return EnumOS2.macos;
        }
        else {
            if (s.contains("solaris")) {
                return EnumOS2.solaris;
            }
            if (s.contains("sunos")) {
                return EnumOS2.solaris;
            }
            if (s.contains("linux")) {
                return EnumOS2.linux;
            }
            if (s.contains("irix")) {
                Minecraft.isIRIX = true;
                Minecraft.chime = "random.indy";
                return EnumOS2.irix;
            }
            if (s.contains("unix")) {
                return EnumOS2.linux;
            }
            return EnumOS2.unknown;
        }
    }
    
    public void playChime() {
        if (Minecraft.isMACOS) {
            System.out.println("BONG");
            this.soundMGR.playSoundFX("random.mac_chord", 1.0f, 1.0f);
        }
    }
    
    public void setCurrentScreen(GuiScreen guiscreen) {
        if (this.currentScreen instanceof GuiUnused) {
            return;
        }
        if (this.currentScreen != null) {
            this.currentScreen.onGuiClosed();
        }
        if (guiscreen == null && this.mcWorld == null) {
            guiscreen = new GuiMainMenu();
        }
        else if (guiscreen == null && this.thePlayer.health <= 0) {
            guiscreen = new GuiGameOver();
        }
        if ((this.currentScreen = guiscreen) != null) {
            this.setIngameNotInFocus();
            final ScaledResolution scaledresolution = new ScaledResolution(this.displayWidth, this.displayHeight, this);
            final int i = scaledresolution.getScaledWidth();
            final int j = scaledresolution.getScaledHeight();
            guiscreen.setResolution(this, i, j);
            this.skipRenderWorld = false;
        }
        else {
            this.setIngameFocus();
        }
    }
    
    private void checkGLError(final String s) {
        final int i = GL11.glGetError();
        if (i != 0) {
            final String s2 = GLU.gluErrorString(i);
            System.out.println("########## GL ERROR ##########");
            System.out.println("@ " + s);
            System.out.println(i + ": " + s2);
            System.exit(0);
        }
    }
    
    public void shutdownMinecraftApplet() {
        if (this.mcApplet != null) {
            this.mcApplet.clearApplet();
        }
        try {
            if (this.downloadResourcesThread != null) {
                this.downloadResourcesThread.closeMinecraft();
            }
        }
        catch (Exception ex) {}
        try {
            System.out.println("Stopping!");
            this.changeWorld1(null);
            try {
                GLAllocation.deleteTexturesAndDisplayLists();
            }
            catch (Exception ex2) {}
            this.soundMGR.closeMinecraft();
            Mouse.destroy();
            Keyboard.destroy();
        }
        finally {
            Display.destroy();
        }
        Display.destroy();
        System.gc();
    }
    
    public void run() {
        this.running = true;
        try {
            this.startupScreen();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            this.onMinecraftCrash(new UnexpectedThrowable("Failed to start game", exception));
            return;
        }
        try {
            long l = System.currentTimeMillis();
            int i = 0;
            while (this.running) {
                if (this.mcApplet != null && !this.mcApplet.isActive()) {
                    break;
                }
                AxisAlignedBB.clearBoundingBoxPool();
                Vec3D.initialize();
                if (this.mcCanvas == null && Display.isCloseRequested()) {
                    this.shutdown();
                }
                if (this.isGamePaused && this.mcWorld != null) {
                    final float f = this.timer.renderPartialTicks;
                    this.timer.updateTimer();
                    this.timer.renderPartialTicks = f;
                }
                else {
                    this.timer.updateTimer();
                }
                for (int j = 0; j < this.timer.elapsedTicks; ++j) {
                    ++this.ticksRan;
                    try {
                        this.runTick();
                    }
                    catch (MinecraftException minecraftexception) {
                        this.changeWorld1(this.mcWorld = null);
                        this.setCurrentScreen(new GuiConflictWarning());
                    }
                }
                this.checkGLError("Pre render");
                this.soundMGR.func_338_a(this.thePlayer, this.timer.renderPartialTicks);
                GL11.glEnable(3553);
                if (this.mcWorld != null) {
                    while (this.mcWorld.updatingLighting()) {}
                }
                if (!this.skipRenderWorld) {
                    if (this.playerController != null) {
                        this.playerController.setPartialTime(this.timer.renderPartialTicks);
                    }
                    this.entityRenderer.updateCameraAndRender(this.timer.renderPartialTicks);
                }
                if (!Display.isActive()) {
                    if (this.isFullscreen) {
                        this.toggleFullscreen();
                    }
                    Thread.sleep(10L);
                }
                if (Keyboard.isKeyDown(65)) {
                    Display.update();
                }
                this.screenshotListener();
                if (Keyboard.isKeyDown(64)) {
                    this.drawLagometer();
                }
                else {
                    this.field_151_H = System.nanoTime();
                }
                Thread.yield();
                Display.update();
                Display.setVSyncEnabled(this.options.vSync);
                if (this.mcCanvas != null && !this.isFullscreen && (this.mcCanvas.getWidth() != this.displayWidth || this.mcCanvas.getHeight() != this.displayHeight)) {
                    this.displayWidth = this.mcCanvas.getWidth();
                    this.displayHeight = this.mcCanvas.getHeight();
                    if (this.displayWidth <= 0) {
                        this.displayWidth = 1;
                    }
                    if (this.displayHeight <= 0) {
                        this.displayHeight = 1;
                    }
                    this.resize(this.displayWidth, this.displayHeight);
                }
                this.checkGLError("Post render");
                ++i;
                this.isGamePaused = (!this.isServer() && this.currentScreen != null && this.currentScreen.doesGuiPauseGame());
                while (System.currentTimeMillis() >= l + 1000L) {
                    this.debug = i + " fps, " + WorldRenderer.chunksUpdated + " chunk updates";
                    WorldRenderer.chunksUpdated = 0;
                    l += 1000L;
                    i = 0;
                }
            }
        }
        catch (MinecraftError minecraftError) {}
        catch (Throwable throwable) {
            this.mcWorld = null;
            throwable.printStackTrace();
            this.onMinecraftCrash(new UnexpectedThrowable("Unexpected error", throwable));
        }
    }
    
    private void screenshotListener() {
        if (Keyboard.isKeyDown(60)) {
            if (!this.isTakingScreenshot) {
                this.isTakingScreenshot = true;
                this.ingameGUI.addChatMessage(ScreenShotHelper.saveScreenshot(Minecraft.dataFolder, this.displayWidth, this.displayHeight));
            }
        }
        else {
            this.isTakingScreenshot = false;
        }
    }
    
    private void drawLagometer() {
        if (this.field_151_H == -1L) {
            this.field_151_H = System.nanoTime();
        }
        final long l = System.nanoTime();
        Minecraft.field_155_D[Minecraft.field_154_E++ & Minecraft.field_155_D.length - 1] = l - this.field_151_H;
        this.field_151_H = l;
        GL11.glClear(256);
        GL11.glMatrixMode(5889);
        GL11.glLoadIdentity();
        GL11.glOrtho(0.0, (double)this.displayWidth, (double)this.displayHeight, 0.0, 1000.0, 3000.0);
        GL11.glMatrixMode(5888);
        GL11.glLoadIdentity();
        GL11.glTranslatef(0.0f, 0.0f, -2000.0f);
        GL11.glLineWidth(1.0f);
        GL11.glDisable(3553);
        final Tessellator tessellator = Tessellator.instance;
        tessellator.startDrawing(7);
        tessellator.setColorOpaque_I(538968064);
        tessellator.addVertex(0.0, this.displayHeight - 100, 0.0);
        tessellator.addVertex(0.0, this.displayHeight, 0.0);
        tessellator.addVertex(Minecraft.field_155_D.length, this.displayHeight, 0.0);
        tessellator.addVertex(Minecraft.field_155_D.length, this.displayHeight - 100, 0.0);
        tessellator.draw();
        long l2 = 0L;
        for (int i = 0; i < Minecraft.field_155_D.length; ++i) {
            l2 += Minecraft.field_155_D[i];
        }
        final int j = (int)(l2 / 200000L / Minecraft.field_155_D.length);
        tessellator.startDrawing(7);
        tessellator.setColorOpaque_I(541065216);
        tessellator.addVertex(0.0, this.displayHeight - j, 0.0);
        tessellator.addVertex(0.0, this.displayHeight, 0.0);
        tessellator.addVertex(Minecraft.field_155_D.length, this.displayHeight, 0.0);
        tessellator.addVertex(Minecraft.field_155_D.length, this.displayHeight - j, 0.0);
        tessellator.draw();
        tessellator.startDrawing(1);
        for (int k = 0; k < Minecraft.field_155_D.length; ++k) {
            final int i2 = (k - Minecraft.field_154_E & Minecraft.field_155_D.length - 1) * 255 / Minecraft.field_155_D.length;
            int j2 = i2 * i2 / 255;
            j2 = j2 * j2 / 255;
            int k2 = j2 * j2 / 255;
            k2 = k2 * k2 / 255;
            tessellator.setColorOpaque_I(-16777216 + k2 + j2 * 256 + i2 * 65536);
            final long l3 = Minecraft.field_155_D[k] / 200000L;
            tessellator.addVertex(k + 0.5f, this.displayHeight - l3 + 0.5f, 0.0);
            tessellator.addVertex(k + 0.5f, this.displayHeight + 0.5f, 0.0);
        }
        tessellator.draw();
        GL11.glEnable(3553);
    }
    
    public void shutdown() {
        this.running = false;
    }
    
    public void setIngameFocus() {
        if (!Display.isActive()) {
            return;
        }
        if (this.inGameHasFocus) {
            return;
        }
        this.inGameHasFocus = true;
        this.mouseHelper.grabMouseCursor();
        this.setCurrentScreen(null);
        this.mouseTicksRan = this.ticksRan + 10000;
    }
    
    public void setIngameNotInFocus() {
        if (!this.inGameHasFocus) {
            return;
        }
        if (this.thePlayer != null) {
            this.thePlayer.resetPlayerKeyState();
        }
        this.inGameHasFocus = false;
        this.mouseHelper.ungrabMouseCursor();
    }
    
    public void displayInGameMenu() {
        if (this.currentScreen != null) {
            return;
        }
        if (this.thePlayer != null && this.thePlayer.loopHandler != null) {
            this.thePlayer.loopHandler.killLoops();
        }
        this.setCurrentScreen(new GuiIngameMenu());
    }
    
    private void func_119_a(final int i, final boolean flag) {
        if (this.playerController.isCreative) {
            return;
        }
        if (i == 0 && this.leftClickCounter > 0) {
            return;
        }
        if (flag && this.objectMouseOver != null && this.objectMouseOver.typeOfHit == 0 && i == 0) {
            final int j = this.objectMouseOver.blockX;
            final int k = this.objectMouseOver.blockY;
            final int l = this.objectMouseOver.blockZ;
            this.playerController.sendRemovingBlock(j, k, l, this.objectMouseOver.sideHit);
            this.effectRenderer.addBlockHitEffects(j, k, l, this.objectMouseOver.sideHit);
        }
        else {
            this.playerController.resetBlockRemoving();
        }
    }
    
    private void clickMouse(final int i) {
        if (i == 0 && this.leftClickCounter > 0) {
            return;
        }
        if (i == 0) {
            this.thePlayer.swingItem();
        }
        if (this.objectMouseOver == null) {
            if (i == 0 && !(this.playerController instanceof PlayerControllerCreative)) {
                this.leftClickCounter = 10;
            }
        }
        else if (this.objectMouseOver.typeOfHit == 1) {
            if (this.mcWorld.multiplayerWorld) {
                if (i == 0) {
                    this.playerController.attackEntity(this.thePlayer, this.objectMouseOver.entityHit);
                }
                if (i == 1) {
                    this.playerController.interactWithEntity(this.thePlayer, this.objectMouseOver.entityHit);
                }
            }
            else {
                if (i == 0) {
                    this.thePlayer.attackEntity(this.objectMouseOver.entityHit);
                }
                if (i == 1) {
                    this.thePlayer.useCurrentItemOnEntity(this.objectMouseOver.entityHit);
                }
            }
        }
        else if (this.objectMouseOver.typeOfHit == 0) {
            final int j = this.objectMouseOver.blockX;
            final int k = this.objectMouseOver.blockY;
            final int i2 = this.objectMouseOver.blockZ;
            final int j2 = this.objectMouseOver.sideHit;
            final Block block = Block.allBlocks[this.mcWorld.getBlockId(j, k, i2)];
            if (i == 0) {
                this.mcWorld.func_612_i(j, k, i2, this.objectMouseOver.sideHit);
                if (block != Block.bedrock || this.thePlayer.field_777_c >= 100) {
                    this.playerController.clickBlock(j, k, i2, this.objectMouseOver.sideHit);
                }
            }
            else {
                final ItemStack itemstack2 = this.thePlayer.inventory.getCurrentItem();
                final int k2 = (itemstack2 == null) ? 0 : itemstack2.stackSize;
                if (this.playerController.sendPlaceBlock(this.thePlayer, this.mcWorld, itemstack2, j, k, i2, j2)) {
                    this.thePlayer.swingItem();
                }
                if (itemstack2 == null) {
                    return;
                }
                if (itemstack2.stackSize == 0 && !this.playerController.isCreative) {
                    this.thePlayer.inventory.mainInventory[this.thePlayer.inventory.currentItem] = null;
                }
                else if (itemstack2.stackSize != k2) {
                    this.entityRenderer.itemRenderer.func_891_b();
                }
            }
        }
        if (i == 1 && (this.objectMouseOver == null || (this.objectMouseOver != null && this.objectMouseOver.typeOfHit == 0))) {
            final ItemStack itemstack3 = this.thePlayer.inventory.getCurrentItem();
            if (itemstack3 != null && this.playerController.sendUseItem(this.thePlayer, this.mcWorld, itemstack3)) {
                final int l = itemstack3.stackSize;
                final ItemStack itemstack4 = itemstack3.useItemRightClick(this.mcWorld, this.thePlayer);
                if (this.playerController.isCreative) {
                    itemstack4.stackSize = 1;
                }
                if (itemstack4 != itemstack3 || (itemstack4 != null && itemstack4.stackSize != l)) {
                    this.thePlayer.inventory.mainInventory[this.thePlayer.inventory.currentItem] = itemstack4;
                    this.entityRenderer.itemRenderer.func_896_c();
                    if (itemstack4.stackSize == 0) {
                        this.thePlayer.inventory.mainInventory[this.thePlayer.inventory.currentItem] = null;
                    }
                }
            }
        }
    }
    
    public void toggleFullscreen() {
        try {
            this.isFullscreen = !this.isFullscreen;
            System.out.println("Toggle fullscreen!");
            if (this.isFullscreen) {
                final ArrayList<DisplayMode> Resolutions = new ArrayList<DisplayMode>();
                try {
                    final DisplayMode[] modes = Display.getAvailableDisplayModes();
                    for (int i = 0; i < modes.length; ++i) {
                        final DisplayMode current = modes[i];
                        Resolutions.add(current);
                    }
                }
                catch (LWJGLException e) {
                    e.printStackTrace();
                }
                if (this.options.displayMode == 0) {
                    Display.setDisplayMode(Display.getDesktopDisplayMode());
                }
                else {
                    Display.setDisplayMode((DisplayMode)Resolutions.get(this.options.displayMode - 1));
                }
                this.displayWidth = Display.getDisplayMode().getWidth();
                this.displayHeight = Display.getDisplayMode().getHeight();
                if (this.displayWidth <= 0) {
                    this.displayWidth = 1;
                }
                if (this.displayHeight <= 0) {
                    this.displayHeight = 1;
                }
            }
            else {
                if (this.mcCanvas != null) {
                    this.displayWidth = this.mcCanvas.getWidth();
                    this.displayHeight = this.mcCanvas.getHeight();
                }
                else {
                    this.displayWidth = this.field_142_Q;
                    this.displayHeight = this.field_141_R;
                }
                if (this.displayWidth <= 0) {
                    this.displayWidth = 1;
                }
                if (this.displayHeight <= 0) {
                    this.displayHeight = 1;
                }
                Display.setDisplayMode(new DisplayMode(this.field_142_Q, this.field_141_R));
            }
            this.setIngameNotInFocus();
            Display.setFullscreen(this.isFullscreen);
            Display.update();
            if (this.isFullscreen) {
                this.setIngameFocus();
            }
            if (this.currentScreen != null) {
                this.setIngameNotInFocus();
                this.resize(this.displayWidth, this.displayHeight);
            }
            System.out.println("Size: " + this.displayWidth + ", " + this.displayHeight);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    private void resize(int i, int j) {
        if (i <= 0) {
            i = 1;
        }
        if (j <= 0) {
            j = 1;
        }
        this.displayWidth = i;
        this.displayHeight = j;
        if (this.currentScreen != null) {
            final ScaledResolution scaledresolution = new ScaledResolution(i, j, this);
            final int k = scaledresolution.getScaledWidth();
            final int l = scaledresolution.getScaledHeight();
            this.currentScreen.setResolution(this, k, l);
        }
    }
    
    private void pickBlock() {
        if (this.objectMouseOver != null) {
            int i = this.mcWorld.getBlockId(this.objectMouseOver.blockX, this.objectMouseOver.blockY, this.objectMouseOver.blockZ);
            if (i == Block.stairDouble.blockID) {
                i = Block.stairSingle.blockID;
            }
            if (i == Block.bedrock.blockID) {
                i = Block.stone.blockID;
            }
            if (i == Block.doorWood.blockID) {
                i = Item.doorWood.shiftedIndex;
            }
            if (i == Block.doorSteel.blockID) {
                i = Item.doorSteel.shiftedIndex;
            }
            if (i == Block.crops.blockID) {
                i = Item.seeds.shiftedIndex;
            }
            if (i == Block.pressurePlateWoodIdle.blockID) {
                i = Item.sign.shiftedIndex;
            }
            if (i == Block.signPost.blockID) {
                i = Item.sign.shiftedIndex;
            }
            if (i == Block.redstoneWire.blockID) {
                i = Item.redstone.shiftedIndex;
            }
            this.thePlayer.inventory.setCurrentItem(i, 1, this.playerController instanceof PlayerControllerCreative);
        }
    }
    
    public void runTick() {
        this.ingameGUI.updateTick();
        this.entityRenderer.getMouseOver(1.0f);
        if (this.thePlayer != null) {
            this.thePlayer.func_462_n();
        }
        if (!this.isGamePaused && this.mcWorld != null) {
            this.playerController.updateController();
        }
        GL11.glBindTexture(3553, this.renderEngine.getTex("/terrain.png"));
        if (!this.isGamePaused) {
            this.renderEngine.updateDynamicTextures();
        }
        if (this.currentScreen == null && this.thePlayer != null && this.thePlayer.health <= 0) {
            this.setCurrentScreen(null);
        }
        if (this.currentScreen != null) {
            this.mouseTicksRan = this.ticksRan + 10000;
        }
        if (this.currentScreen != null) {
            this.currentScreen.handleInput();
            if (this.currentScreen != null) {
                this.currentScreen.updateScreen();
            }
        }
        if (this.currentScreen == null || this.currentScreen.field_948_f) {
            while (Mouse.next()) {
                final long l = System.currentTimeMillis() - this.systemTime;
                if (l <= 200L) {
                    final int j = Mouse.getEventDWheel();
                    if (j != 0) {
                        this.thePlayer.inventory.changeCurrentItem(j);
                    }
                    if (this.currentScreen == null) {
                        if (!this.inGameHasFocus && Mouse.getEventButtonState()) {
                            this.setIngameFocus();
                        }
                        else {
                            if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState()) {
                                this.clickMouse(0);
                                this.mouseTicksRan = this.ticksRan;
                            }
                            if (Mouse.getEventButton() == 1 && Mouse.getEventButtonState()) {
                                this.clickMouse(1);
                                this.mouseTicksRan = this.ticksRan;
                            }
                            if (Mouse.getEventButton() != 2 || !Mouse.getEventButtonState()) {
                                continue;
                            }
                            this.pickBlock();
                        }
                    }
                    else {
                        if (this.currentScreen == null) {
                            continue;
                        }
                        this.currentScreen.handleMouseInput();
                    }
                }
            }
            if (this.leftClickCounter > 0) {
                --this.leftClickCounter;
            }
            while (Keyboard.next()) {
                this.thePlayer.handleKeyPress(Keyboard.getEventKey(), Keyboard.getEventKeyState());
                if (Keyboard.getEventKeyState()) {
                    if (Keyboard.getEventKey() == 87) {
                        this.toggleFullscreen();
                    }
                    else {
                        if (this.currentScreen != null) {
                            this.currentScreen.handleKeyboardInput();
                        }
                        else {
                            if (Keyboard.getEventKey() == 1) {
                                this.displayInGameMenu();
                            }
                            if (Keyboard.getEventKey() == 31 && Keyboard.isKeyDown(61)) {
                                this.forceReload();
                            }
                            if (Keyboard.getEventKey() == 63) {
                                this.options.thirdPersonView = !this.options.thirdPersonView;
                            }
                            if (Keyboard.getEventKey() == 65) {
                                this.enableRain = !this.enableRain;
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindBuild.keyCode && this.thePlayer.isCreative) {
                                this.setCurrentScreen(new GuiBuild(this, 0));
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindInventory.keyCode) {
                                this.setCurrentScreen(new GuiInventory(this.thePlayer));
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindDrop.keyCode) {
                                if (this.thePlayer instanceof EntityClientPlayerMP) {
                                    final EntityClientPlayerMP entmp = (EntityClientPlayerMP)this.thePlayer;
                                    entmp.dropCurrentItem();
                                }
                                else {
                                    this.thePlayer.dropInventory(this.thePlayer.inventory.decrStackSize(this.thePlayer.inventory.currentItem, 1), false);
                                }
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindChat.keyCode) {
                                this.setCurrentScreen(new GuiChat());
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindSaveLocation.keyCode && this.thePlayer.isCreative) {
                                this.savedPlayerPos = Vec3D.createVectorHelper(this.thePlayer.posX, this.thePlayer.posY, this.thePlayer.posZ);
                            }
                            if (Keyboard.getEventKey() == this.options.keyBindLoadLocation.keyCode && this.thePlayer.isCreative) {
                                this.thePlayer.setPosition(this.savedPlayerPos.xCoord, this.savedPlayerPos.yCoord, this.savedPlayerPos.zCoord);
                            }
                        }
                        for (int i = 0; i < 9; ++i) {
                            if (Keyboard.getEventKey() == 2 + i) {
                                this.thePlayer.inventory.currentItem = i;
                            }
                        }
                        if (Keyboard.getEventKey() != this.options.keyBindToggleFog.keyCode) {
                            continue;
                        }
                        this.options.setOptionValue(4, (!Keyboard.isKeyDown(42) && !Keyboard.isKeyDown(54)) ? 1 : -1);
                    }
                }
            }
            if (this.currentScreen == null) {
                if (Mouse.isButtonDown(0) && this.ticksRan - this.mouseTicksRan >= this.timer.field_1380_a / 4.0f && this.inGameHasFocus) {
                    this.clickMouse(0);
                    this.mouseTicksRan = this.ticksRan;
                }
                if (Mouse.isButtonDown(1) && this.ticksRan - this.mouseTicksRan >= this.timer.field_1380_a / 4.0f && this.inGameHasFocus) {
                    this.clickMouse(1);
                    this.mouseTicksRan = this.ticksRan;
                }
            }
            this.func_119_a(0, this.currentScreen == null && Mouse.isButtonDown(0) && this.inGameHasFocus);
        }
        if (this.mcWorld != null) {
            if (this.thePlayer != null) {
                ++this.joinPlayerCounter;
                if (this.joinPlayerCounter == 30) {
                    this.joinPlayerCounter = 0;
                    this.mcWorld.joinEntityInSurroundings(this.thePlayer);
                }
            }
            this.mcWorld.difficulty = this.options.difficulty;
            if (this.mcWorld.multiplayerWorld) {
                this.mcWorld.difficulty = this.mcWorld.multiplayerDifficulty;
            }
            else {
                this.mcWorld.setSaveInterval(this.options.chunkSavingInterval);
            }
            if (!this.isGamePaused) {
                this.entityRenderer.updateRenderer();
            }
            if (!this.isGamePaused) {
                this.renderGlobal.updateClouds();
            }
            if (!this.isGamePaused) {
                this.mcWorld.updateEntityList();
            }
            if (!this.isGamePaused || this.isServer()) {
                this.mcWorld.tick();
            }
            if (!this.isGamePaused && this.mcWorld != null) {
                this.mcWorld.randomDisplayUpdates(MathHelper.floor_double(this.thePlayer.posX), MathHelper.floor_double(this.thePlayer.posY), MathHelper.floor_double(this.thePlayer.posZ));
            }
            if (!this.isGamePaused) {
                this.effectRenderer.updateEffects();
            }
        }
        this.systemTime = System.currentTimeMillis();
    }
    
    private void forceReload() {
        System.out.println("FORCING RELOAD!");
        (this.soundMGR = new SoundManager()).initialize(this.options);
        this.downloadResourcesThread.func_1210_a();
    }
    
    public boolean isServer() {
        return this.mcWorld != null && this.mcWorld.multiplayerWorld;
    }
    
    public void startWorld(final String s, final boolean snowCovered, final boolean cheatsEnabled, final int worldType) {
        this.changeWorld1(null);
        System.gc();
        final World world = new World(new File(getMinecraftDir(), "NSSSsaves"), s, snowCovered, cheatsEnabled, worldType, this);
        if (world.isNewWorld) {
            world.justLoaded = false;
            this.changeWorld(world, "Generating level");
        }
        else {
            world.justLoaded = true;
            this.changeWorld(world, "Loading level");
        }
    }
    
    public void changeWorld1(final World world) {
        this.changeWorld(world, "");
    }
    
    public void changeWorld(final World world, final String s) {
        this.soundMGR.playStreaming(null, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        if (this.mcWorld != null) {
            this.mcWorld.saveWorldIndirectly(this.loadScreen);
        }
        if ((this.mcWorld = world) != null) {
            this.playerController.func_717_a(world);
            world.field_1038_m = this.fontRender;
            if (!this.isServer()) {
                this.thePlayer = (EntityPlayerSP)world.func_661_a(EntityPlayerSP.class);
            }
            else if (this.thePlayer != null) {
                this.thePlayer.preparePlayerToSpawn();
                if (world != null) {
                    world.entityJoinedWorld(this.thePlayer);
                }
            }
            if (!world.multiplayerWorld) {
                this.func_120_d(s);
            }
            if (this.thePlayer == null) {
                (this.thePlayer = (EntityPlayerSP)this.playerController.createPlayer(world)).preparePlayerToSpawn();
                this.playerController.flipPlayer(this.thePlayer);
            }
            this.thePlayer.currentInput = new MovementInputFromOptions(this.options);
            if (this.renderGlobal != null) {
                this.renderGlobal.changeWorld(world);
            }
            if (this.effectRenderer != null) {
                this.effectRenderer.clearEffects(world);
            }
            this.playerController.initiateInventory(this.thePlayer);
            world.spawnPlayerWithLoadedChunks(this.thePlayer);
            if (world.isNewWorld) {
                world.saveWorldIndirectly(this.loadScreen);
            }
        }
        else {
            this.thePlayer = null;
        }
        System.gc();
        this.systemTime = 0L;
    }
    
    private void func_120_d(final String s) {
        this.loadScreen.func_596_a(s);
        this.loadScreen.func_595_d("Building terrain");
        final char questionMark = '\u0080';
        int i = 0;
        int prog = questionMark * '\u0002' / 16 + 1;
        prog *= prog;
        for (int k = -questionMark; k <= questionMark; k += 16) {
            int spawnX = this.mcWorld.spawnX;
            int spawnZ = this.mcWorld.spawnZ;
            if (this.thePlayer != null) {
                spawnX = (int)this.thePlayer.posX;
                spawnZ = (int)this.thePlayer.posZ;
            }
            for (int j1 = -questionMark; j1 <= questionMark; j1 += 16) {
                this.loadScreen.setProgess(i++ * 100 / prog);
                this.mcWorld.getBlockId(spawnX + k, 64, spawnZ + j1);
            }
        }
        this.loadScreen.func_595_d("Simulating world for a bit");
        prog = 2000;
        this.mcWorld.func_656_j();
    }
    
    public void installResource(String s, final File file) {
        final int i = s.indexOf("/");
        final String s2 = s.substring(0, i);
        s = s.substring(i + 1);
        if (s2.equalsIgnoreCase("sound")) {
            this.soundMGR.addToSoundPool(s, file);
        }
        else if (s2.equalsIgnoreCase("newsound")) {
            this.soundMGR.addToSoundPool(s, file);
        }
        else if (s2.equalsIgnoreCase("streaming")) {
            this.soundMGR.addToStreamingPool(s, file);
        }
        else if (s2.equalsIgnoreCase("music")) {
            this.soundMGR.addToMusicPool(s, file);
        }
        else if (s2.equalsIgnoreCase("newmusic")) {
            this.soundMGR.addToMusicPool(s, file);
        }
        else if (s2.equalsIgnoreCase("loops")) {
            this.soundMGR.addToLoopsPool(s, file);
        }
    }
    
    public OpenGlCapsChecker getOpenGlCapsChecker() {
        return this.glCapabilities;
    }
    
    public String getDebugInfoRenders() {
        return this.renderGlobal.getDebugInfoRenders();
    }
    
    public String getDebugInfoEntities() {
        return this.renderGlobal.getDebugInfoEntities();
    }
    
    public String getDebugInfoParticlesAndGfx() {
        return "Particles: " + this.effectRenderer.getStatistics() + (". Gfx: " + GL11.glGetString(7937) + " ") + this.mcWorld.loadedEntites();
    }
    
    public void respawn() {
        this.mcWorld.func_622_a();
        int j = 0;
        if (this.thePlayer != null) {
            j = this.thePlayer.entityId;
            this.mcWorld.setEntityDead(this.thePlayer);
        }
        (this.thePlayer = (EntityPlayerSP)this.playerController.createPlayer(this.mcWorld)).preparePlayerToSpawn();
        this.playerController.flipPlayer(this.thePlayer);
        this.mcWorld.spawnPlayerWithLoadedChunks(this.thePlayer);
        this.thePlayer.currentInput = new MovementInputFromOptions(this.options);
        this.thePlayer.entityId = j;
        this.playerController.initiateInventory(this.thePlayer);
        this.func_120_d("Respawning");
        if (this.currentScreen instanceof GuiGameOver) {
            this.setCurrentScreen(null);
        }
    }
    
    public void respawn(final boolean flag, final int i) {
        System.out.println("RESPAWNING!");
        ChunkCoordinates chunkcoordinates = null;
        ChunkCoordinates chunkcoordinates2 = null;
        boolean flag2 = true;
        if (this.thePlayer != null && !flag) {
            chunkcoordinates = this.thePlayer.getPlayerSpawnCoordinate();
            if (chunkcoordinates != null) {
                chunkcoordinates2 = EntityPlayer.func_25060_a(this.mcWorld, chunkcoordinates);
            }
        }
        if (chunkcoordinates2 == null) {
            chunkcoordinates2 = this.mcWorld.getSpawnPoint();
            flag2 = false;
        }
        final IChunkProvider ichunkprovider = this.mcWorld.chunkProvider;
        if (ichunkprovider instanceof ChunkProviderLoadOrGenerate) {
            final ChunkProviderLoadOrGenerate chunkproviderloadorgenerate = (ChunkProviderLoadOrGenerate)ichunkprovider;
            chunkproviderloadorgenerate.setCurrentChunkOver(chunkcoordinates2.x >> 4, chunkcoordinates2.z >> 4);
        }
        this.mcWorld.updateEntityList();
        int j = 0;
        if (this.thePlayer != null) {
            j = this.thePlayer.entityId;
            this.mcWorld.setEntityDead(this.thePlayer);
            this.mcWorld.justLoaded = false;
        }
        this.renderViewEntity = null;
        this.thePlayer = (EntityPlayerSP)this.playerController.createPlayer(this.mcWorld);
        this.renderViewEntity = this.thePlayer;
        this.thePlayer.preparePlayerToSpawn();
        if (flag2) {
            this.thePlayer.setPlayerSpawnCoordinate(chunkcoordinates);
            this.thePlayer.setLocationAndAngles(chunkcoordinates2.x + 0.5f, chunkcoordinates2.y + 0.1f, chunkcoordinates2.z + 0.5f, 0.0f, 0.0f);
        }
        this.playerController.flipPlayer(this.thePlayer);
        this.mcWorld.spawnPlayerWithLoadedChunks(this.thePlayer);
        this.thePlayer.currentInput = new MovementInputFromOptions(this.options);
        this.thePlayer.entityId = j;
        this.thePlayer.func_6420_o();
        this.playerController.initiateInventory(this.thePlayer);
        this.func_120_d("Respawning");
        if (this.currentScreen instanceof GuiGameOver) {
            this.setCurrentScreen(null);
        }
    }
    
    public static void start(final String username, final String uuid, final String token) {
        startMainThread(username, token, uuid, null);
    }
    
    public static void startMainThread(final String s, final String sessionId, final String uuid, final String s2) {
        final boolean flag = false;
        final String username = s;
        final Frame frame = new Frame("Minecraft");
        final Canvas canvas = new Canvas();
        frame.setLayout(new BorderLayout());
        frame.add(canvas, "Center");
        canvas.setPreferredSize(new Dimension(854, 480));
        frame.pack();
        frame.setLocationRelativeTo(null);
        final MinecraftImpl minecraftimpl = new MinecraftImpl(frame, canvas, null, 854, 480, flag, frame);
        final Thread thread = new Thread(minecraftimpl, "Minecraft main thread");
        thread.setPriority(10);
        minecraftimpl.field_173_l = false;
        minecraftimpl.field_175_j = "www.minecraft.net";
        System.out.println(String.valueOf(username) + " " + sessionId + " " + uuid);
        if (username != null && sessionId != null && uuid != null) {
            minecraftimpl.session = new Session(username, sessionId, uuid);
        }
        else if (username != null && sessionId != null) {
            minecraftimpl.session = new Session(username, sessionId);
        }
        else {
            minecraftimpl.session = new Session("Player" + System.currentTimeMillis() % 1000L, "", "");
        }
        if (s2 != null) {
            final String[] as = s2.split(":");
            minecraftimpl.setServer(as[0], Integer.parseInt(as[1]));
        }
        frame.setVisible(true);
        frame.addWindowListener(new GameWindowListener(minecraftimpl, thread));
        thread.start();
    }
    
    public NetClientHandler getSendQueue() {
        if (this.thePlayer instanceof EntityClientPlayerMP) {
            return ((EntityClientPlayerMP)this.thePlayer).sendQueue;
        }
        return null;
    }
    
    public static void main(final String[] args) {
        final String username = (args.length > 0) ? args[0] : "Player";
        final String uuid = (args.length > 1) ? args[1] : "0";
        final String token = (args.length > 2) ? args[2] : "0";
        start(username, uuid, token);
    }
    
    public static Minecraft getMinecraft() {
        return Minecraft.theMinecraft;
    }
}
