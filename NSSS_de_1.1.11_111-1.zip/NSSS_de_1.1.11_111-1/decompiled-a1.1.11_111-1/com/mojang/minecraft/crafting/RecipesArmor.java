package com.mojang.minecraft.crafting;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;

public class RecipesArmor
{
    private String[][] recipePatterns;
    private Object[][] field_1680_b;
    
    public RecipesArmor() {
        this.recipePatterns = new String[][] { { "XXX", "X X" }, { "X X", "XXX", "XXX" }, { "XXX", "X X", "X X" }, { "X X", "X X" } };
        this.field_1680_b = new Object[][] { { Item.leather, Block.fire, Item.ingotIron, Item.diamond, Item.ingotGold, Block.sponge }, { Item.helmetLeather, Item.helmetChain, Item.helmetSteel, Item.helmetDiamond, Item.helmetGold, Item.helmetSponge }, { Item.plateLeather, Item.plateChain, Item.plateSteel, Item.plateDiamond, Item.plateGold, Item.plateSponge }, { Item.legsLeather, Item.legsChain, Item.legsSteel, Item.legsDiamond, Item.legsGold, Item.legsSponge }, { Item.bootsLeather, Item.bootsChain, Item.bootsSteel, Item.bootsDiamond, Item.bootsGold, Item.bootsSponge } };
    }
    
    public void addRecipes(final CraftingManager craftingmanager) {
        for (int i = 0; i < this.field_1680_b[0].length; ++i) {
            final Object obj = this.field_1680_b[0][i];
            for (int j = 0; j < this.field_1680_b.length - 1; ++j) {
                final Item item = (Item)this.field_1680_b[j + 1][i];
                craftingmanager.addRecipe(new ItemStack(item), new Object[] { this.recipePatterns[j], 'X', obj });
            }
        }
    }
}
