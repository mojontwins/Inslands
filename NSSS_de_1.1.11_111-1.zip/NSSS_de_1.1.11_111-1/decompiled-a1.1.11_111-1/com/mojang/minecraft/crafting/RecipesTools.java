package com.mojang.minecraft.crafting;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;

public class RecipesTools
{
    private String[][] field_1665_a;
    private Object[][] field_1664_b;
    
    public RecipesTools() {
        this.field_1665_a = new String[][] { { "XXX", " # ", " # " }, { "X", "#", "#" }, { "XX", "X#", " #" }, { "XX", " #", " #" } };
        this.field_1664_b = new Object[][] { { Block.planks, Block.cobblestone, Item.ingotIron, Item.diamond, Item.ingotGold }, { Item.pickaxeWood, Item.pickaxeStone, Item.pickaxeSteel, Item.pickaxeDiamond, Item.pickaxeGold }, { Item.shovelWood, Item.shovelStone, Item.shovel, Item.shovelDiamond, Item.shovelGold }, { Item.axeWood, Item.axeStone, Item.axeSteel, Item.axeDiamond, Item.axeGold }, { Item.hoeWood, Item.hoeStone, Item.hoeSteel, Item.hoeDiamond, Item.hoeGold } };
    }
    
    public void addRecipes(final CraftingManager craftingmanager) {
        for (int i = 0; i < this.field_1664_b[0].length; ++i) {
            final Object obj = this.field_1664_b[0][i];
            for (int j = 0; j < this.field_1664_b.length - 1; ++j) {
                final Item item = (Item)this.field_1664_b[j + 1][i];
                craftingmanager.addRecipe(new ItemStack(item), new Object[] { this.field_1665_a[j], '#', Item.stick, 'X', obj });
            }
        }
    }
}
