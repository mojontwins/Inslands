package com.mojang.minecraft.crafting;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.tile.*;

public class RecipesFood
{
    public void addRecipes(final CraftingManager craftingmanager) {
        craftingmanager.addRecipe(new ItemStack(Item.bowlSoup), new Object[] { "Y", "X", "#", 'X', Block.mushroomBrown, 'Y', Block.mushroomRed, '#', Item.bowlEmpty });
        craftingmanager.addRecipe(new ItemStack(Item.bowlSoup), new Object[] { "Y", "X", "#", 'X', Block.mushroomRed, 'Y', Block.mushroomBrown, '#', Item.bowlEmpty });
    }
}
