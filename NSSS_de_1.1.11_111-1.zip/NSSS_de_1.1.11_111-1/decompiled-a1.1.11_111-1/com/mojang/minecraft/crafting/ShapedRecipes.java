package com.mojang.minecraft.crafting;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.player.inventory.*;

public class ShapedRecipes implements IRecipe
{
    private int recipeWidth;
    private int recipeHeight;
    private ItemStack[] recipeItems;
    private ItemStack recipeOutput;
    public final int recipeOutputItemID;
    
    public ShapedRecipes(final int i, final int j, final ItemStack[] aitemstack, final ItemStack itemstack) {
        this.recipeOutputItemID = itemstack.itemID;
        this.recipeWidth = i;
        this.recipeHeight = j;
        this.recipeItems = aitemstack;
        this.recipeOutput = itemstack;
    }
    
    public ItemStack getRecipeOutput() {
        return this.recipeOutput;
    }
    
    public boolean matches(final InventoryCrafting inventorycrafting) {
        for (int i = 0; i <= 3 - this.recipeWidth; ++i) {
            for (int j = 0; j <= 3 - this.recipeHeight; ++j) {
                if (this.func_21137_a(inventorycrafting, i, j, true)) {
                    return true;
                }
                if (this.func_21137_a(inventorycrafting, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean func_21137_a(final InventoryCrafting inventorycrafting, final int i, final int j, final boolean flag) {
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 3; ++l) {
                final int i2 = k - i;
                final int j2 = l - j;
                ItemStack itemstack = null;
                if (i2 >= 0 && j2 >= 0 && i2 < this.recipeWidth && j2 < this.recipeHeight) {
                    if (flag) {
                        itemstack = this.recipeItems[this.recipeWidth - i2 - 1 + j2 * this.recipeWidth];
                    }
                    else {
                        itemstack = this.recipeItems[i2 + j2 * this.recipeWidth];
                    }
                }
                final ItemStack itemstack2 = inventorycrafting.func_21103_b(k, l);
                if (itemstack2 != null || itemstack != null) {
                    if ((itemstack2 == null && itemstack != null) || (itemstack2 != null && itemstack == null)) {
                        return false;
                    }
                    if (itemstack.itemID != itemstack2.itemID) {
                        return false;
                    }
                    if (itemstack.getItemDamage() != -1 && itemstack.getItemDamage() != itemstack2.getItemDamage()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public ItemStack getCraftingResult(final InventoryCrafting inventorycrafting) {
        return new ItemStack(this.recipeOutput.itemID, this.recipeOutput.stackSize, this.recipeOutput.getItemDamage());
    }
    
    public int getRecipeSize() {
        return this.recipeWidth * this.recipeHeight;
    }
}
