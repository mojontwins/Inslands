package com.mojang.minecraft.crafting;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.player.inventory.*;
import java.util.*;

public class ShapelessRecipes implements IRecipe
{
    private final ItemStack recipeOutput;
    private final List recipeItems;
    
    public ShapelessRecipes(final ItemStack itemstack, final List list) {
        this.recipeOutput = itemstack;
        this.recipeItems = list;
    }
    
    public ItemStack getRecipeOutput() {
        return this.recipeOutput;
    }
    
    public boolean matches(final InventoryCrafting inventorycrafting) {
        final ArrayList arraylist = new ArrayList(this.recipeItems);
        for (int i = 0; i < 3; ++i) {
            ItemStack itemstack;
            boolean flag;
            Label_0127_Outer:Label_0134:
            for (int j = 0; j < 3; ++j) {
                itemstack = inventorycrafting.func_21103_b(j, i);
                if (itemstack != null) {
                    flag = false;
                    while (true) {
                        for (final ItemStack itemstack2 : arraylist) {
                            if (itemstack.itemID == itemstack2.itemID) {
                                if (itemstack2.getItemDamage() != -1 && itemstack.getItemDamage() != itemstack2.getItemDamage()) {
                                    continue Label_0127_Outer;
                                }
                                flag = true;
                                arraylist.remove(itemstack2);
                                if (!flag) {
                                    return false;
                                }
                                continue Label_0134;
                            }
                        }
                        continue;
                    }
                }
            }
        }
        return arraylist.isEmpty();
    }
    
    public ItemStack getCraftingResult(final InventoryCrafting inventorycrafting) {
        return this.recipeOutput.copy();
    }
    
    public int getRecipeSize() {
        return this.recipeItems.size();
    }
}
