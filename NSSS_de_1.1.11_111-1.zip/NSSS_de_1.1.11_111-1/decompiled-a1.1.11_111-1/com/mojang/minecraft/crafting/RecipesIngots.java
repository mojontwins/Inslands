package com.mojang.minecraft.crafting;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;

public class RecipesIngots
{
    private Object[][] field_1198_a;
    
    public RecipesIngots() {
        this.field_1198_a = new Object[][] { { Block.blockGold, Item.ingotGold }, { Block.blockSteel, Item.ingotIron }, { Block.blockDiamond, Item.diamond }, { Block.blockCopper, Item.ingotCopper }, { Block.cloth, Item.silk } };
    }
    
    public void addRecipes(final CraftingManager craftingmanager) {
        for (int i = 0; i < this.field_1198_a.length; ++i) {
            final Block block = (Block)this.field_1198_a[i][0];
            final Item item = (Item)this.field_1198_a[i][1];
            craftingmanager.addRecipe(new ItemStack(block), new Object[] { "###", "###", "###", '#', item });
            craftingmanager.addRecipe(new ItemStack(item, 9), new Object[] { "#", '#', block });
        }
    }
}
