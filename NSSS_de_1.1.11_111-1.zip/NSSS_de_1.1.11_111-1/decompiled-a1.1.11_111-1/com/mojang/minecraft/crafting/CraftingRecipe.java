package com.mojang.minecraft.crafting;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.player.inventory.*;

public class CraftingRecipe
{
    private int width;
    private int height;
    private int[] ingredientMap;
    private ItemStack resultStack;
    public final int resultId;
    
    public CraftingRecipe(final int i, final int j, final int[] ai, final ItemStack itemstack) {
        this.resultId = itemstack.itemID;
        this.width = i;
        this.height = j;
        this.ingredientMap = ai;
        this.resultStack = itemstack;
    }
    
    public boolean matches(final int[] ai) {
        for (int i = 0; i <= 3 - this.width; ++i) {
            for (int j = 0; j <= 3 - this.height; ++j) {
                if (this.func_1185_a(ai, i, j, true)) {
                    return true;
                }
                if (this.func_1185_a(ai, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean matches(final InventoryCrafting inventorycrafting) {
        for (int i = 0; i <= 3 - this.width; ++i) {
            for (int j = 0; j <= 3 - this.height; ++j) {
                if (this.func_21137_a(inventorycrafting, i, j, true)) {
                    return true;
                }
                if (this.func_21137_a(inventorycrafting, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean func_1185_a(final int[] ai, final int i, final int j, final boolean flag) {
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 3; ++l) {
                final int i2 = k - i;
                final int j2 = l - j;
                int k2 = -1;
                if (i2 >= 0 && j2 >= 0 && i2 < this.width && j2 < this.height) {
                    if (flag) {
                        k2 = this.ingredientMap[this.width - i2 - 1 + j2 * this.width];
                    }
                    else {
                        k2 = this.ingredientMap[i2 + j2 * this.width];
                    }
                }
                if (ai[k + l * 3] != k2) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private boolean func_21137_a(final InventoryCrafting inventorycrafting, final int i, final int j, final boolean flag) {
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 3; ++l) {
                final int i2 = k - i;
                final int j2 = l - j;
                ItemStack itemstack = null;
                if (i2 >= 0 && j2 >= 0 && i2 < this.width && j2 < this.height) {
                    if (flag) {
                        itemstack = new ItemStack(this.ingredientMap[this.width - i2 - 1 + j2 * this.width]);
                    }
                    else {
                        itemstack = new ItemStack(this.ingredientMap[i2 + j2 * this.width]);
                    }
                }
                final ItemStack itemstack2 = inventorycrafting.func_21103_b(k, l);
                if (itemstack2 != null || itemstack != null) {
                    if ((itemstack2 == null && itemstack != null) || (itemstack2 != null && itemstack == null)) {
                        return false;
                    }
                    if (itemstack.itemID != itemstack2.itemID) {
                        return false;
                    }
                    if (itemstack.getItemDamage() != -1 && itemstack.getItemDamage() != itemstack2.getItemDamage()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public ItemStack getCraftingResult(final int[] ai) {
        return new ItemStack(this.resultStack.itemID, this.resultStack.stackSize);
    }
    
    public ItemStack getCraftingResult(final InventoryCrafting inventorycrafting) {
        return new ItemStack(this.resultStack.itemID, this.resultStack.stackSize, this.resultStack.getItemDamage());
    }
    
    public int getRecipeSize() {
        return this.width * this.height;
    }
}
