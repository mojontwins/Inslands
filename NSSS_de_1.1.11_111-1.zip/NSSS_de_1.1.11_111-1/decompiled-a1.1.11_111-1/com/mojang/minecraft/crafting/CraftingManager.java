package com.mojang.minecraft.crafting;

import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.tile.*;
import java.util.*;
import com.mojang.minecraft.player.inventory.*;

public class CraftingManager
{
    private static final CraftingManager instance;
    private List<IRecipe> recipes;
    
    static {
        instance = new CraftingManager();
    }
    
    public static final CraftingManager getInstance() {
        return CraftingManager.instance;
    }
    
    private CraftingManager() {
        this.recipes = new ArrayList<IRecipe>();
        new RecipesTools().addRecipes(this);
        new RecipesWeapons().addRecipes(this);
        new RecipesIngots().addRecipes(this);
        new RecipesFood().addRecipes(this);
        new RecipesCrafting().addRecipes(this);
        new RecipesArmor().addRecipes(this);
        this.addRecipe(new ItemStack(Item.paper, 3), new Object[] { "###", '#', Item.reed });
        this.addRecipe(new ItemStack(Item.book, 1), new Object[] { "#", "#", "#", '#', Item.paper });
        this.addRecipe(new ItemStack(Block.fence, 2), new Object[] { "###", "###", '#', Item.stick });
        this.addRecipe(new ItemStack(Block.jukebox, 1), new Object[] { "###", "#X#", "###", '#', Block.planks, 'X', Item.diamond });
        this.addRecipe(new ItemStack(Block.bookShelf, 1), new Object[] { "###", "XXX", "###", '#', Block.planks, 'X', Item.book });
        this.addRecipe(new ItemStack(Block.blockSnow, 1), new Object[] { "##", "##", '#', Item.snowball });
        this.addRecipe(new ItemStack(Block.blockClay, 1), new Object[] { "##", "##", '#', Item.clay });
        this.addRecipe(new ItemStack(Block.brick, 1), new Object[] { "##", "##", '#', Item.brick });
        this.addRecipe(new ItemStack(Block.tnt, 1), new Object[] { "X#X", "#X#", "X#X", 'X', Item.gunpowder, '#', Block.sand });
        this.addRecipe(new ItemStack(Block.stairSingle, 6), new Object[] { "###", '#', Block.cobblestone });
        this.addRecipe(new ItemStack(Block.ladder, 4), new Object[] { "# #", "###", "# #", '#', Item.stick });
        this.addRecipe(new ItemStack(Item.doorWood, 1), new Object[] { "##", "##", "##", '#', Block.planks });
        this.addRecipe(new ItemStack(Item.doorSteel, 1), new Object[] { "##", "##", "##", '#', Item.ingotIron });
        this.addRecipe(new ItemStack(Item.sign, 4), new Object[] { "###", "###", " X ", '#', Block.planks, 'X', Item.stick });
        this.addRecipe(new ItemStack(Block.planks, 4), new Object[] { "#", '#', Block.wood });
        this.addRecipe(new ItemStack(Item.stick, 4), new Object[] { "#", "#", '#', Block.planks });
        this.addRecipe(new ItemStack(Block.torchWood, 4), new Object[] { "X", "#", 'X', Item.coal, '#', Item.stick });
        this.addRecipe(new ItemStack(Item.bowlEmpty, 4), new Object[] { "# #", " # ", '#', Block.planks });
        this.addRecipe(new ItemStack(Block.minecartTrack, 16), new Object[] { "X X", "X#X", "X X", 'X', Item.ingotIron, '#', Item.stick });
        this.addRecipe(new ItemStack(Item.minecartEmpty, 1), new Object[] { "# #", "###", '#', Item.ingotIron });
        this.addRecipe(new ItemStack(Item.minecartBox, 1), new Object[] { "A", "B", 'A', Block.crate, 'B', Item.minecartEmpty });
        this.addRecipe(new ItemStack(Item.minecartEngine, 1), new Object[] { "A", "B", 'A', Block.stoneOvenIdle, 'B', Item.minecartEmpty });
        this.addRecipe(new ItemStack(Item.boat, 1), new Object[] { "# #", "###", '#', Block.planks });
        this.addRecipe(new ItemStack(Item.bucketEmpty, 1), new Object[] { "# #", " # ", '#', Item.ingotIron });
        this.addRecipe(new ItemStack(Item.striker, 1), new Object[] { "A ", " B", 'A', Item.ingotIron, 'B', Item.flint });
        this.addRecipe(new ItemStack(Item.bread, 1), new Object[] { "###", '#', Item.wheat });
        this.addRecipe(new ItemStack(Block.stairCompact_Wood, 4), new Object[] { "#  ", "## ", "###", '#', Block.planks });
        this.addRecipe(new ItemStack(Item.fishingRod, 1), new Object[] { "  #", " #X", "# X", '#', Item.stick, 'X', Item.silk });
        this.addRecipe(new ItemStack(Block.stairCompactStone, 4), new Object[] { "#  ", "## ", "###", '#', Block.cobblestone });
        this.addRecipe(new ItemStack(Item.painting, 1), new Object[] { "###", "#X#", "###", '#', Item.stick, 'X', Block.cloth });
        this.addRecipe(new ItemStack(Item.appleGold, 1), new Object[] { "###", "#X#", "###", '#', Item.ingotGold, 'X', Item.appleRed });
        this.addRecipe(new ItemStack(Block.lever, 1), new Object[] { "X", "#", '#', Block.cobblestone, 'X', Item.stick });
        this.addRecipe(new ItemStack(Block.torchRedstoneActive, 1), new Object[] { "X", "#", '#', Item.stick, 'X', Item.redstone });
        this.addRecipe(new ItemStack(Item.compass, 1), new Object[] { " # ", "#X#", " # ", '#', Item.ingotIron, 'X', Item.redstone });
        this.addRecipe(new ItemStack(Block.button, 1), new Object[] { "#", "#", '#', Block.stone });
        this.addRecipe(new ItemStack(Block.pressurePlateStone, 1), new Object[] { "###", '#', Block.stone });
        this.addRecipe(new ItemStack(Block.pressurePlateWood, 1), new Object[] { "###", '#', Block.planks });
        this.addRecipe(new ItemStack(Block.pressurePlateSteel, 1), new Object[] { "###", '#', Item.ingotIron });
        this.addRecipe(new ItemStack(Item.dyeRed, 2), new Object[] { "A", 'A', Block.plantRed });
        this.addRecipe(new ItemStack(Item.dyeYellow, 2), new Object[] { "A", 'A', Block.plantYellow });
        this.addRecipe(new ItemStack(Item.bonemeal, 3), new Object[] { "A", 'A', Item.bone });
        this.addRecipe(new ItemStack(Item.dyeGrey, 2), new Object[] { "A", "B", 'A', Item.bonemeal, 'B', Item.dyeBlack });
        this.addRecipe(new ItemStack(Item.dyeGrey, 2), new Object[] { "B", "A", 'A', Item.bonemeal, 'B', Item.dyeBlack });
        this.addRecipe(new ItemStack(Item.dyeOrange, 2), new Object[] { "A", "B", 'A', Item.dyeRed, 'B', Item.dyeYellow });
        this.addRecipe(new ItemStack(Item.dyeOrange, 2), new Object[] { "B", "A", 'A', Item.dyeRed, 'B', Item.dyeYellow });
        this.addRecipe(new ItemStack(Item.dyeLime, 2), new Object[] { "B", "A", 'A', Item.dyeGreen, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeLime, 2), new Object[] { "A", "B", 'A', Item.dyeGreen, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeAquaGreen, 2), new Object[] { "B", "A", 'A', Item.dyeGreen, 'B', Item.dyeBlue });
        this.addRecipe(new ItemStack(Item.dyeAquaGreen, 2), new Object[] { "A", "B", 'A', Item.dyeGreen, 'B', Item.dyeBlue });
        this.addRecipe(new ItemStack(Item.dyeCyan, 2), new Object[] { "B", "A", 'A', Item.dyeBlue, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeCyan, 2), new Object[] { "A", "B", 'A', Item.dyeBlue, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyePurple, 2), new Object[] { "A", "B", 'A', Item.dyeBlue, 'B', Item.dyeRed });
        this.addRecipe(new ItemStack(Item.dyePurple, 2), new Object[] { "B", "A", 'A', Item.dyeBlue, 'B', Item.dyeRed });
        this.addRecipe(new ItemStack(Item.dyeIndigo, 2), new Object[] { "B", "A", 'A', Item.dyeBlue, 'B', Item.dyePurple });
        this.addRecipe(new ItemStack(Item.dyeIndigo, 2), new Object[] { "A", "B", 'A', Item.dyeBlue, 'B', Item.dyePurple });
        this.addRecipe(new ItemStack(Item.dyeMagenta, 2), new Object[] { "A", "B", 'A', Item.dyeRed, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeMagenta, 2), new Object[] { "B", "A", 'A', Item.dyeRed, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyePink, 2), new Object[] { "A", "B", 'A', Item.dyeRed, 'B', Item.dyeMagenta });
        this.addRecipe(new ItemStack(Item.dyePink, 2), new Object[] { "B", "A", 'A', Item.dyeRed, 'B', Item.dyeMagenta });
        this.addRecipe(new ItemStack(Item.dyeViolet, 2), new Object[] { "A", "B", 'A', Item.dyeIndigo, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeViolet, 2), new Object[] { "B", "A", 'A', Item.dyeIndigo, 'B', Item.bonemeal });
        this.addRecipe(new ItemStack(Item.dyeBlue, 2), new Object[] { "A", 'A', Block.plantBlue });
        this.addRecipe(new ItemStack(Block.cloth_red, 1), new Object[] { "A", "#", 'A', Item.dyeRed, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_yellow, 1), new Object[] { "A", "#", 'A', Item.dyeYellow, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_blue, 1), new Object[] { "A", "#", 'A', Item.dyeBlue, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_darkgray, 1), new Object[] { "A", "#", 'A', Item.dyeBlack, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_cyan, 1), new Object[] { "A", "#", 'A', Item.dyeCyan, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_orange, 1), new Object[] { "A", "#", 'A', Item.dyeOrange, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_lime, 1), new Object[] { "A", "#", 'A', Item.dyeLime, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_green, 1), new Object[] { "A", "#", 'A', Item.dyeGreen, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_teal, 1), new Object[] { "A", "#", 'A', Item.dyeAquaGreen, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_lilac, 1), new Object[] { "A", "#", 'A', Item.dyePurple, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_indigo, 1), new Object[] { "A", "#", 'A', Item.dyeIndigo, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_violet, 1), new Object[] { "A", "#", 'A', Item.dyeViolet, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_pink, 1), new Object[] { "A", "#", 'A', Item.dyePink, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_magenta, 1), new Object[] { "A", "#", 'A', Item.dyeMagenta, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.cloth_lightgray, 1), new Object[] { "A", "#", 'A', Item.dyeGrey, '#', Block.cloth });
        this.addRecipe(new ItemStack(Block.gear, 5), new Object[] { " # ", "#X#", " # ", '#', Item.ingotIron, 'X', Item.ingotCopper });
        this.addRecipe(new ItemStack(Block.lightBulb, 2), new Object[] { "###", "#X#", "#Y#", '#', Block.glass, 'Y', Item.ingotCopper, 'X', Item.carbonFilament });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_red });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_yellow });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_blue });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_darkgray });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_cyan });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_orange });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_lime });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_green });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_teal });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_lilac });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_indigo });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_violet });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_pink });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_magenta });
        this.addRecipe(new ItemStack(Item.silk, 9), new Object[] { "#", '#', Block.cloth_lightgray });
        this.addShapelessRecipe(new ItemStack(Item.bowlSoup, 1), new Object[] { Item.bowlEmpty, Block.mushroomBrown, Block.mushroomRed });
        this.addShapelessRecipe(new ItemStack(Item.bread, 1), new Object[] { Item.wheat, Item.wheat, Item.wheat });
        this.addShapelessRecipe(new ItemStack(Item.dyeRed, 2), new Object[] { Block.plantRed });
        this.addShapelessRecipe(new ItemStack(Item.dyeBlack, 4), new Object[] { Item.coal, Item.coal });
        this.addShapelessRecipe(new ItemStack(Item.dyeYellow, 2), new Object[] { Block.plantYellow });
        this.addShapelessRecipe(new ItemStack(Item.bonemeal, 3), new Object[] { Item.bone });
        this.addShapelessRecipe(new ItemStack(Item.dyeGrey, 2), new Object[] { Item.bonemeal, Item.dyeBlack });
        this.addShapelessRecipe(new ItemStack(Item.dyeGrey, 2), new Object[] { Item.bonemeal, Item.dyeBlack });
        this.addShapelessRecipe(new ItemStack(Item.dyeOrange, 2), new Object[] { Item.dyeRed, Item.dyeYellow });
        this.addShapelessRecipe(new ItemStack(Item.dyeOrange, 2), new Object[] { Item.dyeRed, Item.dyeYellow });
        this.addShapelessRecipe(new ItemStack(Item.dyeLime, 2), new Object[] { Item.dyeGreen, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeLime, 2), new Object[] { Item.dyeGreen, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeAquaGreen, 2), new Object[] { Item.dyeGreen, Item.dyeBlue });
        this.addShapelessRecipe(new ItemStack(Item.dyeAquaGreen, 2), new Object[] { Item.dyeGreen, Item.dyeBlue });
        this.addShapelessRecipe(new ItemStack(Item.dyeCyan, 2), new Object[] { Item.dyeBlue, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeCyan, 2), new Object[] { Item.dyeBlue, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyePurple, 2), new Object[] { Item.dyeBlue, Item.dyeRed });
        this.addShapelessRecipe(new ItemStack(Item.dyePurple, 2), new Object[] { Item.dyeBlue, Item.dyeRed });
        this.addShapelessRecipe(new ItemStack(Item.dyeIndigo, 2), new Object[] { Item.dyeBlue, Item.dyePurple });
        this.addShapelessRecipe(new ItemStack(Item.dyeIndigo, 2), new Object[] { Item.dyeBlue, Item.dyePurple });
        this.addShapelessRecipe(new ItemStack(Item.dyeMagenta, 2), new Object[] { Item.dyeRed, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeMagenta, 2), new Object[] { Item.dyeRed, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyePink, 2), new Object[] { Item.dyeRed, Item.dyeMagenta });
        this.addShapelessRecipe(new ItemStack(Item.dyePink, 2), new Object[] { Item.dyeRed, Item.dyeMagenta });
        this.addShapelessRecipe(new ItemStack(Item.dyeViolet, 2), new Object[] { Item.dyeIndigo, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeViolet, 2), new Object[] { Item.dyeIndigo, Item.bonemeal });
        this.addShapelessRecipe(new ItemStack(Item.dyeBlue, 2), new Object[] { Block.plantBlue });
        this.addShapelessRecipe(new ItemStack(Block.cloth_red, 1), new Object[] { Item.dyeRed, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_yellow, 1), new Object[] { Item.dyeYellow, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_blue, 1), new Object[] { Item.dyeBlue, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_darkgray, 1), new Object[] { Item.dyeBlack, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_cyan, 1), new Object[] { Item.dyeCyan, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_orange, 1), new Object[] { Item.dyeOrange, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_lime, 1), new Object[] { Item.dyeLime, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_green, 1), new Object[] { Item.dyeGreen, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_teal, 1), new Object[] { Item.dyeAquaGreen, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_lilac, 1), new Object[] { Item.dyePurple, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_indigo, 1), new Object[] { Item.dyeIndigo, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_violet, 1), new Object[] { Item.dyeViolet, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_pink, 1), new Object[] { Item.dyePink, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_magenta, 1), new Object[] { Item.dyeMagenta, Block.cloth });
        this.addShapelessRecipe(new ItemStack(Block.cloth_lightgray, 1), new Object[] { Item.dyeGrey, Block.cloth });
        Collections.sort(this.recipes, new RecipeSorter(this));
        System.out.println(this.recipes.size() + " recipes");
    }
    
    void addRecipe(final ItemStack itemstack, final Object[] aobj) {
        String s = "";
        int i = 0;
        int j = 0;
        int k = 0;
        if (aobj[i] instanceof String[]) {
            final String[] as = (String[])aobj[i++];
            for (int l = 0; l < as.length; ++l) {
                final String s2 = as[l];
                ++k;
                j = s2.length();
                s += s2;
            }
        }
        else {
            while (aobj[i] instanceof String) {
                final String s3 = (String)aobj[i++];
                ++k;
                j = s3.length();
                s += s3;
            }
        }
        final HashMap hashmap = new HashMap();
        while (i < aobj.length) {
            final Character character = (Character)aobj[i];
            ItemStack itemstack2 = null;
            if (aobj[i + 1] instanceof Item) {
                itemstack2 = new ItemStack((Item)aobj[i + 1]);
            }
            else if (aobj[i + 1] instanceof Block) {
                itemstack2 = new ItemStack((Block)aobj[i + 1], 1, -1);
            }
            else if (aobj[i + 1] instanceof ItemStack) {
                itemstack2 = (ItemStack)aobj[i + 1];
            }
            hashmap.put(character, itemstack2);
            i += 2;
        }
        final ItemStack[] aitemstack = new ItemStack[j * k];
        for (int i2 = 0; i2 < j * k; ++i2) {
            final char c = s.charAt(i2);
            if (hashmap.containsKey(c)) {
                aitemstack[i2] = hashmap.get(c).copy();
            }
            else {
                aitemstack[i2] = null;
            }
        }
        this.recipes.add(new ShapedRecipes(j, k, aitemstack, itemstack));
    }
    
    void addShapelessRecipe(final ItemStack itemstack, final Object[] aobj) {
        final ArrayList arraylist = new ArrayList();
        for (final Object obj : aobj) {
            if (obj instanceof ItemStack) {
                arraylist.add(((ItemStack)obj).copy());
            }
            else if (obj instanceof Item) {
                arraylist.add(new ItemStack((Item)obj));
            }
            else {
                if (!(obj instanceof Block)) {
                    throw new RuntimeException("Invalid shapeless recipy!");
                }
                arraylist.add(new ItemStack((Block)obj));
            }
        }
        this.recipes.add(new ShapelessRecipes(itemstack, arraylist));
    }
    
    public ItemStack findMatchingRecipe(final InventoryCrafting inventorycrafting) {
        for (int i = 0; i < this.recipes.size(); ++i) {
            final IRecipe irecipe = this.recipes.get(i);
            if (irecipe.matches(inventorycrafting)) {
                return irecipe.getCraftingResult(inventorycrafting);
            }
        }
        return null;
    }
}
