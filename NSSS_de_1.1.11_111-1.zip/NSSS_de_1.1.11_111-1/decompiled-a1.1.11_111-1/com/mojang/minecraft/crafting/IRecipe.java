package com.mojang.minecraft.crafting;

import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.item.*;

public interface IRecipe
{
    boolean matches(final InventoryCrafting p0);
    
    ItemStack getCraftingResult(final InventoryCrafting p0);
    
    int getRecipeSize();
    
    ItemStack getRecipeOutput();
}
