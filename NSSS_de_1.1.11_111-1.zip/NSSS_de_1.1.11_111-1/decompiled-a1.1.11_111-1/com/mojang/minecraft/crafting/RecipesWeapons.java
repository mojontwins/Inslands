package com.mojang.minecraft.crafting;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;

public class RecipesWeapons
{
    private String[][] field_1100_a;
    private Object[][] field_1099_b;
    
    public RecipesWeapons() {
        this.field_1100_a = new String[][] { { "X", "X", "#" } };
        this.field_1099_b = new Object[][] { { Block.planks, Block.cobblestone, Item.ingotIron, Item.diamond, Item.ingotGold }, { Item.swordWood, Item.swordStone, Item.swordSteel, Item.swordDiamond, Item.swordGold } };
    }
    
    public void addRecipes(final CraftingManager craftingmanager) {
        for (int i = 0; i < this.field_1099_b[0].length; ++i) {
            final Object obj = this.field_1099_b[0][i];
            for (int j = 0; j < this.field_1099_b.length - 1; ++j) {
                final Item item = (Item)this.field_1099_b[j + 1][i];
                craftingmanager.addRecipe(new ItemStack(item), new Object[] { this.field_1100_a[j], '#', Item.stick, 'X', obj });
            }
        }
        craftingmanager.addRecipe(new ItemStack(Item.bow, 1), new Object[] { " #X", "# X", " #X", 'X', Item.silk, '#', Item.stick });
        craftingmanager.addRecipe(new ItemStack(Item.arrow, 4), new Object[] { "X", "#", "Y", 'Y', Item.feather, 'X', Item.flint, '#', Item.stick });
    }
}
