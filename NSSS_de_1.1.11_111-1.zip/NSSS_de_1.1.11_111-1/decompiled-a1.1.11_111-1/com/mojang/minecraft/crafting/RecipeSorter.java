package com.mojang.minecraft.crafting;

import java.util.*;

class RecipeSorter implements Comparator<Object>
{
    final CraftingManager craftingManager;
    
    RecipeSorter(final CraftingManager craftingmanager) {
        this.craftingManager = craftingmanager;
    }
    
    public int compareRecipes(final IRecipe irecipe, final IRecipe irecipe1) {
        if (irecipe instanceof ShapelessRecipes && irecipe1 instanceof ShapedRecipes) {
            return 1;
        }
        if (irecipe1 instanceof ShapelessRecipes && irecipe instanceof ShapedRecipes) {
            return -1;
        }
        if (irecipe1.getRecipeSize() < irecipe.getRecipeSize()) {
            return -1;
        }
        return (irecipe1.getRecipeSize() > irecipe.getRecipeSize()) ? 1 : 0;
    }
    
    public int compare(final Object obj, final Object obj1) {
        return this.compareRecipes((IRecipe)obj, (IRecipe)obj1);
    }
}
