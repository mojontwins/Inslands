package com.mojang.minecraft.crafting;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.item.*;

public class RecipesCrafting
{
    public void addRecipes(final CraftingManager craftingmanager) {
        craftingmanager.addRecipe(new ItemStack(Block.crate), new Object[] { "###", "# #", "###", '#', Block.planks });
        craftingmanager.addRecipe(new ItemStack(Block.stoneOvenIdle), new Object[] { "###", "# #", "###", '#', Block.cobblestone });
        craftingmanager.addRecipe(new ItemStack(Block.workbench), new Object[] { "##", "##", '#', Block.planks });
    }
}
