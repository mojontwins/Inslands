package com.mojang.minecraft;

public class MinecraftException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
    
    public MinecraftException(final String s) {
        super(s);
    }
}
