package com.mojang.minecraft.level;

public class NextTickListEntry implements Comparable<Object>
{
    private static long field_1363_f;
    public int field_1361_a;
    public int field_1360_b;
    public int field_1366_c;
    public int field_1365_d;
    public long field_1364_e;
    private long field_1362_g;
    
    static {
        NextTickListEntry.field_1363_f = 0L;
    }
    
    public NextTickListEntry(final int i, final int j, final int k, final int l) {
        this.field_1362_g = NextTickListEntry.field_1363_f++;
        this.field_1361_a = i;
        this.field_1360_b = j;
        this.field_1366_c = k;
        this.field_1365_d = l;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof NextTickListEntry) {
            final NextTickListEntry nextticklistentry = (NextTickListEntry)obj;
            return this.field_1361_a == nextticklistentry.field_1361_a && this.field_1360_b == nextticklistentry.field_1360_b && this.field_1366_c == nextticklistentry.field_1366_c && this.field_1365_d == nextticklistentry.field_1365_d;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (this.field_1361_a * 128 * 1024 + this.field_1366_c * 128 + this.field_1360_b) * 256 + this.field_1365_d;
    }
    
    public NextTickListEntry func_900_a(final long l) {
        this.field_1364_e = l;
        return this;
    }
    
    public int func_899_a(final NextTickListEntry nextticklistentry) {
        if (this.field_1364_e < nextticklistentry.field_1364_e) {
            return -1;
        }
        if (this.field_1364_e > nextticklistentry.field_1364_e) {
            return 1;
        }
        if (this.field_1362_g < nextticklistentry.field_1362_g) {
            return -1;
        }
        return (this.field_1362_g > nextticklistentry.field_1362_g) ? 1 : 0;
    }
    
    public int compareTo(final Object obj) {
        return this.func_899_a((NextTickListEntry)obj);
    }
}
