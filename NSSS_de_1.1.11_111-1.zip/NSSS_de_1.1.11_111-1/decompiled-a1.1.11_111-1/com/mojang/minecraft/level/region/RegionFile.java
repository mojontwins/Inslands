package com.mojang.minecraft.level.region;

import java.util.*;
import java.util.zip.*;
import java.io.*;

public class RegionFile
{
    static final int CHUNK_HEADER_SIZE = 5;
    private static final byte[] emptySector;
    private final File file;
    private RandomAccessFile dataFile;
    private final int[] offsets;
    private ArrayList<Boolean> sectorFree;
    private int sizeDelta;
    private long lastModified;
    
    static {
        emptySector = new byte[4096];
    }
    
    public RegionFile(final File path) {
        this.lastModified = 0L;
        this.offsets = new int[1024];
        this.file = path;
        this.debugln("REGION LOAD " + this.file);
        this.sizeDelta = 0;
        try {
            if (path.exists()) {
                this.lastModified = path.lastModified();
            }
            this.dataFile = new RandomAccessFile(path, "rw");
            if (this.dataFile.length() < 4096L) {
                for (int i = 0; i < 1024; ++i) {
                    this.dataFile.writeInt(0);
                }
                for (int i = 0; i < 1024; ++i) {
                    this.dataFile.writeInt(0);
                }
                this.sizeDelta += 4096;
            }
            if ((this.dataFile.length() & 0xFFFL) != 0x0L) {
                for (int i = 0; i < (this.dataFile.length() & 0xFFFL); ++i) {
                    this.dataFile.write(0);
                }
            }
            final int nSectors = (int)this.dataFile.length() / 4096;
            this.sectorFree = new ArrayList<Boolean>(nSectors);
            for (int j = 0; j < nSectors; ++j) {
                this.sectorFree.add(true);
            }
            this.sectorFree.set(0, false);
            this.sectorFree.set(1, false);
            this.dataFile.seek(0L);
            for (int j = 0; j < 1024; ++j) {
                final int offset = this.dataFile.readInt();
                this.offsets[j] = offset;
                if (offset != 0 && (offset >> 8) + (offset & 0xFF) <= this.sectorFree.size()) {
                    for (int sectorNum = 0; sectorNum < (offset & 0xFF); ++sectorNum) {
                        this.sectorFree.set((offset >> 8) + sectorNum, false);
                    }
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public long lastModified() {
        return this.lastModified;
    }
    
    public synchronized int getSizeDelta() {
        final int ret = this.sizeDelta;
        this.sizeDelta = 0;
        return ret;
    }
    
    private void debug(final String in) {
    }
    
    private void debugln(final String in) {
        this.debug(String.valueOf(in) + "\n");
    }
    
    private void debug(final String mode, final int x, final int z, final String in) {
        this.debug("REGION " + mode + " " + this.file.getName() + "[" + x + "," + z + "] = " + in);
    }
    
    private void debug(final String mode, final int x, final int z, final int count, final String in) {
        this.debug("REGION " + mode + " " + this.file.getName() + "[" + x + "," + z + "] " + count + "B = " + in);
    }
    
    private void debugln(final String mode, final int x, final int z, final String in) {
        this.debug(mode, x, z, String.valueOf(in) + "\n");
    }
    
    public synchronized DataInputStream getChunkDataInputStream(final int x, final int z) {
        if (this.outOfBounds(x, z)) {
            this.debugln("READ", x, z, "out of bounds");
            return null;
        }
        try {
            final int offset = this.getOffset(x, z);
            if (offset == 0) {
                return null;
            }
            final int sectorNumber = offset >> 8;
            final int numSectors = offset & 0xFF;
            if (sectorNumber + numSectors > this.sectorFree.size()) {
                this.debugln("READ", x, z, "invalid sector");
                return null;
            }
            this.dataFile.seek(sectorNumber * 4096);
            final int length = this.dataFile.readInt();
            if (length > 4096 * numSectors) {
                this.debugln("READ", x, z, "invalid length: " + length + " > 4096 * " + numSectors);
                return null;
            }
            final byte version = this.dataFile.readByte();
            if (version == 1) {
                final byte[] data = new byte[length - 1];
                this.dataFile.read(data);
                final DataInputStream ret = new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(data)));
                return ret;
            }
            if (version == 2) {
                final byte[] data = new byte[length - 1];
                this.dataFile.read(data);
                final DataInputStream ret = new DataInputStream(new InflaterInputStream(new ByteArrayInputStream(data)));
                return ret;
            }
            this.debugln("READ", x, z, "unknown version " + version);
            return null;
        }
        catch (IOException e) {
            this.debugln("READ", x, z, "exception");
            return null;
        }
    }
    
    public DataOutputStream getChunkDataOutputStream(final int x, final int z) {
        if (this.outOfBounds(x, z)) {
            return null;
        }
        return new DataOutputStream(new DeflaterOutputStream(new ChunkBuffer(x, z)));
    }
    
    protected synchronized void write(final int x, final int z, final byte[] data, final int length) {
        try {
            final int offset = this.getOffset(x, z);
            int sectorNumber = offset >> 8;
            final int sectorsAllocated = offset & 0xFF;
            final int sectorsNeeded = (length + 5) / 4096 + 1;
            if (sectorsNeeded >= 256) {
                return;
            }
            if (sectorNumber != 0 && sectorsAllocated == sectorsNeeded) {
                this.debug("SAVE", x, z, length, "rewrite");
                this.write(sectorNumber, data, length);
            }
            else {
                for (int i = 0; i < sectorsAllocated; ++i) {
                    this.sectorFree.set(sectorNumber + i, true);
                }
                int runStart = this.sectorFree.indexOf(true);
                int runLength = 0;
                if (runStart != -1) {
                    for (int j = runStart; j < this.sectorFree.size(); ++j) {
                        if (runLength != 0) {
                            if (this.sectorFree.get(j)) {
                                ++runLength;
                            }
                            else {
                                runLength = 0;
                            }
                        }
                        else if (this.sectorFree.get(j)) {
                            runStart = j;
                            runLength = 1;
                        }
                        if (runLength >= sectorsNeeded) {
                            break;
                        }
                    }
                }
                if (runLength >= sectorsNeeded) {
                    this.debug("SAVE", x, z, length, "reuse");
                    sectorNumber = runStart;
                    this.setOffset(x, z, sectorNumber << 8 | sectorsNeeded);
                    for (int j = 0; j < sectorsNeeded; ++j) {
                        this.sectorFree.set(sectorNumber + j, false);
                    }
                    this.write(sectorNumber, data, length);
                }
                else {
                    this.debug("SAVE", x, z, length, "grow");
                    this.dataFile.seek(this.dataFile.length());
                    sectorNumber = this.sectorFree.size();
                    for (int j = 0; j < sectorsNeeded; ++j) {
                        this.dataFile.write(RegionFile.emptySector);
                        this.sectorFree.add(false);
                    }
                    this.sizeDelta += 4096 * sectorsNeeded;
                    this.write(sectorNumber, data, length);
                    this.setOffset(x, z, sectorNumber << 8 | sectorsNeeded);
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void write(final int sectorNumber, final byte[] data, final int length) throws IOException {
        this.debugln(" " + sectorNumber);
        this.dataFile.seek(sectorNumber * 4096);
        this.dataFile.writeInt(length + 1);
        this.dataFile.writeByte(2);
        this.dataFile.write(data, 0, length);
    }
    
    private boolean outOfBounds(final int x, final int z) {
        return x < 0 || x >= 32 || z < 0 || z >= 32;
    }
    
    private int getOffset(final int x, final int z) throws IOException {
        return this.offsets[x + z * 32];
    }
    
    private void setOffset(final int x, final int z, final int offset) throws IOException {
        this.offsets[x + z * 32] = offset;
        this.dataFile.seek((x + z * 32) * 4);
        this.dataFile.writeInt(offset);
    }
    
    public void close() throws IOException {
        this.dataFile.close();
    }
    
    class ChunkBuffer extends ByteArrayOutputStream
    {
        private int x;
        private int z;
        
        public ChunkBuffer(final int x, final int z) {
            super(8096);
            this.x = x;
            this.z = z;
        }
        
        @Override
        public void close() {
            RegionFile.this.write(this.x, this.z, this.buf, this.count);
        }
    }
}
