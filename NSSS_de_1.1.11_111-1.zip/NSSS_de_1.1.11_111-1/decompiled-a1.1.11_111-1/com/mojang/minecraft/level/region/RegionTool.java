package com.mojang.minecraft.level.region;

import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import java.io.*;

class RegionTool
{
    private static boolean isConsole;
    
    static {
        RegionTool.isConsole = false;
    }
    
    public static void main(final String[] args) {
        if (args.length != 2 && args.length != 3) {
            exitUsage();
        }
        if (System.in != null) {
            RegionTool.isConsole = true;
        }
        int mode = 0;
        if (args[0].equalsIgnoreCase("unpack")) {
            mode = 1;
        }
        else if (args[0].equalsIgnoreCase("pack")) {
            mode = 2;
        }
        if (mode == 0) {
            exitUsage();
        }
        final File worldDir = new File(args[1]);
        if (!worldDir.exists() || !worldDir.isDirectory()) {
            exit("error: " + worldDir.getPath() + " is not a directory");
        }
        File targetDir = worldDir;
        if (args.length == 3) {
            targetDir = new File(args[2]);
            if (!targetDir.isDirectory()) {
                targetDir.mkdirs();
            }
        }
        if (mode == 1) {
            unpack(worldDir, targetDir);
        }
        else if (mode == 2) {
            pack(worldDir, targetDir);
        }
    }
    
    private static void unpack(final File worldDir, final File targetDir) {
        final File regionDir = new File(worldDir, "region");
        if (!regionDir.exists()) {
            exit("error: region directory not found");
        }
        Set<File> processedFiles = null;
        if (worldDir != targetDir) {
            processedFiles = new HashSet<File>();
        }
        final Pattern regionFilePattern = Pattern.compile("r\\.(-?[0-9]+)\\.(-?[0-9]+).mcr");
        File[] listFiles;
        for (int length = (listFiles = regionDir.listFiles()).length, i = 0; i < length; ++i) {
            final File file = listFiles[i];
            if (file.isFile()) {
                final Matcher match = regionFilePattern.matcher(file.getName());
                if (match.matches()) {
                    try {
                        unpackRegionFile(targetDir, file, match);
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (processedFiles != null) {
                        processedFiles.add(file);
                    }
                }
            }
        }
        if (processedFiles != null) {
            copyDir(worldDir, targetDir, processedFiles);
        }
    }
    
    private static void pack(final File worldDir, final File targetDir) {
        Set<File> processedFiles = null;
        if (worldDir != targetDir) {
            processedFiles = new HashSet<File>();
        }
        final Pattern chunkFilePattern = Pattern.compile("c\\.(-?[0-9a-z]+)\\.(-?[0-9a-z]+).dat");
        final Pattern chunkFolderPattern = Pattern.compile("[0-9a-z]|1[0-9a-r]");
        int chunksPacked = 0;
        int chunksSkipped = 0;
        File[] listFiles;
        for (int length = (listFiles = worldDir.listFiles()).length, i = 0; i < length; ++i) {
            final File dir1 = listFiles[i];
            if (dir1.isDirectory()) {
                if (chunkFolderPattern.matcher(dir1.getName()).matches()) {
                    File[] listFiles2;
                    for (int length2 = (listFiles2 = dir1.listFiles()).length, j = 0; j < length2; ++j) {
                        final File dir2 = listFiles2[j];
                        if (dir2.isDirectory()) {
                            if (chunkFolderPattern.matcher(dir2.getName()).matches()) {
                                File[] listFiles3;
                                for (int length3 = (listFiles3 = dir2.listFiles()).length, k = 0; k < length3; ++k) {
                                    final File chunkFile = listFiles3[k];
                                    final Matcher m = chunkFilePattern.matcher(chunkFile.getName());
                                    if (m.matches()) {
                                        if (packChunk(targetDir, chunkFile, m)) {
                                            ++chunksPacked;
                                        }
                                        else {
                                            ++chunksSkipped;
                                        }
                                        if (processedFiles != null) {
                                            processedFiles.add(chunkFile);
                                        }
                                    }
                                    if (RegionTool.isConsole) {
                                        System.out.print("\rpacked " + chunksPacked + " chunks" + ((chunksSkipped > 0) ? (", skipped " + chunksSkipped + " older ones") : ""));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (RegionTool.isConsole) {
            System.out.print("\r");
        }
        System.out.println("packed " + chunksPacked + " chunks" + ((chunksSkipped > 0) ? (", skipped " + chunksSkipped + " older ones") : ""));
        if (processedFiles != null) {
            copyDir(worldDir, targetDir, processedFiles);
        }
    }
    
    private static boolean packChunk(final File worldDir, final File chunkFile, final Matcher m) {
        final int x = Integer.parseInt(m.group(1), 36);
        final int z = Integer.parseInt(m.group(2), 36);
        final RegionFile region = RegionFileCache.getRegionFile(worldDir, x, z);
        if (region.lastModified() > chunkFile.lastModified()) {
            return false;
        }
        final byte[] buf = new byte[4096];
        int len = 0;
        try {
            final DataInputStream istream = new DataInputStream(new GZIPInputStream(new FileInputStream(chunkFile)));
            final DataOutputStream out = region.getChunkDataOutputStream(x & 0x1F, z & 0x1F);
            while (len != -1) {
                out.write(buf, 0, len);
                len = istream.read(buf);
            }
            out.close();
            istream.close();
            return true;
        }
        catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    private static void unpackRegionFile(final File worldDir, final File file, final Matcher match) throws IOException {
        final long regionModified = file.lastModified();
        final RegionFile region = new RegionFile(file);
        final String name = file.getName();
        final int regionX = Integer.parseInt(match.group(1));
        final int regionZ = Integer.parseInt(match.group(2));
        int nWritten = 0;
        int nSkipped = 0;
        for (int x = 0; x < 32; ++x) {
            for (int z = 0; z < 32; ++z) {
                final DataInputStream istream = region.getChunkDataInputStream(x, z);
                if (istream != null) {
                    final int chunkX = x + (regionX << 5);
                    final int chunkZ = z + (regionZ << 5);
                    final String chunkName = "c." + Integer.toString(chunkX, 36) + "." + Integer.toString(chunkZ, 36) + ".dat";
                    File chunkFile = new File(worldDir, Integer.toString(chunkX & 0x3F, 36));
                    chunkFile = new File(chunkFile, Integer.toString(chunkZ & 0x3F, 36));
                    if (!chunkFile.exists()) {
                        chunkFile.mkdirs();
                    }
                    chunkFile = new File(chunkFile, chunkName);
                    final byte[] buf = new byte[4096];
                    int len = 0;
                    if (chunkFile.lastModified() > regionModified) {
                        ++nSkipped;
                    }
                    else {
                        try {
                            final DataOutputStream out = new DataOutputStream(new GZIPOutputStream(new FileOutputStream(chunkFile)));
                            while (len != -1) {
                                out.write(buf, 0, len);
                                len = istream.read(buf);
                            }
                            out.close();
                            ++nWritten;
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    istream.close();
                    if (RegionTool.isConsole) {
                        System.out.print("\r" + name + ": unpacked " + nWritten + " chunks" + ((nSkipped > 0) ? (", skipped " + nSkipped + " newer ones") : ""));
                    }
                }
            }
        }
        if (RegionTool.isConsole) {
            System.out.print("\r");
        }
        System.out.println(String.valueOf(name) + ": unpacked " + nWritten + " chunks" + ((nSkipped > 0) ? (", skipped " + nSkipped + " newer ones") : ""));
    }
    
    private static void copyDir(final File srcDir, final File dstDir, final Set<File> skip) {
        final byte[] buf = new byte[4096];
        File[] listFiles;
        for (int length = (listFiles = srcDir.listFiles()).length, i = 0; i < length; ++i) {
            final File child = listFiles[i];
            if (child.isDirectory()) {
                copyDir(child, new File(dstDir, child.getName()), skip);
            }
            else if (!skip.contains(child)) {
                FileInputStream in = null;
                FileOutputStream out = null;
                try {
                    final File dstfile = new File(dstDir, child.getName());
                    dstDir.mkdirs();
                    out = new FileOutputStream(dstfile);
                    in = new FileInputStream(child);
                    for (int len = 0; len != -1; len = in.read(buf)) {
                        out.write(buf, 0, len);
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    if (out != null) {
                        try {
                            out.close();
                        }
                        catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    continue;
                }
                finally {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                    if (out != null) {
                        try {
                            out.close();
                        }
                        catch (IOException e2) {
                            e2.printStackTrace();
                        }
                    }
                }
                if (in != null) {
                    try {
                        in.close();
                    }
                    catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
                if (out != null) {
                    try {
                        out.close();
                    }
                    catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            }
        }
    }
    
    private static void exitUsage() {
        exit("regionTool: converts between chunks and regions\nusage: java -jar RegionTool.jar [un]pack <world directory> [target directory]");
    }
    
    private static void exit(final String message) {
        System.err.println(message);
        System.exit(1);
    }
}
