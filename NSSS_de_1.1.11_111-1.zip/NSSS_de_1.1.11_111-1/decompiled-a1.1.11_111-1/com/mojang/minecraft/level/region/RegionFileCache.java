package com.mojang.minecraft.level.region;

import java.lang.ref.*;
import java.util.*;
import java.io.*;

public class RegionFileCache
{
    private static final Map<File, Reference<RegionFile>> cache;
    
    static {
        cache = new HashMap<File, Reference<RegionFile>>();
    }
    
    private RegionFileCache() {
    }
    
    public static synchronized RegionFile getRegionFile(final File basePath, final int x, final int z) {
        final File regionDir = new File(basePath, "region");
        final File file = new File(regionDir, "r." + (x >> 5) + "." + (z >> 5) + ".mcr");
        final Reference<RegionFile> ref = RegionFileCache.cache.get(file);
        if (ref != null && ref.get() != null) {
            return ref.get();
        }
        if (!regionDir.exists()) {
            regionDir.mkdirs();
        }
        final RegionFile reg = new RegionFile(file);
        RegionFileCache.cache.put(file, new SoftReference<RegionFile>(reg));
        return reg;
    }
    
    public static synchronized void clear() {
        for (final Reference<RegionFile> ref : RegionFileCache.cache.values()) {
            try {
                if (ref.get() == null) {
                    continue;
                }
                ref.get().close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        RegionFileCache.cache.clear();
    }
    
    public static int getSizeDelta(final File basePath, final int x, final int z) {
        final RegionFile r = getRegionFile(basePath, x, z);
        return r.getSizeDelta();
    }
    
    public static DataInputStream getChunkDataInputStream(final File basePath, final int x, final int z) {
        final RegionFile r = getRegionFile(basePath, x, z);
        return r.getChunkDataInputStream(x & 0x1F, z & 0x1F);
    }
    
    public static DataOutputStream getChunkDataOutputStream(final File basePath, final int x, final int z) {
        final RegionFile r = getRegionFile(basePath, x, z);
        return r.getChunkDataOutputStream(x & 0x1F, z & 0x1F);
    }
}
