package com.mojang.minecraft.level;

import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.level.region.*;
import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.gui.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.*;
import java.util.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.entity.path.*;
import java.io.*;
import com.mojang.minecraft.*;

public class World implements IBlockAccess
{
    public static final int NORMAL = 0;
    public static final int FLOATING = 1;
    public static final int CORRUPTION = 2;
    public static final int DESERT = 3;
    public static final int INDEV = 4;
    public static final HashMap<Integer, String> TYPENAMES;
    public float cloudHeight;
    private List<MetadataChunkBlock> field_1025_z;
    public List<Entity> loadedEntityList;
    private List<Object> unloadedEntityList;
    private TreeSet<NextTickListEntry> field_1023_B;
    private Set<NextTickListEntry> field_1022_C;
    public List<Object> field_1049_b;
    public long worldTime;
    public boolean snowCovered;
    private long field_1021_D;
    private long field_1020_E;
    private long field_1019_F;
    public int skyLightSubtracted;
    protected int randomInt;
    protected int someOtherNumber;
    public boolean etitingBlocks;
    public static float[] field_1042_i;
    private final long field_1018_G;
    protected int saveRate;
    public List<EntityPlayer> playerEntities;
    public List<Entity> weatherEffects;
    public int difficulty;
    public Object field_1038_m;
    public Random rand;
    public int spawnX;
    public int spawnY;
    public int spawnZ;
    public boolean isNewWorld;
    protected List<IWorldAccess> worldAccesses;
    public IChunkProvider chunkProvider;
    public File worldFolder;
    public long randomSeed;
    private NBTTagCompound nbtCompoundPlayer;
    public long sizeOnDisk;
    public final String field_1028_w;
    public boolean findingSpawnPoint;
    private ArrayList<AxisAlignedBB> field_1015_J;
    private Set<ChunkCoordIntPair> setOfTickableChunks;
    private int ambienceChance;
    private List<Entity> field_1012_M;
    public boolean multiplayerWorld;
    public boolean cheatsDisabled;
    public int worldType;
    public ArrayList<GearGroup> gearGroups;
    public int multiplayerDifficulty;
    public Minecraft mc;
    public boolean justLoaded;
    
    static {
        TYPENAMES = new HashMap<Integer, String>() {
            private static final long serialVersionUID = 1L;
            
            {
                this.put(0, "NORMAL");
                this.put(1, "FLOATING");
                this.put(2, "CORRUPTION");
                this.put(3, "DESERT");
                this.put(4, "2D PERLIN");
            }
        };
        World.field_1042_i = new float[16];
        final float f = 0.05f;
        for (int i = 0; i <= 15; ++i) {
            final float f2 = 1.0f - i / 15.0f;
            World.field_1042_i[i] = (1.0f - f2) / (f2 * 3.0f + 1.0f) * (1.0f - f) + f;
        }
    }
    
    public static NBTTagCompound func_629_a(final File file, final String s) {
        final File file2 = new File(file, "NSSSsaves");
        final File file3 = new File(file2, s);
        if (!file3.exists()) {
            return null;
        }
        final File file4 = new File(file3, "level.dat");
        if (file4.exists()) {
            try {
                final FileInputStream fis = new FileInputStream(file4);
                final NBTTagCompound nbttagcompound = CompressedStreamTools.func_1138_a(fis);
                final NBTTagCompound nbttagcompound2 = nbttagcompound.getCompoundTag("Data");
                fis.close();
                return nbttagcompound2;
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        return null;
    }
    
    public static void func_615_b(final File file, final String s) {
        final File file2 = new File(file, "NSSSsaves");
        final File file3 = new File(file2, s);
        if (!file3.exists()) {
            return;
        }
        func_653_a(file3.listFiles());
        file3.delete();
    }
    
    public static void func_615_b2(final File file, final String s) {
        final File file2 = new File(file, "NSSSservers");
        final File file3 = new File(file2, s);
        if (!file3.exists()) {
            return;
        }
        func_653_a(file3.listFiles());
        file3.delete();
    }
    
    private static void func_653_a(final File[] afile) {
        RegionFileCache.clear();
        for (int i = 0; i < afile.length; ++i) {
            if (afile[i].isDirectory()) {
                func_653_a(afile[i].listFiles());
            }
            afile[i].delete();
        }
    }
    
    public World(final File file, final String s, final boolean snow, final boolean cheatsDisabled, final int worldType, final Minecraft mine) {
        this(file, s, new Random().nextLong(), snow, cheatsDisabled, worldType, mine);
    }
    
    public World(final String s, final Minecraft mine) {
        this.cloudHeight = 108.0f;
        this.field_1025_z = new ArrayList<MetadataChunkBlock>();
        this.loadedEntityList = new ArrayList<Entity>();
        this.unloadedEntityList = new ArrayList<Object>();
        this.field_1023_B = new TreeSet<NextTickListEntry>();
        this.field_1022_C = new HashSet<NextTickListEntry>();
        this.field_1049_b = new ArrayList<Object>();
        this.worldTime = 0L;
        this.snowCovered = false;
        this.field_1021_D = 8961023L;
        this.field_1020_E = 12638463L;
        this.field_1019_F = 16777215L;
        this.skyLightSubtracted = 0;
        this.randomInt = new Random().nextInt();
        this.someOtherNumber = 1013904223;
        this.etitingBlocks = false;
        this.field_1018_G = System.currentTimeMillis();
        this.saveRate = 40;
        this.playerEntities = new ArrayList<EntityPlayer>();
        this.weatherEffects = new ArrayList<Entity>();
        this.rand = new Random();
        this.isNewWorld = false;
        this.worldAccesses = new ArrayList<IWorldAccess>();
        this.randomSeed = 0L;
        this.sizeOnDisk = 0L;
        this.field_1015_J = new ArrayList<AxisAlignedBB>();
        this.setOfTickableChunks = new HashSet<ChunkCoordIntPair>();
        this.ambienceChance = this.rand.nextInt(12000);
        this.field_1012_M = new ArrayList<Entity>();
        this.multiplayerWorld = false;
        this.field_1028_w = s;
        this.chunkProvider = this.getWorldChunkProvider(this.worldFolder);
        this.gearGroups = new ArrayList<GearGroup>();
        this.mc = mine;
        this.justLoaded = false;
        this.func_644_f();
    }
    
    public World(final File file, final String s, final long l, final boolean snowCovereds, final boolean cheatsDisableds, final int worldTypes, final Minecraft mine) {
        this.cloudHeight = 108.0f;
        this.cheatsDisabled = cheatsDisableds;
        this.field_1025_z = new ArrayList<MetadataChunkBlock>();
        this.loadedEntityList = new ArrayList<Entity>();
        this.unloadedEntityList = new ArrayList<Object>();
        this.field_1023_B = new TreeSet<NextTickListEntry>();
        this.field_1022_C = new HashSet<NextTickListEntry>();
        this.field_1049_b = new ArrayList<Object>();
        this.worldTime = 0L;
        this.snowCovered = snowCovereds;
        this.worldType = worldTypes;
        this.field_1021_D = 8961023L;
        this.field_1020_E = 12638463L;
        this.field_1019_F = 16777215L;
        this.skyLightSubtracted = 0;
        this.randomInt = new Random().nextInt();
        this.someOtherNumber = 1013904223;
        this.etitingBlocks = false;
        this.field_1018_G = System.currentTimeMillis();
        this.saveRate = 40;
        this.playerEntities = new ArrayList<EntityPlayer>();
        this.weatherEffects = new ArrayList<Entity>();
        this.rand = new Random();
        this.isNewWorld = false;
        this.worldAccesses = new ArrayList<IWorldAccess>();
        this.randomSeed = 0L;
        this.sizeOnDisk = 0L;
        this.field_1015_J = new ArrayList<AxisAlignedBB>();
        this.setOfTickableChunks = new HashSet<ChunkCoordIntPair>();
        this.ambienceChance = this.rand.nextInt(12000);
        this.field_1012_M = new ArrayList<Entity>();
        this.multiplayerWorld = false;
        this.field_1028_w = s;
        file.mkdirs();
        (this.worldFolder = new File(file, s)).mkdirs();
        this.gearGroups = new ArrayList<GearGroup>();
        this.mc = mine;
        try {
            final File file2 = new File(this.worldFolder, "session.lock");
            final DataOutputStream dataoutputstream = new DataOutputStream(new FileOutputStream(file2));
            try {
                dataoutputstream.writeLong(this.field_1018_G);
            }
            finally {
                dataoutputstream.close();
            }
            dataoutputstream.close();
        }
        catch (IOException ioexception) {
            throw new RuntimeException("Failed to check session lock, aborting");
        }
        final File file3 = new File(this.worldFolder, "level.dat");
        this.isNewWorld = !file3.exists();
        if (file3.exists()) {
            try {
                final FileInputStream fis = new FileInputStream(file3);
                final NBTTagCompound nbttagcompound = CompressedStreamTools.func_1138_a(fis);
                final NBTTagCompound nbttagcompound2 = nbttagcompound.getCompoundTag("Data");
                this.randomSeed = nbttagcompound2.getLong("RandomSeed");
                this.spawnX = nbttagcompound2.getInteger("SpawnX");
                this.spawnY = nbttagcompound2.getInteger("SpawnY");
                this.spawnZ = nbttagcompound2.getInteger("SpawnZ");
                this.worldTime = nbttagcompound2.getLong("Time");
                this.sizeOnDisk = nbttagcompound2.getLong("SizeOnDisk");
                this.snowCovered = nbttagcompound2.getBoolean("SnowCovered");
                this.cheatsDisabled = nbttagcompound2.getBoolean("cheatsDisabled");
                if (nbttagcompound2.getBoolean("isFloating")) {
                    this.worldType = 1;
                }
                else {
                    this.worldType = nbttagcompound2.getInteger("WorldType");
                }
                if (nbttagcompound2.hasKey("Player")) {
                    this.nbtCompoundPlayer = nbttagcompound2.getCompoundTag("Player");
                }
                fis.close();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        boolean flag = false;
        if (this.randomSeed == 0L) {
            this.randomSeed = l;
            flag = true;
        }
        this.chunkProvider = this.getWorldChunkProvider(this.worldFolder);
        if (flag) {
            this.findingSpawnPoint = true;
            this.spawnX = 0;
            this.spawnY = 64;
            this.spawnZ = 0;
            while (!this.isThisBlockSpawnable(this.spawnX, this.spawnZ)) {
                this.spawnX += this.rand.nextInt(64) - this.rand.nextInt(64);
                this.spawnZ += this.rand.nextInt(64) - this.rand.nextInt(64);
            }
            this.findingSpawnPoint = false;
        }
        this.func_644_f();
    }
    
    protected IChunkProvider getWorldChunkProvider(final File file) {
        if (this.worldType == 1) {
            return new ChunkProviderLoadOrGenerate(this, new ChunkLoader(file, true), new ChunkProviderSky(this, this.randomSeed));
        }
        if (this.worldType == 2) {
            return new ChunkProviderLoadOrGenerate(this, new ChunkLoader(file, true), new ChunkProviderCorruption(this, this.randomSeed));
        }
        if (this.worldType == 3) {
            return new ChunkProviderLoadOrGenerate(this, new ChunkLoader(file, true), new ChunkProviderDesert(this, this.randomSeed));
        }
        if (this.worldType == 4) {
            return new ChunkProviderLoadOrGenerate(this, new ChunkLoader(file, true), new ChunkProviderIndev(this, this.randomSeed));
        }
        return new ChunkProviderLoadOrGenerate(this, new ChunkLoader(file, true), new ChunkProviderGenerate(this, this.randomSeed));
    }
    
    public void func_622_a() {
        if (this.spawnY <= 0) {
            this.spawnY = 64;
        }
        while (this.getLowestSpawnableBlock(this.spawnX, this.spawnZ) == 0) {
            this.spawnX += this.rand.nextInt(8) - this.rand.nextInt(8);
            this.spawnZ += this.rand.nextInt(8) - this.rand.nextInt(8);
        }
    }
    
    public void setSpawnLocation() {
        if (this.spawnY <= 0) {
            this.spawnY = 64;
        }
        int i;
        int j;
        for (i = this.spawnX, j = this.spawnZ; this.getFirstUncoveredBlock(i, j) == 0; i += this.rand.nextInt(8) - this.rand.nextInt(8), j += this.rand.nextInt(8) - this.rand.nextInt(8)) {}
        this.spawnX = i;
        this.spawnZ = j;
    }
    
    public int getFirstUncoveredBlock(final int i, final int j) {
        int k;
        for (k = 63; !this.isAirBlock(i, k + 1, j); ++k) {}
        return this.getBlockId(i, k, j);
    }
    
    private boolean isThisBlockSpawnable(final int x, final int z) {
        final int k = this.getLowestSpawnableBlock(x, z);
        if (this.worldType == 1 || this.worldType == 2 || this.worldType == 3) {
            return k == Block.grass.blockID;
        }
        return k == Block.sand.blockID;
    }
    
    private int getLowestSpawnableBlock(final int x, final int z) {
        int k;
        for (k = 63; this.getBlockId(x, k + 1, z) != 0; ++k) {}
        return this.getBlockId(x, k, z);
    }
    
    public void spawnPlayerWithLoadedChunks(final EntityPlayer entityplayer) {
        try {
            if (this.nbtCompoundPlayer != null) {
                entityplayer.readFromNBT(this.nbtCompoundPlayer);
                this.nbtCompoundPlayer = null;
            }
            this.entityJoinedWorld(entityplayer);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    public void saveAllChunks(final boolean flag, final IProgressUpdate iprogressupdate) {
        if (!this.chunkProvider.canSave()) {
            return;
        }
        if (iprogressupdate != null) {
            iprogressupdate.func_594_b("Saving level");
        }
        this.loadWorldSaveInfo();
        if (iprogressupdate != null) {
            iprogressupdate.func_595_d("Saving chunks");
        }
        this.chunkProvider.saveChunks(flag, iprogressupdate);
        if (iprogressupdate != null) {
            RegionFileCache.clear();
        }
    }
    
    public void setSpawn(final int x, final int y, final int z) {
        this.spawnX = x;
        this.spawnY = y;
        this.spawnZ = z;
    }
    
    private void loadWorldSaveInfo() {
        this.checkSessionLock();
        final File getName = new File(this.worldFolder, "name.data");
        String lvlName = "New World";
        if (getName.exists()) {
            try {
                final BufferedReader br = new BufferedReader(new FileReader(getName));
                lvlName = br.readLine().replace("\u0000", "");
                br.close();
            }
            catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            catch (IOException e2) {
                e2.printStackTrace();
            }
        }
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        nbttagcompound.setLong("RandomSeed", this.randomSeed);
        nbttagcompound.setString("LevelName", lvlName);
        nbttagcompound.setInteger("SpawnX", this.spawnX);
        nbttagcompound.setInteger("SpawnY", this.spawnY);
        nbttagcompound.setInteger("SpawnZ", this.spawnZ);
        nbttagcompound.setLong("Time", this.worldTime);
        nbttagcompound.setLong("SizeOnDisk", this.sizeOnDisk);
        nbttagcompound.setBool("SnowCovered", this.snowCovered);
        nbttagcompound.setBool("cheatsDisabled", this.cheatsDisabled);
        nbttagcompound.setInteger("WorldType", this.worldType);
        nbttagcompound.setLong("LastPlayed", System.currentTimeMillis());
        EntityPlayer entityplayer = null;
        if (this.playerEntities.size() > 0) {
            entityplayer = this.playerEntities.get(0);
        }
        if (entityplayer != null) {
            final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
            entityplayer.writeToNBT(nbttagcompound2);
            nbttagcompound.func_763_a("Player", nbttagcompound2);
        }
        final NBTTagCompound nbttagcompound3 = new NBTTagCompound();
        nbttagcompound3.func_762_a("Data", nbttagcompound);
        try {
            final File file = new File(this.worldFolder, "level.dat_new");
            final File file2 = new File(this.worldFolder, "level.dat_old");
            final File file3 = new File(this.worldFolder, "level.dat");
            final FileOutputStream fos = new FileOutputStream(file);
            CompressedStreamTools.writeGzippedCompoundToOutputStream(nbttagcompound3, fos);
            if (file2.exists()) {
                file2.delete();
            }
            file3.renameTo(file2);
            if (file3.exists()) {
                file3.delete();
            }
            file.renameTo(file3);
            if (file.exists()) {
                file.delete();
            }
            fos.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    public boolean func_650_a(final int i) {
        if (!this.chunkProvider.canSave()) {
            return true;
        }
        if (i == 0) {
            this.loadWorldSaveInfo();
        }
        return this.chunkProvider.saveChunks(false, null);
    }
    
    public int getBlockId(final int x, final int y, final int z) {
        if (x < -32000000 || z < -32000000 || x >= 32000000 || z > 32000000 || y < 0 || y >= 128) {
            return 0;
        }
        return this.getChunkFromChunkCoords(x >> 4, z >> 4).getBlockId(x & 0xF, y, z & 0xF);
    }
    
    public ArrayList<Vec3D> getBlockConnectedGears(final int i, final int j, final int k) {
        final ArrayList<Vec3D> gears = new ArrayList<Vec3D>();
        if (this.getBlockId(i - 1, j, k) == Block.gear.blockID) {
            gears.add(Vec3D.createVectorHelper(i - 1, j, k));
            this.notifyBlockChange(i - 1, j, k, 0);
        }
        if (this.getBlockId(i + 1, j, k) == Block.gear.blockID) {
            gears.add(Vec3D.createVectorHelper(i + 1, j, k));
            this.notifyBlockChange(i - 1, j, k, 0);
        }
        if (this.getBlockId(i, j, k - 1) == Block.gear.blockID) {
            gears.add(Vec3D.createVectorHelper(i, j, k - 1));
            this.notifyBlockChange(i - 1, j, k, 0);
        }
        if (this.getBlockId(i, j, k + 1) == Block.gear.blockID) {
            gears.add(Vec3D.createVectorHelper(i, j, k + 1));
            this.notifyBlockChange(i - 1, j, k, 0);
        }
        return gears;
    }
    
    public boolean isSolidBlockTowardDirection(final int posX, final int posY, final int posZ, final int dirX, final int dirZ) {
        return this.isBlockNormalCube(posX + dirX, posY, posZ + dirZ);
    }
    
    public int getGearPower(final int x, final int y, final int z) {
        final TileEntity gearEntity = this.getBlockTileEntity(x, y, z);
        if (gearEntity != null && gearEntity instanceof TileEntityGear) {
            return ((TileEntityGear)gearEntity).getGearPower();
        }
        return 0;
    }
    
    public int getGearTextureIndex(final int x, final int y, final int z) {
        final int power = this.getGearPower(x, y, z);
        if (power > 0) {
            return 78;
        }
        return 62;
    }
    
    public ArrayList<Vec3D> getGearConnectedGears(final int i, final int j, final int k) {
        final ArrayList<Vec3D> gears = new ArrayList<Vec3D>();
        return gears;
    }
    
    public void addToGearList(final TileEntityGear origin, final TileEntityGear toAdd) {
        this.gearListCleanup();
        if (toAdd != null && !toAdd.isInGroup) {
            if (this.gearGroups.size() <= 1) {
                this.gearGroups.add(new GearGroup(this));
            }
            for (int i = 0; i < this.gearGroups.size() - 1; ++i) {
                if (this.gearGroups.get(i).hasGear(origin) && !this.gearGroups.get(i).hasGear(toAdd)) {
                    this.gearGroups.get(i).addToGearGroup(toAdd);
                }
                else if (!this.gearGroups.get(i).hasGear(origin)) {
                    this.gearGroups.add(new GearGroup(this));
                    this.gearGroups.get(this.gearGroups.size() - 1).addToGearGroup(origin);
                    this.gearGroups.get(this.gearGroups.size() - 1).addToGearGroup(toAdd);
                }
            }
            toAdd.isInGroup = true;
        }
    }
    
    public GearGroup getGearGroupFromGear(final TileEntityGear reference) {
        this.gearListCleanup();
        if (reference == null) {
            return null;
        }
        if (this.gearGroups.size() <= 1) {
            this.gearGroups.add(new GearGroup(this));
            this.gearGroups.get(0).addToGearGroup(reference);
            return this.gearGroups.get(0);
        }
        for (int i = 0; i < this.gearGroups.size(); ++i) {
            if (this.gearGroups.get(i).hasGear(reference)) {
                return this.gearGroups.get(i);
            }
        }
        this.gearGroups.add(new GearGroup(this));
        this.gearGroups.get(this.gearGroups.size() - 1).addToGearGroup(reference);
        return this.gearGroups.get(this.gearGroups.size() - 1);
    }
    
    public void addToGearList(final TileEntityGear toAdd) {
        if (toAdd != null) {
            if (this.gearGroups.size() <= 1) {
                this.gearGroups.add(new GearGroup(this));
            }
            final ArrayList<GearGroup> groups = new ArrayList<GearGroup>();
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x + 1, toAdd.y, toAdd.z)));
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x - 1, toAdd.y, toAdd.z)));
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x, toAdd.y + 1, toAdd.z)));
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x, toAdd.y - 1, toAdd.z)));
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x, toAdd.y, toAdd.z + 1)));
            groups.add(this.getGearGroupFromGear(this.getGearAt(toAdd.x, toAdd.y, toAdd.z - 1)));
            final ArrayList<GearGroup> filteredGroup = new ArrayList<GearGroup>();
            for (int i = 0; i < groups.size(); ++i) {
                if (groups.get(i) != null) {
                    filteredGroup.add(groups.get(i));
                }
            }
            if (filteredGroup.size() != 0) {
                for (int i = 0; i < filteredGroup.size(); ++i) {
                    if (filteredGroup.size() > 3) {
                        filteredGroup.get(0).mergeGroup(filteredGroup.get(1));
                        filteredGroup.remove(1);
                    }
                }
                System.out.println(filteredGroup.size());
                filteredGroup.get(0).addToGearGroup(toAdd);
            }
            else {
                final GearGroup groupNew = new GearGroup(this);
                groupNew.addToGearGroup(toAdd);
                this.gearGroups.add(groupNew);
            }
            toAdd.isInGroup = true;
        }
    }
    
    public void removeFromGearList(final TileEntityGear toRemove) {
        if (toRemove != null) {
            for (int i = 0; i < this.gearGroups.size(); ++i) {
                if (this.gearGroups.get(i).hasGear(toRemove)) {
                    this.gearGroups.get(i).removeFromGearGroup(toRemove);
                }
            }
            toRemove.isInGroup = false;
        }
        this.gearListCleanup();
    }
    
    public void gearListCleanup() {
        for (int i = 0; i < this.gearGroups.size(); ++i) {
            if (this.gearGroups.get(i).getGearGroupSize() == 0) {
                this.gearGroups.remove(i);
            }
        }
    }
    
    public boolean applyGearPower(final TileEntityGear powered, final int amount) {
        this.gearListCleanup();
        System.out.println("APPLYING " + powered);
        if (powered != null) {
            for (int i = 0; i < this.gearGroups.size() - 1; ++i) {
                System.out.println(this.gearGroups.get(i));
                if (this.gearGroups.get(i).hasGear(powered)) {
                    this.gearGroups.get(i).setLimit(amount);
                    return this.gearGroups.get(i).powerGearCache();
                }
                this.addToGearList(null, powered);
            }
        }
        return false;
    }
    
    public boolean removeGearPower(final TileEntityGear powered, final int amount) {
        this.gearListCleanup();
        System.out.println("REMOVING " + powered);
        if (powered != null) {
            for (int i = 0; i < this.gearGroups.size() - 1; ++i) {
                System.out.println(this.gearGroups.get(i));
                if (this.gearGroups.get(i).hasGear(powered)) {
                    this.gearGroups.get(i).setLimit(0);
                    return this.gearGroups.get(i).unPowerGearCache();
                }
                this.addToGearList(null, powered);
            }
        }
        return false;
    }
    
    public boolean checkGearPower(final TileEntityGear toCheck) {
        this.gearListCleanup();
        if (toCheck != null) {
            for (int i = 0; i < this.gearGroups.size() - 1; ++i) {
                if (this.gearGroups.get(i).hasGear(toCheck)) {
                    return this.gearGroups.get(i).checkPowered();
                }
            }
        }
        return false;
    }
    
    public TileEntityGear getGearAt(final int x, final int y, final int z) {
        final TileEntity entity = this.getBlockTileEntity(x, y, z);
        TileEntityGear gearEntity = null;
        if (entity instanceof TileEntityGear) {
            gearEntity = (TileEntityGear)entity;
        }
        return gearEntity;
    }
    
    public boolean blockExists(final int i, final int j, final int k) {
        return j >= 0 && j < 128 && this.chunkExists(i >> 4, k >> 4);
    }
    
    public boolean doChunksNearChunkExist(final int i, final int j, final int k, final int l) {
        return this.checkChunksExist(i - l, j - l, k - l, i + l, j + l, k + l);
    }
    
    public boolean checkChunksExist(int i, int j, int k, int l, int i1, int j1) {
        if (i1 < 0 || j >= 128) {
            return false;
        }
        i >>= 4;
        j >>= 4;
        k >>= 4;
        l >>= 4;
        i1 >>= 4;
        j1 >>= 4;
        for (int k2 = i; k2 <= l; ++k2) {
            for (int l2 = k; l2 <= j1; ++l2) {
                if (!this.chunkExists(k2, l2)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private boolean chunkExists(final int i, final int j) {
        return this.chunkProvider.chunkExists(i, j);
    }
    
    public Chunk getChunkFromBlockCoords(final int i, final int j) {
        return this.getChunkFromChunkCoords(i >> 4, j >> 4);
    }
    
    public Chunk getChunkFromChunkCoords(final int i, final int j) {
        return this.chunkProvider.provideChunk(i, j);
    }
    
    public boolean setBlockAndMetadata(final int i, final int j, final int k, final int l, final int i1) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        return chunk.setBlockIDWithMetadata(i & 0xF, j, k & 0xF, l, i1);
    }
    
    public boolean setBlock(final int i, final int j, final int k, final int l) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        return chunk.setBlockID(i & 0xF, j, k & 0xF, l);
    }
    
    public Material getMaterialXYZ(final int i, final int j, final int k) {
        final int l = this.getBlockId(i, j, k);
        if (l == 0) {
            return Material.air;
        }
        return Block.allBlocks[l].blockMaterial;
    }
    
    public boolean isTouchingAir(final int x, final int y, final int z) {
        return this.getBlockId(x - 1, y, z) == 0 || this.getBlockId(x + 1, y, z) == 0 || this.getBlockId(x, y - 1, z) == 0 || this.getBlockId(x, y + 1, z) == 0 || this.getBlockId(x, y, z - 1) == 0 || this.getBlockId(x, y, z + 1) == 0;
    }
    
    public boolean isAirBlock(final int i, final int j, final int k) {
        final int l = this.getBlockId(i, j, k);
        return l == 0;
    }
    
    public int getBlockMetadata(int i, final int j, int k) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return 0;
        }
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            return 0;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.getBlockMetadata(i, j, k);
    }
    
    public void setBlockMetadataWithNotify(final int i, final int j, final int k, final int l) {
        this.setBlockMetadata(i, j, k, l);
        this.notifyBlockChange(i, j, k, l);
    }
    
    public boolean setBlockMetadata(int i, final int j, int k, final int l) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        chunk.setBlockMetadata(i, j, k, l);
        return true;
    }
    
    public boolean setBlockWithNotify(final int i, final int j, final int k, final int l) {
        if (this.setBlock(i, j, k, l)) {
            this.notifyBlockChange(i, j, k, l);
            return true;
        }
        return false;
    }
    
    public boolean setBlockAndMetadataWithNotify(final int i, final int j, final int k, final int l, final int i1) {
        if (this.setBlockAndMetadata(i, j, k, l, i1)) {
            this.notifyBlockChange(i, j, k, l);
            return true;
        }
        return false;
    }
    
    public void markBlockNeedsUpdate(final int i, final int j, final int k) {
        for (int l = 0; l < this.worldAccesses.size(); ++l) {
            this.worldAccesses.get(l).func_934_a(i, j, k);
        }
    }
    
    protected void notifyBlockChange(final int i, final int j, final int k, final int l) {
        this.markBlockNeedsUpdate(i, j, k);
        this.notifyBlocksOfNeighborChange(i, j, k, l);
    }
    
    public void markBlocksDirtyVertical(final int i, final int j, int k, int l) {
        if (k > l) {
            final int i2 = l;
            l = k;
            k = i2;
        }
        this.markBlocksDirty(i, k, j, i, l, j);
    }
    
    public void markBlocksDirty(final int i, final int j, final int k, final int l, final int i1, final int j1) {
        for (int k2 = 0; k2 < this.worldAccesses.size(); ++k2) {
            this.worldAccesses.get(k2).markBlockRangeNeedsUpdate(i, j, k, l, i1, j1);
        }
    }
    
    public void notifyBlocksOfNeighborChange(final int i, final int j, final int k, final int l) {
        this.notifyBlockOfNeighborChange(i - 1, j, k, l);
        this.notifyBlockOfNeighborChange(i + 1, j, k, l);
        this.notifyBlockOfNeighborChange(i, j - 1, k, l);
        this.notifyBlockOfNeighborChange(i, j + 1, k, l);
        this.notifyBlockOfNeighborChange(i, j, k - 1, l);
        this.notifyBlockOfNeighborChange(i, j, k + 1, l);
    }
    
    private void notifyBlockOfNeighborChange(final int i, final int j, final int k, final int l) {
        if (this.etitingBlocks || this.multiplayerWorld) {
            return;
        }
        final Block block = Block.allBlocks[this.getBlockId(i, j, k)];
        if (block != null) {
            block.onNeighborBlockChange(this, i, j, k, l);
        }
    }
    
    public boolean func_647_i(final int i, final int j, final int k) {
        return this.getChunkFromChunkCoords(i >> 4, k >> 4).canBlockSeeTheSky(i & 0xF, j, k & 0xF);
    }
    
    public int getBlockLightValue(final int i, final int j, final int k) {
        return this.func_699_a(i, j, k, true);
    }
    
    public int func_699_a(int i, final int j, int k, final boolean flag) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return 15;
        }
        if (flag) {
            final int l = this.getBlockId(i, j, k);
            if (l == Block.stairSingle.blockID || l == Block.tilledField.blockID) {
                int j2 = this.func_699_a(i, j + 1, k, false);
                final int k2 = this.func_699_a(i + 1, j, k, false);
                final int l2 = this.func_699_a(i - 1, j, k, false);
                final int i2 = this.func_699_a(i, j, k + 1, false);
                final int j3 = this.func_699_a(i, j, k - 1, false);
                if (k2 > j2) {
                    j2 = k2;
                }
                if (l2 > j2) {
                    j2 = l2;
                }
                if (i2 > j2) {
                    j2 = i2;
                }
                if (j3 > j2) {
                    j2 = j3;
                }
                return j2;
            }
        }
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            int i3 = 15 - this.skyLightSubtracted;
            if (i3 < 0) {
                i3 = 0;
            }
            return i3;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.getBlockLightValue(i, j, k, this.skyLightSubtracted);
    }
    
    public boolean func_708_k(int i, final int j, int k) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return true;
        }
        if (!this.chunkExists(i >> 4, k >> 4)) {
            return false;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.canBlockSeeTheSky(i, j, k);
    }
    
    public int getHeightValue(final int i, final int j) {
        if (i < -32000000 || j < -32000000 || i >= 32000000 || j > 32000000) {
            return 0;
        }
        if (!this.chunkExists(i >> 4, j >> 4)) {
            return 0;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, j >> 4);
        return chunk.getHeightValue(i & 0xF, j & 0xF);
    }
    
    public void func_631_a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, int l) {
        if (!this.blockExists(i, j, k)) {
            return;
        }
        if (enumskyblock == EnumSkyBlock.Sky) {
            if (this.func_708_k(i, j, k)) {
                l = 15;
            }
        }
        else if (enumskyblock == EnumSkyBlock.Block) {
            final int i2 = this.getBlockId(i, j, k);
            if (Block.lightValue[i2] > l) {
                l = Block.lightValue[i2];
            }
        }
        if (this.getBlockLighting(enumskyblock, i, j, k) != l) {
            this.scheduleLightingUpdate(enumskyblock, i, j, k, i, j, k);
        }
    }
    
    public int getBlockLighting(final EnumSkyBlock enumskyblock, final int i, final int j, final int k) {
        if (j < 0 || j >= 128 || i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return enumskyblock.field_1722_c;
        }
        final int l = i >> 4;
        final int i2 = k >> 4;
        if (!this.chunkExists(l, i2)) {
            return 0;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(l, i2);
        return chunk.getSavedLightValue(enumskyblock, i & 0xF, j, k & 0xF);
    }
    
    public void func_664_b(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return;
        }
        if (j < 0) {
            return;
        }
        if (j >= 128) {
            return;
        }
        if (!this.chunkExists(i >> 4, k >> 4)) {
            return;
        }
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        chunk.setLightValue(enumskyblock, i & 0xF, j, k & 0xF, l);
        for (int i2 = 0; i2 < this.worldAccesses.size(); ++i2) {
            this.worldAccesses.get(i2).func_934_a(i, j, k);
        }
    }
    
    public float getBrightness(final int i, final int j, final int k) {
        return World.field_1042_i[this.getBlockLightValue(i, j, k)];
    }
    
    public boolean func_624_b() {
        return this.skyLightSubtracted < 4;
    }
    
    public MovingObjectPosition rayTraceBlocks(final Vec3D vec3d, final Vec3D vec3d1) {
        return this.rayTraceBlocks_do(vec3d, vec3d1, false);
    }
    
    public MovingObjectPosition rayTraceBlocks_do(final Vec3D vec3d, final Vec3D vec3d1, final boolean flag) {
        if (Double.isNaN(vec3d.xCoord) || Double.isNaN(vec3d.yCoord) || Double.isNaN(vec3d.zCoord)) {
            return null;
        }
        if (Double.isNaN(vec3d1.xCoord) || Double.isNaN(vec3d1.yCoord) || Double.isNaN(vec3d1.zCoord)) {
            return null;
        }
        final int i = MathHelper.floor_double(vec3d1.xCoord);
        final int j = MathHelper.floor_double(vec3d1.yCoord);
        final int k = MathHelper.floor_double(vec3d1.zCoord);
        int l = MathHelper.floor_double(vec3d.xCoord);
        int i2 = MathHelper.floor_double(vec3d.yCoord);
        int j2 = MathHelper.floor_double(vec3d.zCoord);
        int k2 = 20;
        while (k2-- >= 0) {
            if (Double.isNaN(vec3d.xCoord) || Double.isNaN(vec3d.yCoord) || Double.isNaN(vec3d.zCoord)) {
                return null;
            }
            if (l == i && i2 == j && j2 == k) {
                return null;
            }
            double d = 999.0;
            double d2 = 999.0;
            double d3 = 999.0;
            if (i > l) {
                d = l + 1.0;
            }
            if (i < l) {
                d = l + 0.0;
            }
            if (j > i2) {
                d2 = i2 + 1.0;
            }
            if (j < i2) {
                d2 = i2 + 0.0;
            }
            if (k > j2) {
                d3 = j2 + 1.0;
            }
            if (k < j2) {
                d3 = j2 + 0.0;
            }
            double d4 = 999.0;
            double d5 = 999.0;
            double d6 = 999.0;
            final double d7 = vec3d1.xCoord - vec3d.xCoord;
            final double d8 = vec3d1.yCoord - vec3d.yCoord;
            final double d9 = vec3d1.zCoord - vec3d.zCoord;
            if (d != 999.0) {
                d4 = (d - vec3d.xCoord) / d7;
            }
            if (d2 != 999.0) {
                d5 = (d2 - vec3d.yCoord) / d8;
            }
            if (d3 != 999.0) {
                d6 = (d3 - vec3d.zCoord) / d9;
            }
            byte byte0 = 0;
            if (d4 < d5 && d4 < d6) {
                if (i > l) {
                    byte0 = 4;
                }
                else {
                    byte0 = 5;
                }
                vec3d.xCoord = d;
                vec3d.yCoord += d8 * d4;
                vec3d.zCoord += d9 * d4;
            }
            else if (d5 < d6) {
                if (j > i2) {
                    byte0 = 0;
                }
                else {
                    byte0 = 1;
                }
                vec3d.xCoord += d7 * d5;
                vec3d.yCoord = d2;
                vec3d.zCoord += d9 * d5;
            }
            else {
                if (k > j2) {
                    byte0 = 2;
                }
                else {
                    byte0 = 3;
                }
                vec3d.xCoord += d7 * d6;
                vec3d.yCoord += d8 * d6;
                vec3d.zCoord = d3;
            }
            final Vec3D vector;
            final Vec3D vec3d2 = vector = Vec3D.createVector(vec3d.xCoord, vec3d.yCoord, vec3d.zCoord);
            final double xCoord = MathHelper.floor_double(vec3d.xCoord);
            vector.xCoord = xCoord;
            l = (int)xCoord;
            if (byte0 == 5) {
                --l;
                final Vec3D vec3D = vec3d2;
                ++vec3D.xCoord;
            }
            final Vec3D vec3D2 = vec3d2;
            final double yCoord = MathHelper.floor_double(vec3d.yCoord);
            vec3D2.yCoord = yCoord;
            i2 = (int)yCoord;
            if (byte0 == 1) {
                --i2;
                final Vec3D vec3D3 = vec3d2;
                ++vec3D3.yCoord;
            }
            final Vec3D vec3D4 = vec3d2;
            final double zCoord = MathHelper.floor_double(vec3d.zCoord);
            vec3D4.zCoord = zCoord;
            j2 = (int)zCoord;
            if (byte0 == 3) {
                --j2;
                final Vec3D vec3D5 = vec3d2;
                ++vec3D5.zCoord;
            }
            final int l2 = this.getBlockId(l, i2, j2);
            final int i3 = this.getBlockMetadata(l, i2, j2);
            final Block block = Block.allBlocks[l2];
            if (l2 <= 0 || !block.canCollideCheck(i3, flag)) {
                continue;
            }
            final MovingObjectPosition movingobjectposition = block.collisionRayTrace(this, l, i2, j2, vec3d, vec3d1);
            if (movingobjectposition != null) {
                return movingobjectposition;
            }
        }
        return null;
    }
    
    public void playSoundAtEntity(final Entity entity, final String s, final float f, final float f1) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).makeSound(s, entity.posX, entity.posY - entity.yOffset, entity.posZ, f, f1);
        }
    }
    
    public void playSoundEffect(final double d, final double d1, final double d2, final String s, final float f, final float f1) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).makeSound(s, d, d1, d2, f, f1);
        }
    }
    
    public void playAmbience(final double posX, final double posY, final double posZ, final String soundName, final float volume, final float pitch) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).makeAmbience(soundName, posX, posY, posZ, volume, pitch);
        }
    }
    
    public void updateAmbience(final double posX, final double posY, final double posZ, final String soundName, final float volume, final float pitch) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).updateAmbience(soundName, posX, posY, posZ, volume, pitch);
        }
    }
    
    public boolean isAmbienceEnabled() {
        return this.worldAccesses.get(0).isAmbienceEnabled();
    }
    
    public IWorldAccess getWorldAccess(final int i) {
        return this.worldAccesses.get(i);
    }
    
    public void playRecord(final String s, final int i, final int j, final int k) {
        for (int l = 0; l < this.worldAccesses.size(); ++l) {
            this.worldAccesses.get(l).playRecord(s, i, j, k);
        }
    }
    
    public void spawnParticle(final String s, final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            try {
                this.worldAccesses.get(i).spawnParticle(s, d, d1, d2, d3, d4, d5);
            }
            catch (Exception ex) {
                System.out.println("Tried to render non-existant entity! Left server?");
            }
        }
    }
    
    public boolean addWeatherEffect(final Entity entity) {
        this.weatherEffects.add(entity);
        return true;
    }
    
    public boolean entityJoinedWorld(final Entity entity) {
        final int i = MathHelper.floor_double(entity.posX / 16.0);
        final int j = MathHelper.floor_double(entity.posZ / 16.0);
        boolean flag = false;
        if (entity instanceof EntityPlayer) {
            flag = true;
            if (!this.multiplayerWorld) {
                this.getBlockId(this.spawnX, this.spawnY, this.spawnZ);
                final int blockID = Block.bleedingObsidian.blockID;
            }
        }
        if (flag || this.chunkExists(i, j)) {
            if (entity instanceof EntityPlayer && !this.playerEntities.contains(entity)) {
                this.playerEntities.add((EntityPlayer)entity);
                System.out.println("Player count: " + this.playerEntities.size());
            }
            this.getChunkFromChunkCoords(i, j).addEntity(entity);
            this.loadedEntityList.add(entity);
            this.obtainEntitySkin(entity);
            return true;
        }
        return false;
    }
    
    public void obtainEntitySkin(final Entity entity) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).obtainEntitySkin(entity);
        }
    }
    
    public void releaseEntitySkin(final Entity entity) {
        for (int i = 0; i < this.worldAccesses.size(); ++i) {
            this.worldAccesses.get(i).releaseEntitySkin(entity);
        }
    }
    
    public void setEntityDead(final Entity entity) {
        entity.setEntityDead();
        if (entity instanceof EntityPlayer) {
            this.playerEntities.remove(entity);
            System.out.println("Player count: " + this.playerEntities.size());
        }
    }
    
    public void func_613_a(final IWorldAccess iworldaccess) {
        this.worldAccesses.add(iworldaccess);
    }
    
    public void func_672_b(final IWorldAccess iworldaccess) {
        this.worldAccesses.remove(iworldaccess);
    }
    
    public List<AxisAlignedBB> getCollidingBoundingBoxes(final Entity entity, final AxisAlignedBB axisalignedbb) {
        this.field_1015_J.clear();
        final int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        final int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        final int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = i2; l2 < j2; ++l2) {
                if (this.blockExists(k2, 64, l2)) {
                    for (int i3 = k - 1; i3 < l; ++i3) {
                        final Block block = Block.allBlocks[this.getBlockId(k2, i3, l2)];
                        if (block != null && ((!(entity instanceof EntityItem) && !(entity instanceof EntityGiant)) || block.blockID != Block.leaves.blockID) && (!(entity instanceof EntityGiant) || block.blockID != Block.wood.blockID)) {
                            block.getCollidingBoundingBoxes(this, k2, i3, l2, axisalignedbb, this.field_1015_J);
                        }
                    }
                }
            }
        }
        final double d = 0.25;
        final List<Entity> list = this.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb.expand(d, d, d));
        for (int j3 = 0; j3 < list.size(); ++j3) {
            AxisAlignedBB axisalignedbb2 = list.get(j3).func_372_f_();
            if (axisalignedbb2 != null && axisalignedbb2.intersectsWith(axisalignedbb)) {
                this.field_1015_J.add(axisalignedbb2);
            }
            axisalignedbb2 = entity.getCollisionBox(list.get(j3));
            if (axisalignedbb2 != null && axisalignedbb2.intersectsWith(axisalignedbb)) {
                this.field_1015_J.add(axisalignedbb2);
            }
        }
        return this.field_1015_J;
    }
    
    public int getTimeOfDayBrightness(final float f) {
        final float celestialAngle = this.getCelestialAngle(f);
        float lightNess = 1.0f - (MathHelper.cos(celestialAngle * 3.141593f * 2.0f) * 2.0f + 0.5f);
        if (lightNess < 0.0f) {
            lightNess = 0.0f;
        }
        if (lightNess > 1.0f) {
            lightNess = 1.0f;
        }
        return (int)(lightNess * 11.0f);
    }
    
    public Vec3D func_626_b(final float f) {
        final float f2 = this.getCelestialAngle(f);
        float f3 = MathHelper.cos(f2 * 3.141593f * 2.0f) * 2.0f + 0.5f;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        float f4 = (this.field_1021_D >> 16 & 0xFFL) / 255.0f;
        float f5 = (this.field_1021_D >> 8 & 0xFFL) / 255.0f;
        float f6 = (this.field_1021_D & 0xFFL) / 255.0f;
        f4 *= f3;
        f5 *= f3;
        f6 *= f3;
        return Vec3D.createVector(f4, f5, f6);
    }
    
    public float getCelestialAngle(final float f) {
        final int i = (int)(this.worldTime % 24000L);
        float f2 = (i + f) / 24000.0f - 0.25f;
        if (f2 < 0.0f) {
            ++f2;
        }
        if (f2 > 1.0f) {
            --f2;
        }
        final float f3 = f2;
        f2 = 1.0f - (float)((Math.cos(f2 * 3.141592653589793) + 1.0) / 2.0);
        f2 = f3 + (f2 - f3) / 3.0f;
        return f2;
    }
    
    public Vec3D func_628_d(final float f) {
        final float f2 = this.getCelestialAngle(f);
        float f3 = MathHelper.cos(f2 * 3.141593f * 2.0f) * 2.0f + 0.5f;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        float f4 = (this.field_1019_F >> 16 & 0xFFL) / 255.0f;
        float f5 = (this.field_1019_F >> 8 & 0xFFL) / 255.0f;
        float f6 = (this.field_1019_F & 0xFFL) / 255.0f;
        f4 *= f3 * 0.9f + 0.1f;
        f5 *= f3 * 0.9f + 0.1f;
        f6 *= f3 * 0.85f + 0.15f;
        return Vec3D.createVector(f4, f5, f6);
    }
    
    public Vec3D func_686_e(final float f) {
        final float f2 = this.getCelestialAngle(f);
        float f3 = MathHelper.cos(f2 * 3.141593f * 2.0f) * 2.0f + 0.5f;
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        float f4 = (this.field_1020_E >> 16 & 0xFFL) / 255.0f;
        float f5 = (this.field_1020_E >> 8 & 0xFFL) / 255.0f;
        float f6 = (this.field_1020_E & 0xFFL) / 255.0f;
        f4 *= f3 * 0.94f + 0.06f;
        f5 *= f3 * 0.94f + 0.06f;
        f6 *= f3 * 0.91f + 0.09f;
        return Vec3D.createVector(f4, f5, f6);
    }
    
    public int getTopSolidOrLiquidBlock(int i, int j) {
        final Chunk chunk = this.getChunkFromBlockCoords(i, j);
        int k = 127;
        i &= 0xF;
        j &= 0xF;
        while (k > 0) {
            final int l = chunk.getBlockId(i, k, j);
            if (l != 0 && (Block.allBlocks[l].blockMaterial.blocksMovement() || Block.allBlocks[l].blockMaterial.getIsGroundCover())) {
                return k + 1;
            }
            --k;
        }
        return -1;
    }
    
    public int func_696_e(final int i, final int j) {
        return this.getChunkFromBlockCoords(i, j).getHeightValue(i & 0xF, j & 0xF);
    }
    
    public ChunkCoordinates getSpawnPoint() {
        return new ChunkCoordinates(this.spawnX, this.spawnY, this.spawnZ);
    }
    
    public void setSpawnPoint(final ChunkCoordinates chunkcoordinates) {
        this.spawnX = chunkcoordinates.x;
        this.spawnY = chunkcoordinates.y;
        this.spawnZ = chunkcoordinates.z;
    }
    
    public float func_679_f(final float f) {
        final float f2 = this.getCelestialAngle(f);
        float f3 = 1.0f - (MathHelper.cos(f2 * 3.141593f * 2.0f) * 2.0f + 0.75f);
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        return f3 * f3 * 0.5f;
    }
    
    public void scheduleUpdateTick(final int i, final int j, final int k, final int l) {
        final NextTickListEntry nextticklistentry = new NextTickListEntry(i, j, k, l);
        final byte byte0 = 8;
        if (this.checkChunksExist(i - byte0, j - byte0, k - byte0, i + byte0, j + byte0, k + byte0)) {
            if (l > 0) {
                nextticklistentry.func_900_a(Block.allBlocks[l].tickRate() + this.worldTime);
            }
            if (!this.field_1022_C.contains(nextticklistentry)) {
                this.field_1022_C.add(nextticklistentry);
                this.field_1023_B.add(nextticklistentry);
            }
        }
    }
    
    public void updateEntityList() {
        for (int i = 0; i < this.weatherEffects.size(); ++i) {
            final Entity entity = this.weatherEffects.get(i);
            entity.onUpdate();
            if (entity.isDead) {
                this.weatherEffects.remove(i--);
            }
        }
        this.loadedEntityList.removeAll(this.unloadedEntityList);
        for (int i = 0; i < this.unloadedEntityList.size(); ++i) {
            final Entity entity = this.unloadedEntityList.get(i);
            final int i2 = entity.chunkCoordX;
            final int k1 = entity.chunkCoordZ;
            if (entity.addedToChunk && this.chunkExists(i2, k1)) {
                this.getChunkFromChunkCoords(i2, k1).removeEntity(entity);
            }
        }
        for (int j = 0; j < this.unloadedEntityList.size(); ++j) {
            this.releaseEntitySkin(this.unloadedEntityList.get(j));
        }
        this.unloadedEntityList.clear();
        for (int l = 0; l < this.loadedEntityList.size(); ++l) {
            final Entity entity2 = this.loadedEntityList.get(l);
            if (entity2.entityBeingRidden != null) {
                if (!entity2.entityBeingRidden.isDead && entity2.entityBeingRidden.riddenByEntity == entity2) {
                    continue;
                }
                entity2.entityBeingRidden.riddenByEntity = null;
                entity2.entityBeingRidden = null;
            }
            if (!entity2.isDead) {
                this.updateEntityWithOptionalForce(entity2);
            }
            if (entity2.isDead) {
                final int j2 = entity2.chunkCoordX;
                final int l2 = entity2.chunkCoordZ;
                if (entity2.addedToChunk && this.chunkExists(j2, l2)) {
                    this.getChunkFromChunkCoords(j2, l2).removeEntity(entity2);
                }
                this.loadedEntityList.remove(l--);
                this.releaseEntitySkin(entity2);
            }
        }
        for (int m = 0; m < this.field_1049_b.size(); ++m) {
            final TileEntity tileentity = this.field_1049_b.get(m);
            tileentity.func_475_b();
        }
    }
    
    protected void updateEntityWithOptionalForce(final Entity entity) {
        final int i = MathHelper.floor_double(entity.posX);
        final int j = MathHelper.floor_double(entity.posZ);
        final byte byte0 = 16;
        if (!this.checkChunksExist(i - byte0, 0, j - byte0, i + byte0, 128, j + byte0)) {
            return;
        }
        entity.lastTickPosX = entity.posX;
        entity.lastTickPosY = entity.posY;
        entity.lastTickPosZ = entity.posZ;
        entity.prevRotationYaw = entity.rotationYaw;
        entity.prevRotationPitch = entity.rotationPitch;
        if (entity.entityBeingRidden != null) {
            entity.updateRidden();
        }
        else {
            entity.onUpdate();
        }
        final int k = MathHelper.floor_double(entity.posX / 16.0);
        final int l = MathHelper.floor_double(entity.posY / 16.0);
        final int i2 = MathHelper.floor_double(entity.posZ / 16.0);
        if (!entity.addedToChunk || entity.chunkCoordX != k || entity.chunkCoordY != l || entity.chunkCoordZ != i2) {
            if (entity.addedToChunk && this.chunkExists(entity.chunkCoordX, entity.chunkCoordZ)) {
                this.getChunkFromChunkCoords(entity.chunkCoordX, entity.chunkCoordZ).removeEntityAtIndex(entity, entity.chunkCoordY);
            }
            if (this.chunkExists(k, i2)) {
                this.getChunkFromChunkCoords(k, i2).addEntity(entity);
            }
            else {
                entity.addedToChunk = false;
                System.out.println("Removing entity because it's not in a chunk!!");
                entity.setEntityDead();
            }
        }
        if (entity.riddenByEntity != null) {
            if (entity.riddenByEntity.isDead || entity.riddenByEntity.entityBeingRidden != entity) {
                entity.riddenByEntity.entityBeingRidden = null;
                entity.riddenByEntity = null;
            }
            else {
                this.updateEntityWithOptionalForce(entity.riddenByEntity);
            }
        }
        if (Double.isNaN(entity.posX) || Double.isInfinite(entity.posX)) {
            entity.posX = entity.lastTickPosX;
        }
        if (Double.isNaN(entity.posY) || Double.isInfinite(entity.posY)) {
            entity.posY = entity.lastTickPosY;
        }
        if (Double.isNaN(entity.posZ) || Double.isInfinite(entity.posZ)) {
            entity.posZ = entity.lastTickPosZ;
        }
        if (Double.isNaN(entity.rotationPitch) || Double.isInfinite(entity.rotationPitch)) {
            entity.rotationPitch = entity.prevRotationPitch;
        }
        if (Double.isNaN(entity.rotationYaw) || Double.isInfinite(entity.rotationYaw)) {
            entity.rotationYaw = entity.prevRotationYaw;
        }
    }
    
    public boolean func_604_a(final AxisAlignedBB axisalignedbb) {
        final List<Entity> list = this.getEntitiesWithinAABBExcludingEntity(null, axisalignedbb);
        for (int i = 0; i < list.size(); ++i) {
            final Entity entity = list.get(i);
            if (!entity.isDead && entity.preventEntitySpawning) {
                return false;
            }
        }
        return true;
    }
    
    public boolean getIsAnyLiquid(final AxisAlignedBB axisalignedbb) {
        int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        if (axisalignedbb.minX < 0.0) {
            --i;
        }
        if (axisalignedbb.minY < 0.0) {
            --k;
        }
        if (axisalignedbb.minZ < 0.0) {
            --i2;
        }
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.allBlocks[this.getBlockId(k2, l2, i3)];
                    if (block != null && block.blockMaterial.getIsGroundCover()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean isBoundingBoxBurning(final AxisAlignedBB axisalignedbb) {
        final int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        final int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        final int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final int j3 = this.getBlockId(k2, l2, i3);
                    if (j3 == Block.fire.blockID || j3 == Block.lavaMoving.blockID || j3 == Block.lavaStill.blockID) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean handleMaterialAcceleration(final AxisAlignedBB axisalignedbb, final Material material, final Entity entity) {
        final int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        final int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        final int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        boolean flag = false;
        Vec3D vec3d = Vec3D.createVector(0.0, 0.0, 0.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.allBlocks[this.getBlockId(k2, l2, i3)];
                    if (block != null) {
                        if (block.blockMaterial == material) {
                            final double d1 = l2 + 1 - BlockFluids.getFluidLevel(this.getBlockMetadata(k2, l2, i3));
                            if (l >= d1) {
                                flag = true;
                                block.velocityToAddToEntity(this, k2, l2, i3, entity, vec3d);
                            }
                        }
                    }
                }
            }
        }
        if (vec3d.lengthVector() > 0.0) {
            vec3d = vec3d.normalize();
            final double d2 = 0.004;
            entity.motionX += vec3d.xCoord * d2;
            entity.motionY += vec3d.yCoord * d2;
            entity.motionZ += vec3d.zCoord * d2;
        }
        return flag;
    }
    
    public boolean func_689_a(final AxisAlignedBB axisalignedbb, final Material material) {
        final int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        final int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        final int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.allBlocks[this.getBlockId(k2, l2, i3)];
                    if (block != null && block.blockMaterial == material) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean isAABBInMaterial(final AxisAlignedBB axisalignedbb, final Material material) {
        final int i = MathHelper.floor_double(axisalignedbb.minX);
        final int j = MathHelper.floor_double(axisalignedbb.maxX + 1.0);
        final int k = MathHelper.floor_double(axisalignedbb.minY);
        final int l = MathHelper.floor_double(axisalignedbb.maxY + 1.0);
        final int i2 = MathHelper.floor_double(axisalignedbb.minZ);
        final int j2 = MathHelper.floor_double(axisalignedbb.maxZ + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.allBlocks[this.getBlockId(k2, l2, i3)];
                    if (block != null) {
                        if (block.blockMaterial == material) {
                            final int j3 = this.getBlockMetadata(k2, l2, i3);
                            double d = l2 + 1;
                            if (j3 < 8) {
                                d = l2 + 1 - j3 / 8.0;
                            }
                            if (d >= axisalignedbb.minY) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public void createExplosion(final Entity entity, final double d, final double d1, final double d2, final float f) {
        new Explosion().func_901_a(this, entity, d, d1, d2, f);
    }
    
    public float func_675_a(final Vec3D vec3d, final AxisAlignedBB axisalignedbb) {
        final double d = 1.0 / ((axisalignedbb.maxX - axisalignedbb.minX) * 2.0 + 1.0);
        final double d2 = 1.0 / ((axisalignedbb.maxY - axisalignedbb.minY) * 2.0 + 1.0);
        final double d3 = 1.0 / ((axisalignedbb.maxZ - axisalignedbb.minZ) * 2.0 + 1.0);
        int i = 0;
        int j = 0;
        for (float f = 0.0f; f <= 1.0f; f += (float)d) {
            for (float f2 = 0.0f; f2 <= 1.0f; f2 += (float)d2) {
                for (float f3 = 0.0f; f3 <= 1.0f; f3 += (float)d3) {
                    final double d4 = axisalignedbb.minX + (axisalignedbb.maxX - axisalignedbb.minX) * f;
                    final double d5 = axisalignedbb.minY + (axisalignedbb.maxY - axisalignedbb.minY) * f2;
                    final double d6 = axisalignedbb.minZ + (axisalignedbb.maxZ - axisalignedbb.minZ) * f3;
                    if (this.rayTraceBlocks(Vec3D.createVector(d4, d5, d6), vec3d) == null) {
                        ++i;
                    }
                    ++j;
                }
            }
        }
        return i / (float)j;
    }
    
    public void func_612_i(int i, int j, int k, final int l) {
        if (l == 0) {
            --j;
        }
        if (l == 1) {
            ++j;
        }
        if (l == 2) {
            --k;
        }
        if (l == 3) {
            ++k;
        }
        if (l == 4) {
            --i;
        }
        if (l == 5) {
            ++i;
        }
        if (this.getBlockId(i, j, k) == Block.fire.blockID) {
            this.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "random.fizz", 0.5f, 2.6f + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.8f);
            this.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    public Entity func_661_a(final Class<?> class1) {
        return null;
    }
    
    public String loadedEntites() {
        return "All entities: " + this.loadedEntityList.size();
    }
    
    public TileEntity getBlockTileEntity(final int i, final int j, final int k) {
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        if (chunk != null) {
            return chunk.getChunkBlockTileEntity(i & 0xF, j, k & 0xF);
        }
        return null;
    }
    
    public void func_654_a(final int i, final int j, final int k, final TileEntity tileentity) {
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        if (chunk != null) {
            chunk.setChunkBlockTileEntity(i & 0xF, j, k & 0xF, tileentity);
        }
    }
    
    public void func_692_l(final int i, final int j, final int k) {
        final Chunk chunk = this.getChunkFromChunkCoords(i >> 4, k >> 4);
        if (chunk != null) {
            chunk.removeChunkBlockTileEntity(i & 0xF, j, k & 0xF);
        }
    }
    
    public boolean isBlockNormalCube(final int i, final int j, final int k) {
        final Block block = Block.allBlocks[this.getBlockId(i, j, k)];
        return block != null && block.isOpaqueCube();
    }
    
    public boolean isWater(final int i, final int j, final int k) {
        final Block block = Block.allBlocks[this.getBlockId(i, j, k)];
        return block != null && block.blockMaterial == Material.water;
    }
    
    public void saveWorldIndirectly(final IProgressUpdate iprogressupdate) {
        this.saveAllChunks(true, iprogressupdate);
    }
    
    public boolean updatingLighting() {
        int i = 1000;
        while (this.field_1025_z.size() > 0) {
            if (--i <= 0) {
                return true;
            }
            this.field_1025_z.remove(this.field_1025_z.size() - 1).func_865_a(this);
        }
        return false;
    }
    
    public void scheduleLightingUpdate(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        this.func_627_a(enumskyblock, i, j, k, l, i1, j1, true);
    }
    
    public void func_627_a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l, final int i1, final int j1, final boolean flag) {
        final int k2 = (l + i) / 2;
        final int l2 = (j1 + k) / 2;
        if (!this.blockExists(k2, 64, l2)) {
            return;
        }
        final int i2 = this.field_1025_z.size();
        if (flag) {
            int j2 = 4;
            if (j2 > i2) {
                j2 = i2;
            }
            for (int k3 = 0; k3 < j2; ++k3) {
                final MetadataChunkBlock metadatachunkblock = this.field_1025_z.get(this.field_1025_z.size() - k3 - 1);
                if (metadatachunkblock.field_1299_a == enumskyblock && metadatachunkblock.func_866_a(i, j, k, l, i1, j1)) {
                    return;
                }
            }
        }
        this.field_1025_z.add(new MetadataChunkBlock(enumskyblock, i, j, k, l, i1, j1));
    }
    
    public void func_644_f() {
        final int i = this.getTimeOfDayBrightness(1.0f);
        if (i != this.skyLightSubtracted) {
            this.skyLightSubtracted = i;
        }
    }
    
    public void setSaveInterval(final int interval) {
        this.saveRate = interval * 20 + 40;
    }
    
    public void tick() {
        this.chunkProvider.unload100OldestChunks();
        final int timeOfDayBrightness = this.getTimeOfDayBrightness(1.0f);
        if (timeOfDayBrightness != this.skyLightSubtracted) {
            this.skyLightSubtracted = timeOfDayBrightness;
            for (int j = 0; j < this.worldAccesses.size(); ++j) {
                this.worldAccesses.get(j).updateAllRenderers();
            }
        }
        ++this.worldTime;
        if (this.worldTime % this.saveRate == 0L) {
            this.saveAllChunks(false, null);
        }
        this.tickUpdates(false);
        this.doWorldTick();
    }
    
    protected void doWorldTick() {
        this.setOfTickableChunks.clear();
        for (int i = 0; i < this.playerEntities.size(); ++i) {
            final EntityPlayer entityplayer = this.playerEntities.get(i);
            final int playerPosX = MathHelper.floor_double(entityplayer.posX / 16.0);
            final int playerPosZ = MathHelper.floor_double(entityplayer.posZ / 16.0);
            final byte chunkRadius = 9;
            for (int cX = -chunkRadius; cX <= chunkRadius; ++cX) {
                for (int cZ = -chunkRadius; cZ <= chunkRadius; ++cZ) {
                    this.setOfTickableChunks.add(new ChunkCoordIntPair(cX + playerPosX, cZ + playerPosZ));
                }
            }
        }
        if (this.ambienceChance > 0) {
            --this.ambienceChance;
        }
        for (final ChunkCoordIntPair chunkcoordintpair : this.setOfTickableChunks) {
            final int chunkX = chunkcoordintpair.chunkX * 16;
            final int chunkZ = chunkcoordintpair.chunkZ * 16;
            final Chunk chunk = this.getChunkFromChunkCoords(chunkcoordintpair.chunkX, chunkcoordintpair.chunkZ);
            if (this.ambienceChance == 0) {
                this.randomInt = this.randomInt * 3 + this.someOtherNumber;
                final int k1 = this.randomInt >> 2;
                int k2 = k1 & 0xF;
                int j3 = k1 >> 8 & 0xF;
                final int i2 = k1 >> 16 & 0x7F;
                final int l4 = chunk.getBlockId(k2, i2, j3);
                k2 += chunkX;
                j3 += chunkZ;
                if (l4 == 0 && this.getBlockLightValue(k2, i2, j3) <= this.rand.nextInt(8) && this.getBlockLighting(EnumSkyBlock.Sky, k2, i2, j3) <= 0) {
                    final EntityPlayer entityplayer2 = this.getClosestPlayer(k2 + 0.5, i2 + 0.5, j3 + 0.5, 8.0);
                    if (entityplayer2 != null && entityplayer2.getDistanceSq(k2 + 0.5, i2 + 0.5, j3 + 0.5) > 4.0) {
                        this.playSoundEffect(k2 + 0.5, i2 + 0.5, j3 + 0.5, "ambient.cave.cave", 0.7f, 0.8f + this.rand.nextFloat() * 0.2f);
                        this.ambienceChance = this.rand.nextInt(12000) + 6000;
                    }
                }
            }
            if (this.snowCovered && this.rand.nextInt(4) == 0) {
                this.randomInt = this.randomInt * 3 + this.someOtherNumber;
                final int l5 = this.randomInt >> 2;
                final int l6 = l5 & 0xF;
                final int k3 = l5 >> 8 & 0xF;
                final int j4 = this.getTopSolidOrLiquidBlock(l6 + chunkX, k3 + chunkZ);
                if (j4 >= 0 && j4 < 128 && chunk.getSavedLightValue(EnumSkyBlock.Block, l6, j4, k3) < 10) {
                    final int i3 = chunk.getBlockId(l6, j4 - 1, k3);
                    if (chunk.getBlockId(l6, j4, k3) == 0 && Block.snow.canPlace(this, l6 + chunkX, j4, k3 + chunkZ)) {
                        this.setBlockWithNotify(l6 + chunkX, j4, k3 + chunkZ, Block.snow.blockID);
                    }
                    if (i3 == Block.waterStill.blockID && chunk.getBlockMetadata(l6, j4 - 1, k3) == 0) {
                        this.setBlockWithNotify(l6 + chunkX, j4 - 1, k3 + chunkZ, Block.ice.blockID);
                    }
                }
            }
            if (!this.snowCovered && this.rand.nextInt(4) == 0) {
                this.randomInt = this.randomInt * 3 + this.someOtherNumber;
                final int l5 = this.randomInt >> 2;
                final int l6 = l5 & 0xF;
                final int k3 = l5 >> 8 & 0xF;
                final int j4 = this.getTopSolidOrLiquidBlock(l6 + chunkX, k3 + chunkZ);
                if (j4 >= 0 && j4 < 128 && chunk.getSavedLightValue(EnumSkyBlock.Block, l6, j4, k3) < 10) {
                    final int i3 = chunk.getBlockId(l6, j4 - 1, k3);
                    if (chunk.getBlockId(l6, j4, k3) == Block.snow.blockID) {
                        this.setBlockWithNotify(l6 + chunkX, j4, k3 + chunkZ, 0);
                    }
                    if (i3 == Block.ice.blockID && chunk.getBlockMetadata(l6, j4 - 1, k3) == 0) {
                        this.setBlockWithNotify(l6 + chunkX, j4 - 1, k3 + chunkZ, Block.waterStill.blockID);
                    }
                }
            }
            for (int i4 = 0; i4 < this.mc.options.randomTickRate; ++i4) {
                this.randomInt = this.randomInt * 3 + this.someOtherNumber;
                final int i5 = this.randomInt >> 2;
                final int l7 = i5 & 0xF;
                final int k4 = i5 >> 8 & 0xF;
                final int j5 = i5 >> 16 & 0x7F;
                final byte byte1 = chunk.blocks[l7 << 11 | k4 << 7 | j5];
                if (Block.tickOnLoad[byte1]) {
                    Block.allBlocks[byte1].updateTick(this, l7 + chunkX, j5, k4 + chunkZ, this.rand);
                }
            }
        }
    }
    
    public boolean tickUpdates(final boolean flag) {
        int i = this.field_1023_B.size();
        if (i != this.field_1022_C.size()) {
            throw new IllegalStateException("TickNextTick list out of synch");
        }
        if (i > 1000) {
            i = 1000;
        }
        for (int j = 0; j < i; ++j) {
            final NextTickListEntry nextticklistentry = this.field_1023_B.first();
            if (!flag && nextticklistentry.field_1364_e > this.worldTime) {
                break;
            }
            this.field_1023_B.remove(nextticklistentry);
            this.field_1022_C.remove(nextticklistentry);
            final byte byte0 = 8;
            if (this.checkChunksExist(nextticklistentry.field_1361_a - byte0, nextticklistentry.field_1360_b - byte0, nextticklistentry.field_1366_c - byte0, nextticklistentry.field_1361_a + byte0, nextticklistentry.field_1360_b + byte0, nextticklistentry.field_1366_c + byte0)) {
                final int k = this.getBlockId(nextticklistentry.field_1361_a, nextticklistentry.field_1360_b, nextticklistentry.field_1366_c);
                if (k == nextticklistentry.field_1365_d && k > 0) {
                    Block.allBlocks[k].updateTick(this, nextticklistentry.field_1361_a, nextticklistentry.field_1360_b, nextticklistentry.field_1366_c, this.rand);
                }
            }
        }
        return this.field_1023_B.size() != 0;
    }
    
    public void randomDisplayUpdates(final int i, final int j, final int k) {
        final byte byte0 = 16;
        final Random random = new Random();
        for (int l = 0; l < 1000; ++l) {
            final int i2 = i + this.rand.nextInt(byte0) - this.rand.nextInt(byte0);
            final int j2 = j + this.rand.nextInt(byte0) - this.rand.nextInt(byte0);
            final int k2 = k + this.rand.nextInt(byte0) - this.rand.nextInt(byte0);
            final int l2 = this.getBlockId(i2, j2, k2);
            if (l2 > 0) {
                Block.allBlocks[l2].randomDisplayTick(this, i2, j2, k2, random);
            }
        }
    }
    
    public List<Entity> getEntitiesWithinAABBExcludingEntity(final Entity entity, final AxisAlignedBB axisalignedbb) {
        this.field_1012_M.clear();
        final int i = MathHelper.floor_double((axisalignedbb.minX - 2.0) / 16.0);
        final int j = MathHelper.floor_double((axisalignedbb.maxX + 2.0) / 16.0);
        final int k = MathHelper.floor_double((axisalignedbb.minZ - 2.0) / 16.0);
        final int l = MathHelper.floor_double((axisalignedbb.maxZ + 2.0) / 16.0);
        for (int i2 = i; i2 <= j; ++i2) {
            for (int j2 = k; j2 <= l; ++j2) {
                if (this.chunkExists(i2, j2)) {
                    this.getChunkFromChunkCoords(i2, j2).getEntitiesWithinAABBForEntity(entity, axisalignedbb, this.field_1012_M);
                }
            }
        }
        return this.field_1012_M;
    }
    
    public List<Entity> getEntitiesWithinAABB(final Class<?> class1, final AxisAlignedBB axisalignedbb) {
        final int i = MathHelper.floor_double((axisalignedbb.minX - 2.0) / 16.0);
        final int j = MathHelper.floor_double((axisalignedbb.maxX + 2.0) / 16.0);
        final int k = MathHelper.floor_double((axisalignedbb.minZ - 2.0) / 16.0);
        final int l = MathHelper.floor_double((axisalignedbb.maxZ + 2.0) / 16.0);
        final ArrayList<Entity> arraylist = new ArrayList<Entity>();
        for (int i2 = i; i2 <= j; ++i2) {
            for (int j2 = k; j2 <= l; ++j2) {
                if (this.chunkExists(i2, j2)) {
                    this.getChunkFromChunkCoords(i2, j2).getEntitiesOfTypeWithinAAAB(class1, axisalignedbb, arraylist);
                }
            }
        }
        return arraylist;
    }
    
    public List<Entity> getLoadedEntityList() {
        return this.loadedEntityList;
    }
    
    public void cacheTileEntity(final int i, final int j, final int k, final TileEntity tileentity) {
        if (this.blockExists(i, j, k)) {
            this.getChunkFromBlockCoords(i, k).setChunkModified();
        }
        for (int l = 0; l < this.worldAccesses.size(); ++l) {
            this.worldAccesses.get(l).hashTileEntity(i, j, k, tileentity);
        }
    }
    
    public int func_621_b(final Class<?> class1) {
        int i = 0;
        for (int j = 0; j < this.loadedEntityList.size(); ++j) {
            final Entity entity = this.loadedEntityList.get(j);
            if (class1.isAssignableFrom(entity.getClass())) {
                ++i;
            }
        }
        return i;
    }
    
    public void addLoadedEntities(final List<Entity> list) {
        this.loadedEntityList.addAll(list);
        for (int i = 0; i < list.size(); ++i) {
            this.obtainEntitySkin(list.get(i));
        }
    }
    
    public void addUnloadedEntities(final List<Entity> field_1528_m) {
        this.unloadedEntityList.addAll(field_1528_m);
    }
    
    public void func_656_j() {
        while (this.chunkProvider.unload100OldestChunks()) {}
    }
    
    public IChunkProvider getIChunkProvider() {
        return this.chunkProvider;
    }
    
    public boolean func_695_a(final int i, final int j, final int k, final int l, final boolean flag) {
        final int i2 = this.getBlockId(j, k, l);
        final Block block = Block.allBlocks[i2];
        final Block block2 = Block.allBlocks[i];
        AxisAlignedBB axisalignedbb = block2.getCollisionBoundingBoxFromPool(this, j, k, l);
        if (flag) {
            axisalignedbb = null;
        }
        return (axisalignedbb == null || this.func_604_a(axisalignedbb)) && (block == Block.waterMoving || block == Block.waterStill || block == Block.lavaMoving || block == Block.lavaStill || block == Block.fire || block == Block.snow || (i > 0 && block == null && block2.canPlace(this, j, k, l)));
    }
    
    public PathEntity getPathEntityToEntity(final Entity entity, final Entity entity1, final float f) {
        final int i = MathHelper.floor_double(entity.posX);
        final int j = MathHelper.floor_double(entity.posY);
        final int k = MathHelper.floor_double(entity.posZ);
        final int l = (int)(f + 16.0f);
        final int i2 = i - l;
        final int j2 = j - l;
        final int k2 = k - l;
        final int l2 = i + l;
        final int i3 = j + l;
        final int j3 = k + l;
        final ChunkCache chunkcache = new ChunkCache(this, i2, j2, k2, l2, i3, j3);
        return new Pathfinder(chunkcache).createEntityPathTo(entity, entity1, f);
    }
    
    public PathEntity func_637_a(final Entity entity, final int i, final int j, final int k, final float f) {
        final int l = MathHelper.floor_double(entity.posX);
        final int i2 = MathHelper.floor_double(entity.posY);
        final int j2 = MathHelper.floor_double(entity.posZ);
        final int k2 = (int)(f + 8.0f);
        final int l2 = l - k2;
        final int i3 = i2 - k2;
        final int j3 = j2 - k2;
        final int k3 = l + k2;
        final int l3 = i2 + k2;
        final int i4 = j2 + k2;
        final ChunkCache chunkcache = new ChunkCache(this, l2, i3, j3, k3, l3, i4);
        return new Pathfinder(chunkcache).createEntityPathTo(entity, i, j, k, f);
    }
    
    public boolean func_668_j(final int i, final int j, final int k, final int l) {
        final int i2 = this.getBlockId(i, j, k);
        return i2 != 0 && Block.allBlocks[i2].isIndirectlyPoweringTo(this, i, j, k, l);
    }
    
    public boolean func_646_n(final int i, final int j, final int k) {
        return this.func_668_j(i, j - 1, k, 0) || this.func_668_j(i, j + 1, k, 1) || this.func_668_j(i, j, k - 1, 2) || this.func_668_j(i, j, k + 1, 3) || this.func_668_j(i - 1, j, k, 4) || this.func_668_j(i + 1, j, k, 5);
    }
    
    public boolean isBlockIndirectlyProvidingPowerTo(final int i, final int j, final int k, final int l) {
        if (this.getBlockId(i, j, k) == Block.motor.blockID) {
            return true;
        }
        if (this.isBlockNormalCube(i, j, k) && this.getBlockId(i, j, k) != Block.motor.blockID) {
            return this.func_646_n(i, j, k);
        }
        final int i2 = this.getBlockId(i, j, k);
        return i2 != 0 && Block.allBlocks[i2].isPoweringTo(this, i, j, k, l);
    }
    
    public boolean isBlockIndirectlyGettingPowered(final int i, final int j, final int k) {
        return this.isBlockIndirectlyProvidingPowerTo(i, j - 1, k, 0) || this.isBlockIndirectlyProvidingPowerTo(i, j + 1, k, 1) || this.isBlockIndirectlyProvidingPowerTo(i, j, k - 1, 2) || this.isBlockIndirectlyProvidingPowerTo(i, j, k + 1, 3) || this.isBlockIndirectlyProvidingPowerTo(i - 1, j, k, 4) || this.isBlockIndirectlyProvidingPowerTo(i + 1, j, k, 5);
    }
    
    public EntityPlayer getClosestPlayerToEntity(final Entity entity, final double d) {
        return this.getClosestPlayer(entity.posX, entity.posY, entity.posZ, d);
    }
    
    public EntityPlayer getClosestPlayer(final double d, final double d1, final double d2, final double d3) {
        double d4 = -1.0;
        EntityPlayer entityplayer = null;
        for (int i = 0; i < this.playerEntities.size(); ++i) {
            final EntityPlayer entityplayer2 = this.playerEntities.get(i);
            final double d5 = entityplayer2.getDistanceSq(d, d1, d2);
            if ((d3 < 0.0 || d5 < d3 * d3) && (d4 == -1.0 || d5 < d4)) {
                d4 = d5;
                entityplayer = entityplayer2;
            }
        }
        return entityplayer;
    }
    
    public void setChunkData(final int xPos, final int yPos, final int zPos, final int xSize, final int ySize, final int zSize, final byte[] chunk) {
        final int chunkPosXMin = xPos >> 4;
        final int chunkPosZMin = zPos >> 4;
        final int chunkPosXMax = xPos + xSize - 1 >> 4;
        final int chunkPosZMax = zPos + zSize - 1 >> 4;
        int k2 = 0;
        int chunkPosYMin = yPos;
        int chunkPosYMax = yPos + ySize;
        if (chunkPosYMin < 0) {
            chunkPosYMin = 0;
        }
        if (chunkPosYMax > 128) {
            chunkPosYMax = 128;
        }
        for (int xIndex = chunkPosXMin; xIndex <= chunkPosXMax; ++xIndex) {
            int k3 = xPos - xIndex * 16;
            int l3 = xPos + xSize - xIndex * 16;
            if (k3 < 0) {
                k3 = 0;
            }
            if (l3 > 16) {
                l3 = 16;
            }
            for (int zIndex = chunkPosZMin; zIndex <= chunkPosZMax; ++zIndex) {
                int j4 = zPos - zIndex * 16;
                int k4 = zPos + zSize - zIndex * 16;
                if (j4 < 0) {
                    j4 = 0;
                }
                if (k4 > 16) {
                    k4 = 16;
                }
                k2 = this.getChunkFromChunkCoords(xIndex, zIndex).getChunkData(chunk, k3, chunkPosYMin, j4, l3, chunkPosYMax, k4, k2);
                this.markBlocksDirty(xIndex * 16 + k3, chunkPosYMin, zIndex * 16 + j4, xIndex * 16 + l3, chunkPosYMax, zIndex * 16 + k4);
            }
        }
    }
    
    public void sendQuittingDisconnectingPacket() {
    }
    
    public void checkSessionLock() {
        try {
            final File file = new File(this.worldFolder, "session.lock");
            final DataInputStream datainputstream = new DataInputStream(new FileInputStream(file));
            try {
                if (datainputstream.readLong() != this.field_1018_G) {
                    throw new MinecraftException("The save is being accessed from another location, aborting");
                }
            }
            finally {
                datainputstream.close();
            }
            datainputstream.close();
        }
        catch (IOException ioexception) {
            throw new MinecraftException("Failed to check session lock, aborting");
        }
    }
    
    public void setWorldTime(final long l) {
        this.worldTime = l;
    }
    
    public void joinEntityInSurroundings(final Entity entity) {
        final int i = MathHelper.floor_double(entity.posX / 16.0);
        final int j = MathHelper.floor_double(entity.posZ / 16.0);
        final byte byte0 = 2;
        for (int k = i - byte0; k <= i + byte0; ++k) {
            for (int l = j - byte0; l <= j + byte0; ++l) {
                this.getChunkFromChunkCoords(k, l);
            }
        }
        if (!this.loadedEntityList.contains(entity)) {
            System.out.println("REINSERTING PLAYER!");
            this.loadedEntityList.add(entity);
            this.obtainEntitySkin(entity);
        }
    }
    
    public void func_28106_e(final int i, final int j, final int k, final int l, final int i1) {
        this.func_28107_a(null, i, j, k, l, i1);
    }
    
    public void func_28107_a(final EntityPlayer entityplayer, final int i, final int j, final int k, final int l, final int i1) {
        for (int j2 = 0; j2 < this.worldAccesses.size(); ++j2) {
            this.worldAccesses.get(j2).func_28136_a(entityplayer, i, j, k, l, i1);
        }
    }
}
