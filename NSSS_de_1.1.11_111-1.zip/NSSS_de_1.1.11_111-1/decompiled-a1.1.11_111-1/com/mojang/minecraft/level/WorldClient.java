package com.mojang.minecraft.level;

import com.mojang.minecraft.networknew.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.*;
import java.util.*;
import com.mojang.minecraft.render.*;
import java.io.*;
import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.networknew.packet.*;

public class WorldClient extends World
{
    private LinkedList<WorldBlockPositionType> blockPositionTypes;
    private NetClientHandler sendQueue;
    private ChunkProviderClient clientChunkProvider;
    private boolean field_1056_C;
    private MCHashTable field_1055_D;
    private Set<Entity> field_1054_E;
    private Set<Entity> field_1053_F;
    
    public WorldClient(final NetClientHandler netclienthandler, final Minecraft mine) {
        super("MpServer", mine);
        this.blockPositionTypes = new LinkedList<WorldBlockPositionType>();
        this.field_1056_C = false;
        this.field_1055_D = new MCHashTable();
        this.field_1054_E = new HashSet<Entity>();
        this.field_1053_F = new HashSet<Entity>();
        this.sendQueue = netclienthandler;
        this.spawnX = 8;
        this.spawnY = 64;
        this.spawnZ = 8;
        this.mc = mine;
    }
    
    @Override
    public void tick() {
        ++this.worldTime;
        final int i = this.getTimeOfDayBrightness(1.0f);
        if (i != this.skyLightSubtracted) {
            this.skyLightSubtracted = i;
            for (int j = 0; j < this.worldAccesses.size(); ++j) {
                this.worldAccesses.get(j).updateAllRenderers();
            }
        }
        for (int k = 0; k < 10 && !this.field_1053_F.isEmpty(); ++k) {
            final Entity entity = this.field_1053_F.iterator().next();
            this.entityJoinedWorld(entity);
        }
        this.sendQueue.processReadPackets();
        for (int l = 0; l < this.blockPositionTypes.size(); ++l) {
            final WorldBlockPositionType worldBlockPositionType;
            final WorldBlockPositionType worldblockpositiontype = worldBlockPositionType = this.blockPositionTypes.get(l);
            if (--worldBlockPositionType.field_1206_d == 0) {
                super.setBlockAndMetadata(worldblockpositiontype.bPosX, worldblockpositiontype.bPosY, worldblockpositiontype.bPosZ, worldblockpositiontype.field_1205_e, worldblockpositiontype.field_1204_f);
                super.markBlockNeedsUpdate(worldblockpositiontype.bPosX, worldblockpositiontype.bPosY, worldblockpositiontype.bPosZ);
                this.blockPositionTypes.remove(l--);
            }
        }
    }
    
    public void markRangeForUpdate(final int xMin, final int yMin, final int zMin, final int xMax, final int yMax, final int zMax) {
        for (int index = 0; index < this.blockPositionTypes.size(); ++index) {
            final WorldBlockPositionType worldblockpositiontype = this.blockPositionTypes.get(index);
            if (worldblockpositiontype.bPosX >= xMin && worldblockpositiontype.bPosY >= yMin && worldblockpositiontype.bPosZ >= zMin && worldblockpositiontype.bPosX <= xMax && worldblockpositiontype.bPosY <= yMax && worldblockpositiontype.bPosZ <= zMax) {
                this.blockPositionTypes.remove(index--);
            }
        }
    }
    
    @Override
    protected IChunkProvider getWorldChunkProvider(final File file) {
        return this.clientChunkProvider = new ChunkProviderClient(this);
    }
    
    @Override
    public void func_622_a() {
        this.spawnX = 8;
        this.spawnY = 64;
        this.spawnZ = 8;
    }
    
    @Override
    protected void doWorldTick() {
    }
    
    @Override
    public void scheduleUpdateTick(final int i, final int j, final int k, final int l) {
    }
    
    @Override
    public boolean tickUpdates(final boolean flag) {
        return false;
    }
    
    public void doPreChunk(final int x, final int z, final boolean isLoading) {
        if (isLoading) {
            this.clientChunkProvider.prepareChunk(x, z);
        }
        else {
            this.clientChunkProvider.unloadChunk(x, z);
        }
        if (!isLoading) {
            this.markBlocksDirty(x * 16, 0, z * 16, x * 16 + 15, 128, z * 16 + 15);
        }
    }
    
    @Override
    public boolean entityJoinedWorld(final Entity entity) {
        final boolean flag = super.entityJoinedWorld(entity);
        if (entity instanceof EntityPlayerSP) {
            this.field_1054_E.add(entity);
        }
        return flag;
    }
    
    @Override
    public void setEntityDead(final Entity entity) {
        super.setEntityDead(entity);
        if (entity instanceof EntityPlayerSP) {
            this.field_1054_E.remove(entity);
        }
    }
    
    @Override
    public void obtainEntitySkin(final Entity entity) {
        super.obtainEntitySkin(entity);
        if (this.field_1053_F.contains(entity)) {
            this.field_1053_F.remove(entity);
        }
    }
    
    @Override
    public void releaseEntitySkin(final Entity entity) {
        super.releaseEntitySkin(entity);
        if (this.field_1054_E.contains(entity)) {
            this.field_1053_F.add(entity);
        }
    }
    
    public void func_712_a(final int i, final Entity entity) {
        final Entity entity2 = this.func_709_b(i);
        if (entity2 != null) {
            this.setEntityDead(entity2);
        }
        this.field_1054_E.add(entity);
        entity.entityId = i;
        if (!this.entityJoinedWorld(entity)) {
            this.field_1053_F.add(entity);
        }
        this.field_1055_D.addKey(i, entity);
    }
    
    public Entity func_709_b(final int i) {
        return (Entity)this.field_1055_D.func_1057_a(i);
    }
    
    public Entity removeEntityFromWorld(final int i) {
        final Entity entity = (Entity)this.field_1055_D.func_1052_b(i);
        if (entity != null) {
            this.field_1054_E.remove(entity);
            this.setEntityDead(entity);
        }
        return entity;
    }
    
    @Override
    public boolean setBlockMetadata(final int i, final int j, final int k, final int l) {
        final int i2 = this.getBlockId(i, j, k);
        final int j2 = this.getBlockMetadata(i, j, k);
        if (super.setBlockMetadata(i, j, k, l)) {
            this.blockPositionTypes.add(new WorldBlockPositionType(this, i, j, k, i2, j2));
            return true;
        }
        return false;
    }
    
    @Override
    public boolean setBlockAndMetadata(final int i, final int j, final int k, final int l, final int i1) {
        final int j2 = this.getBlockId(i, j, k);
        final int k2 = this.getBlockMetadata(i, j, k);
        if (super.setBlockAndMetadata(i, j, k, l, i1)) {
            this.blockPositionTypes.add(new WorldBlockPositionType(this, i, j, k, j2, k2));
            return true;
        }
        return false;
    }
    
    @Override
    public boolean setBlock(final int i, final int j, final int k, final int l) {
        final int i2 = this.getBlockId(i, j, k);
        final int j2 = this.getBlockMetadata(i, j, k);
        if (super.setBlock(i, j, k, l)) {
            this.blockPositionTypes.add(new WorldBlockPositionType(this, i, j, k, i2, j2));
            return true;
        }
        return false;
    }
    
    public boolean func_714_c(final int i, final int j, final int k, final int l, final int i1) {
        this.markRangeForUpdate(i, j, k, i, j, k);
        if (super.setBlockAndMetadata(i, j, k, l, i1)) {
            this.notifyBlockChange(i, j, k, l);
            return true;
        }
        return false;
    }
    
    @Override
    public void cacheTileEntity(final int i, final int j, final int k, final TileEntity tileentity) {
        if (this.field_1056_C) {
            return;
        }
    }
    
    @Override
    public void sendQuittingDisconnectingPacket() {
        this.sendQueue.addToSendQueue(new Packet255KickDisconnect("Quitting"));
    }
}
