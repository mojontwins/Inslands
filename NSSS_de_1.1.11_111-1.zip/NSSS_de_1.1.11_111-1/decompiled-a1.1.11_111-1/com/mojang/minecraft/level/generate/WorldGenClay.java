package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.util.*;

public class WorldGenClay extends WorldGenerator
{
    private ArrayList<Integer> blockIds;
    private int clayBlockId;
    private int numberOfBlocks;
    
    public WorldGenClay(final int i) {
        this.clayBlockId = Block.blockClay.blockID;
        this.numberOfBlocks = i;
        (this.blockIds = new ArrayList<Integer>()).add(Block.gravel.blockID);
        this.blockIds.add(Block.sand.blockID);
    }
    
    public WorldGenClay(final int i, final int[] b) {
        this.clayBlockId = Block.blockClay.blockID;
        this.numberOfBlocks = i;
        this.blockIds = new ArrayList<Integer>();
        for (int x = 0; x < b.length; ++x) {
            this.blockIds.add(b[x]);
        }
    }
    
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        if (world.getMaterialXYZ(i, j, k) != Material.sand) {
            return false;
        }
        final float f = random.nextFloat() * 3.141593f;
        final double d = i + 8 + MathHelper.sin(f) * this.numberOfBlocks / 8.0f;
        final double d2 = i + 8 - MathHelper.sin(f) * this.numberOfBlocks / 8.0f;
        final double d3 = k + 8 + MathHelper.cos(f) * this.numberOfBlocks / 8.0f;
        final double d4 = k + 8 - MathHelper.cos(f) * this.numberOfBlocks / 8.0f;
        final double d5 = j + random.nextInt(3) + 2;
        final double d6 = j + random.nextInt(3) + 2;
        for (int l = 0; l <= this.numberOfBlocks; ++l) {
            final double d7 = d + (d2 - d) * l / this.numberOfBlocks;
            final double d8 = d5 + (d6 - d5) * l / this.numberOfBlocks;
            final double d9 = d3 + (d4 - d3) * l / this.numberOfBlocks;
            final double d10 = random.nextDouble() * this.numberOfBlocks / 16.0;
            final double d11 = (MathHelper.sin(l * 3.141593f / this.numberOfBlocks) + 1.0f) * d10 + 1.0;
            final double d12 = (MathHelper.sin(l * 3.141593f / this.numberOfBlocks) + 1.0f) * d10 + 1.0;
            for (double i2 = d7 - d11 / 2.0; i2 <= d7 + d11 / 2.0; ++i2) {
                for (double j2 = d8 - d12 / 2.0; j2 <= d8 + d12 / 2.0; ++j2) {
                    for (double k2 = d9 - d11 / 2.0; k2 <= d9 + d11 / 2.0; ++k2) {
                        final double d13 = (Math.floor(i2) + 0.5 - d7) / (d11 / 2.0);
                        final double d14 = (Math.floor(j2) + 0.5 - d8) / (d12 / 2.0);
                        final double d15 = (Math.floor(k2) + 0.5 - d9) / (d11 / 2.0);
                        if (d13 * d13 + d14 * d14 + d15 * d15 < 100.0) {
                            final int l2 = world.getBlockId((int)Math.floor(i2), (int)Math.floor(j2), (int)Math.floor(k2));
                            if (this.blockIds.contains(l2)) {
                                world.setBlock((int)Math.floor(i2), (int)Math.floor(j2), (int)Math.floor(k2), this.clayBlockId);
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
}
