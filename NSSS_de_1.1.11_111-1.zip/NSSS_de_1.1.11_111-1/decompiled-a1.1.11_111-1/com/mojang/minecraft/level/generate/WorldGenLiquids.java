package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenLiquids extends WorldGenerator
{
    private int field_865_a;
    
    public WorldGenLiquids(final int i) {
        this.field_865_a = i;
    }
    
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        if (world.getBlockId(i, j + 1, k) != Block.stone.blockID) {
            return false;
        }
        if (world.getBlockId(i, j - 1, k) != Block.stone.blockID) {
            return false;
        }
        if (world.getBlockId(i, j, k) != 0 && world.getBlockId(i, j, k) != Block.stone.blockID) {
            return false;
        }
        int l = 0;
        if (world.getBlockId(i - 1, j, k) == Block.stone.blockID) {
            ++l;
        }
        if (world.getBlockId(i + 1, j, k) == Block.stone.blockID) {
            ++l;
        }
        if (world.getBlockId(i, j, k - 1) == Block.stone.blockID) {
            ++l;
        }
        if (world.getBlockId(i, j, k + 1) == Block.stone.blockID) {
            ++l;
        }
        int i2 = 0;
        if (world.getBlockId(i - 1, j, k) == 0) {
            ++i2;
        }
        if (world.getBlockId(i + 1, j, k) == 0) {
            ++i2;
        }
        if (world.getBlockId(i, j, k - 1) == 0) {
            ++i2;
        }
        if (world.getBlockId(i, j, k + 1) == 0) {
            ++i2;
        }
        if (l == 3 && i2 == 1) {
            world.setBlockWithNotify(i, j, k, this.field_865_a);
        }
        return true;
    }
}
