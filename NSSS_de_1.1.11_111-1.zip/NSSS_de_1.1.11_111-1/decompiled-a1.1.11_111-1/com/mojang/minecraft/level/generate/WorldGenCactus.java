package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenCactus extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        for (int l = 0; l < 10; ++l) {
            final int i2 = i + random.nextInt(8) - random.nextInt(8);
            final int j2 = j + random.nextInt(4) - random.nextInt(4);
            final int k2 = k + random.nextInt(8) - random.nextInt(8);
            if (world.getBlockId(i2, j2, k2) == 0) {
                for (int l2 = 1 + random.nextInt(random.nextInt(3) + 1), i3 = 0; i3 < l2; ++i3) {
                    if (Block.cactus.canBlockStay(world, i2, j2 + i3, k2)) {
                        world.setBlock(i2, j2 + i3, k2, Block.cactus.blockID);
                    }
                }
            }
        }
        return true;
    }
}
