package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.gui.*;

public interface IChunkProvider
{
    boolean chunkExists(final int p0, final int p1);
    
    Chunk provideChunk(final int p0, final int p1);
    
    void generateStructures(final IChunkProvider p0, final int p1, final int p2);
    
    boolean saveChunks(final boolean p0, final IProgressUpdate p1);
    
    boolean unload100OldestChunks();
    
    boolean canSave();
}
