package com.mojang.minecraft.level.generate;

import java.util.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.*;

public class MapGenCaves extends MapGenBase
{
    protected void func_870_a(final int i, final int j, final byte[] abyte0, final double d, final double d1, final double d2) {
        this.func_869_a(i, j, abyte0, d, d1, d2, 1.0f + this.rand.nextFloat() * 6.0f, 0.0f, 0.0f, -1, -1, 0.5);
    }
    
    protected void func_869_a(final int i, final int j, final byte[] abyte0, double d, double d1, double d2, final float f, float f1, float f2, int k, int l, final double d3) {
        final double d4 = i * 16 + 8;
        final double d5 = j * 16 + 8;
        float f3 = 0.0f;
        float f4 = 0.0f;
        final Random random = new Random(this.rand.nextLong());
        if (l <= 0) {
            final int i2 = this.field_1306_a * 16 - 16;
            l = i2 - random.nextInt(i2 / 4);
        }
        boolean flag = false;
        if (k == -1) {
            k = l / 2;
            flag = true;
        }
        final int j2 = random.nextInt(l / 2) + l / 4;
        final boolean flag2 = random.nextInt(6) == 0;
        while (k < l) {
            final double d6 = 1.5 + MathHelper.sin(k * 3.141593f / l) * f * 1.0f;
            final double d7 = d6 * d3;
            final float f5 = MathHelper.cos(f2);
            final float f6 = MathHelper.sin(f2);
            d += MathHelper.cos(f1) * f5;
            d1 += f6;
            d2 += MathHelper.sin(f1) * f5;
            if (flag2) {
                f2 *= 0.92f;
            }
            else {
                f2 *= 0.7f;
            }
            f2 += f4 * 0.1f;
            f1 += f3 * 0.1f;
            f4 *= 0.9f;
            f3 *= 0.75f;
            f4 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 2.0f;
            f3 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 4.0f;
            if (!flag && k == j2 && f > 1.0f) {
                this.func_869_a(i, j, abyte0, d, d1, d2, random.nextFloat() * 0.5f + 0.5f, f1 - 1.570796f, f2 / 3.0f, k, l, 1.0);
                this.func_869_a(i, j, abyte0, d, d1, d2, random.nextFloat() * 0.5f + 0.5f, f1 + 1.570796f, f2 / 3.0f, k, l, 1.0);
                return;
            }
            if (flag || random.nextInt(4) != 0) {
                double d8 = d - d4;
                double d9 = d2 - d5;
                double d10 = l - k;
                final double d11 = f + 2.0f + 16.0f;
                if (d8 * d8 + d9 * d9 - d10 * d10 > d11 * d11) {
                    return;
                }
                if (d >= d4 - 16.0 - d6 * 2.0 && d2 >= d5 - 16.0 - d6 * 2.0 && d <= d4 + 16.0 + d6 * 2.0) {
                    if (d2 <= d5 + 16.0 + d6 * 2.0) {
                        d8 = MathHelper.floor_double(d - d6) - i * 16 - 1;
                        int k2 = MathHelper.floor_double(d + d6) - i * 16 + 1;
                        d9 = MathHelper.floor_double(d1 - d7) - 1;
                        int l2 = MathHelper.floor_double(d1 + d7) + 1;
                        d10 = MathHelper.floor_double(d2 - d6) - j * 16 - 1;
                        int i3 = MathHelper.floor_double(d2 + d6) - j * 16 + 1;
                        if (d8 < 0.0) {
                            d8 = 0.0;
                        }
                        if (k2 > 16) {
                            k2 = 16;
                        }
                        if (d9 < 1.0) {
                            d9 = 1.0;
                        }
                        if (l2 > 120) {
                            l2 = 120;
                        }
                        if (d10 < 0.0) {
                            d10 = 0.0;
                        }
                        if (i3 > 16) {
                            i3 = 16;
                        }
                        boolean flag3 = false;
                        for (int j3 = (int)d8; !flag3 && j3 < k2; ++j3) {
                            for (int l3 = (int)d10; !flag3 && l3 < i3; ++l3) {
                                for (int i4 = l2 + 1; !flag3 && i4 >= d9 - 1.0; --i4) {
                                    final int j4 = (j3 * 16 + l3) * 128 + i4;
                                    if (i4 >= 0) {
                                        if (i4 < 128) {
                                            if (abyte0[j4] == Block.waterMoving.blockID || abyte0[j4] == Block.waterStill.blockID) {
                                                flag3 = true;
                                            }
                                            if (i4 != d9 - 1.0 && j3 != d8 && j3 != k2 - 1 && l3 != d10 && l3 != i3 - 1) {
                                                i4 = (int)d9;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (!flag3) {
                            for (int k3 = (int)d8; k3 < k2; ++k3) {
                                final double d12 = (k3 + i * 16 + 0.5 - d) / d6;
                                for (int k4 = (int)d10; k4 < i3; ++k4) {
                                    final double d13 = (k4 + j * 16 + 0.5 - d2) / d6;
                                    int l4 = (k3 * 16 + k4) * 128 + l2;
                                    boolean flag4 = false;
                                    for (int i5 = l2 - 1; i5 >= d9; --i5) {
                                        final double d14 = (i5 + 0.5 - d1) / d7;
                                        if (d14 > -0.7 && d12 * d12 + d14 * d14 + d13 * d13 < 1.0) {
                                            final byte byte0 = abyte0[l4];
                                            if (byte0 == Block.grass.blockID) {
                                                flag4 = true;
                                            }
                                            if (byte0 == Block.stone.blockID || byte0 == Block.dirt.blockID || byte0 == Block.grass.blockID) {
                                                if (i5 < 10) {
                                                    abyte0[l4] = (byte)Block.lavaMoving.blockID;
                                                }
                                                else {
                                                    abyte0[l4] = 0;
                                                    if (flag4 && abyte0[l4 - 1] == Block.dirt.blockID) {
                                                        abyte0[l4 - 1] = (byte)Block.grass.blockID;
                                                    }
                                                }
                                            }
                                        }
                                        --l4;
                                    }
                                }
                            }
                            if (flag) {
                                break;
                            }
                        }
                    }
                }
            }
            ++k;
        }
    }
    
    @Override
    protected void func_868_a(final World world, final int i, final int j, final int k, final int l, final byte[] abyte0) {
        int i2 = this.rand.nextInt(this.rand.nextInt(this.rand.nextInt(40) + 1) + 1);
        if (this.rand.nextInt(15) != 0) {
            i2 = 0;
        }
        for (int j2 = 0; j2 < i2; ++j2) {
            final double d = i * 16 + this.rand.nextInt(16);
            final double d2 = this.rand.nextInt(this.rand.nextInt(120) + 8);
            final double d3 = j * 16 + this.rand.nextInt(16);
            int k2 = 1;
            if (this.rand.nextInt(4) == 0) {
                this.func_870_a(k, l, abyte0, d, d2, d3);
                k2 += this.rand.nextInt(4);
            }
            for (int l2 = 0; l2 < k2; ++l2) {
                final float f = this.rand.nextFloat() * 3.141593f * 2.0f;
                final float f2 = (this.rand.nextFloat() - 0.5f) * 2.0f / 8.0f;
                final float f3 = this.rand.nextFloat() * 2.0f + this.rand.nextFloat();
                this.func_869_a(k, l, abyte0, d, d2, d3, f3, f, f2, 0, 0, 1.0);
            }
        }
    }
}
