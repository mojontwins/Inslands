package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenFlowers extends WorldGenerator
{
    private int field_885_a;
    
    public WorldGenFlowers(final int i) {
        this.field_885_a = i;
    }
    
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        for (int l = 0; l < 64; ++l) {
            final int i2 = i + random.nextInt(8) - random.nextInt(8);
            final int j2 = j + random.nextInt(4) - random.nextInt(4);
            final int k2 = k + random.nextInt(8) - random.nextInt(8);
            if (world.getBlockId(i2, j2, k2) == 0 && ((BlockFlower)Block.allBlocks[this.field_885_a]).canBlockStay(world, i2, j2, k2)) {
                world.setBlock(i2, j2, k2, this.field_885_a);
            }
        }
        return true;
    }
}
