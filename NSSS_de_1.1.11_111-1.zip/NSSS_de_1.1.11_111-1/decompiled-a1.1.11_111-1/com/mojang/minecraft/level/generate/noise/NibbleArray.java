package com.mojang.minecraft.level.generate.noise;

public class NibbleArray
{
    public final byte[] data;
    
    public NibbleArray(final int i) {
        this.data = new byte[i >> 1];
    }
    
    public NibbleArray(final byte[] abyte0) {
        this.data = abyte0;
    }
    
    public int getNibble(final int i, final int j, final int k) {
        final int l = i << 11 | k << 7 | j;
        final int i2 = l >> 1;
        final int j2 = l & 0x1;
        if (j2 == 0) {
            return this.data[i2] & 0xF;
        }
        return this.data[i2] >> 4 & 0xF;
    }
    
    public void setNibble(final int i, final int j, final int k, final int l) {
        final int i2 = i << 11 | k << 7 | j;
        final int j2 = i2 >> 1;
        final int k2 = i2 & 0x1;
        if (k2 == 0) {
            this.data[j2] = (byte)((this.data[j2] & 0xF0) | (l & 0xF));
        }
        else {
            this.data[j2] = (byte)((this.data[j2] & 0xF) | (l & 0xF) << 4);
        }
    }
    
    public boolean isValid() {
        return this.data != null;
    }
}
