package com.mojang.minecraft.level.generate.noise;

import java.util.*;

public class InfdevOldNoiseGeneratorOctaves extends NoiseGenerator
{
    private InfdevOldNoiseGeneratorPerlin[] generatorCollection;
    private int octaves;
    
    public InfdevOldNoiseGeneratorOctaves(final int i) {
        this(new Random(), i);
    }
    
    public InfdevOldNoiseGeneratorOctaves(final Random random, final int i) {
        this.octaves = i;
        this.generatorCollection = new InfdevOldNoiseGeneratorPerlin[i];
        for (int j = 0; j < i; ++j) {
            this.generatorCollection[j] = new InfdevOldNoiseGeneratorPerlin(random);
        }
    }
    
    public double func_806_a(final double d, final double d1) {
        double d2 = 0.0;
        double d3 = 1.0;
        for (int i = 0; i < this.octaves; ++i) {
            d2 += this.generatorCollection[i].a(d / d3, d1 / d3) * d3;
            d3 *= 2.0;
        }
        return d2;
    }
    
    public double a(final double d, double d1, final double d2) {
        double d3 = 0.0;
        double d4 = 1.0;
        for (d1 = 0.0; d1 < this.octaves; ++d1) {
            d3 += this.generatorCollection[(int)d1].a(d / d4, 0.0 / d4, d2 / d4) * d4;
            d4 *= 2.0;
        }
        return d3;
    }
}
