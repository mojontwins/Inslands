package com.mojang.minecraft.level.generate.noise;

public abstract class NoiseGenerator
{
}
