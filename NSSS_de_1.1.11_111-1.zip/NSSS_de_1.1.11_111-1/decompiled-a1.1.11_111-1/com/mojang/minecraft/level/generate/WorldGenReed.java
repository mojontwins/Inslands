package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenReed extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        for (int l = 0; l < 20; ++l) {
            final int i2 = i + random.nextInt(4) - random.nextInt(4);
            final int j2 = j;
            final int k2 = k + random.nextInt(4) - random.nextInt(4);
            if (world.getBlockId(i2, j2, k2) == 0) {
                if (world.getMaterialXYZ(i2 - 1, j2 - 1, k2) == Material.water || world.getMaterialXYZ(i2 + 1, j2 - 1, k2) == Material.water || world.getMaterialXYZ(i2, j2 - 1, k2 - 1) == Material.water || world.getMaterialXYZ(i2, j2 - 1, k2 + 1) == Material.water) {
                    for (int l2 = 2 + random.nextInt(random.nextInt(3) + 1), i3 = 0; i3 < l2; ++i3) {
                        if (Block.reed.canBlockStay(world, i2, j2 + i3, k2)) {
                            world.setBlock(i2, j2 + i3, k2, Block.reed.blockID);
                        }
                    }
                }
            }
        }
        return true;
    }
}
