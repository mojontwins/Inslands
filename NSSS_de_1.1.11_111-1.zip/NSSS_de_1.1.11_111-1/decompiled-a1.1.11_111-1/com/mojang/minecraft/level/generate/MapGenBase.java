package com.mojang.minecraft.level.generate;

import java.util.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.level.*;

public class MapGenBase
{
    protected int field_1306_a;
    protected Random rand;
    
    public MapGenBase() {
        this.field_1306_a = 8;
        this.rand = new Random();
    }
    
    public void func_867_a(final ChunkProviderGenerate chunkProviderGenerate, final World world, final int i, final int j, final byte[] abyte0) {
        final int k = this.field_1306_a;
        this.rand.setSeed(world.randomSeed);
        final long l = this.rand.nextLong() / 2L * 2L + 1L;
        final long l2 = this.rand.nextLong() / 2L * 2L + 1L;
        for (int i2 = i - k; i2 <= i + k; ++i2) {
            for (int j2 = j - k; j2 <= j + k; ++j2) {
                this.rand.setSeed(i2 * l + j2 * l2 ^ world.randomSeed);
                this.func_868_a(world, i2, j2, i, j, abyte0);
            }
        }
    }
    
    protected void func_868_a(final World world, final int i, final int j, final int k, final int l, final byte[] abyte0) {
    }
}
