package com.mojang.minecraft.level.generate.noise;

import java.util.*;

public class NoiseGeneratorOctaves extends NoiseGenerator
{
    private NoiseGeneratorPerlin[] generatorCollection;
    private int field_1191_b;
    
    public NoiseGeneratorOctaves(final Random random, final int i) {
        this.field_1191_b = i;
        this.generatorCollection = new NoiseGeneratorPerlin[i];
        for (int j = 0; j < i; ++j) {
            this.generatorCollection[j] = new NoiseGeneratorPerlin(random);
        }
    }
    
    public double func_806_a(final double d, final double d1) {
        double d2 = 0.0;
        double d3 = 1.0;
        for (int i = 0; i < this.field_1191_b; ++i) {
            d2 += this.generatorCollection[i].func_801_a(d * d3, d1 * d3) / d3;
            d3 /= 2.0;
        }
        return d2;
    }
    
    public double[] generateNoiseOctaves(double[] ad, final double d, final double d1, final double d2, final int i, final int j, final int k, final double xScale, final double yScale, final double zScale) {
        if (ad == null) {
            ad = new double[i * j * k];
        }
        else {
            for (int l = 0; l < ad.length; ++l) {
                ad[l] = 0.0;
            }
        }
        double d3 = 1.0;
        for (int i2 = 0; i2 < this.field_1191_b; ++i2) {
            this.generatorCollection[i2].func_805_a(ad, d, d1, d2, i, j, k, xScale * d3, yScale * d3, zScale * d3, d3);
            d3 /= 2.0;
        }
        return ad;
    }
    
    public double[] generateNoiseOctaves_2(double[] ad, final double d, final double d1, final double d2, final int i, final int j, final int k, final double xScale, final double yScale, final double zScale) {
        if (ad == null) {
            ad = new double[i * j * k];
        }
        else {
            for (int l = 0; l < ad.length; ++l) {
                ad[l] = 0.0;
            }
        }
        double d3 = 1.0;
        for (int i2 = 0; i2 < this.field_1191_b; ++i2) {
            this.generatorCollection[i2].func_805_a_(ad, d, d1, d2, i, j, k, xScale * d3, yScale * d3, zScale * d3, d3);
            d3 /= 2.0;
        }
        return ad;
    }
}
