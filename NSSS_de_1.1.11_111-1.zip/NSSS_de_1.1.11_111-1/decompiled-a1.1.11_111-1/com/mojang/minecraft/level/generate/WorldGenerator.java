package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;

public abstract class WorldGenerator
{
    public abstract boolean generate(final World p0, final Random p1, final int p2, final int p3, final int p4);
    
    public void func_517_a(final double d, final double d1, final double d2) {
    }
}
