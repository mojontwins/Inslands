package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.item.*;

public class WorldGenDungeons extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        final byte byte0 = 3;
        final int l = random.nextInt(2) + 2;
        final int i2 = random.nextInt(2) + 2;
        int validspots = 0;
        for (int k2 = i - l - 1; k2 <= i + l + 1; ++k2) {
            for (int j2 = j - 1; j2 <= j + byte0 + 1; ++j2) {
                for (int i3 = k - i2 - 1; i3 <= k + i2 + 1; ++i3) {
                    final Material material = world.getMaterialXYZ(k2, j2, i3);
                    if (j2 == j - 1 && !material.isSolidMaterial()) {
                        return false;
                    }
                    if (j2 == j + byte0 + 1 && !material.isSolidMaterial()) {
                        return false;
                    }
                    if ((k2 == i - l - 1 || k2 == i + l + 1 || i3 == k - i2 - 1 || i3 == k + i2 + 1) && j2 == j && world.getBlockId(k2, j2, i3) == 0 && world.getBlockId(k2, j2 + 1, i3) == 0) {
                        ++validspots;
                    }
                }
            }
        }
        if (validspots < 1 || validspots > 5) {
            return false;
        }
        for (int l2 = i - l - 1; l2 <= i + l + 1; ++l2) {
            for (int k3 = j + byte0; k3 >= j - 1; --k3) {
                for (int j3 = k - i2 - 1; j3 <= k + i2 + 1; ++j3) {
                    if (l2 == i - l - 1 || k3 == j - 1 || j3 == k - i2 - 1 || l2 == i + l + 1 || k3 == j + byte0 + 1 || j3 == k + i2 + 1) {
                        if (k3 >= 0 && !world.getMaterialXYZ(l2, k3 - 1, j3).isSolidMaterial()) {
                            world.setBlockWithNotify(l2, k3, j3, 0);
                        }
                        else if (world.getMaterialXYZ(l2, k3, j3).isSolidMaterial()) {
                            if (k3 == j - 1 && random.nextInt(4) != 0) {
                                world.setBlockWithNotify(l2, k3, j3, Block.cobblestoneMossy.blockID);
                            }
                            else {
                                world.setBlockWithNotify(l2, k3, j3, Block.cobblestone.blockID);
                            }
                        }
                    }
                    else {
                        world.setBlockWithNotify(l2, k3, j3, 0);
                    }
                }
            }
        }
        for (int i4 = 0; i4 < 2; ++i4) {
            for (int l3 = 0; l3 < 3; ++l3) {
                final int k4 = i + random.nextInt(l * 2 + 1) - l;
                final int l4 = j;
                final int i5 = k + random.nextInt(i2 * 2 + 1) - i2;
                if (world.getBlockId(k4, l4, i5) == 0) {
                    int nonViableSpace = 0;
                    if (world.getMaterialXYZ(k4 - 1, l4, i5).isSolidMaterial()) {
                        ++nonViableSpace;
                    }
                    if (world.getMaterialXYZ(k4 + 1, l4, i5).isSolidMaterial()) {
                        ++nonViableSpace;
                    }
                    if (world.getMaterialXYZ(k4, l4, i5 - 1).isSolidMaterial()) {
                        ++nonViableSpace;
                    }
                    if (world.getMaterialXYZ(k4, l4, i5 + 1).isSolidMaterial()) {
                        ++nonViableSpace;
                    }
                    if (nonViableSpace == 1) {
                        world.setBlockWithNotify(k4, l4, i5, Block.crate.blockID);
                        final TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(k4, l4, i5);
                        for (int k5 = 0; k5 < 8; ++k5) {
                            final ItemStack itemstack = this.chestLoot(random);
                            if (itemstack != null) {
                                tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), itemstack);
                            }
                        }
                        break;
                    }
                }
            }
        }
        world.setBlockWithNotify(i, j, k, Block.mobSpawner.blockID);
        final TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)world.getBlockTileEntity(i, j, k);
        tileentitymobspawner.entityID = this.func_531_b(random);
        return true;
    }
    
    private ItemStack chestLoot(final Random random) {
        final int i = random.nextInt(11);
        if (i == 0) {
            return new ItemStack(Item.saddle);
        }
        if (i == 1) {
            return new ItemStack(Item.ingotIron, random.nextInt(4) + 1);
        }
        if (i == 2) {
            return new ItemStack(Item.bread);
        }
        if (i == 3) {
            return new ItemStack(Item.wheat, random.nextInt(4) + 1);
        }
        if (i == 4) {
            return new ItemStack(Item.gunpowder, random.nextInt(4) + 1);
        }
        if (i == 5) {
            return new ItemStack(Item.silk, random.nextInt(4) + 1);
        }
        if (i == 6) {
            return new ItemStack(Item.bucketEmpty);
        }
        if (i == 7 && random.nextInt(100) == 0) {
            return new ItemStack(Item.appleGold);
        }
        if (i == 8 && random.nextInt(2) == 0) {
            return new ItemStack(Item.redstone, random.nextInt(4) + 1);
        }
        if (i == 9 && random.nextInt(10) == 0) {
            return new ItemStack(Item.itemsList[Item.record13.shiftedIndex + random.nextInt(13)]);
        }
        if (i == 10) {
            return new ItemStack(Item.cocoa, 3);
        }
        return null;
    }
    
    private String func_531_b(final Random random) {
        final int i = random.nextInt(4);
        if (i == 0) {
            return "Skeleton";
        }
        if (i == 1) {
            return "Zombie";
        }
        if (i == 2) {
            return "Zombie";
        }
        if (i == 3) {
            return "Spider";
        }
        return "";
    }
}
