package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.item.*;

public class WorldGenWaterDungeons extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int x, final int y, final int z) {
        final byte dungeonHeight = 3;
        final int randomWidthX = random.nextInt(2) + 2;
        final int randomWidthZ = random.nextInt(2) + 2;
        int validSpots = 0;
        for (int spotCheckX = x - randomWidthX - 1; spotCheckX <= x + randomWidthX + 1; ++spotCheckX) {
            for (int spotCheckY = y - 1; spotCheckY <= y + dungeonHeight + 1; ++spotCheckY) {
                for (int spotCheckZ = z - randomWidthZ - 1; spotCheckZ <= z + randomWidthZ + 1; ++spotCheckZ) {
                    if ((spotCheckX == x - randomWidthX - 1 || spotCheckX == x + randomWidthX + 1 || spotCheckZ == z - randomWidthZ - 1 || spotCheckZ == z + randomWidthZ + 1) && spotCheckY == y && world.getBlockId(spotCheckX, spotCheckY, spotCheckZ) != 9 && world.getBlockId(spotCheckX, spotCheckY + 1, spotCheckZ) == 9 && world.getBlockId(spotCheckX, spotCheckY + 2, spotCheckZ) == 9 && world.getBlockId(spotCheckX, spotCheckY + 3, spotCheckZ) == 9 && world.getBlockId(spotCheckX, spotCheckY + 4, spotCheckZ) == 9 && world.getBlockId(spotCheckX, spotCheckY + 5, spotCheckZ) == 9 && world.getBlockId(spotCheckX, spotCheckY + 6, spotCheckZ) == 9) {
                        ++validSpots;
                    }
                }
            }
        }
        if (validSpots < 1 || validSpots > 50) {
            return false;
        }
        for (int blockGenX = x - randomWidthX - 1; blockGenX <= x + randomWidthX + 1; ++blockGenX) {
            for (int blockGenY = y + dungeonHeight; blockGenY >= y - 1; --blockGenY) {
                for (int blockGenZ = z - randomWidthZ - 1; blockGenZ <= z + randomWidthZ + 1; ++blockGenZ) {
                    if (blockGenX == x - randomWidthX - 1 || blockGenY == y - 1 || blockGenZ == z - randomWidthZ - 1 || blockGenX == x + randomWidthX + 1 || blockGenY == y + dungeonHeight + 1 || blockGenZ == z + randomWidthZ + 1) {
                        if (blockGenY >= 0 && !world.getMaterialXYZ(blockGenX, blockGenY - 1, blockGenZ).isSolidMaterial()) {
                            if (world.getBlockId(blockGenX, blockGenY, blockGenZ) != 0 && blockGenY < 64) {
                                if (random.nextInt(4) < 2) {
                                    world.setBlockWithNotify(blockGenX, blockGenY, blockGenZ, Block.brickMossy.blockID);
                                }
                                else {
                                    world.setBlockWithNotify(blockGenX, blockGenY, blockGenZ, Block.brick.blockID);
                                }
                            }
                        }
                        else if (world.getMaterialXYZ(blockGenX, blockGenY, blockGenZ) == Material.water) {
                            if (blockGenY == y - 1) {
                                if (random.nextInt(4) < 2) {
                                    world.setBlockWithNotify(blockGenX, blockGenY, blockGenZ, Block.brickMossy.blockID);
                                }
                                else {
                                    world.setBlockWithNotify(blockGenX, blockGenY, blockGenZ, Block.brick.blockID);
                                }
                            }
                        }
                    }
                    else if (world.getBlockId(blockGenX, blockGenY, blockGenZ) != 0 && blockGenY < 64) {
                        world.setBlockWithNotify(blockGenX, blockGenY, blockGenZ, 0);
                        if (random.nextInt(4) < 2) {
                            world.setBlockWithNotify(blockGenX, y + dungeonHeight, blockGenZ, Block.brickMossy.blockID);
                        }
                        else {
                            world.setBlockWithNotify(blockGenX, y + dungeonHeight, blockGenZ, Block.brick.blockID);
                        }
                    }
                }
            }
        }
        for (int i2 = 0; i2 < 2; ++i2) {
            for (int l2 = 0; l2 < 3; ++l2) {
                final int k3 = x + random.nextInt(randomWidthX * 2 + 1) - randomWidthX;
                final int l3 = y;
                final int i3 = z + random.nextInt(randomWidthZ * 2 + 1) - randomWidthZ;
                if (world.getBlockId(k3, l3, i3) != 9) {
                    int viableSpace = 0;
                    if (world.getMaterialXYZ(k3 - 1, l3, i3).isSolidMaterial()) {
                        ++viableSpace;
                    }
                    if (world.getMaterialXYZ(k3 + 1, l3, i3).isSolidMaterial()) {
                        ++viableSpace;
                    }
                    if (world.getMaterialXYZ(k3, l3, i3 - 1).isSolidMaterial()) {
                        ++viableSpace;
                    }
                    if (world.getMaterialXYZ(k3, l3, i3 + 1).isSolidMaterial()) {
                        ++viableSpace;
                    }
                    if (viableSpace == 1) {
                        world.setBlockWithNotify(k3, l3, i3, Block.crate.blockID);
                        final TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(k3, l3, i3);
                        for (int k4 = 0; k4 < 8; ++k4) {
                            final ItemStack itemstack = this.chestLoot(random);
                            if (itemstack != null) {
                                tileentitychest.setInventorySlotContents(random.nextInt(tileentitychest.getSizeInventory()), itemstack);
                            }
                        }
                        break;
                    }
                }
            }
        }
        world.setBlockWithNotify(x, y, z, Block.mobSpawner.blockID);
        final TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)world.getBlockTileEntity(x, y, z);
        world.setBlockWithNotify(x, y - 1, z, Block.sponge.blockID);
        world.notifyBlocksOfNeighborChange(x, y - 1, z, 1);
        tileentitymobspawner.entityID = this.func_531_b(random);
        return true;
    }
    
    private ItemStack chestLoot(final Random random) {
        final int i = random.nextInt(11);
        if (i == 0) {
            return new ItemStack(Block.sponge, random.nextInt(4) + 1);
        }
        if (i == 1) {
            return new ItemStack(Item.ingotGold, random.nextInt(4) + 1);
        }
        if (i == 2) {
            return new ItemStack(Item.paper, random.nextInt(4) + 1);
        }
        if (i == 3) {
            return new ItemStack(Item.reed, random.nextInt(4) + 1);
        }
        if (i == 4) {
            return new ItemStack(Item.flint, random.nextInt(4) + 1);
        }
        if (i == 5) {
            final int roll = random.nextInt(4);
            if (roll == 0) {
                return new ItemStack(Item.helmetChain);
            }
            if (roll == 1) {
                return new ItemStack(Item.plateChain);
            }
            if (roll == 2) {
                return new ItemStack(Item.legsChain);
            }
            if (roll == 3) {
                return new ItemStack(Item.bootsChain);
            }
        }
        if (i == 6) {
            return new ItemStack(Item.bucketWater);
        }
        if (i == 7 && random.nextInt(100) == 0) {
            return new ItemStack(Item.appleGold);
        }
        if (i == 8 && random.nextInt(2) == 0) {
            return new ItemStack(Item.redstone, random.nextInt(4) + 1);
        }
        if (i == 9 && random.nextInt(10) == 0) {
            return new ItemStack(Item.diamond);
        }
        return null;
    }
    
    private String func_531_b(final Random random) {
        final int i = random.nextInt(4);
        if (i == 0) {
            return "Skeleton";
        }
        if (i == 1) {
            return "Zombie";
        }
        if (i == 2) {
            return "Zombie";
        }
        if (i == 3) {
            return "Spider";
        }
        return "";
    }
}
