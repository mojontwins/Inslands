package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;

public class aaa2 extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        System.out.println("Making floating pyramid");
        for (int y = 64; y > 0; --y) {
            for (int x = i - y; x < i + y - 1; ++x) {
                for (int z = k - y; z < k + y - 1; ++z) {
                    if (!world.isBlockNormalCube(x, 128 - y, z) && (x == i - y || x == i + y - 2 || z == k - y || z == k + y - 2)) {
                        if (random.nextInt(4) != 0) {
                            world.setBlock(x, 128 - y, z, Block.brick.blockID);
                        }
                        else {
                            world.setBlock(x, 128 - y, z, Block.brickMossy.blockID);
                        }
                    }
                    if (!world.isBlockNormalCube(x, y, z) && (x == i - y || x == i + y - 2 || z == k - y || z == k + y - 2)) {
                        if (random.nextInt(4) != 0) {
                            world.setBlock(x, y, z, Block.brickMossy.blockID);
                        }
                        else {
                            world.setBlock(x, y, z, Block.brick.blockID);
                        }
                    }
                }
            }
        }
        world.setBlock(i - 1, 127, k - 1, Block.pyramidion.blockID);
        return true;
    }
}
