package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenMinable extends WorldGenerator
{
    private int field_884_a;
    private int field_883_b;
    
    public WorldGenMinable(final int i, final int j) {
        this.field_884_a = i;
        this.field_883_b = j;
    }
    
    @Override
    public boolean generate(final World world, final Random random, final int x, final int y, final int z) {
        final float f = random.nextFloat() * 3.141593f;
        final double d = x + 8 + MathHelper.sin(f) * this.field_883_b / 8.0f;
        final double d2 = x + 8 - MathHelper.sin(f) * this.field_883_b / 8.0f;
        final double d3 = z + 8 + MathHelper.cos(f) * this.field_883_b / 8.0f;
        final double d4 = z + 8 - MathHelper.cos(f) * this.field_883_b / 8.0f;
        final double d5 = y + random.nextInt(3) + 2;
        final double d6 = y + random.nextInt(3) + 2;
        for (int l = 0; l <= this.field_883_b; ++l) {
            final double d7 = d + (d2 - d) * l / this.field_883_b;
            final double d8 = d5 + (d6 - d5) * l / this.field_883_b;
            final double d9 = d3 + (d4 - d3) * l / this.field_883_b;
            final double d10 = random.nextDouble() * this.field_883_b / 16.0;
            final double d11 = (MathHelper.sin(l * 3.141593f / this.field_883_b) + 1.0f) * d10 + 1.0;
            final double d12 = (MathHelper.sin(l * 3.141593f / this.field_883_b) + 1.0f) * d10 + 1.0;
            for (double i1 = d7 - d11 / 2.0; i1 <= d7 + d11 / 2.0; ++i1) {
                for (double j1 = d8 - d12 / 2.0; j1 <= (int)(d8 + d12 / 2.0); ++j1) {
                    for (double k1 = d9 - d11 / 2.0; k1 <= (int)(d9 + d11 / 2.0); ++k1) {
                        final double d13 = (Math.floor(i1) + 0.5 - d7) / (d11 / 2.0);
                        final double d14 = (Math.floor(j1) + 0.5 - d8) / (d12 / 2.0);
                        final double d15 = (Math.floor(k1) + 0.5 - d9) / (d11 / 2.0);
                        if (d13 * d13 + d14 * d14 + d15 * d15 < 1.0 && world.getBlockId((int)Math.floor(i1), (int)Math.floor(j1), (int)Math.floor(k1)) == Block.stone.blockID) {
                            world.setBlock((int)Math.floor(i1), (int)Math.floor(j1), (int)Math.floor(k1), this.field_884_a);
                        }
                    }
                }
            }
        }
        return true;
    }
}
