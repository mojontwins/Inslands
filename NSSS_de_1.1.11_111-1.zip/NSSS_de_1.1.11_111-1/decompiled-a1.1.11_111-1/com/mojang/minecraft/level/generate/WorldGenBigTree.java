package com.mojang.minecraft.level.generate;

import java.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;

public class WorldGenBigTree extends WorldGenerator
{
    static final byte[] field_882_a;
    Random random0;
    World worldObj;
    int[] basePos;
    int field_878_e;
    int height;
    double field_754_g;
    double field_753_h;
    double field_752_i;
    double field_751_j;
    double field_750_k;
    int field_749_l;
    int field_748_m;
    int field_747_n;
    int[][] field_746_o;
    
    static {
        field_882_a = new byte[] { 2, 0, 0, 1, 2, 1 };
    }
    
    public WorldGenBigTree() {
        this.basePos = new int[3];
        this.random0 = new Random();
        this.field_878_e = 0;
        this.field_754_g = 0.618;
        this.field_753_h = 1.0;
        this.field_752_i = 0.381;
        this.field_751_j = 1.0;
        this.field_750_k = 1.0;
        this.field_749_l = 1;
        this.field_748_m = 12;
        this.field_747_n = 4;
    }
    
    void generate() {
        this.height = (int)(this.field_878_e * this.field_754_g);
        if (this.height >= this.field_878_e) {
            this.height = this.field_878_e - 1;
        }
        int i = (int)(1.382 + Math.pow(this.field_750_k * this.field_878_e / 13.0, 2.0));
        if (i < 1) {
            i = 1;
        }
        final int[][] ai = new int[i * this.field_878_e][4];
        int j = this.basePos[1] + this.field_878_e - this.field_747_n;
        int k = 1;
        final int l = this.basePos[1] + this.height;
        int i2 = j - this.basePos[1];
        ai[0][0] = this.basePos[0];
        ai[0][1] = j;
        ai[0][2] = this.basePos[2];
        ai[0][3] = l;
        --j;
        while (i2 >= 0) {
            int j2 = 0;
            final float f = this.func_528_a(i2);
            if (f < 0.0f) {
                --j;
                --i2;
            }
            else {
                final double d = 0.5;
                while (j2 < i) {
                    final double d2 = this.field_751_j * (f * (this.random0.nextFloat() + 0.328));
                    final double d3 = this.random0.nextFloat() * 2.0 * 3.14159;
                    final int k2 = (int)(d2 * Math.sin(d3) + this.basePos[0] + d);
                    final int l2 = (int)(d2 * Math.cos(d3) + this.basePos[2] + d);
                    final int[] ai2 = { k2, j, l2 };
                    final int[] ai3 = { k2, j + this.field_747_n, l2 };
                    if (this.func_524_a(ai2, ai3) == -1) {
                        final int[] ai4 = { this.basePos[0], this.basePos[1], this.basePos[2] };
                        final double d4 = Math.sqrt(Math.pow(Math.abs(this.basePos[0] - ai2[0]), 2.0) + Math.pow(Math.abs(this.basePos[2] - ai2[2]), 2.0));
                        final double d5 = d4 * this.field_752_i;
                        if (ai2[1] - d5 > l) {
                            ai4[1] = l;
                        }
                        else {
                            ai4[1] = (int)(ai2[1] - d5);
                        }
                        if (this.func_524_a(ai4, ai2) == -1) {
                            ai[k][0] = k2;
                            ai[k][1] = j;
                            ai[k][2] = l2;
                            ai[k][3] = ai4[1];
                            ++k;
                        }
                    }
                    ++j2;
                }
                --j;
                --i2;
            }
        }
        System.arraycopy(ai, 0, this.field_746_o = new int[k][4], 0, k);
    }
    
    void func_523_a(final int i, final int j, final int k, final float f, final byte byte0, final int l) {
        final int i2 = (int)(f + 0.618);
        final byte byte1 = WorldGenBigTree.field_882_a[byte0];
        final byte byte2 = WorldGenBigTree.field_882_a[byte0 + 3];
        final int[] ai = { i, j, k };
        final int[] ai2 = new int[3];
        int j2 = -i2;
        ai2[byte0] = ai[byte0];
        while (j2 <= i2) {
            ai2[byte1] = ai[byte1] + j2;
            for (int l2 = -i2; l2 <= i2; ++l2) {
                final double d = Math.sqrt(Math.pow(Math.abs(j2) + 0.5, 2.0) + Math.pow(Math.abs(l2) + 0.5, 2.0));
                if (d <= f) {
                    ai2[byte2] = ai[byte2] + l2;
                    final int i3 = this.worldObj.getBlockId(ai2[0], ai2[1], ai2[2]);
                    if (i3 == 0 || i3 == 18) {
                        this.worldObj.setBlock(ai2[0], ai2[1], ai2[2], l);
                    }
                }
            }
            ++j2;
        }
    }
    
    float func_528_a(final int i) {
        if (i < (float)this.field_878_e * 0.3) {
            return -1.618f;
        }
        final float f = this.field_878_e / 2.0f;
        final float f2 = this.field_878_e / 2.0f - i;
        float f3;
        if (f2 == 0.0f) {
            f3 = f;
        }
        else if (Math.abs(f2) >= f) {
            f3 = 0.0f;
        }
        else {
            f3 = (float)Math.sqrt(Math.pow(Math.abs(f), 2.0) - Math.pow(Math.abs(f2), 2.0));
        }
        f3 *= 0.5f;
        return f3;
    }
    
    float func_526_b(final int i) {
        if (i < 0 || i >= this.field_747_n) {
            return -1.0f;
        }
        return (i != 0 && i != this.field_747_n - 1) ? 3.0f : 2.0f;
    }
    
    void func_520_a(final int i, final int j, final int k) {
        for (int l = j, i2 = j + this.field_747_n; l < i2; ++l) {
            final float f = this.func_526_b(l - j);
            this.func_523_a(i, l, k, f, (byte)1, 18);
        }
    }
    
    void func_522_a(final int[] ai, final int[] ai1, final int i) {
        final int[] ai2 = new int[3];
        byte byte0 = 0;
        int j = 0;
        while (byte0 < 3) {
            ai2[byte0] = ai1[byte0] - ai[byte0];
            if (Math.abs(ai2[byte0]) > Math.abs(ai2[j])) {
                j = byte0;
            }
            ++byte0;
        }
        if (ai2[j] == 0) {
            return;
        }
        final byte byte2 = WorldGenBigTree.field_882_a[j];
        final byte byte3 = WorldGenBigTree.field_882_a[j + 3];
        byte byte4;
        if (ai2[j] > 0) {
            byte4 = 1;
        }
        else {
            byte4 = -1;
        }
        final double d = ai2[byte2] / (double)ai2[j];
        final double d2 = ai2[byte3] / (double)ai2[j];
        final int[] ai3 = new int[3];
        for (int k = 0, l = ai2[j] + byte4; k != l; k += byte4) {
            ai3[j] = MathHelper.floor_double(ai[j] + k + 0.5);
            ai3[byte2] = MathHelper.floor_double(ai[byte2] + k * d + 0.5);
            ai3[byte3] = MathHelper.floor_double(ai[byte3] + k * d2 + 0.5);
            this.worldObj.setBlock(ai3[0], ai3[1], ai3[2], i);
        }
    }
    
    void func_518_b() {
        for (int i = 0, j = this.field_746_o.length; i < j; ++i) {
            final int k = this.field_746_o[i][0];
            final int l = this.field_746_o[i][1];
            final int i2 = this.field_746_o[i][2];
            this.func_520_a(k, l, i2);
        }
    }
    
    boolean func_527_c(final int i) {
        return i >= this.field_878_e * 0.2;
    }
    
    void func_529_c() {
        final int i = this.basePos[0];
        final int j = this.basePos[1];
        final int k = this.basePos[1] + this.height;
        final int l = this.basePos[2];
        final int[] ai = { i, j, l };
        final int[] ai2 = { i, k, l };
        this.func_522_a(ai, ai2, 17);
        if (this.field_749_l == 2) {
            final int[] array = ai;
            final int n = 0;
            ++array[n];
            final int[] array2 = ai2;
            final int n2 = 0;
            ++array2[n2];
            this.func_522_a(ai, ai2, 17);
            final int[] array3 = ai;
            final int n3 = 2;
            ++array3[n3];
            final int[] array4 = ai2;
            final int n4 = 2;
            ++array4[n4];
            this.func_522_a(ai, ai2, 17);
            final int[] array5 = ai;
            final int n5 = 0;
            --array5[n5];
            final int[] array6 = ai2;
            final int n6 = 0;
            --array6[n6];
            this.func_522_a(ai, ai2, 17);
        }
    }
    
    void func_525_d() {
        int i = 0;
        final int j = this.field_746_o.length;
        final int[] ai = { this.basePos[0], this.basePos[1], this.basePos[2] };
        while (i < j) {
            final int[] ai2 = this.field_746_o[i];
            final int[] ai3 = { ai2[0], ai2[1], ai2[2] };
            ai[1] = ai2[3];
            final int k = ai[1] - this.basePos[1];
            if (this.func_527_c(k)) {
                this.func_522_a(ai, ai3, 17);
            }
            ++i;
        }
    }
    
    int func_524_a(final int[] ai, final int[] ai1) {
        final int[] ai2 = new int[3];
        byte byte0 = 0;
        int i = 0;
        while (byte0 < 3) {
            ai2[byte0] = ai1[byte0] - ai[byte0];
            if (Math.abs(ai2[byte0]) > Math.abs(ai2[i])) {
                i = byte0;
            }
            ++byte0;
        }
        if (ai2[i] == 0) {
            return -1;
        }
        final byte byte2 = WorldGenBigTree.field_882_a[i];
        final byte byte3 = WorldGenBigTree.field_882_a[i + 3];
        byte byte4;
        if (ai2[i] > 0) {
            byte4 = 1;
        }
        else {
            byte4 = -1;
        }
        final double d = ai2[byte2] / (double)ai2[i];
        final double d2 = ai2[byte3] / (double)ai2[i];
        final int[] ai3 = new int[3];
        int j = 0;
        final int k = ai2[i] + byte4;
        while (true) {
            while (j != k) {
                ai3[i] = ai[i] + j;
                ai3[byte2] = (int)(ai[byte2] + j * d);
                ai3[byte3] = (int)(ai[byte3] + j * d2);
                final int l = this.worldObj.getBlockId(ai3[0], ai3[1], ai3[2]);
                if (l != 0 && l != 18) {
                    if (j == k) {
                        return -1;
                    }
                    return Math.abs(j);
                }
                else {
                    j += byte4;
                }
            }
            continue;
        }
    }
    
    boolean func_519_e() {
        final int[] ai = { this.basePos[0], this.basePos[1], this.basePos[2] };
        final int[] ai2 = { this.basePos[0], this.basePos[1] + this.field_878_e - 1, this.basePos[2] };
        final int i = this.worldObj.getBlockId(this.basePos[0], this.basePos[1] - 1, this.basePos[2]);
        if (i != 2 && i != 3) {
            return false;
        }
        final int j = this.func_524_a(ai, ai2);
        if (j == -1) {
            return true;
        }
        if (j < 6) {
            return false;
        }
        this.field_878_e = j;
        return true;
    }
    
    @Override
    public void func_517_a(final double d, final double d1, final double d2) {
        this.field_748_m = (int)(d * 12.0);
        if (d > 0.5) {
            this.field_747_n = 5;
        }
        this.field_751_j = d1;
        this.field_750_k = d2;
    }
    
    @Override
    public boolean generate(final World world, final Random random, final int i, final int j, final int k) {
        this.worldObj = world;
        final long l = random.nextLong();
        this.random0.setSeed(l);
        this.basePos[0] = i;
        this.basePos[1] = j;
        this.basePos[2] = k;
        if (this.field_878_e == 0) {
            this.field_878_e = 5 + this.random0.nextInt(this.field_748_m);
        }
        if (!this.func_519_e()) {
            return false;
        }
        this.generate();
        this.func_518_b();
        this.func_529_c();
        this.func_525_d();
        return true;
    }
}
