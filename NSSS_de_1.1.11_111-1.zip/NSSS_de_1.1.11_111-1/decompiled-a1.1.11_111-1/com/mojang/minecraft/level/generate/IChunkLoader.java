package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.chunk.*;
import java.io.*;

public interface IChunkLoader
{
    Chunk loadChunkFromFile(final World p0, final int p1, final int p2) throws IOException;
    
    void saveChunk(final World p0, final Chunk p1) throws IOException;
    
    void saveExtraChunkData(final World p0, final Chunk p1) throws IOException;
    
    void func_814_a();
    
    void saveExtraData();
}
