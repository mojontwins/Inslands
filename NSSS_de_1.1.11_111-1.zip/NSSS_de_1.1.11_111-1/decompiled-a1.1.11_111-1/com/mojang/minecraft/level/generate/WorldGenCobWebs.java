package com.mojang.minecraft.level.generate;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.*;

public class WorldGenCobWebs extends WorldGenerator
{
    @Override
    public boolean generate(final World world, final Random random, final int x, final int y, final int z) {
        if (world.getBlockId(x, y, z) != 0 || world.getBlockId(x, y + 1, z) != Block.stone.blockID) {
            return false;
        }
        world.setBlockWithNotify(x, y, z, Block.web.blockID);
        return true;
    }
}
