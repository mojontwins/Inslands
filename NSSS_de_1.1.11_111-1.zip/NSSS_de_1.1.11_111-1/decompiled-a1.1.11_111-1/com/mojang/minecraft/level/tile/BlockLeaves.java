package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;

public class BlockLeaves extends BlockLeavesBase
{
    public static final int radius = 4;
    private int field_463_b;
    private boolean passThrough;
    
    protected BlockLeaves(final int i, final int j) {
        super(i, j, Material.leaves, 0);
        this.field_463_b = j;
        this.setTickOnLoad(true);
        this.passThrough = false;
    }
    
    public boolean getConnectLog(final World world, final int x, final int y, final int z) {
        for (int x2 = x - 4; x2 <= x + 4; ++x2) {
            for (int z2 = z - 4; z2 <= z + 4; ++z2) {
                for (int y2 = y - 4; y2 <= y + 4; ++y2) {
                    if (world.getBlockId(x2, y2, z2) == Block.wood.blockID || world.getBlockId(x2, y2, z2) == Block.brickMossy.blockID) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.multiplayerWorld) {
            return;
        }
        if (!this.getConnectLog(world, i, j, k)) {
            world.setBlockWithNotify(i, j, k, 0);
            if (random.nextInt(10) == 0) {
                if (world.multiplayerWorld) {
                    return;
                }
                final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Block.sapling));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
            if (random.nextInt(128) == 0) {
                if (world.multiplayerWorld) {
                    return;
                }
                final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.appleRed));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
            if (random.nextInt(10000) == 0) {
                if (world.multiplayerWorld) {
                    return;
                }
                final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.appleGold));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return 0;
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l) {
        super.dropBlockAsItemWithChance(world, i, j, k, l);
        if (world.multiplayerWorld) {
            return;
        }
        final Random random = new Random();
        if (random.nextInt(10) == 0) {
            final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Block.sapling));
            entityitem.delayBeforeCanPickup = 10;
            world.entityJoinedWorld(entityitem);
        }
        if (random.nextInt(128) == 0) {
            final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.appleRed));
            entityitem.delayBeforeCanPickup = 10;
            world.entityJoinedWorld(entityitem);
        }
        if (random.nextInt(10000) == 0) {
            final EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.appleGold));
            entityitem.delayBeforeCanPickup = 10;
            world.entityJoinedWorld(entityitem);
        }
    }
    
    public void setFastOrFancy(final int level) {
        this.graphicsLevel = level;
        this.blockIndexInTexture = this.field_463_b + ((level == 0) ? 1 : 0);
    }
}
