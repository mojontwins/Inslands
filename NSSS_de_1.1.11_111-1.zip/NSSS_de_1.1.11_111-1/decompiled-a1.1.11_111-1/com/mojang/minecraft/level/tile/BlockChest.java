package com.mojang.minecraft.level.tile;

import java.util.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.player.inventory.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockChest extends BlockContainer
{
    private Random field_457_a;
    
    protected BlockChest(final int i) {
        super(i, Material.wood);
        this.field_457_a = new Random();
        this.blockIndexInTexture = 26;
    }
    
    @Override
    public int getTextureIndex(final IBlockAccess iblockaccess, final int x, final int y, final int z, final int meta) {
        final int leftHalf = 57;
        final int rightHalf = 58;
        final int middle = 30;
        if (meta == 1) {
            return this.blockIndexInTexture - 1;
        }
        if (meta == 0) {
            return this.blockIndexInTexture - 1;
        }
        final int blockEast = iblockaccess.getBlockId(x, y, z - 1);
        final int blockWest = iblockaccess.getBlockId(x, y, z + 1);
        final int blockNorth = iblockaccess.getBlockId(x - 1, y, z);
        final int blockSouth = iblockaccess.getBlockId(x + 1, y, z);
        final int blockEaster = iblockaccess.getBlockId(x, y, z - 2);
        final int blockWester = iblockaccess.getBlockId(x, y, z + 2);
        final int blockNorther = iblockaccess.getBlockId(x - 2, y, z);
        final int blockSouther = iblockaccess.getBlockId(x + 2, y, z);
        if (blockWest == this.blockID && blockWester == this.blockID) {
            if (meta == 2) {
                return this.blockIndexInTexture;
            }
            if (meta == 3) {
                return this.blockIndexInTexture;
            }
            if (meta == 4) {
                return leftHalf;
            }
            if (meta == 5) {
                return rightHalf;
            }
        }
        if (blockNorth == this.blockID && blockNorther == this.blockID) {
            if (meta == 2) {
                return leftHalf;
            }
            if (meta == 3) {
                return rightHalf;
            }
            if (meta == 4) {
                return this.blockIndexInTexture;
            }
            if (meta == 5) {
                return this.blockIndexInTexture;
            }
        }
        if (blockEast == this.blockID && blockEaster == this.blockID) {
            if (meta == 2) {
                return this.blockIndexInTexture;
            }
            if (meta == 3) {
                return this.blockIndexInTexture;
            }
            if (meta == 4) {
                return rightHalf;
            }
            if (meta == 5) {
                return leftHalf;
            }
        }
        if (blockSouth == this.blockID && blockSouther == this.blockID) {
            if (meta == 2) {
                return rightHalf;
            }
            if (meta == 3) {
                return leftHalf;
            }
            if (meta == 4) {
                return this.blockIndexInTexture;
            }
            if (meta == 5) {
                return this.blockIndexInTexture;
            }
        }
        if (blockEast == this.blockID && blockWest == this.blockID) {
            byte byte0 = 3;
            if (Block.opaqueCubeLookup[blockEast] && !Block.opaqueCubeLookup[blockWest]) {
                byte0 = 3;
            }
            if (Block.opaqueCubeLookup[blockWest] && !Block.opaqueCubeLookup[blockEast]) {
                byte0 = 2;
            }
            if (Block.opaqueCubeLookup[blockNorth] && !Block.opaqueCubeLookup[blockSouth]) {
                byte0 = 5;
            }
            if (Block.opaqueCubeLookup[blockSouth] && !Block.opaqueCubeLookup[blockNorth]) {
                byte0 = 4;
            }
            return (meta != byte0) ? this.blockIndexInTexture : middle;
        }
        if (blockNorth == this.blockID && blockSouth == this.blockID) {
            byte byte0 = 3;
            if (Block.opaqueCubeLookup[blockEast] && !Block.opaqueCubeLookup[blockWest]) {
                byte0 = 3;
            }
            if (Block.opaqueCubeLookup[blockWest] && !Block.opaqueCubeLookup[blockEast]) {
                byte0 = 2;
            }
            if (Block.opaqueCubeLookup[blockNorth] && !Block.opaqueCubeLookup[blockSouth]) {
                byte0 = 5;
            }
            if (Block.opaqueCubeLookup[blockSouth] && !Block.opaqueCubeLookup[blockNorth]) {
                byte0 = 4;
            }
            return (meta != byte0) ? this.blockIndexInTexture : middle;
        }
        if (blockEast == this.blockID || blockWest == this.blockID) {
            if (meta == 2 || meta == 3) {
                return this.blockIndexInTexture;
            }
            int i2 = 0;
            if (blockEast == this.blockID) {
                i2 = -1;
            }
            final int k2 = iblockaccess.getBlockId(x - 1, y, (blockEast != this.blockID) ? (z + 1) : (z - 1));
            final int i3 = iblockaccess.getBlockId(x + 1, y, (blockEast != this.blockID) ? (z + 1) : (z - 1));
            if (meta == 4) {
                i2 = -1 - i2;
            }
            byte byte2 = 5;
            if ((Block.opaqueCubeLookup[blockNorth] || Block.opaqueCubeLookup[k2]) && !Block.opaqueCubeLookup[blockSouth] && !Block.opaqueCubeLookup[i3]) {
                byte2 = 5;
            }
            if ((Block.opaqueCubeLookup[blockSouth] || Block.opaqueCubeLookup[i3]) && !Block.opaqueCubeLookup[blockNorth] && !Block.opaqueCubeLookup[k2]) {
                byte2 = 4;
            }
            return ((meta != byte2) ? (this.blockIndexInTexture + 32) : (this.blockIndexInTexture + 16)) + i2;
        }
        else {
            if (blockNorth != this.blockID && blockSouth != this.blockID) {
                byte byte0 = 3;
                if (Block.opaqueCubeLookup[blockEast] && !Block.opaqueCubeLookup[blockWest]) {
                    byte0 = 3;
                }
                if (Block.opaqueCubeLookup[blockWest] && !Block.opaqueCubeLookup[blockEast]) {
                    byte0 = 2;
                }
                if (Block.opaqueCubeLookup[blockNorth] && !Block.opaqueCubeLookup[blockSouth]) {
                    byte0 = 5;
                }
                if (Block.opaqueCubeLookup[blockSouth] && !Block.opaqueCubeLookup[blockNorth]) {
                    byte0 = 4;
                }
                return (meta != byte0) ? this.blockIndexInTexture : (this.blockIndexInTexture + 1);
            }
            if (meta == 4 || meta == 5) {
                return this.blockIndexInTexture;
            }
            int j2 = 0;
            if (blockNorth == this.blockID) {
                j2 = -1;
            }
            final int l2 = iblockaccess.getBlockId((blockNorth != this.blockID) ? (x + 1) : (x - 1), y, z - 1);
            final int j3 = iblockaccess.getBlockId((blockNorth != this.blockID) ? (x + 1) : (x - 1), y, z + 1);
            if (meta == 3) {
                j2 = -1 - j2;
            }
            byte byte3 = 3;
            if ((Block.opaqueCubeLookup[blockEast] || Block.opaqueCubeLookup[l2]) && !Block.opaqueCubeLookup[blockWest] && !Block.opaqueCubeLookup[j3]) {
                byte3 = 3;
            }
            if ((Block.opaqueCubeLookup[blockWest] || Block.opaqueCubeLookup[j3]) && !Block.opaqueCubeLookup[blockEast] && !Block.opaqueCubeLookup[l2]) {
                byte3 = 2;
            }
            return ((meta != byte3) ? (this.blockIndexInTexture + 32) : (this.blockIndexInTexture + 16)) + j2;
        }
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return this.blockIndexInTexture - 1;
        }
        if (i == 0) {
            return this.blockIndexInTexture - 1;
        }
        if (i == 3) {
            return this.blockIndexInTexture + 1;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        int l = 0;
        if (world.getBlockId(i - 1, j, k) == this.blockID) {
            ++l;
        }
        if (world.getBlockId(i + 1, j, k) == this.blockID) {
            ++l;
        }
        if (world.getBlockId(i, j, k - 1) == this.blockID) {
            ++l;
        }
        if (world.getBlockId(i, j, k + 1) == this.blockID) {
            ++l;
        }
        return l <= 1 && !this.isThereANeighborChest(world, i - 1, j, k) && !this.isThereANeighborChest(world, i + 1, j, k) && !this.isThereANeighborChest(world, i, j, k - 1) && !this.isThereANeighborChest(world, i, j, k + 1);
    }
    
    private boolean isThereANeighborChest(final World world, final int i, final int j, final int k) {
        return world.getBlockId(i, j, k) == this.blockID && (world.getBlockId(i - 1, j, k) == this.blockID || world.getBlockId(i + 1, j, k) == this.blockID || world.getBlockId(i, j, k - 1) == this.blockID || world.getBlockId(i, j, k + 1) == this.blockID);
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final TileEntityChest tileentitychest = (TileEntityChest)world.getBlockTileEntity(i, j, k);
        for (int l = 0; l < tileentitychest.getSizeInventory(); ++l) {
            final ItemStack itemstack = tileentitychest.getStackInSlot(l);
            if (itemstack != null) {
                final float f = this.field_457_a.nextFloat() * 0.8f + 0.1f;
                final float f2 = this.field_457_a.nextFloat() * 0.8f + 0.1f;
                final float f3 = this.field_457_a.nextFloat() * 0.8f + 0.1f;
                while (itemstack.stackSize > 0) {
                    int i2 = this.field_457_a.nextInt(21) + 10;
                    if (i2 > itemstack.stackSize) {
                        i2 = itemstack.stackSize;
                    }
                    final ItemStack itemStack = itemstack;
                    itemStack.stackSize -= i2;
                    final EntityItem entityitem = new EntityItem(world, i + f, j + f2, k + f3, new ItemStack(itemstack.itemID, i2, itemstack.itemDamage));
                    final float f4 = 0.05f;
                    entityitem.motionX = (float)this.field_457_a.nextGaussian() * f4;
                    entityitem.motionY = (float)this.field_457_a.nextGaussian() * f4 + 0.2f;
                    entityitem.motionZ = (float)this.field_457_a.nextGaussian() * f4;
                    world.entityJoinedWorld(entityitem);
                }
            }
        }
        super.onBlockRemoval(world, i, j, k);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        Object obj = world.getBlockTileEntity(i, j, k);
        if (world.isBlockNormalCube(i, j + 1, k)) {
            return true;
        }
        if (world.getBlockId(i - 1, j, k) == this.blockID && world.isBlockNormalCube(i - 1, j + 1, k)) {
            return true;
        }
        if (world.getBlockId(i + 1, j, k) == this.blockID && world.isBlockNormalCube(i + 1, j + 1, k)) {
            return true;
        }
        if (world.getBlockId(i, j, k - 1) == this.blockID && world.isBlockNormalCube(i, j + 1, k - 1)) {
            return true;
        }
        if (world.getBlockId(i, j, k + 1) == this.blockID && world.isBlockNormalCube(i, j + 1, k + 1)) {
            return true;
        }
        if (world.getBlockId(i - 1, j, k) == this.blockID) {
            obj = new InventoryLargeChest("Large chest", (IInventory)world.getBlockTileEntity(i - 1, j, k), (IInventory)obj);
        }
        if (world.getBlockId(i + 1, j, k) == this.blockID) {
            obj = new InventoryLargeChest("Large chest", (IInventory)obj, (IInventory)world.getBlockTileEntity(i + 1, j, k));
        }
        if (world.getBlockId(i, j, k - 1) == this.blockID) {
            obj = new InventoryLargeChest("Large chest", (IInventory)world.getBlockTileEntity(i, j, k - 1), (IInventory)obj);
        }
        if (world.getBlockId(i, j, k + 1) == this.blockID) {
            obj = new InventoryLargeChest("Large chest", (IInventory)obj, (IInventory)world.getBlockTileEntity(i, j, k + 1));
        }
        if (world.multiplayerWorld) {
            return true;
        }
        entityplayer.displayGUIChest((IInventory)obj);
        return true;
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityChest();
    }
}
