package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.item.*;

public class BlockBleedingObsidian extends Block
{
    protected BlockBleedingObsidian(final int i, final int j) {
        super(i, Material.rock);
        this.blockIndexInTexture = j;
    }
    
    @Override
    public boolean blockActivated(final World world, final int x, final int y, final int z, final EntityPlayer entityplayer) {
        if (entityplayer.getCurrentEquippedItem() != null && entityplayer.getCurrentEquippedItem().itemID == Item.compass.shiftedIndex) {
            world.spawnX = x;
            world.spawnY = y;
            world.spawnZ = z;
            if (!world.multiplayerWorld) {
                world.getWorldAccess(0).displayInfoGUI("You have set your spawn point to this block.");
            }
            for (int i = 0; i < 7; ++i) {
                final double d = x + world.rand.nextFloat();
                final double d2 = y + world.rand.nextFloat();
                final double d3 = z + world.rand.nextFloat();
                world.spawnParticle("largesmoke", d, d2, d3, 0.0, 0.0, 0.0);
            }
            world.playSoundEffect(x, y, z, "random.drr", 1.0f, 0.25f);
            world.playSoundEffect(x, y, z, "random.breath", 0.5f, 0.15f);
            return true;
        }
        return true;
    }
}
