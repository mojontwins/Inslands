package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.*;
import java.util.*;
import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockSnow extends Block
{
    protected BlockSnow(final int i, final int j) {
        super(i, j, Material.snow);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
        this.setTickOnLoad(true);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j - 1, k);
        return l != 0 && Block.allBlocks[l].isOpaqueCube() && world.getMaterialXYZ(i, j - 1, k).blocksMovement();
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        this.func_314_h(world, i, j, k);
    }
    
    private boolean func_314_h(final World world, final int i, final int j, final int k) {
        if (!this.canPlace(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void harvestBlock(final World world, final int i, final int j, final int k, final int l) {
        if (world.multiplayerWorld) {
            return;
        }
        final int i2 = Item.snowball.shiftedIndex;
        final float f = 0.7f;
        final double d = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final double d2 = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final double d3 = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final EntityItem entityitem = new EntityItem(world, i + d, j + d2, k + d3, new ItemStack(i2));
        entityitem.delayBeforeCanPickup = 10;
        world.entityJoinedWorld(entityitem);
        world.setBlockWithNotify(i, j, k, 0);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.snowball.shiftedIndex;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockLighting(EnumSkyBlock.Block, i, j, k) > 11) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        final Material material = iblockaccess.getMaterialXYZ(i, j, k);
        return l == 1 || (material != this.blockMaterial && super.shouldSideBeRendered(iblockaccess, i, j, k, l));
    }
}
