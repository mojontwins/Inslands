package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;

public class BlockGlass extends BlockBreakable
{
    public int chance;
    
    public BlockGlass(final int i, final int j, final Material material, final boolean flag) {
        super(i, j, material, flag);
        this.chance = 1;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    @Override
    public void goldTouch() {
        this.chance = 1;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.glass.blockID;
    }
}
