package com.mojang.minecraft.level.tile.fx;

public class TextureWaterOverlayFX extends TextureFX
{
    protected float[] field_1158_g;
    protected float[] field_1157_h;
    protected float[] field_1156_i;
    protected float[] field_1155_j;
    
    public TextureWaterOverlayFX() {
        super(0);
        this.field_1158_g = new float[256];
        this.field_1157_h = new float[256];
        this.field_1156_i = new float[256];
        this.field_1155_j = new float[256];
        this.tile = 3;
    }
    
    @Override
    public void render() {
        for (int i = 0; i < 16; ++i) {
            for (int k = 0; k < 16; ++k) {
                float f = 0.0f;
                for (int j1 = i - 1; j1 <= i + 1; ++j1) {
                    final int k2 = j1 & 0xF;
                    final int i2 = k & 0xF;
                    f += this.field_1158_g[k2 + i2 * 16];
                }
                this.field_1157_h[i + k * 16] = f / 3.3f + this.field_1156_i[i + k * 16] * 0.8f;
            }
        }
        for (int l = 0; l < 16; ++l) {
            for (int m = 0; m < 16; ++m) {
                final float[] field_1156_i = this.field_1156_i;
                final int n = l + m * 16;
                field_1156_i[n] += this.field_1155_j[l + m * 16] * 0.05f;
                if (this.field_1156_i[l + m * 16] < 0.0f) {
                    this.field_1156_i[l + m * 16] = 0.0f;
                }
                final float[] field_1155_j = this.field_1155_j;
                final int n2 = l + m * 16;
                field_1155_j[n2] -= 0.1f;
                if (Math.random() < 0.05) {
                    this.field_1155_j[l + m * 16] = 0.5f;
                }
            }
        }
        final float[] af = this.field_1157_h;
        this.field_1157_h = this.field_1158_g;
        this.field_1158_g = af;
        for (int i3 = 0; i3 < 256; ++i3) {
            float f2 = this.field_1158_g[i3];
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            final float f3 = f2 * f2;
            int l2 = (int)(32.0f + f3 * 32.0f);
            int j2 = (int)(50.0f + f3 * 64.0f);
            int k3 = 255;
            final int l3 = (int)(146.0f + f3 * 50.0f);
            if (this.field_1131_c) {
                final int i4 = (l2 * 30 + j2 * 59 + k3 * 11) / 100;
                final int j3 = (l2 * 30 + j2 * 70) / 100;
                final int k4 = (l2 * 30 + k3 * 70) / 100;
                l2 = i4;
                j2 = j3;
                k3 = k4;
            }
            this.field_1127_a[i3 * 4 + 0] = (byte)l2;
            this.field_1127_a[i3 * 4 + 1] = (byte)j2;
            this.field_1127_a[i3 * 4 + 2] = (byte)k3;
            this.field_1127_a[i3 * 4 + 3] = (byte)l3;
        }
    }
}
