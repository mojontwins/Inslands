package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;

public class BlockLog extends Block
{
    protected BlockLog(final int i) {
        super(i, Material.wood);
        this.blockIndexInTexture = 20;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.wood.blockID;
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return 21;
        }
        return (i != 0) ? 20 : 21;
    }
}
