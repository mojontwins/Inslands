package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.*;
import javax.imageio.*;
import java.io.*;
import com.mojang.minecraft.util.*;

public class TextureGearFX extends TextureFX
{
    private int tickCounter;
    private int[] gear;
    private int[] gearMiddle;
    private int h;
    
    public TextureGearFX(final int n) {
        super(Block.gear.blockIndexInTexture + n);
        this.tickCounter = 0;
        this.gear = new int[1024];
        this.gearMiddle = new int[1024];
        this.h = (n << 1) - 1;
        this.tickCounter = 2;
        try {
            ImageIO.read(Minecraft.class.getResource("/misc/gear.png")).getRGB(0, 0, 32, 32, this.gear, 0, 32);
            ImageIO.read(Minecraft.class.getResource("/misc/gearmiddle.png")).getRGB(0, 0, 16, 16, this.gearMiddle, 0, 16);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public final void render() {
        this.tickCounter = (this.tickCounter + this.h & 0x3F);
        final float a = MathHelper.sin(this.tickCounter / 64.0f * 3.1415927f * 2.0f);
        final float b = MathHelper.cos(this.tickCounter / 64.0f * 3.1415927f * 2.0f);
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                float n = (i / 15.0f - 0.5f) * 31.0f;
                final float n2 = (j / 15.0f - 0.5f) * 31.0f;
                final float n3 = b * n - a * n2;
                n = b * n2 + a * n;
                int n4 = (int)(n3 + 16.0f);
                int n5 = (int)(n + 16.0f);
                int n6 = 0;
                if (n4 >= 0 && n5 >= 0 && n4 < 32 && n5 < 32) {
                    n6 = this.gear[n4 + (n5 << 5)];
                    if ((n5 = this.gearMiddle[i + (j << 4)]) >>> 24 > 128) {
                        n6 = n5;
                    }
                }
                n5 = (n6 >> 16 & 0xFF);
                n4 = (n6 >> 8 & 0xFF);
                final int n7 = n6 & 0xFF;
                n6 = ((n6 >>> 24 > 128) ? 255 : 0);
                final int n8 = i + (j << 4);
                this.field_1127_a[n8 << 2] = (byte)n5;
                this.field_1127_a[(n8 << 2) + 1] = (byte)n4;
                this.field_1127_a[(n8 << 2) + 2] = (byte)n7;
                this.field_1127_a[(n8 << 2) + 3] = (byte)n6;
            }
        }
    }
}
