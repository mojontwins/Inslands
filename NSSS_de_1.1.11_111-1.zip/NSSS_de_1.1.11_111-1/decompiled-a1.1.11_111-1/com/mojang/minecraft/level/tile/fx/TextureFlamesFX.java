package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.level.tile.*;

public class TextureFlamesFX extends TextureFX
{
    protected float[] field_1133_g;
    protected float[] field_1132_h;
    
    public TextureFlamesFX(final int i) {
        super(Block.fire.blockIndexInTexture + i * 16);
        this.field_1133_g = new float[320];
        this.field_1132_h = new float[320];
    }
    
    @Override
    public void render() {
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 20; ++j) {
                int l = 18;
                float f1 = this.field_1133_g[i + (j + 1) % 20 * 16] * l;
                for (int i2 = i - 1; i2 <= i + 1; ++i2) {
                    for (int k1 = j; k1 <= j + 1; ++k1) {
                        final int i3 = i2;
                        final int k2 = k1;
                        if (i3 >= 0 && k2 >= 0 && i3 < 16 && k2 < 20) {
                            f1 += this.field_1133_g[i3 + k2 * 16];
                        }
                        ++l;
                    }
                }
                this.field_1132_h[i + j * 16] = f1 / (l * 1.06f);
                if (j >= 19) {
                    this.field_1132_h[i + j * 16] = (float)(Math.random() * Math.random() * Math.random() * 4.0 + Math.random() * 0.10000000149011612 + 0.20000000298023224);
                }
            }
        }
        final float[] af = this.field_1132_h;
        this.field_1132_h = this.field_1133_g;
        this.field_1133_g = af;
        for (int m = 0; m < 256; ++m) {
            float f2 = this.field_1133_g[m] * 1.8f;
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            float f3 = f2;
            int j2 = (int)(f3 * 155.0f + 100.0f);
            int l2 = (int)(f3 * f3 * 255.0f);
            int j3 = (int)(f3 * f3 * f3 * f3 * f3 * f3 * f3 * f3 * f3 * f3 * 255.0f);
            char c = '\u00ff';
            if (f3 < 0.5f) {
                c = '\0';
            }
            f3 = (f3 - 0.5f) * 2.0f;
            if (this.field_1131_c) {
                final int l3 = (j2 * 30 + l2 * 59 + j3 * 11) / 100;
                final int i4 = (j2 * 30 + l2 * 70) / 100;
                final int j4 = (j2 * 30 + j3 * 70) / 100;
                j2 = l3;
                l2 = i4;
                j3 = j4;
            }
            this.field_1127_a[m * 4 + 0] = (byte)j2;
            this.field_1127_a[m * 4 + 1] = (byte)l2;
            this.field_1127_a[m * 4 + 2] = (byte)j3;
            this.field_1127_a[m * 4 + 3] = (byte)c;
        }
    }
}
