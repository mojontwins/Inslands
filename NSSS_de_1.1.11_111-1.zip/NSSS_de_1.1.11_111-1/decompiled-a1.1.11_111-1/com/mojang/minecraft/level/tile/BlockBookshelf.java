package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;

public class BlockBookshelf extends Block
{
    public BlockBookshelf(final int i, final int j) {
        super(i, j, Material.wood);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i <= 1) {
            return 4;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
}
