package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockFlowing extends BlockFluids
{
    int field_460_a;
    boolean[] field_459_b;
    int[] field_461_c;
    
    protected BlockFlowing(final int i, final Material material) {
        super(i, material);
        this.field_460_a = 0;
        this.field_459_b = new boolean[4];
        this.field_461_c = new int[4];
    }
    
    private void func_294_j(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        world.setBlockAndMetadata(i, j, k, this.blockID + 1, l);
        world.markBlocksDirty(i, j, k, i, j, k);
        world.markBlockNeedsUpdate(i, j, k);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        return this.blockIndexInTexture + 1;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        int l = this.func_290_h(world, i, j, k);
        boolean flag = true;
        if (l > 0) {
            int i2 = -100;
            this.field_460_a = 0;
            i2 = this.func_296_f(world, i - 1, j, k, i2);
            i2 = this.func_296_f(world, i + 1, j, k, i2);
            i2 = this.func_296_f(world, i, j, k - 1, i2);
            i2 = this.func_296_f(world, i, j, k + 1, i2);
            int j2 = i2 + this.field_458_d;
            if (j2 >= 8 || i2 < 0) {
                j2 = -1;
            }
            if (this.func_290_h(world, i, j + 1, k) >= 0) {
                final int l2 = this.func_290_h(world, i, j + 1, k);
                if (l2 >= 8) {
                    j2 = l2;
                }
                else {
                    j2 = l2 + 8;
                }
            }
            if (this.field_460_a >= 2 && this.blockMaterial == Material.water) {
                if (world.isBlockNormalCube(i, j - 1, k) || world.isWater(i, j - 1, k)) {
                    j2 = 0;
                }
                else if (world.getMaterialXYZ(i, j - 1, k) == this.blockMaterial && world.getBlockMetadata(i, j, k) == 0 && !BlockSponge.getSurroundSponge(world, i, j, k)) {
                    j2 = 0;
                }
            }
            if (this.blockMaterial == Material.lava && l < 8 && j2 < 8 && j2 > l && random.nextInt(4) != 0) {
                j2 = l;
                flag = false;
            }
            if (j2 != l) {
                l = j2;
                if (l < 0) {
                    world.setBlockWithNotify(i, j, k, 0);
                }
                else {
                    world.setBlockMetadataWithNotify(i, j, k, l);
                    world.scheduleUpdateTick(i, j, k, this.blockID);
                    world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
                }
            }
            else if (flag) {
                this.func_294_j(world, i, j, k);
            }
        }
        else {
            this.func_294_j(world, i, j, k);
        }
        if (this.liquidCanDisplaceBlock(world, i, j - 1, k)) {
            if (l >= 8) {
                world.setBlockAndMetadataWithNotify(i, j - 1, k, this.blockID, l);
            }
            else {
                world.setBlockAndMetadataWithNotify(i, j - 1, k, this.blockID, l + 8);
            }
        }
        else if (l >= 0 && (l == 0 || this.func_295_l(world, i, j - 1, k))) {
            final boolean[] aflag = this.func_297_k(world, i, j, k);
            int k2 = l + this.field_458_d;
            if (l >= 8) {
                k2 = 1;
            }
            if (k2 >= 8) {
                return;
            }
            if (aflag[0]) {
                this.flowIntoBlock(world, i - 1, j, k, k2);
            }
            if (aflag[1]) {
                this.flowIntoBlock(world, i + 1, j, k, k2);
            }
            if (aflag[2]) {
                this.flowIntoBlock(world, i, j, k - 1, k2);
            }
            if (aflag[3]) {
                this.flowIntoBlock(world, i, j, k + 1, k2);
            }
        }
    }
    
    private void flowIntoBlock(final World world, final int i, final int j, final int k, final int l) {
        if (this.liquidCanDisplaceBlock(world, i, j, k)) {
            final int i2 = world.getBlockId(i, j, k);
            if (i2 > 0) {
                if (this.blockMaterial == Material.lava) {
                    this.triggerLavaMixEffects(world, i, j, k);
                }
                else {
                    Block.allBlocks[i2].dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
                }
            }
            world.setBlockAndMetadataWithNotify(i, j, k, this.blockID, l);
        }
    }
    
    private int calculateFlowCost(final World world, final int i, final int j, final int k, final int l, final int i1) {
        int j2 = 1000;
        for (int k2 = 0; k2 < 4; ++k2) {
            if ((k2 != 0 || i1 != 1) && (k2 != 1 || i1 != 0) && (k2 != 2 || i1 != 3)) {
                if (k2 != 3 || i1 != 2) {
                    int l2 = i;
                    final int i2 = j;
                    int j3 = k;
                    if (k2 == 0) {
                        --l2;
                    }
                    if (k2 == 1) {
                        ++l2;
                    }
                    if (k2 == 2) {
                        --j3;
                    }
                    if (k2 == 3) {
                        ++j3;
                    }
                    if (!this.func_295_l(world, l2, i2, j3)) {
                        if (world.getMaterialXYZ(l2, i2, j3) != this.blockMaterial || world.getBlockMetadata(l2, i2, j3) != 0) {
                            if (!this.func_295_l(world, l2, i2 - 1, j3)) {
                                return l;
                            }
                            if (l < 4) {
                                final int k3 = this.calculateFlowCost(world, l2, i2, j3, l + 1, k2);
                                if (k3 < j2) {
                                    j2 = k3;
                                }
                            }
                        }
                    }
                }
            }
        }
        return j2;
    }
    
    private boolean[] func_297_k(final World world, final int i, final int j, final int k) {
        for (int l = 0; l < 4; ++l) {
            this.field_461_c[l] = 1000;
            int j2 = i;
            final int i2 = j;
            int j3 = k;
            if (l == 0) {
                --j2;
            }
            if (l == 1) {
                ++j2;
            }
            if (l == 2) {
                --j3;
            }
            if (l == 3) {
                ++j3;
            }
            if (!this.func_295_l(world, j2, i2, j3)) {
                if (world.getMaterialXYZ(j2, i2, j3) != this.blockMaterial || world.getBlockMetadata(j2, i2, j3) != 0) {
                    if (!this.func_295_l(world, j2, i2 - 1, j3)) {
                        this.field_461_c[l] = 0;
                    }
                    else {
                        this.field_461_c[l] = this.calculateFlowCost(world, j2, i2, j3, 1, l);
                    }
                }
            }
        }
        int i3 = this.field_461_c[0];
        for (int k2 = 1; k2 < 4; ++k2) {
            if (this.field_461_c[k2] < i3) {
                i3 = this.field_461_c[k2];
            }
        }
        for (int l2 = 0; l2 < 4; ++l2) {
            this.field_459_b[l2] = (this.field_461_c[l2] == i3);
        }
        return this.field_459_b;
    }
    
    private boolean func_295_l(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j, k);
        if (l == Block.doorWood.blockID || BlockSponge.getSurroundSponge(world, i, j, k) || l == Block.doorSteel.blockID || l == Block.signPost.blockID || l == Block.ladder.blockID || l == Block.reed.blockID) {
            return true;
        }
        if (l == 0) {
            return false;
        }
        final Material material = Block.allBlocks[l].blockMaterial;
        return material.isSolidMaterial();
    }
    
    protected int func_296_f(final World world, final int i, final int j, final int k, final int l) {
        int i2 = this.func_290_h(world, i, j, k);
        if (i2 < 0) {
            return l;
        }
        if (i2 == 0) {
            ++this.field_460_a;
        }
        if (i2 >= 8) {
            i2 = 0;
        }
        return (l >= 0 && i2 >= l) ? l : i2;
    }
    
    private boolean liquidCanDisplaceBlock(final World world, final int i, final int j, final int k) {
        final Material material = world.getMaterialXYZ(i, j, k);
        return material != this.blockMaterial && material != Material.lava && !this.func_295_l(world, i, j, k);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
        if (world.getBlockId(i, j, k) == this.blockID) {
            world.scheduleUpdateTick(i, j, k, this.blockID);
        }
    }
}
