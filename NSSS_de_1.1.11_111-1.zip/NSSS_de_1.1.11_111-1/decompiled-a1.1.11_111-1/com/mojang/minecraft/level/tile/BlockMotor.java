package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockMotor extends BlockContainer
{
    private boolean isMotor;
    private boolean isPowered;
    private int powerLimit;
    
    protected BlockMotor(final int i, final int j, final Material material1, final boolean isMtr, final int limit) {
        super(i, j, material1);
        this.isMotor = isMtr;
        this.powerLimit = limit;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        final TileEntityMotor motorEntity = (TileEntityMotor)world.getBlockTileEntity(i, j, k);
        motorEntity.onUpdated(world);
        if (this.isMotor) {
            if (l > 0 && Block.allBlocks[l].canProvidePower() && world.isBlockIndirectlyGettingPowered(i, j, k)) {
                this.applyPower(world, i, j, k);
            }
            else {
                this.removePower(world, i, j, k);
            }
        }
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        world.func_654_a(i, j, k, this.getBlockEntity());
        this.onNeighborBlockChange(world, i, j, k, 0);
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final TileEntityMotor motorEntity = (TileEntityMotor)world.getBlockTileEntity(i, j, k);
        motorEntity.onRemoved(world);
        if (this.isPowered) {
            this.removePower(world, i, j, k);
        }
    }
    
    public boolean checkPower(final World world, final int i, final int j, final int k) {
        final TileEntityGear gearEntity = world.getGearAt(i, j, k);
        return world.checkGearPower(gearEntity);
    }
    
    public void applyPower(final World world, final int i, final int j, final int k) {
        final TileEntityGear gearEntity = world.getGearAt(i, j, k);
        System.out.println(world.applyGearPower(gearEntity, this.powerLimit));
        this.isPowered = true;
    }
    
    public void removePower(final World world, final int i, final int j, final int k) {
        final TileEntityGear gearEntity = world.getGearAt(i, j, k);
        System.out.println(world.removeGearPower(gearEntity, this.powerLimit));
        this.isPowered = false;
    }
    
    @Override
    public final boolean canProvidePower() {
        return !this.isMotor;
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (this.checkPower((World)iblockaccess, i, j, k) && !this.isMotor) {
            ((World)iblockaccess).markBlocksDirty(i, j, k, i, j, k);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        if (this.checkPower(world, i, j, k) && !this.isMotor) {
            world.markBlocksDirty(i, j, k, i, j, k);
        }
        return true;
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityMotor();
    }
}
