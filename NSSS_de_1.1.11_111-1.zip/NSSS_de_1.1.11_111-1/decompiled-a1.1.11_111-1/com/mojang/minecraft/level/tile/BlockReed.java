package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.item.*;

public class BlockReed extends Block
{
    protected BlockReed(final int i, final int j) {
        super(i, Material.plants);
        this.blockIndexInTexture = j;
        final float f = 0.375f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, 1.0f, 0.5f + f);
        this.setTickOnLoad(true);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockId(i, j + 1, k) == 0) {
            int l;
            for (l = 1; world.getBlockId(i, j - l, k) == this.blockID; ++l) {}
            if (l < 3) {
                final int i2 = world.getBlockMetadata(i, j, k);
                if (i2 == 15) {
                    world.setBlockWithNotify(i, j + 1, k, this.blockID);
                    world.setBlockMetadataWithNotify(i, j, k, 0);
                }
                else {
                    world.setBlockMetadataWithNotify(i, j, k, i2 + 1);
                }
            }
        }
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j - 1, k);
        return l == this.blockID || ((l == Block.grass.blockID || l == Block.dirt.blockID) && (world.getMaterialXYZ(i - 1, j - 1, k) == Material.water || world.getMaterialXYZ(i + 1, j - 1, k) == Material.water || world.getMaterialXYZ(i, j - 1, k - 1) == Material.water || world.getMaterialXYZ(i, j - 1, k + 1) == Material.water));
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        this.func_303_h(world, i, j, k);
    }
    
    protected final void func_303_h(final World world, final int i, final int j, final int k) {
        if (!this.canBlockStay(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public boolean canBlockStay(final World world, final int i, final int j, final int k) {
        return this.canPlace(world, i, j, k);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.reed.shiftedIndex;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 1;
    }
}
