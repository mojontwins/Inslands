package com.mojang.minecraft.level.tile;

class RedstoneUpdateInfo
{
    int x;
    int y;
    int z;
    long field_1010_d;
    
    public RedstoneUpdateInfo(final int i, final int j, final int k, final long l) {
        this.x = i;
        this.y = j;
        this.z = k;
        this.field_1010_d = l;
    }
}
