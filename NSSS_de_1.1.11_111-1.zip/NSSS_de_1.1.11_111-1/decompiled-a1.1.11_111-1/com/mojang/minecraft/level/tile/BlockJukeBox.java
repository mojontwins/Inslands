package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.*;

public class BlockJukeBox extends Block
{
    protected BlockJukeBox(final int i, final int j) {
        super(i, j, Material.wood);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        return this.blockIndexInTexture + ((i == 1) ? 1 : 0);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        final int l = world.getBlockMetadata(i, j, k);
        if (l > 0) {
            this.ejectRecord(world, i, j, k, l);
            return true;
        }
        return false;
    }
    
    public void ejectRecord(final World world, final int i, final int j, final int k, final int l) {
        world.playRecord(null, i, j, k);
        if (!world.multiplayerWorld) {
            world.setBlockMetadataWithNotify(i, j, k, 0);
            final int i2 = Item.record13.shiftedIndex + l - 1;
            final float f = 0.7f;
            final double d = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
            final double d2 = world.rand.nextFloat() * f + (1.0f - f) * 0.2 + 0.6;
            final double d3 = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
            final EntityItem entityitem = new EntityItem(world, i + d, j + d2, k + d3, new ItemStack(i2));
            entityitem.delayBeforeCanPickup = 10;
            world.entityJoinedWorld(entityitem);
        }
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l, final float f) {
        if (world.multiplayerWorld) {
            return;
        }
        if (l > 0) {
            this.ejectRecord(world, i, j, k, l);
        }
        super.dropBlockAsItemWithChance(world, i, j, k, l, f);
    }
}
