package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.*;

public class BlockCrops extends BlockFlower
{
    protected BlockCrops(final int i, final int j) {
        super(i, j);
        this.blockIndexInTexture = j;
        this.setTickOnLoad(true);
        final float f = 0.5f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, 0.25f, 0.5f + f);
    }
    
    @Override
    protected boolean canThisPlantGrowOnThisBlockID(final int i) {
        return i == Block.tilledField.blockID;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        super.updateTick(world, i, j, k, random);
        if (world.getBlockLightValue(i, j + 1, k) >= 9) {
            int l = world.getBlockMetadata(i, j, k);
            if (l < 7) {
                final float f = this.getGrowthRate(world, i, j, k);
                if (random.nextInt((int)(100.0f / f)) == 0) {
                    ++l;
                    world.setBlockMetadataWithNotify(i, j, k, l);
                }
            }
        }
    }
    
    public void fertilize(final World world, final int i, final int j, final int k) {
        world.setBlockMetadataWithNotify(i, j, k, 7);
    }
    
    private float getGrowthRate(final World world, final int i, final int j, final int k) {
        float f = 1.0f;
        final int l = world.getBlockId(i, j, k - 1);
        final int i2 = world.getBlockId(i, j, k + 1);
        final int j2 = world.getBlockId(i - 1, j, k);
        final int k2 = world.getBlockId(i + 1, j, k);
        final int l2 = world.getBlockId(i - 1, j, k - 1);
        final int i3 = world.getBlockId(i + 1, j, k - 1);
        final int j3 = world.getBlockId(i + 1, j, k + 1);
        final int k3 = world.getBlockId(i - 1, j, k + 1);
        final boolean flag = j2 == this.blockID || k2 == this.blockID;
        final boolean flag2 = l == this.blockID || i2 == this.blockID;
        final boolean flag3 = l2 == this.blockID || i3 == this.blockID || j3 == this.blockID || k3 == this.blockID;
        for (int l3 = i - 1; l3 <= i + 1; ++l3) {
            for (int i4 = k - 1; i4 <= k + 1; ++i4) {
                final int j4 = world.getBlockId(l3, j - 1, i4);
                float f2 = 0.0f;
                if (j4 == Block.tilledField.blockID) {
                    f2 = 1.0f;
                    if (world.getBlockMetadata(l3, j - 1, i4) > 0) {
                        f2 = 3.0f;
                    }
                }
                if (l3 != i || i4 != k) {
                    f2 /= 4.0f;
                }
                f += f2;
            }
        }
        if (flag3 || (flag && flag2)) {
            f /= 2.0f;
        }
        return f;
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, int j) {
        if (j < 0) {
            j = 7;
        }
        return this.blockIndexInTexture + j;
    }
    
    @Override
    public int getRenderType() {
        return 6;
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l) {
        super.dropBlockAsItemWithChance(world, i, j, k, l);
        if (world.multiplayerWorld) {
            return;
        }
        for (int i2 = 0; i2 < 3; ++i2) {
            if (world.rand.nextInt(15) <= l) {
                final float f = 0.7f;
                final float f2 = world.rand.nextFloat() * f + (1.0f - f) * 0.5f;
                final float f3 = world.rand.nextFloat() * f + (1.0f - f) * 0.5f;
                final float f4 = world.rand.nextFloat() * f + (1.0f - f) * 0.5f;
                final EntityItem entityitem = new EntityItem(world, i + f2, j + f3, k + f4, new ItemStack(Item.seeds));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
        }
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l, final float f) {
        super.dropBlockAsItemWithChance(world, i, j, k, l, f);
        if (world.multiplayerWorld) {
            return;
        }
        for (int i2 = 0; i2 < 3; ++i2) {
            if (world.rand.nextInt(15) <= l) {
                final float f2 = 0.7f;
                final float f3 = world.rand.nextFloat() * f2 + (1.0f - f2) * 0.5f;
                final float f4 = world.rand.nextFloat() * f2 + (1.0f - f2) * 0.5f;
                final float f5 = world.rand.nextFloat() * f2 + (1.0f - f2) * 0.5f;
                final EntityItem entityitem = new EntityItem(world, i + f3, j + f4, k + f5, new ItemStack(Item.seeds));
                entityitem.delayBeforeCanPickup = 10;
                world.entityJoinedWorld(entityitem);
            }
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        System.out.println("Get resource: " + i);
        if (i == 7) {
            return Item.wheat.shiftedIndex;
        }
        return -1;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
}
