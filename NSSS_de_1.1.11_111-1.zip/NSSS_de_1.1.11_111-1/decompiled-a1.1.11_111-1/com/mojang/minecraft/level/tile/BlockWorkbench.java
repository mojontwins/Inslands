package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;

public class BlockWorkbench extends Block
{
    protected BlockWorkbench(final int i) {
        super(i, Material.wood);
        this.blockIndexInTexture = 59;
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return this.blockIndexInTexture - 16;
        }
        if (i == 0) {
            return Block.planks.getTextureIndex(0);
        }
        if (i == 2 || i == 4) {
            return this.blockIndexInTexture + 1;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        if (world.multiplayerWorld) {
            return true;
        }
        entityplayer.displayWorkbenchGUI(i, j, k);
        return true;
    }
}
