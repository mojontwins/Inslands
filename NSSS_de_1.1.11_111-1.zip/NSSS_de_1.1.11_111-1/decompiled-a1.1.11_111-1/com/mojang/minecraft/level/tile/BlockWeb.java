package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockWeb extends Block
{
    public BlockWeb(final int i, final int j) {
        super(i, j, Material.web);
    }
    
    @Override
    public void onEntityCollidedWithBlock(final World world, final int i, final int j, final int k, final Entity entity) {
        entity.isInWeb = true;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int getRenderType() {
        return 1;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.silk.shiftedIndex;
    }
}
