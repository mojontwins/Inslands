package com.mojang.minecraft.level.tile;

import java.util.*;

public class BlockObsidian extends BlockStone
{
    public BlockObsidian(final int i, final int j) {
        super(i, j);
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.obsidian.blockID;
    }
}
