package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;

public class BlockStairs extends Block
{
    private Block modelBlock;
    
    protected BlockStairs(final int i, final Block block) {
        super(i, block.blockIndexInTexture, block.blockMaterial);
        this.modelBlock = block;
        this.setHardness(block.blockHardness);
        this.setResistance(block.blockResistance / 3.0f);
        this.setStepSound(block.stepSound);
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return super.getCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public int getRenderType() {
        return 10;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return super.shouldSideBeRendered(iblockaccess, i, j, k, l);
    }
    
    @Override
    public void getCollidingBoundingBoxes(final World world, final int i, final int j, final int k, final AxisAlignedBB axisalignedbb, final ArrayList arraylist) {
        final int l = world.getBlockMetadata(i, j, k);
        if (l == 0) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
            this.setBlockBounds(0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
        }
        else if (l == 1) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 0.5f, 1.0f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
            this.setBlockBounds(0.5f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
        }
        else if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 0.5f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
            this.setBlockBounds(0.0f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
        }
        else if (l == 3) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.5f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
            this.setBlockBounds(0.0f, 0.0f, 0.5f, 1.0f, 0.5f, 1.0f);
            super.getCollidingBoundingBoxes(world, i, j, k, axisalignedbb, arraylist);
        }
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        this.modelBlock.randomDisplayTick(world, i, j, k, random);
    }
    
    @Override
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.modelBlock.onBlockClicked(world, i, j, k, entityplayer);
    }
    
    @Override
    public float getBlockBrightness(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return this.modelBlock.getBlockBrightness(iblockaccess, i, j, k);
    }
    
    @Override
    public float getExplosionResistance(final Entity entity) {
        return this.modelBlock.getExplosionResistance(entity);
    }
    
    @Override
    public int getRenderBlockPass() {
        return this.modelBlock.getRenderBlockPass();
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return this.blockID;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        return this.modelBlock.getBlockTextureFromSideAndMetadata(i, j);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        return this.modelBlock.getTextureIndex(i);
    }
    
    @Override
    public int getTextureIndex(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return this.modelBlock.getTextureIndex(iblockaccess, i, j, k, l);
    }
    
    @Override
    public int tickRate() {
        return this.modelBlock.tickRate();
    }
    
    @Override
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return this.modelBlock.getSelectedCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public void velocityToAddToEntity(final World world, final int i, final int j, final int k, final Entity entity, final Vec3D vec3d) {
        this.modelBlock.velocityToAddToEntity(world, i, j, k, entity, vec3d);
    }
    
    @Override
    public boolean isCollidable() {
        return this.modelBlock.isCollidable();
    }
    
    @Override
    public boolean canCollideCheck(final int i, final boolean flag) {
        return this.modelBlock.canCollideCheck(i, flag);
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return this.modelBlock.canPlace(world, i, j, k);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        this.onNeighborBlockChange(world, i, j, k, 0);
        this.modelBlock.onBlockAdded(world, i, j, k);
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        this.modelBlock.onBlockRemoval(world, i, j, k);
    }
    
    @Override
    public void onEntityWalking(final World world, final int i, final int j, final int k, final Entity entity) {
        this.modelBlock.onEntityWalking(world, i, j, k, entity);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        this.modelBlock.updateTick(world, i, j, k, random);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        return this.modelBlock.blockActivated(world, i, j, k, entityplayer);
    }
    
    @Override
    public void onBlockDestroyedByExplosion(final World world, final int i, final int j, final int k) {
    }
    
    @Override
    public void onBlockPlacedBy(final World world, final int i, final int j, final int k, final EntityLiving entityliving) {
        final int l = MathHelper.floor_double(entityliving.rotationYaw * 4.0f / 360.0f + 0.5) & 0x3;
        if (l == 0) {
            world.setBlockMetadataWithNotify(i, j, k, 2);
        }
        if (l == 1) {
            world.setBlockMetadataWithNotify(i, j, k, 1);
        }
        if (l == 2) {
            world.setBlockMetadataWithNotify(i, j, k, 3);
        }
        if (l == 3) {
            world.setBlockMetadataWithNotify(i, j, k, 0);
        }
    }
}
