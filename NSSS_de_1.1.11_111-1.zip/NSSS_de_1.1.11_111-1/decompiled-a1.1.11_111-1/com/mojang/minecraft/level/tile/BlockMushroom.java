package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockMushroom extends BlockFlower
{
    public static boolean spreading;
    
    static {
        BlockMushroom.spreading = true;
    }
    
    protected BlockMushroom(final int i, final int j) {
        super(i, j);
        final float f = 0.2f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, f * 2.0f, 0.5f + f);
        this.setTickOnLoad(true);
    }
    
    @Override
    public void updateTick(final World par1World, int par2, int par3, int par4, final Random par5Random) {
        if (par5Random.nextInt(25) == 0 && BlockMushroom.spreading) {
            final byte byte0 = 4;
            int i = 15;
            for (int j = par2 - byte0; j <= par2 + byte0; ++j) {
                for (int l = par4 - byte0; l <= par4 + byte0; ++l) {
                    for (int j2 = par3 - 1; j2 <= par3 + 1; ++j2) {
                        if (par1World.getBlockId(j, j2, l) == this.blockID && --i <= 0) {
                            return;
                        }
                    }
                }
            }
            int k = par2 + par5Random.nextInt(3) - 1;
            int i2 = par3 + par5Random.nextInt(2) - par5Random.nextInt(2);
            int k2 = par4 + par5Random.nextInt(3) - 1;
            for (int l2 = 0; l2 < 4; ++l2) {
                if (par1World.isAirBlock(k, i2, k2) && this.canBlockStay(par1World, k, i2, k2)) {
                    par2 = k;
                    par3 = i2;
                    par4 = k2;
                }
                k = par2 + par5Random.nextInt(3) - 1;
                i2 = par3 + par5Random.nextInt(2) - par5Random.nextInt(2);
                k2 = par4 + par5Random.nextInt(3) - 1;
            }
            if (par1World.isAirBlock(k, i2, k2) && this.canBlockStay(par1World, k, i2, k2)) {
                par1World.setBlockWithNotify(k, i2, k2, this.blockID);
            }
        }
    }
    
    public boolean canPlaceBlockAt(final World par1World, final int par2, final int par3, final int par4) {
        return super.canPlace(par1World, par2, par3, par4) && this.canBlockStay(par1World, par2, par3, par4);
    }
    
    @Override
    protected boolean canThisPlantGrowOnThisBlockID(final int i) {
        return Block.opaqueCubeLookup[i];
    }
    
    @Override
    public boolean canBlockStay(final World world, final int i, final int j, final int k) {
        return world.getBlockLightValue(i, j, k) <= 13 && this.canThisPlantGrowOnThisBlockID(world.getBlockId(i, j - 1, k));
    }
}
