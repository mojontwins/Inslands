package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public class BlockTNT extends Block
{
    public BlockTNT(final int i, final int j) {
        super(i, j, Material.tnt);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 0) {
            return this.blockIndexInTexture + 2;
        }
        if (i == 1) {
            return this.blockIndexInTexture + 1;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (l > 0 && Block.allBlocks[l].canProvidePower() && world.isBlockIndirectlyGettingPowered(i, j, k)) {
            this.dropBlockAsItemWithChance(world, i, j, k, 0);
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    @Override
    public void onBlockDestroyedByExplosion(final World world, final int i, final int j, final int k) {
        final EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, i + 0.5f, j + 0.5f, k + 0.5f);
        entitytntprimed.field_689_a = world.rand.nextInt(entitytntprimed.field_689_a / 4) + entitytntprimed.field_689_a / 8;
        world.entityJoinedWorld(entitytntprimed);
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l) {
        if (world.multiplayerWorld) {
            return;
        }
        final EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, i + 0.5f, j + 0.5f, k + 0.5f);
        world.entityJoinedWorld(entitytntprimed);
        world.playSoundAtEntity(entitytntprimed, "random.fuse", 1.0f, 1.0f);
    }
}
