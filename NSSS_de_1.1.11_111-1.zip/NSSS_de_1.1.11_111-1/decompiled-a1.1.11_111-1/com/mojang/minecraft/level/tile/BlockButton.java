package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.*;
import java.util.*;

public class BlockButton extends Block
{
    protected BlockButton(final int i, final int j) {
        super(i, j, Material.circuits);
        this.setTickOnLoad(true);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int tickRate() {
        return 20;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i - 1, j, k) || world.isBlockNormalCube(i + 1, j, k) || world.isBlockNormalCube(i, j, k - 1) || world.isBlockNormalCube(i, j, k + 1);
    }
    
    @Override
    public void onBlockPlaced(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getBlockMetadata(i, j, k);
        final int j2 = i2 & 0x8;
        i2 &= 0x7;
        if (l == 2 && world.isBlockNormalCube(i, j, k + 1)) {
            i2 = 4;
        }
        if (l == 3 && world.isBlockNormalCube(i, j, k - 1)) {
            i2 = 3;
        }
        if (l == 4 && world.isBlockNormalCube(i + 1, j, k)) {
            i2 = 2;
        }
        if (l == 5 && world.isBlockNormalCube(i - 1, j, k)) {
            i2 = 1;
        }
        world.setBlockMetadataWithNotify(i, j, k, i2 + j2);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (world.isBlockNormalCube(i - 1, j, k)) {
            world.setBlockMetadataWithNotify(i, j, k, 1);
        }
        else if (world.isBlockNormalCube(i + 1, j, k)) {
            world.setBlockMetadataWithNotify(i, j, k, 2);
        }
        else if (world.isBlockNormalCube(i, j, k - 1)) {
            world.setBlockMetadataWithNotify(i, j, k, 3);
        }
        else if (world.isBlockNormalCube(i, j, k + 1)) {
            world.setBlockMetadataWithNotify(i, j, k, 4);
        }
        this.func_305_h(world, i, j, k);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (this.func_305_h(world, i, j, k)) {
            final int i2 = world.getBlockMetadata(i, j, k) & 0x7;
            boolean flag = false;
            if (!world.isBlockNormalCube(i - 1, j, k) && i2 == 1) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i + 1, j, k) && i2 == 2) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k - 1) && i2 == 3) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k + 1) && i2 == 4) {
                flag = true;
            }
            if (flag) {
                this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
                world.setBlockWithNotify(i, j, k, 0);
            }
        }
    }
    
    private boolean func_305_h(final World world, final int i, final int j, final int k) {
        if (!this.canPlace(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getBlockMetadata(i, j, k);
        final int i2 = l & 0x7;
        final boolean flag = (l & 0x8) > 0;
        final float f = 0.375f;
        final float f2 = 0.625f;
        final float f3 = 0.1875f;
        float f4 = 0.125f;
        if (flag) {
            f4 = 0.0625f;
        }
        if (i2 == 1) {
            this.setBlockBounds(0.0f, f, 0.5f - f3, f4, f2, 0.5f + f3);
        }
        else if (i2 == 2) {
            this.setBlockBounds(1.0f - f4, f, 0.5f - f3, 1.0f, f2, 0.5f + f3);
        }
        else if (i2 == 3) {
            this.setBlockBounds(0.5f - f3, f, 0.0f, 0.5f + f3, f2, f4);
        }
        else if (i2 == 4) {
            this.setBlockBounds(0.5f - f3, f, 1.0f - f4, 0.5f + f3, f2, 1.0f);
        }
    }
    
    @Override
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.blockActivated(world, i, j, k, entityplayer);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        final int l = world.getBlockMetadata(i, j, k);
        final int i2 = l & 0x7;
        final int j2 = 8 - (l & 0x8);
        if (j2 == 0) {
            return true;
        }
        world.setBlockMetadataWithNotify(i, j, k, i2 + j2);
        world.markBlocksDirty(i, j, k, i, j, k);
        world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, 0.6f);
        world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
        if (i2 == 1) {
            world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
        }
        else if (i2 == 2) {
            world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
        }
        else if (i2 == 3) {
            world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
        }
        else if (i2 == 4) {
            world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        }
        else {
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        }
        world.scheduleUpdateTick(i, j, k, this.blockID);
        return true;
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        if ((l & 0x8) > 0) {
            world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
            final int i2 = l & 0x7;
            if (i2 == 1) {
                world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
            }
            else if (i2 == 2) {
                world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
            }
            else if (i2 == 3) {
                world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
            }
            else if (i2 == 4) {
                world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
            }
            else {
                world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            }
        }
        super.onBlockRemoval(world, i, j, k);
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return (iblockaccess.getBlockMetadata(i, j, k) & 0x8) > 0;
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockMetadata(i, j, k);
        if ((i2 & 0x8) == 0x0) {
            return false;
        }
        final int j2 = i2 & 0x7;
        return (j2 == 5 && l == 1) || (j2 == 4 && l == 2) || (j2 == 3 && l == 3) || (j2 == 2 && l == 4) || (j2 == 1 && l == 5);
    }
    
    @Override
    public boolean canProvidePower() {
        return true;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.multiplayerWorld) {
            return;
        }
        final int l = world.getBlockMetadata(i, j, k);
        if ((l & 0x8) == 0x0) {
            return;
        }
        world.setBlockMetadataWithNotify(i, j, k, l & 0x7);
        world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
        final int i2 = l & 0x7;
        if (i2 == 1) {
            world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
        }
        else if (i2 == 2) {
            world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
        }
        else if (i2 == 3) {
            world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
        }
        else if (i2 == 4) {
            world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        }
        else {
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        }
        world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, 0.5f);
        world.markBlocksDirty(i, j, k, i, j, k);
    }
    
    @Override
    public void setBlockBoundsForItemRender() {
        final float f = 0.1875f;
        final float f2 = 0.125f;
        final float f3 = 0.125f;
        this.setBlockBounds(0.5f - f, 0.5f - f2, 0.5f - f3, 0.5f + f, 0.5f + f2, 0.5f + f3);
    }
}
