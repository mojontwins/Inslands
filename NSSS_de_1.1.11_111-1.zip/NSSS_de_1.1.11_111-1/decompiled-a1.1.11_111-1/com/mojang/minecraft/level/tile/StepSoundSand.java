package com.mojang.minecraft.level.tile;

final class StepSoundSand extends StepSound
{
    StepSoundSand(final String s, final float f, final float f1) {
        super(s, f, f1);
    }
    
    @Override
    public String stepSoundDir() {
        return "step.gravel";
    }
}
