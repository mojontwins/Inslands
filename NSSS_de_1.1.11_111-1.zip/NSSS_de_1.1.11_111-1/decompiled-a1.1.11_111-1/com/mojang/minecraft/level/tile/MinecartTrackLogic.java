package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.chunk.*;
import java.util.*;

class MinecartTrackLogic
{
    private World field_1159_b;
    private int field_1165_c;
    private int field_1164_d;
    private int field_1163_e;
    private int field_1162_f;
    private List<ChunkPosition> field_1161_g;
    final BlockMinecartTrack field_1160_a;
    
    public MinecartTrackLogic(final BlockMinecartTrack blockminecarttrack, final World world, final int i, final int j, final int k) {
        this.field_1160_a = blockminecarttrack;
        this.field_1161_g = new ArrayList<ChunkPosition>();
        this.field_1159_b = world;
        this.field_1165_c = i;
        this.field_1164_d = j;
        this.field_1163_e = k;
        this.field_1162_f = world.getBlockMetadata(i, j, k);
        this.func_789_a();
    }
    
    private void func_789_a() {
        this.field_1161_g.clear();
        if (this.field_1162_f == 0) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
        }
        else if (this.field_1162_f == 1) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
        }
        else if (this.field_1162_f == 2) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e));
        }
        else if (this.field_1162_f == 3) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
        }
        else if (this.field_1162_f == 4) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
        }
        else if (this.field_1162_f == 5) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1));
        }
        else if (this.field_1162_f == 6) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
        }
        else if (this.field_1162_f == 7) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1));
        }
        else if (this.field_1162_f == 8) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
        }
        else if (this.field_1162_f == 9) {
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e));
            this.field_1161_g.add(new ChunkPosition(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1));
        }
    }
    
    private void func_785_b() {
        for (int i = 0; i < this.field_1161_g.size(); ++i) {
            final MinecartTrackLogic minecarttracklogic = this.func_795_a(this.field_1161_g.get(i));
            if (minecarttracklogic == null || !minecarttracklogic.func_793_b(this)) {
                this.field_1161_g.remove(i--);
            }
            else {
                this.field_1161_g.set(i, new ChunkPosition(minecarttracklogic.field_1165_c, minecarttracklogic.field_1164_d, minecarttracklogic.field_1163_e));
            }
        }
    }
    
    private boolean func_784_a(final int i, final int j, final int k) {
        return this.field_1159_b.getBlockId(i, j, k) == this.field_1160_a.blockID || this.field_1159_b.getBlockId(i, j + 1, k) == this.field_1160_a.blockID || this.field_1159_b.getBlockId(i, j - 1, k) == this.field_1160_a.blockID;
    }
    
    private MinecartTrackLogic func_795_a(final ChunkPosition chunkposition) {
        if (this.field_1159_b.getBlockId(chunkposition.x, chunkposition.y, chunkposition.z) == this.field_1160_a.blockID) {
            return new MinecartTrackLogic(this.field_1160_a, this.field_1159_b, chunkposition.x, chunkposition.y, chunkposition.z);
        }
        if (this.field_1159_b.getBlockId(chunkposition.x, chunkposition.y + 1, chunkposition.z) == this.field_1160_a.blockID) {
            return new MinecartTrackLogic(this.field_1160_a, this.field_1159_b, chunkposition.x, chunkposition.y + 1, chunkposition.z);
        }
        if (this.field_1159_b.getBlockId(chunkposition.x, chunkposition.y - 1, chunkposition.z) == this.field_1160_a.blockID) {
            return new MinecartTrackLogic(this.field_1160_a, this.field_1159_b, chunkposition.x, chunkposition.y - 1, chunkposition.z);
        }
        return null;
    }
    
    private boolean func_793_b(final MinecartTrackLogic minecarttracklogic) {
        for (int i = 0; i < this.field_1161_g.size(); ++i) {
            final ChunkPosition chunkposition = this.field_1161_g.get(i);
            if (chunkposition.x == minecarttracklogic.field_1165_c && chunkposition.z == minecarttracklogic.field_1163_e) {
                return true;
            }
        }
        return false;
    }
    
    private boolean func_794_b(final int i, final int j, final int k) {
        for (int l = 0; l < this.field_1161_g.size(); ++l) {
            final ChunkPosition chunkposition = this.field_1161_g.get(l);
            if (chunkposition.x == i && chunkposition.z == k) {
                return true;
            }
        }
        return false;
    }
    
    private int func_790_c() {
        int i = 0;
        if (this.func_784_a(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1)) {
            ++i;
        }
        if (this.func_784_a(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1)) {
            ++i;
        }
        if (this.func_784_a(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e)) {
            ++i;
        }
        if (this.func_784_a(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e)) {
            ++i;
        }
        return i;
    }
    
    private boolean func_787_c(final MinecartTrackLogic minecarttracklogic) {
        if (this.func_793_b(minecarttracklogic)) {
            return true;
        }
        if (this.field_1161_g.size() == 2) {
            return false;
        }
        if (this.field_1161_g.size() == 0) {
            return true;
        }
        final ChunkPosition chunkposition = this.field_1161_g.get(0);
        return (minecarttracklogic.field_1164_d == this.field_1164_d && chunkposition.y == this.field_1164_d) || true;
    }
    
    private void func_788_d(final MinecartTrackLogic minecarttracklogic) {
        this.field_1161_g.add(new ChunkPosition(minecarttracklogic.field_1165_c, minecarttracklogic.field_1164_d, minecarttracklogic.field_1163_e));
        final boolean flag = this.func_794_b(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1);
        final boolean flag2 = this.func_794_b(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1);
        final boolean flag3 = this.func_794_b(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e);
        final boolean flag4 = this.func_794_b(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e);
        byte byte0 = -1;
        if (flag || flag2) {
            byte0 = 0;
        }
        if (flag3 || flag4) {
            byte0 = 1;
        }
        if (flag2 && flag4 && !flag && !flag3) {
            byte0 = 6;
        }
        if (flag2 && flag3 && !flag && !flag4) {
            byte0 = 7;
        }
        if (flag && flag3 && !flag2 && !flag4) {
            byte0 = 8;
        }
        if (flag && flag4 && !flag2 && !flag3) {
            byte0 = 9;
        }
        if (byte0 == 0) {
            if (this.field_1159_b.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1) == this.field_1160_a.blockID) {
                byte0 = 4;
            }
            if (this.field_1159_b.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1) == this.field_1160_a.blockID) {
                byte0 = 5;
            }
        }
        if (byte0 == 1) {
            if (this.field_1159_b.getBlockId(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
                byte0 = 2;
            }
            if (this.field_1159_b.getBlockId(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
                byte0 = 3;
            }
        }
        if (byte0 < 0) {
            byte0 = 0;
        }
        this.field_1159_b.setBlockMetadataWithNotify(this.field_1165_c, this.field_1164_d, this.field_1163_e, byte0);
    }
    
    private boolean func_786_c(final int i, final int j, final int k) {
        final MinecartTrackLogic minecarttracklogic = this.func_795_a(new ChunkPosition(i, j, k));
        if (minecarttracklogic == null) {
            return false;
        }
        minecarttracklogic.func_785_b();
        return minecarttracklogic.func_787_c(this);
    }
    
    public void func_792_a(final boolean flag) {
        final boolean flag2 = this.func_786_c(this.field_1165_c, this.field_1164_d, this.field_1163_e - 1);
        final boolean flag3 = this.func_786_c(this.field_1165_c, this.field_1164_d, this.field_1163_e + 1);
        final boolean flag4 = this.func_786_c(this.field_1165_c - 1, this.field_1164_d, this.field_1163_e);
        final boolean flag5 = this.func_786_c(this.field_1165_c + 1, this.field_1164_d, this.field_1163_e);
        int i = -1;
        if ((flag2 || flag3) && !flag4 && !flag5) {
            i = 0;
        }
        if ((flag4 || flag5) && !flag2 && !flag3) {
            i = 1;
        }
        if (flag3 && flag5 && !flag2 && !flag4) {
            i = 6;
        }
        if (flag3 && flag4 && !flag2 && !flag5) {
            i = 7;
        }
        if (flag2 && flag4 && !flag3 && !flag5) {
            i = 8;
        }
        if (flag2 && flag5 && !flag3 && !flag4) {
            i = 9;
        }
        if (i == -1) {
            if (flag2 || flag3) {
                i = 0;
            }
            if (flag4 || flag5) {
                i = 1;
            }
            if (flag) {
                if (flag3 && flag5) {
                    i = 6;
                }
                if (flag4 && flag3) {
                    i = 7;
                }
                if (flag5 && flag2) {
                    i = 9;
                }
                if (flag2 && flag4) {
                    i = 8;
                }
            }
            else {
                if (flag2 && flag4) {
                    i = 8;
                }
                if (flag5 && flag2) {
                    i = 9;
                }
                if (flag4 && flag3) {
                    i = 7;
                }
                if (flag3 && flag5) {
                    i = 6;
                }
            }
        }
        if (i == 0) {
            if (this.field_1159_b.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e - 1) == this.field_1160_a.blockID) {
                i = 4;
            }
            if (this.field_1159_b.getBlockId(this.field_1165_c, this.field_1164_d + 1, this.field_1163_e + 1) == this.field_1160_a.blockID) {
                i = 5;
            }
        }
        if (i == 1) {
            if (this.field_1159_b.getBlockId(this.field_1165_c + 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
                i = 2;
            }
            if (this.field_1159_b.getBlockId(this.field_1165_c - 1, this.field_1164_d + 1, this.field_1163_e) == this.field_1160_a.blockID) {
                i = 3;
            }
        }
        if (i < 0) {
            i = 0;
        }
        this.field_1162_f = i;
        this.func_789_a();
        this.field_1159_b.setBlockMetadataWithNotify(this.field_1165_c, this.field_1164_d, this.field_1163_e, i);
        for (int j = 0; j < this.field_1161_g.size(); ++j) {
            final MinecartTrackLogic minecarttracklogic = this.func_795_a(this.field_1161_g.get(j));
            if (minecarttracklogic != null) {
                minecarttracklogic.func_785_b();
                if (minecarttracklogic.func_787_c(this)) {
                    minecarttracklogic.func_788_d(this);
                }
            }
        }
    }
    
    static int func_791_a(final MinecartTrackLogic minecarttracklogic) {
        return minecarttracklogic.func_790_c();
    }
}
