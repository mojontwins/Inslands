package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;

public class BlockOreBlock extends Block
{
    public BlockOreBlock(final int i, final int j) {
        super(i, Material.iron);
        this.blockIndexInTexture = j;
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return this.blockIndexInTexture - 16;
        }
        if (i == 0) {
            return this.blockIndexInTexture + 16;
        }
        return this.blockIndexInTexture;
    }
}
