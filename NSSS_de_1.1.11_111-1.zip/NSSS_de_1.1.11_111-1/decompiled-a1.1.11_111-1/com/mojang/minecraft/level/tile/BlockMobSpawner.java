package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockMobSpawner extends BlockContainer
{
    protected BlockMobSpawner(final int i, final int j) {
        super(i, j, Material.rock);
        BlockMobSpawner.isBlockContainer[i] = true;
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityMobSpawner();
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.quiver.shiftedIndex;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
}
