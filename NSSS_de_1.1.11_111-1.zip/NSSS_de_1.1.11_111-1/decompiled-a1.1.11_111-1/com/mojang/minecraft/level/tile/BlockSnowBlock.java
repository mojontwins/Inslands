package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.enums.*;

public class BlockSnowBlock extends Block
{
    protected BlockSnowBlock(final int i, final int j) {
        super(i, j, Material.builtSnow);
        this.setTickOnLoad(true);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.snowball.shiftedIndex;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 4;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockLighting(EnumSkyBlock.Block, i, j, k) > 11) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
}
