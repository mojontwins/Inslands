package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class BlockDoor extends Block
{
    protected BlockDoor(final int i, final Material material) {
        super(i, material);
        this.blockIndexInTexture = 97;
        if (material == Material.iron) {
            ++this.blockIndexInTexture;
        }
        final float f = 0.5f;
        final float f2 = 1.0f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, f2, 0.5f + f);
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        if (i == 0 || i == 1) {
            return this.blockIndexInTexture;
        }
        final int k = this.func_312_c(j);
        if ((k == 0 || k == 2) ^ i <= 3) {
            return this.blockIndexInTexture;
        }
        int l = k / 2 + ((i & 0x1) ^ k);
        l += (j & 0x4) / 4;
        int i2 = this.blockIndexInTexture - (j & 0x8) * 2;
        if ((l & 0x1) != 0x0) {
            i2 = -i2;
        }
        return i2;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 7;
    }
    
    @Override
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        this.setBlockBoundsBasedOnState(world, i, j, k);
        return super.getSelectedCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        this.setBlockBoundsBasedOnState(world, i, j, k);
        return super.getCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        this.func_313_b(this.func_312_c(iblockaccess.getBlockMetadata(i, j, k)));
    }
    
    public void func_313_b(final int i) {
        final float f = 0.1875f;
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 1.0f);
        if (i == 0) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, f);
        }
        if (i == 1) {
            this.setBlockBounds(1.0f - f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        if (i == 2) {
            this.setBlockBounds(0.0f, 0.0f, 1.0f - f, 1.0f, 1.0f, 1.0f);
        }
        if (i == 3) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, f, 1.0f, 1.0f);
        }
    }
    
    @Override
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.blockActivated(world, i, j, k, entityplayer);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        if (this.blockMaterial == Material.iron) {
            return true;
        }
        final int l = world.getBlockMetadata(i, j, k);
        if ((l & 0x8) != 0x0) {
            if (world.getBlockId(i, j - 1, k) == this.blockID) {
                this.blockActivated(world, i, j - 1, k, entityplayer);
            }
            return true;
        }
        if (world.getBlockId(i, j + 1, k) == this.blockID) {
            world.setBlockMetadataWithNotify(i, j + 1, k, (l ^ 0x4) + 8);
        }
        world.setBlockMetadataWithNotify(i, j, k, l ^ 0x4);
        world.markBlocksDirty(i, j - 1, k, i, j, k);
        if (Math.random() < 0.5) {
            world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.door_open", 1.0f, world.rand.nextFloat() * 0.1f + 0.9f);
        }
        else {
            world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.door_close", 1.0f, world.rand.nextFloat() * 0.1f + 0.9f);
        }
        return true;
    }
    
    public void func_311_a(final World world, final int i, final int j, final int k, final boolean flag) {
        final int l = world.getBlockMetadata(i, j, k);
        if ((l & 0x8) != 0x0) {
            if (world.getBlockId(i, j - 1, k) == this.blockID) {
                this.func_311_a(world, i, j - 1, k, flag);
            }
            return;
        }
        final boolean flag2 = (world.getBlockMetadata(i, j, k) & 0x4) > 0;
        if (flag2 == flag) {
            return;
        }
        if (world.getBlockId(i, j + 1, k) == this.blockID) {
            world.setBlockMetadataWithNotify(i, j + 1, k, (l ^ 0x4) + 8);
        }
        world.setBlockMetadataWithNotify(i, j, k, l ^ 0x4);
        world.markBlocksDirty(i, j - 1, k, i, j, k);
        if (Math.random() < 0.5) {
            world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.door_open", 1.0f, world.rand.nextFloat() * 0.1f + 0.9f);
        }
        else {
            world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.door_close", 1.0f, world.rand.nextFloat() * 0.1f + 0.9f);
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockMetadata(i, j, k);
        if ((i2 & 0x8) != 0x0) {
            if (world.getBlockId(i, j - 1, k) != this.blockID) {
                world.setBlockWithNotify(i, j, k, 0);
            }
            if (l > 0 && Block.allBlocks[l].canProvidePower()) {
                this.onNeighborBlockChange(world, i, j - 1, k, l);
            }
        }
        else {
            boolean flag = false;
            if (world.getBlockId(i, j + 1, k) != this.blockID) {
                world.setBlockWithNotify(i, j, k, 0);
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j - 1, k)) {
                world.setBlockWithNotify(i, j, k, 0);
                flag = true;
                if (world.getBlockId(i, j + 1, k) == this.blockID) {
                    world.setBlockWithNotify(i, j + 1, k, 0);
                }
            }
            if (flag) {
                if (!world.multiplayerWorld) {
                    this.dropBlockAsItem(world, i, j, k, i2);
                }
            }
            else if (l > 0 && Block.allBlocks[l].canProvidePower()) {
                final boolean flag2 = world.isBlockIndirectlyGettingPowered(i, j, k) || world.isBlockIndirectlyGettingPowered(i, j + 1, k);
                this.func_311_a(world, i, j, k, flag2);
            }
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        if ((i & 0x8) != 0x0) {
            return 0;
        }
        if (this.blockMaterial == Material.iron) {
            return Item.doorSteel.shiftedIndex;
        }
        return Item.doorWood.shiftedIndex;
    }
    
    @Override
    public MovingObjectPosition collisionRayTrace(final World world, final int i, final int j, final int k, final Vec3D vec3d, final Vec3D vec3d1) {
        this.setBlockBoundsBasedOnState(world, i, j, k);
        return super.collisionRayTrace(world, i, j, k, vec3d, vec3d1);
    }
    
    public int func_312_c(final int i) {
        if ((i & 0x4) == 0x0) {
            return i - 1 & 0x3;
        }
        return i & 0x3;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return j < 127 && (world.isBlockNormalCube(i, j - 1, k) && super.canPlace(world, i, j, k) && super.canPlace(world, i, j + 1, k));
    }
}
