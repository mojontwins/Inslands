package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockFire extends Block
{
    private int[] chanceToEncourageFire;
    private int[] abilityToCatchFire;
    
    protected BlockFire(final int i, final int j) {
        super(i, j, Material.fire);
        this.chanceToEncourageFire = new int[256];
        this.abilityToCatchFire = new int[256];
        this.setBurnRate(Block.planks.blockID, 5, 20);
        this.setBurnRate(Block.wood.blockID, 5, 5);
        this.setBurnRate(Block.leaves.blockID, 30, 60);
        this.setBurnRate(Block.bookShelf.blockID, 30, 20);
        this.setBurnRate(Block.tnt.blockID, 15, 100);
        this.setBurnRate(Block.cloth.blockID, 30, 60);
        this.setTickOnLoad(true);
    }
    
    private void setBurnRate(final int i, final int j, final int k) {
        this.chanceToEncourageFire[i] = j;
        this.abilityToCatchFire[i] = k;
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 3;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    @Override
    public int tickRate() {
        return 10;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        final int l = world.getBlockMetadata(i, j, k);
        if (l < 15) {
            world.setBlockMetadataWithNotify(i, j, k, l + 1);
            world.scheduleUpdateTick(i, j, k, this.blockID);
        }
        if (!this.func_263_h(world, i, j, k)) {
            if (!world.isBlockNormalCube(i, j - 1, k) || l > 3) {
                world.setBlockWithNotify(i, j, k, 0);
            }
            return;
        }
        if (!this.canBlockCatchFire(world, i, j - 1, k) && l == 15 && random.nextInt(4) == 0) {
            world.setBlockWithNotify(i, j, k, 0);
            return;
        }
        if (l % 2 == 0 && l > 2) {
            this.tryToCatchBlockOnFire(world, i + 1, j, k, 300, random);
            this.tryToCatchBlockOnFire(world, i - 1, j, k, 300, random);
            this.tryToCatchBlockOnFire(world, i, j - 1, k, 200, random);
            this.tryToCatchBlockOnFire(world, i, j + 1, k, 250, random);
            this.tryToCatchBlockOnFire(world, i, j, k - 1, 300, random);
            this.tryToCatchBlockOnFire(world, i, j, k + 1, 300, random);
            for (int i2 = i - 1; i2 <= i + 1; ++i2) {
                for (int j2 = k - 1; j2 <= k + 1; ++j2) {
                    for (int k2 = j - 1; k2 <= j + 4; ++k2) {
                        if (i2 != i || k2 != j || j2 != k) {
                            int l2 = 100;
                            if (k2 > j + 1) {
                                l2 += (k2 - (j + 1)) * 100;
                            }
                            final int i3 = this.getChanceOfNeighborsEncouragingFire(world, i2, k2, j2);
                            if (i3 > 0 && random.nextInt(l2) <= i3) {
                                world.setBlockWithNotify(i2, k2, j2, this.blockID);
                            }
                        }
                    }
                }
            }
        }
    }
    
    private void tryToCatchBlockOnFire(final World world, final int i, final int j, final int k, final int l, final Random random) {
        final int i2 = this.abilityToCatchFire[world.getBlockId(i, j, k)];
        if (random.nextInt(l) < i2) {
            final boolean flag = world.getBlockId(i, j, k) == Block.tnt.blockID;
            if (random.nextInt(2) == 0) {
                world.setBlockWithNotify(i, j, k, this.blockID);
            }
            else {
                world.setBlockWithNotify(i, j, k, 0);
            }
            if (flag) {
                Block.tnt.dropBlockAsItemWithChance(world, i, j, k, 0);
            }
        }
    }
    
    private boolean func_263_h(final World world, final int i, final int j, final int k) {
        return this.canBlockCatchFire(world, i + 1, j, k) || this.canBlockCatchFire(world, i - 1, j, k) || this.canBlockCatchFire(world, i, j - 1, k) || this.canBlockCatchFire(world, i, j + 1, k) || this.canBlockCatchFire(world, i, j, k - 1) || this.canBlockCatchFire(world, i, j, k + 1);
    }
    
    private int getChanceOfNeighborsEncouragingFire(final World world, final int i, final int j, final int k) {
        int l = 0;
        if (world.getBlockId(i, j, k) != 0) {
            return 0;
        }
        l = this.getChanceToEncourageFire(world, i + 1, j, k, l);
        l = this.getChanceToEncourageFire(world, i - 1, j, k, l);
        l = this.getChanceToEncourageFire(world, i, j - 1, k, l);
        l = this.getChanceToEncourageFire(world, i, j + 1, k, l);
        l = this.getChanceToEncourageFire(world, i, j, k - 1, l);
        l = this.getChanceToEncourageFire(world, i, j, k + 1, l);
        return l;
    }
    
    @Override
    public boolean isCollidable() {
        return false;
    }
    
    public boolean canBlockCatchFire(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return this.chanceToEncourageFire[iblockaccess.getBlockId(i, j, k)] > 0;
    }
    
    public int getChanceToEncourageFire(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = this.chanceToEncourageFire[world.getBlockId(i, j, k)];
        if (i2 > l) {
            return i2;
        }
        return l;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i, j - 1, k) || this.func_263_h(world, i, j, k);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (!world.isBlockNormalCube(i, j - 1, k) && !this.func_263_h(world, i, j, k)) {
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (!world.isBlockNormalCube(i, j - 1, k) && !this.func_263_h(world, i, j, k)) {
            world.setBlockWithNotify(i, j, k, 0);
            return;
        }
        world.scheduleUpdateTick(i, j, k, this.blockID);
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (random.nextInt(24) == 0) {
            world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "fire.fire", 1.0f + random.nextFloat(), random.nextFloat() * 0.7f + 0.3f);
        }
        if (world.isBlockNormalCube(i, j - 1, k) || Block.fire.canBlockCatchFire(world, i, j - 1, k)) {
            for (int l = 0; l < 3; ++l) {
                final float f = i + random.nextFloat();
                final float f2 = j + random.nextFloat() * 0.5f + 0.5f;
                final float f3 = k + random.nextFloat();
                world.spawnParticle("largesmoke", f, f2, f3, 0.0, 0.0, 0.0);
            }
        }
        else {
            if (Block.fire.canBlockCatchFire(world, i - 1, j, k)) {
                for (int i2 = 0; i2 < 2; ++i2) {
                    final float f4 = i + random.nextFloat() * 0.1f;
                    final float f5 = j + random.nextFloat();
                    final float f6 = k + random.nextFloat();
                    world.spawnParticle("largesmoke", f4, f5, f6, 0.0, 0.0, 0.0);
                }
            }
            if (Block.fire.canBlockCatchFire(world, i + 1, j, k)) {
                for (int j2 = 0; j2 < 2; ++j2) {
                    final float f7 = i + 1 - random.nextFloat() * 0.1f;
                    final float f8 = j + random.nextFloat();
                    final float f9 = k + random.nextFloat();
                    world.spawnParticle("largesmoke", f7, f8, f9, 0.0, 0.0, 0.0);
                }
            }
            if (Block.fire.canBlockCatchFire(world, i, j, k - 1)) {
                for (int k2 = 0; k2 < 2; ++k2) {
                    final float f10 = i + random.nextFloat();
                    final float f11 = j + random.nextFloat();
                    final float f12 = k + random.nextFloat() * 0.1f;
                    world.spawnParticle("largesmoke", f10, f11, f12, 0.0, 0.0, 0.0);
                }
            }
            if (Block.fire.canBlockCatchFire(world, i, j, k + 1)) {
                for (int l2 = 0; l2 < 2; ++l2) {
                    final float f13 = i + random.nextFloat();
                    final float f14 = j + random.nextFloat();
                    final float f15 = k + 1 - random.nextFloat() * 0.1f;
                    world.spawnParticle("largesmoke", f13, f14, f15, 0.0, 0.0, 0.0);
                }
            }
            if (Block.fire.canBlockCatchFire(world, i, j + 1, k)) {
                for (int i3 = 0; i3 < 2; ++i3) {
                    final float f16 = i + random.nextFloat();
                    final float f17 = j + 1 - random.nextFloat() * 0.1f;
                    final float f18 = k + random.nextFloat();
                    world.spawnParticle("largesmoke", f16, f17, f18, 0.0, 0.0, 0.0);
                }
            }
        }
    }
}
