package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.phys.*;

public class BlockFlower extends Block
{
    protected BlockFlower(final int i, final int j) {
        super(i, Material.plants);
        this.blockIndexInTexture = j;
        this.setTickOnLoad(true);
        final float f = 0.2f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, f * 3.0f, 0.5f + f);
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return this.canThisPlantGrowOnThisBlockID(world.getBlockId(i, j - 1, k));
    }
    
    protected boolean canThisPlantGrowOnThisBlockID(final int i) {
        return i == Block.grass.blockID || i == Block.dirt.blockID || i == Block.tilledField.blockID;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        super.onNeighborBlockChange(world, i, j, k, l);
        this.func_268_h(world, i, j, k);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        this.func_268_h(world, i, j, k);
    }
    
    protected final void func_268_h(final World world, final int i, final int j, final int k) {
        if (!this.canBlockStay(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public boolean canBlockStay(final World world, final int i, final int j, final int k) {
        return (world.getBlockLightValue(i, j, k) >= 8 || world.func_647_i(i, j, k)) && this.canThisPlantGrowOnThisBlockID(world.getBlockId(i, j - 1, k));
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 1;
    }
}
