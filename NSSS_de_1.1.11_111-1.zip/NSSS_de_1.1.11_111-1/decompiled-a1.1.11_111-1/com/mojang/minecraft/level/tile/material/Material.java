package com.mojang.minecraft.level.tile.material;

public class Material
{
    public static final Material air;
    public static final Material ground;
    public static final Material wood;
    public static final Material rock;
    public static final Material iron;
    public static final Material water;
    public static final Material lava;
    public static final Material leaves;
    public static final Material plants;
    public static final Material sponge;
    public static final Material cloth;
    public static final Material fire;
    public static final Material sand;
    public static final Material circuits;
    public static final Material glass;
    public static final Material tnt;
    public static final Material web;
    public static final Material ice;
    public static final Material snow;
    public static final Material builtSnow;
    public static final Material cactus;
    public static final Material clay;
    private boolean canBurn;
    
    static {
        air = new MaterialTransparent();
        ground = new Material();
        wood = new Material().setBurning();
        rock = new Material();
        iron = new Material();
        water = new MaterialLiquid();
        lava = new MaterialLiquid();
        leaves = new Material().setBurning();
        plants = new MaterialLogic();
        sponge = new Material();
        cloth = new Material().setBurning();
        fire = new MaterialTransparent();
        sand = new Material();
        circuits = new MaterialLogic();
        glass = new Material();
        tnt = new Material().setBurning();
        web = new Material();
        ice = new Material();
        snow = new MaterialLogic();
        builtSnow = new Material();
        cactus = new Material();
        clay = new Material();
    }
    
    public boolean getIsGroundCover() {
        return false;
    }
    
    public boolean isSolidMaterial() {
        return true;
    }
    
    public boolean func_881_b() {
        return true;
    }
    
    public boolean blocksMovement() {
        return true;
    }
    
    private Material setBurning() {
        this.canBurn = true;
        return this;
    }
    
    public boolean getBurning() {
        return this.canBurn;
    }
}
