package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;

public class BlockFence extends Block
{
    public BlockFence(final int i, final int j) {
        super(i, j, Material.wood);
    }
    
    @Override
    public void getCollidingBoundingBoxes(final World world, final int i, final int j, final int k, final AxisAlignedBB axisalignedbb, final ArrayList<AxisAlignedBB> arraylist) {
        arraylist.add(AxisAlignedBB.getBoundingBoxFromPool(i, j, k, i + 1, j + 1.5, k + 1));
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public int getRenderType() {
        return 11;
    }
}
