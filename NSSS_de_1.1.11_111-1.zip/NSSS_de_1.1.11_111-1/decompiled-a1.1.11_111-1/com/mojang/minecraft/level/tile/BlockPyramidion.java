package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public class BlockPyramidion extends Block
{
    public BlockPyramidion(final int i, final int j) {
        super(i, j, Material.iron);
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l) {
        if (world.mc.options.difficulty == 0) {
            world.setBlock(i, j, k, this.blockID);
            world.getWorldAccess(0).displayInfoGUI("No.");
        }
        final Random rand = new Random();
        final EntityGiant giant = new EntityGiant(world);
        giant.setLocationAndAngles(i, j, k, rand.nextFloat() * 360.0f, 0.0f);
        world.entityJoinedWorld(giant);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return 0;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
}
