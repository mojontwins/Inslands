package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.*;
import java.util.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockPressurePlate extends Block
{
    private EnumMobType field_467_a;
    
    protected BlockPressurePlate(final int i, final int j, final EnumMobType enummobtype) {
        super(i, j, Material.rock);
        this.field_467_a = enummobtype;
        this.setTickOnLoad(true);
        final float f = 0.0625f;
        this.setBlockBounds(f, 0.0f, f, 1.0f - f, 0.03125f, 1.0f - f);
    }
    
    @Override
    public int tickRate() {
        return 20;
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.getBlockId(i, j - 1, k) == Block.fence.blockID || world.isBlockNormalCube(i, j - 1, k);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        boolean flag = false;
        if (!world.isBlockNormalCube(i, j - 1, k) && world.getBlockId(i, j - 1, k) != Block.fence.blockID) {
            flag = true;
        }
        if (flag) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.multiplayerWorld) {
            return;
        }
        if (world.getBlockMetadata(i, j, k) == 0) {
            return;
        }
        this.func_318_h(world, i, j, k);
    }
    
    @Override
    public void onEntityCollidedWithBlock(final World world, final int i, final int j, final int k, final Entity entity) {
        if (world.multiplayerWorld) {
            return;
        }
        if (world.getBlockMetadata(i, j, k) == 1) {
            return;
        }
        this.func_318_h(world, i, j, k);
    }
    
    private void func_318_h(final World world, final int i, final int j, final int k) {
        final boolean flag = world.getBlockMetadata(i, j, k) == 1;
        boolean flag2 = false;
        final float f = 0.125f;
        List<?> list = null;
        if (this.field_467_a == EnumMobType.everything) {
            list = world.getEntitiesWithinAABBExcludingEntity(null, AxisAlignedBB.getBoundingBoxFromPool(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (this.field_467_a == EnumMobType.mobs) {
            list = world.getEntitiesWithinAABB(EntityLiving.class, AxisAlignedBB.getBoundingBoxFromPool(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (this.field_467_a == EnumMobType.players) {
            list = world.getEntitiesWithinAABB(EntityPlayer.class, AxisAlignedBB.getBoundingBoxFromPool(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (list.size() > 0) {
            flag2 = true;
        }
        if (flag2 && !flag) {
            world.setBlockMetadataWithNotify(i, j, k, 1);
            world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            world.markBlocksDirty(i, j, k, i, j, k);
            world.playSoundEffect(i + 0.5, j + 0.1, k + 0.5, "random.click", 0.3f, 0.6f);
        }
        if (!flag2 && flag) {
            world.setBlockMetadataWithNotify(i, j, k, 0);
            world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            world.markBlocksDirty(i, j, k, i, j, k);
            world.playSoundEffect(i + 0.5, j + 0.1, k + 0.5, "random.click", 0.3f, 0.5f);
        }
        if (flag2) {
            world.scheduleUpdateTick(i, j, k, this.blockID);
        }
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        if (l > 0) {
            world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        }
        super.onBlockRemoval(world, i, j, k);
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final boolean flag = iblockaccess.getBlockMetadata(i, j, k) == 1;
        final float f = 0.0625f;
        if (flag) {
            this.setBlockBounds(f, 0.0f, f, 1.0f - f, 0.03125f, 1.0f - f);
        }
        else {
            this.setBlockBounds(f, 0.0f, f, 1.0f - f, 0.0625f, 1.0f - f);
        }
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return iblockaccess.getBlockMetadata(i, j, k) > 0;
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        return world.getBlockMetadata(i, j, k) != 0 && l == 1;
    }
    
    @Override
    public boolean canProvidePower() {
        return true;
    }
    
    @Override
    public void setBlockBoundsForItemRender() {
        final float f = 0.5f;
        final float f2 = 0.125f;
        final float f3 = 0.5f;
        this.setBlockBounds(0.5f - f, 0.5f - f2, 0.5f - f3, 0.5f + f, 0.5f + f2, 0.5f + f3);
    }
}
