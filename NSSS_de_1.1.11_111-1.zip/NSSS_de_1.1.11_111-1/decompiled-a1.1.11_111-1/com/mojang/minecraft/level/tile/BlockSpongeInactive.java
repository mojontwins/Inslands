package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;
import com.mojang.minecraft.level.*;

public class BlockSpongeInactive extends Block
{
    static final byte radius = 3;
    
    protected BlockSpongeInactive(final int i) {
        super(i, Material.sponge);
        this.blockIndexInTexture = 48;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.sponge.blockID;
    }
    
    @Override
    public void onBlockAdded(final World world, final int a, final int b, final int c) {
        super.onBlockAdded(world, a, b, c);
        for (int x = a - 3; x <= a + 3; ++x) {
            for (int y = b - 3; y <= b + 3; ++y) {
                for (int z = c - 3; z <= c + 3; ++z) {
                    if (world.getBlockId(x, y, z) == Block.waterMoving.blockID || world.getBlockId(x, y, z) == Block.waterStill.blockID) {
                        world.setBlockAndMetadataWithNotify(x, y, z, Block.waterMoving.blockID, world.getBlockMetadata(x, y, z));
                    }
                }
            }
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (!this.isReceivingRedstonePower(world, i, j, k, l)) {
            this.dropBlockAsItemWithChance(world, i, j, k, 19);
            world.setBlockWithNotify(i, j, k, 19);
        }
    }
    
    private boolean isReceivingRedstonePower(final World world, final int i, final int j, final int k, final int l) {
        return (l != 0 && world.isBlockIndirectlyProvidingPowerTo(i, j - 1, k, 0)) || (l != 1 && world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k, 1)) || (l != 2 && world.isBlockIndirectlyProvidingPowerTo(i, j, k - 1, 2)) || (l != 3 && world.isBlockIndirectlyProvidingPowerTo(i, j, k + 1, 3)) || (l != 5 && world.isBlockIndirectlyProvidingPowerTo(i + 1, j, k, 5)) || (l != 4 && world.isBlockIndirectlyProvidingPowerTo(i - 1, j, k, 4)) || world.isBlockIndirectlyProvidingPowerTo(i, j, k, 0) || world.isBlockIndirectlyProvidingPowerTo(i, j + 2, k, 1) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k - 1, 2) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k + 1, 3) || world.isBlockIndirectlyProvidingPowerTo(i - 1, j + 1, k, 4) || world.isBlockIndirectlyProvidingPowerTo(i + 1, j + 1, k, 5);
    }
}
