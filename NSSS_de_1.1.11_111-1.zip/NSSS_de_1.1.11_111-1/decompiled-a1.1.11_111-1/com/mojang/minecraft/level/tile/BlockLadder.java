package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;

public class BlockLadder extends Block
{
    protected BlockLadder(final int i, final int j) {
        super(i, j, Material.circuits);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        final float f = 0.125f;
        if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 1.0f - f, 1.0f, 1.0f, 1.0f);
        }
        if (l == 3) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, f);
        }
        if (l == 4) {
            this.setBlockBounds(1.0f - f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        if (l == 5) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, f, 1.0f, 1.0f);
        }
        return super.getCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        final float f = 0.125f;
        if (l == 2) {
            this.setBlockBounds(0.0f, 0.0f, 1.0f - f, 1.0f, 1.0f, 1.0f);
        }
        if (l == 3) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, f);
        }
        if (l == 4) {
            this.setBlockBounds(1.0f - f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        if (l == 5) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, f, 1.0f, 1.0f);
        }
        return super.getSelectedCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 8;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i - 1, j, k) || world.isBlockNormalCube(i + 1, j, k) || world.isBlockNormalCube(i, j, k - 1) || world.isBlockNormalCube(i, j, k + 1);
    }
    
    @Override
    public void onBlockPlaced(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getBlockMetadata(i, j, k);
        if ((i2 == 0 || l == 2) && world.isBlockNormalCube(i, j, k + 1)) {
            i2 = 2;
        }
        if ((i2 == 0 || l == 3) && world.isBlockNormalCube(i, j, k - 1)) {
            i2 = 3;
        }
        if ((i2 == 0 || l == 4) && world.isBlockNormalCube(i + 1, j, k)) {
            i2 = 4;
        }
        if ((i2 == 0 || l == 5) && world.isBlockNormalCube(i - 1, j, k)) {
            i2 = 5;
        }
        world.setBlockMetadataWithNotify(i, j, k, i2);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockMetadata(i, j, k);
        boolean flag = false;
        if (i2 == 2 && world.isBlockNormalCube(i, j, k + 1)) {
            flag = true;
        }
        if (i2 == 3 && world.isBlockNormalCube(i, j, k - 1)) {
            flag = true;
        }
        if (i2 == 4 && world.isBlockNormalCube(i + 1, j, k)) {
            flag = true;
        }
        if (i2 == 5 && world.isBlockNormalCube(i - 1, j, k)) {
            flag = true;
        }
        if (!flag) {
            this.dropBlockAsItem(world, i, j, k, i2);
            world.setBlockWithNotify(i, j, k, 0);
        }
        super.onNeighborBlockChange(world, i, j, k, l);
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
}
