package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockStep extends Block
{
    private boolean isDouble;
    
    public BlockStep(final int i, final boolean flag) {
        super(i, 6, Material.rock);
        if (!(this.isDouble = flag)) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
        }
        this.setLightOpacity(255);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        return (i > 1) ? 5 : 6;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return this.isDouble;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (this != Block.stairSingle) {
            return;
        }
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (this != Block.stairSingle) {
            super.onBlockAdded(world, i, j, k);
        }
        final int l = world.getBlockId(i, j - 1, k);
        if (l == BlockStep.stairSingle.blockID) {
            world.setBlockWithNotify(i, j, k, 0);
            world.setBlockWithNotify(i, j - 1, k, Block.stairDouble.blockID);
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.stairSingle.blockID;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        if (!this.isDouble) {
            return 1;
        }
        return 2;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return this.isDouble;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (this != Block.stairSingle) {
            super.shouldSideBeRendered(iblockaccess, i, j, k, l);
        }
        return l == 1 || (super.shouldSideBeRendered(iblockaccess, i, j, k, l) && (l == 0 || iblockaccess.getBlockId(i, j, k) != this.blockID));
    }
}
