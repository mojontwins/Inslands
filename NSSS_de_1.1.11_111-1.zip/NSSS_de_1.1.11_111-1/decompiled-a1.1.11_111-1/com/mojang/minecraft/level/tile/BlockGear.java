package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.tile.*;

public final class BlockGear extends BlockContainer
{
    private boolean isGearPowered;
    
    protected BlockGear(final int n, final int n2) {
        super(n, n2, Material.circuits);
        BlockGear.isBlockContainer[n] = true;
    }
    
    @Override
    public final AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        this.func_271_h(world, i, j, k);
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i - 1, j, k) || world.isBlockNormalCube(i + 1, j, k) || world.isBlockNormalCube(i, j, k - 1) || world.isBlockNormalCube(i, j, k + 1);
    }
    
    private boolean func_271_h(final World world, final int i, final int j, final int k) {
        if (!this.canPlace(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        world.func_654_a(i, j, k, this.getBlockEntity());
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
    }
    
    private void notifyGearNeighborsOfNeighborChange(final World world, final int i, final int j, final int k) {
        if (world.getBlockId(i, j, k) != this.blockID) {
            return;
        }
        world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
    }
    
    @Override
    public final boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public final boolean isCollidable() {
        return true;
    }
    
    @Override
    public final int tickRate() {
        return 1;
    }
    
    @Override
    public int getRenderType() {
        return 14;
    }
    
    @Override
    public final int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public final boolean canProvidePower() {
        return false;
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        if (j != 0) {
            return 78;
        }
        return 62;
    }
    
    public void applyGearPower(final World world, final int i, final int j, final int k) {
        world.setBlockMetadata(i, j, k, 1);
    }
    
    public void removeGearPower(final World world, final int i, final int j, final int k) {
        world.setBlockMetadata(i, j, k, 0);
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityGear();
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        final int l = world.getBlockMetadata(i, j, k);
        if (l == 0) {
            return;
        }
        world.spawnParticle("smoke", (float)i + 0.5, (float)j + 0.5, (float)k + 0.5, 0.0, 0.0, 0.0);
    }
}
