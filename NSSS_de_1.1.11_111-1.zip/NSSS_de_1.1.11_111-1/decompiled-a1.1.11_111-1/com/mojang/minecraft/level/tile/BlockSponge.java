package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockSponge extends Block
{
    static final byte radius = 2;
    
    protected BlockSponge(final int i) {
        super(i, Material.sponge);
        this.blockIndexInTexture = 48;
    }
    
    @Override
    public void onBlockAdded(final World world, final int a, final int b, final int c) {
        super.onBlockAdded(world, a, b, c);
        for (int x = a - 2; x <= a + 2; ++x) {
            for (int y = b - 2; y <= b + 2; ++y) {
                for (int z = c - 2; z <= c + 2; ++z) {
                    if (world.getBlockId(x, y, z) == Block.waterMoving.blockID || world.getBlockId(x, y, z) == Block.waterStill.blockID) {
                        world.setBlockWithNotify(x, y, z, 0);
                    }
                }
            }
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (this.isReceivingRedstonePower(world, i, j, k, l)) {
            this.dropBlockAsItemWithChance(world, i, j, k, 19);
            world.setBlockWithNotify(i, j, k, 87);
        }
    }
    
    private boolean isReceivingRedstonePower(final World world, final int i, final int j, final int k, final int l) {
        return (l != 0 && world.isBlockIndirectlyProvidingPowerTo(i, j - 1, k, 0)) || (l != 1 && world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k, 1)) || (l != 2 && world.isBlockIndirectlyProvidingPowerTo(i, j, k - 1, 2)) || (l != 3 && world.isBlockIndirectlyProvidingPowerTo(i, j, k + 1, 3)) || (l != 5 && world.isBlockIndirectlyProvidingPowerTo(i + 1, j, k, 5)) || (l != 4 && world.isBlockIndirectlyProvidingPowerTo(i - 1, j, k, 4)) || world.isBlockIndirectlyProvidingPowerTo(i, j, k, 0) || world.isBlockIndirectlyProvidingPowerTo(i, j + 2, k, 1) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k - 1, 2) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k + 1, 3) || world.isBlockIndirectlyProvidingPowerTo(i - 1, j + 1, k, 4) || world.isBlockIndirectlyProvidingPowerTo(i + 1, j + 1, k, 5);
    }
    
    public void dropWater(final World world, final int x, final int y, final int z) {
        for (int i = y; i > y - 3 && (world.getBlockId(x, i, z) == 0 || world.getBlockId(x, i, z) == Block.waterStill.blockID) && getSurroundSponge(world, x, i, z); --i) {}
    }
    
    public void flowWater(final World world, final int x, final int y, final int z, final int sx, final int sy, final int sz) {
        final int radius = 3;
        if ((world.getBlockId(x, y, z) == 0 || world.getBlockId(x, y, z) == Block.waterStill.blockID) && !getSurroundSponge(world, x, y, z)) {
            this.dropWater(world, x, y, z);
            if (x + 1 < sx + radius && (world.getBlockId(x + 1, y, z) == 0 || world.getBlockId(x + 1, y, z) == Block.waterStill.blockID) && !getSurroundSponge(world, x + 1, y, z)) {
                world.notifyBlocksOfNeighborChange(x + 1, y, z, 1);
            }
            if (z + 1 < sz + radius && (world.getBlockId(x, y, z + 1) == 0 || world.getBlockId(x, y, z + 1) == Block.waterStill.blockID) && !getSurroundSponge(world, x, y, z + 1)) {
                world.notifyBlocksOfNeighborChange(x, y, z + 1, 1);
            }
            if (x - 1 > sx - radius && (world.getBlockId(x - 1, y, z) == 0 || world.getBlockId(x - 1, y, z) == Block.waterStill.blockID) && !getSurroundSponge(world, x - 1, y, z)) {
                world.notifyBlocksOfNeighborChange(x - 1, y, z, 1);
            }
            if (z - 1 > sz - radius && (world.getBlockId(x, y, z - 1) == 0 || world.getBlockId(x, y, z - 1) == Block.waterStill.blockID) && !getSurroundSponge(world, x, y, z - 1)) {
                world.notifyBlocksOfNeighborChange(x, y, z + 1, 1);
            }
        }
    }
    
    @Override
    public void updateTick(final World world, final int a, final int b, final int c, final Random random) {
        super.updateTick(world, a, b, c, random);
        for (int x = a - 2; x <= a + 2; ++x) {
            for (int y = b - 2; y <= b + 2; ++y) {
                for (int z = c - 2; z <= c + 2; ++z) {
                    if (world.getBlockId(x, y, z) == Block.waterMoving.blockID || world.getBlockId(x, y, z) == Block.waterStill.blockID) {
                        world.setBlockWithNotify(x, y, z, 0);
                    }
                }
            }
        }
    }
    
    public void fillWater(final World world, final int x, final int y, final int z) {
        for (int radius = 3, x2 = x - radius; x2 <= x + radius; ++x2) {
            for (int y2 = y; y2 > y - radius; --y2) {
                for (int z2 = z - radius; z2 <= z + radius; ++z2) {
                    if ((world.getBlockId(x2, y2, z2) == 0 || world.getBlockId(x2, y2, z2) == Block.waterStill.blockID || world.getBlockId(x2, y2, z2) == Block.waterMoving.blockID) && !getSurroundSponge(world, x, y, z)) {
                        world.setBlockWithNotify(x2, y2, z2, Block.waterMoving.blockID);
                    }
                }
            }
        }
    }
    
    public static boolean getSurroundSponge(final World world, final int x, final int y, final int z) {
        for (int x2 = x - 2; x2 <= x + 2; ++x2) {
            for (int y2 = y - 2; y2 <= y + 2; ++y2) {
                for (int z2 = z - 2; z2 <= z + 2; ++z2) {
                    if (world.getBlockId(x2, y2, z2) == Block.sponge.blockID) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int a, final int b, final int c, final int bid) {
        super.dropBlockAsItemWithChance(world, a, b, c, bid);
        for (int radius = 3, x = a - radius; x <= a + radius; ++x) {
            for (int y = b + radius; y > b - radius; --y) {
                for (int z = c - radius; z <= c + radius; ++z) {
                    if (world.getBlockId(x, y, z) == Block.waterMoving.blockID || world.getBlockId(x, y, z) == Block.waterStill.blockID) {
                        this.flowWater(world, x, y, z, a, b, c);
                    }
                }
            }
        }
    }
}
