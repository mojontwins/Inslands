package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockGrass extends Block
{
    private boolean goldCheck;
    
    protected BlockGrass(final int i) {
        super(i, Material.ground);
        this.blockIndexInTexture = 3;
        this.setTickOnLoad(true);
    }
    
    @Override
    public int getTextureIndex(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (l == 1) {
            return 0;
        }
        if (l == 0) {
            return 2;
        }
        final Material material = iblockaccess.getMaterialXYZ(i, j + 1, k);
        return (material != Material.snow && material != Material.builtSnow) ? 3 : 68;
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return 0;
        }
        if (i == 0) {
            return 2;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.multiplayerWorld) {
            return;
        }
        if (world.getBlockLightValue(i, j + 1, k) < 4 && world.getMaterialXYZ(i, j + 1, k).func_881_b()) {
            if (random.nextInt(4) != 0) {
                return;
            }
            world.setBlockWithNotify(i, j, k, Block.dirt.blockID);
        }
        else if (world.getBlockLightValue(i, j + 1, k) >= 9) {
            final int l = i + random.nextInt(3) - 1;
            final int i2 = j + random.nextInt(5) - 3;
            final int j2 = k + random.nextInt(3) - 1;
            if (world.getBlockId(l, i2, j2) == Block.dirt.blockID && world.getBlockLightValue(l, i2 + 1, j2) >= 4 && !world.getMaterialXYZ(l, i2 + 1, j2).func_881_b()) {
                world.setBlockWithNotify(l, i2, j2, Block.grass.blockID);
            }
        }
    }
    
    @Override
    public void goldTouch() {
        this.goldCheck = true;
        System.out.println("I AM GOLD");
    }
    
    @Override
    public void notGoldTouch() {
        this.goldCheck = false;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        if (this.goldCheck) {
            return Block.grass.blockID;
        }
        return Block.dirt.idDropped(0, random);
    }
}
