package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public class BlockSoil extends Block
{
    protected BlockSoil(final int i) {
        super(i, Material.ground);
        this.blockIndexInTexture = 87;
        this.setTickOnLoad(true);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.9375f, 1.0f);
        this.setLightOpacity(255);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return AxisAlignedBB.getBoundingBoxFromPool(i + 0, j + 0, k + 0, i + 1, j + 1, k + 1);
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        if (i == 1 && j > 0) {
            return this.blockIndexInTexture - 1;
        }
        if (i == 1) {
            return this.blockIndexInTexture;
        }
        return 2;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (random.nextInt(5) == 0) {
            if (this.func_274_i(world, i, j, k)) {
                world.setBlockMetadataWithNotify(i, j, k, 7);
            }
            else {
                final int l = world.getBlockMetadata(i, j, k);
                if (l > 0) {
                    world.setBlockMetadataWithNotify(i, j, k, l - 1);
                }
                else if (!this.func_275_h(world, i, j, k)) {
                    world.setBlockWithNotify(i, j, k, Block.dirt.blockID);
                }
            }
        }
    }
    
    @Override
    public void onEntityWalking(final World world, final int i, final int j, final int k, final Entity entity) {
        if (world.rand.nextInt(4) == 0) {
            world.setBlockWithNotify(i, j, k, Block.dirt.blockID);
        }
    }
    
    private boolean func_275_h(final World world, final int i, final int j, final int k) {
        for (int l = 0, i2 = i - l; i2 <= i + l; ++i2) {
            for (int j2 = k - l; j2 <= k + l; ++j2) {
                if (world.getBlockId(i2, j + 1, j2) == Block.crops.blockID) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean func_274_i(final World world, final int i, final int j, final int k) {
        for (int l = i - 4; l <= i + 4; ++l) {
            for (int i2 = j; i2 <= j + 1; ++i2) {
                for (int j2 = k - 4; j2 <= k + 4; ++j2) {
                    if (world.getMaterialXYZ(l, i2, j2) == Material.water) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        super.onNeighborBlockChange(world, i, j, k, l);
        final Material material = world.getMaterialXYZ(i, j + 1, k);
        if (material.isSolidMaterial()) {
            world.setBlockWithNotify(i, j, k, Block.dirt.blockID);
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.dirt.idDropped(0, random);
    }
}
