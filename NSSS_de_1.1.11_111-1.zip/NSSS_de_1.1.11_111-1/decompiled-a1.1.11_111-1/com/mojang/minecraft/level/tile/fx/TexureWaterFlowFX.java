package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.level.tile.*;

public class TexureWaterFlowFX extends TextureFX
{
    protected float[] field_1138_g;
    protected float[] field_1137_h;
    protected float[] field_1136_i;
    protected float[] field_1135_j;
    private int field_1134_k;
    
    public TexureWaterFlowFX() {
        super(Block.waterMoving.blockIndexInTexture + 1);
        this.field_1138_g = new float[256];
        this.field_1137_h = new float[256];
        this.field_1136_i = new float[256];
        this.field_1135_j = new float[256];
        this.field_1134_k = 0;
        this.prevSize = 2;
    }
    
    @Override
    public void render() {
        ++this.field_1134_k;
        for (int texU = 0; texU < 16; ++texU) {
            for (int texV = 0; texV < 16; ++texV) {
                float f = 0.0f;
                for (int j1 = texV - 2; j1 <= texV; ++j1) {
                    final int k1 = texU & 0xF;
                    final int i2 = j1 & 0xF;
                    f += this.field_1138_g[k1 + i2 * 16];
                }
                this.field_1137_h[texU + texV * 16] = f / 3.2f + this.field_1136_i[texU + texV * 16] * 0.8f;
            }
        }
        for (int texU = 0; texU < 16; ++texU) {
            for (int texV = 0; texV < 16; ++texV) {
                final float[] field_1136_i = this.field_1136_i;
                final int n = texU + texV * 16;
                field_1136_i[n] += this.field_1135_j[texU + texV * 16] * 0.05f;
                if (this.field_1136_i[texU + texV * 16] < 0.0f) {
                    this.field_1136_i[texU + texV * 16] = 0.0f;
                }
                final float[] field_1135_j = this.field_1135_j;
                final int n2 = texU + texV * 16;
                field_1135_j[n2] -= 0.3f;
                if (Math.random() < 0.2) {
                    this.field_1135_j[texU + texV * 16] = 0.5f;
                }
            }
        }
        final float[] af = this.field_1137_h;
        this.field_1137_h = this.field_1138_g;
        this.field_1138_g = af;
        for (int i3 = 0; i3 < 256; ++i3) {
            float f2 = this.field_1138_g[i3 - this.field_1134_k * 16 & 0xFF];
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            final float f3 = f2 * f2;
            int colorRed = (int)(32.0f + f3 * 32.0f);
            int colorGreen = (int)(50.0f + f3 * 64.0f);
            int colorBlue = 255;
            final int colorAlpha = (int)(146.0f + f3 * 50.0f);
            if (this.field_1131_c) {
                final int i4 = (colorRed * 30 + colorGreen * 59 + colorBlue * 11) / 100;
                final int j2 = (colorRed * 30 + colorGreen * 70) / 100;
                final int k2 = (colorRed * 30 + colorBlue * 70) / 100;
                colorRed = i4;
                colorGreen = j2;
                colorBlue = k2;
            }
            this.field_1127_a[i3 * 4 + 0] = (byte)colorRed;
            this.field_1127_a[i3 * 4 + 1] = (byte)colorGreen;
            this.field_1127_a[i3 * 4 + 2] = (byte)colorBlue;
            this.field_1127_a[i3 * 4 + 3] = (byte)colorAlpha;
        }
    }
}
