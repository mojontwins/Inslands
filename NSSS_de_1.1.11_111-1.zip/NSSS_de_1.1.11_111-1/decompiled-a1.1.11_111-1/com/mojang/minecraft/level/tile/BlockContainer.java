package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.tile.*;

public abstract class BlockContainer extends Block
{
    protected BlockContainer(final int i, final Material material) {
        super(i, material);
        BlockContainer.isBlockContainer[i] = true;
    }
    
    protected BlockContainer(final int i, final int j, final Material material) {
        super(i, j, material);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
        world.func_654_a(i, j, k, this.getBlockEntity());
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        super.onBlockRemoval(world, i, j, k);
        world.func_692_l(i, j, k);
    }
    
    protected abstract TileEntity getBlockEntity();
}
