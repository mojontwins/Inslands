package com.mojang.minecraft.level.tile.material;

public class MaterialTransparent extends Material
{
    @Override
    public boolean isSolidMaterial() {
        return false;
    }
    
    @Override
    public boolean func_881_b() {
        return false;
    }
    
    @Override
    public boolean blocksMovement() {
        return false;
    }
}
