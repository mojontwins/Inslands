package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockBreakable extends Block
{
    private boolean field_465_a;
    
    protected BlockBreakable(final int i, final int j, final Material material, final boolean flag) {
        super(i, j, material);
        this.field_465_a = flag;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        final int i2 = iblockaccess.getBlockId(i, j, k);
        return (this.field_465_a || i2 != this.blockID) && super.shouldSideBeRendered(iblockaccess, i, j, k, l);
    }
    
    @Override
    public void goldTouch() {
    }
}
