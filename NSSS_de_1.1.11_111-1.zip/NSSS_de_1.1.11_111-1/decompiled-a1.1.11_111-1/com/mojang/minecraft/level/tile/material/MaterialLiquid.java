package com.mojang.minecraft.level.tile.material;

public class MaterialLiquid extends Material
{
    @Override
    public boolean getIsGroundCover() {
        return true;
    }
    
    @Override
    public boolean blocksMovement() {
        return false;
    }
    
    @Override
    public boolean isSolidMaterial() {
        return false;
    }
}
