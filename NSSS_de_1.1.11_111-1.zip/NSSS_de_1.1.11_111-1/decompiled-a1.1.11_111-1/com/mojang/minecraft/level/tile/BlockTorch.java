package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class BlockTorch extends Block
{
    protected BlockTorch(final int i, final int j) {
        super(i, j, Material.circuits);
        this.setTickOnLoad(true);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 2;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.getBlockId(i, j - 1, k) == Block.fence.blockID || world.getBlockId(i, j - 1, k) == Block.glass.blockID || world.isBlockNormalCube(i - 1, j, k) || world.isBlockNormalCube(i + 1, j, k) || world.isBlockNormalCube(i, j, k - 1) || world.isBlockNormalCube(i, j, k + 1) || world.isBlockNormalCube(i, j - 1, k);
    }
    
    @Override
    public void onBlockPlaced(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getBlockMetadata(i, j, k);
        if (l == 1 && (world.isBlockNormalCube(i, j - 1, k) || world.getBlockId(i, j - 1, k) == Block.fence.blockID)) {
            i2 = 5;
        }
        if (l == 2 && world.isBlockNormalCube(i, j, k + 1)) {
            i2 = 4;
        }
        if (l == 3 && world.isBlockNormalCube(i, j, k - 1)) {
            i2 = 3;
        }
        if (l == 4 && world.isBlockNormalCube(i + 1, j, k)) {
            i2 = 2;
        }
        if (l == 5 && world.isBlockNormalCube(i - 1, j, k)) {
            i2 = 1;
        }
        world.setBlockMetadataWithNotify(i, j, k, i2);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        super.updateTick(world, i, j, k, random);
        if (world.getBlockMetadata(i, j, k) == 0) {
            this.onBlockAdded(world, i, j, k);
        }
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (world.isBlockNormalCube(i - 1, j, k)) {
            world.setBlockMetadataWithNotify(i, j, k, 1);
        }
        else if (world.isBlockNormalCube(i + 1, j, k)) {
            world.setBlockMetadataWithNotify(i, j, k, 2);
        }
        else if (world.isBlockNormalCube(i, j, k - 1)) {
            world.setBlockMetadataWithNotify(i, j, k, 3);
        }
        else if (world.isBlockNormalCube(i, j, k + 1)) {
            world.setBlockMetadataWithNotify(i, j, k, 4);
        }
        else if (world.isBlockNormalCube(i, j - 1, k)) {
            world.setBlockMetadataWithNotify(i, j, k, 5);
        }
        this.func_271_h(world, i, j, k);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (this.func_271_h(world, i, j, k)) {
            final int i2 = world.getBlockMetadata(i, j, k);
            boolean flag = false;
            if (!world.isBlockNormalCube(i - 1, j, k) && i2 == 1) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i + 1, j, k) && i2 == 2) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k - 1) && i2 == 3) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k + 1) && i2 == 4) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j - 1, k) && i2 == 5 && world.getBlockId(i, j - 1, k) != Block.fence.blockID) {
                flag = true;
            }
            if (flag) {
                this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
                world.setBlockWithNotify(i, j, k, 0);
            }
        }
    }
    
    private boolean func_271_h(final World world, final int i, final int j, final int k) {
        if (!this.canPlace(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public MovingObjectPosition collisionRayTrace(final World world, final int i, final int j, final int k, final Vec3D vec3d, final Vec3D vec3d1) {
        final int l = world.getBlockMetadata(i, j, k) & 0x7;
        final float f = 0.15f;
        if (l == 1) {
            this.setBlockBounds(0.0f, 0.2f, 0.5f - f, f * 2.0f, 0.8f, 0.5f + f);
        }
        else if (l == 2) {
            this.setBlockBounds(1.0f - f * 2.0f, 0.2f, 0.5f - f, 1.0f, 0.8f, 0.5f + f);
        }
        else if (l == 3) {
            this.setBlockBounds(0.5f - f, 0.2f, 0.0f, 0.5f + f, 0.8f, f * 2.0f);
        }
        else if (l == 4) {
            this.setBlockBounds(0.5f - f, 0.2f, 1.0f - f * 2.0f, 0.5f + f, 0.8f, 1.0f);
        }
        else {
            final float f2 = 0.1f;
            this.setBlockBounds(0.5f - f2, 0.0f, 0.5f - f2, 0.5f + f2, 0.6f, 0.5f + f2);
        }
        return super.collisionRayTrace(world, i, j, k, vec3d, vec3d1);
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        final int l = world.getBlockMetadata(i, j, k);
        final double d = i + 0.5f;
        final double d2 = j + 0.7f;
        final double d3 = k + 0.5f;
        final double d4 = 0.2199999988079071;
        final double d5 = 0.27000001072883606;
        if (l == 1) {
            world.spawnParticle("smoke", d - d5, d2 + d4, d3, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", d - d5, d2 + d4, d3, 0.0, 0.0, 0.0);
        }
        else if (l == 2) {
            world.spawnParticle("smoke", d + d5, d2 + d4, d3, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", d + d5, d2 + d4, d3, 0.0, 0.0, 0.0);
        }
        else if (l == 3) {
            world.spawnParticle("smoke", d, d2 + d4, d3 - d5, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", d, d2 + d4, d3 - d5, 0.0, 0.0, 0.0);
        }
        else if (l == 4) {
            world.spawnParticle("smoke", d, d2 + d4, d3 + d5, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", d, d2 + d4, d3 + d5, 0.0, 0.0, 0.0);
        }
        else {
            world.spawnParticle("smoke", d, d2, d3, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", d, d2, d3, 0.0, 0.0, 0.0);
        }
    }
}
