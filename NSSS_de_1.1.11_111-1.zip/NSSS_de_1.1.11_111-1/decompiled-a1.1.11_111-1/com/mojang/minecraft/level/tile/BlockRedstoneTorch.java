package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;

public class BlockRedstoneTorch extends BlockTorch
{
    private boolean torchActive;
    private static List<RedstoneUpdateInfo> torchUpdates;
    
    static {
        BlockRedstoneTorch.torchUpdates = new ArrayList<RedstoneUpdateInfo>();
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        if (i == 1) {
            return Block.redstoneWire.getBlockTextureFromSideAndMetadata(i, j);
        }
        return super.getBlockTextureFromSideAndMetadata(i, j);
    }
    
    private boolean checkForBurnout(final World world, final int i, final int j, final int k, final boolean flag) {
        if (flag) {
            BlockRedstoneTorch.torchUpdates.add(new RedstoneUpdateInfo(i, j, k, world.worldTime));
        }
        int l = 0;
        for (int i2 = 0; i2 < BlockRedstoneTorch.torchUpdates.size(); ++i2) {
            final RedstoneUpdateInfo redstoneupdateinfo = BlockRedstoneTorch.torchUpdates.get(i2);
            if (redstoneupdateinfo.x == i && redstoneupdateinfo.y == j && redstoneupdateinfo.z == k && ++l >= 8) {
                return true;
            }
        }
        return false;
    }
    
    protected BlockRedstoneTorch(final int i, final int j, final boolean flag) {
        super(i, j);
        this.torchActive = false;
        this.torchActive = flag;
        this.setTickOnLoad(true);
    }
    
    @Override
    public int tickRate() {
        return 2;
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (world.getBlockMetadata(i, j, k) == 0) {
            super.onBlockAdded(world, i, j, k);
        }
        if (this.torchActive) {
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        }
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        if (this.torchActive) {
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
            world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        }
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (!this.torchActive) {
            return false;
        }
        final int i2 = iblockaccess.getBlockMetadata(i, j, k);
        return (i2 != 5 || l != 1) && (i2 != 3 || l != 3) && (i2 != 4 || l != 2) && (i2 != 1 || l != 5) && (i2 != 2 || l != 4);
    }
    
    private boolean func_272_h(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        return (l == 5 && world.isBlockIndirectlyProvidingPowerTo(i, j - 1, k, 0)) || (l == 3 && world.isBlockIndirectlyProvidingPowerTo(i, j, k - 1, 2)) || (l == 4 && world.isBlockIndirectlyProvidingPowerTo(i, j, k + 1, 3)) || (l == 1 && world.isBlockIndirectlyProvidingPowerTo(i - 1, j, k, 4)) || (l == 2 && world.isBlockIndirectlyProvidingPowerTo(i + 1, j, k, 5));
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        final boolean flag = this.func_272_h(world, i, j, k);
        while (BlockRedstoneTorch.torchUpdates.size() > 0 && world.worldTime - BlockRedstoneTorch.torchUpdates.get(0).field_1010_d > 100L) {
            BlockRedstoneTorch.torchUpdates.remove(0);
        }
        if (this.torchActive) {
            if (flag) {
                world.setBlockAndMetadataWithNotify(i, j, k, Block.torchRedstoneIdle.blockID, world.getBlockMetadata(i, j, k));
                if (this.checkForBurnout(world, i, j, k, true)) {
                    world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "random.fizz", 0.5f, 2.6f + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8f);
                    for (int l = 0; l < 5; ++l) {
                        final double d = i + random.nextDouble() * 0.6 + 0.2;
                        final double d2 = j + random.nextDouble() * 0.6 + 0.2;
                        final double d3 = k + random.nextDouble() * 0.6 + 0.2;
                        world.spawnParticle("smoke", d, d2, d3, 0.0, 0.0, 0.0);
                    }
                }
            }
        }
        else if (!flag && !this.checkForBurnout(world, i, j, k, false)) {
            world.setBlockAndMetadataWithNotify(i, j, k, Block.torchRedstoneActive.blockID, world.getBlockMetadata(i, j, k));
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        super.onNeighborBlockChange(world, i, j, k, l);
        world.scheduleUpdateTick(i, j, k, this.blockID);
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        return l == 0 && this.isPoweringTo(world, i, j, k, l);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.torchRedstoneActive.blockID;
    }
    
    @Override
    public boolean canProvidePower() {
        return true;
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (!this.torchActive) {
            return;
        }
        final int l = world.getBlockMetadata(i, j, k);
        final double d = i + 0.5f + (random.nextFloat() - 0.5f) * 0.2;
        final double d2 = j + 0.7f + (random.nextFloat() - 0.5f) * 0.2;
        final double d3 = k + 0.5f + (random.nextFloat() - 0.5f) * 0.2;
        final double d4 = 0.2199999988079071;
        final double d5 = 0.27000001072883606;
        if (l == 1) {
            world.spawnParticle("reddust", d - d5, d2 + d4, d3, 0.0, 0.0, 0.0);
        }
        else if (l == 2) {
            world.spawnParticle("reddust", d + d5, d2 + d4, d3, 0.0, 0.0, 0.0);
        }
        else if (l == 3) {
            world.spawnParticle("reddust", d, d2 + d4, d3 - d5, 0.0, 0.0, 0.0);
        }
        else if (l == 4) {
            world.spawnParticle("reddust", d, d2 + d4, d3 + d5, 0.0, 0.0, 0.0);
        }
        else {
            world.spawnParticle("reddust", d, d2, d3, 0.0, 0.0, 0.0);
        }
    }
}
