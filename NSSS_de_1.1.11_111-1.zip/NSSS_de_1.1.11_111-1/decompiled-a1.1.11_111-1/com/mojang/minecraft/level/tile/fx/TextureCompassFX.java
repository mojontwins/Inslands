package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.*;
import com.mojang.minecraft.entity.item.*;
import javax.imageio.*;
import java.io.*;
import java.awt.image.*;

public class TextureCompassFX extends TextureFX
{
    protected float[] field_1153_g;
    protected float[] field_1152_h;
    private Minecraft field_1151_i;
    private int[] field_1150_j;
    private double field_1149_k;
    private double field_1148_l;
    
    public TextureCompassFX(final Minecraft minecraft) {
        super(Item.compass.getIconIndex(null));
        this.field_1153_g = new float[320];
        this.field_1152_h = new float[320];
        this.field_1150_j = new int[256];
        this.field_1151_i = minecraft;
        this.tile = 1;
        try {
            final BufferedImage bufferedimage = ImageIO.read(Minecraft.class.getResource("/gui/items.png"));
            final int i = this.texIndex % 16 * 16;
            final int j = this.texIndex / 16 * 16;
            bufferedimage.getRGB(i, j, 16, 16, this.field_1150_j, 0, 16);
        }
        catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }
    
    @Override
    public void render() {
        for (int i = 0; i < 256; ++i) {
            final int j = this.field_1150_j[i] >> 24 & 0xFF;
            int k = this.field_1150_j[i] >> 16 & 0xFF;
            int l = this.field_1150_j[i] >> 8 & 0xFF;
            int i2 = this.field_1150_j[i] >> 0 & 0xFF;
            if (this.field_1131_c) {
                final int j2 = (k * 30 + l * 59 + i2 * 11) / 100;
                final int k2 = (k * 30 + l * 70) / 100;
                final int l2 = (k * 30 + i2 * 70) / 100;
                k = j2;
                l = k2;
                i2 = l2;
            }
            this.field_1127_a[i * 4 + 0] = (byte)k;
            this.field_1127_a[i * 4 + 1] = (byte)l;
            this.field_1127_a[i * 4 + 2] = (byte)i2;
            this.field_1127_a[i * 4 + 3] = (byte)j;
        }
        double d = 0.0;
        if (this.field_1151_i.mcWorld != null && this.field_1151_i.thePlayer != null) {
            final double d2 = this.field_1151_i.mcWorld.spawnX + 0.5 - this.field_1151_i.thePlayer.posX;
            final double d3 = this.field_1151_i.mcWorld.spawnZ + 0.5 - this.field_1151_i.thePlayer.posZ;
            d = (this.field_1151_i.thePlayer.rotationYaw - 90.0f) * 3.141592653589793 / 180.0 - Math.atan2(d3, d2);
        }
        double d4;
        for (d4 = d - this.field_1149_k; d4 < -3.141592653589793; d4 += 6.283185307179586) {}
        while (d4 >= 3.141592653589793) {
            d4 -= 6.283185307179586;
        }
        if (d4 < -1.0) {
            d4 = -1.0;
        }
        if (d4 > 1.0) {
            d4 = 1.0;
        }
        this.field_1148_l += d4 * 0.1;
        this.field_1148_l *= 0.8;
        this.field_1149_k += this.field_1148_l;
        final double d5 = Math.sin(this.field_1149_k);
        final double d6 = Math.cos(this.field_1149_k);
        for (int i3 = -4; i3 <= 4; ++i3) {
            final int k3 = (int)(8.5 + d6 * i3 * 0.3);
            final int i4 = (int)(7.5 - d5 * i3 * 0.3 * 0.5);
            final int k4 = i4 * 16 + k3;
            int i5 = 100;
            int k5 = 100;
            int i6 = 100;
            final char c = '\u00ff';
            if (this.field_1131_c) {
                final int k6 = (i5 * 30 + k5 * 59 + i6 * 11) / 100;
                final int i7 = (i5 * 30 + k5 * 70) / 100;
                final int k7 = (i5 * 30 + i6 * 70) / 100;
                i5 = k6;
                k5 = i7;
                i6 = k7;
            }
            this.field_1127_a[k4 * 4 + 0] = (byte)i5;
            this.field_1127_a[k4 * 4 + 1] = (byte)k5;
            this.field_1127_a[k4 * 4 + 2] = (byte)i6;
            this.field_1127_a[k4 * 4 + 3] = (byte)c;
        }
        for (int j3 = -8; j3 <= 16; ++j3) {
            final int l3 = (int)(8.5 + d5 * j3 * 0.3);
            final int j4 = (int)(7.5 + d6 * j3 * 0.3 * 0.5);
            final int l4 = j4 * 16 + l3;
            int j5 = (j3 < 0) ? 100 : 255;
            int l5 = (j3 < 0) ? 100 : 20;
            int j6 = (j3 < 0) ? 100 : 20;
            final char c2 = '\u00ff';
            if (this.field_1131_c) {
                final int l6 = (j5 * 30 + l5 * 59 + j6 * 11) / 100;
                final int j7 = (j5 * 30 + l5 * 70) / 100;
                final int l7 = (j5 * 30 + j6 * 70) / 100;
                j5 = l6;
                l5 = j7;
                j6 = l7;
            }
            this.field_1127_a[l4 * 4 + 0] = (byte)j5;
            this.field_1127_a[l4 * 4 + 1] = (byte)l5;
            this.field_1127_a[l4 * 4 + 2] = (byte)j6;
            this.field_1127_a[l4 * 4 + 3] = (byte)c2;
        }
    }
}
