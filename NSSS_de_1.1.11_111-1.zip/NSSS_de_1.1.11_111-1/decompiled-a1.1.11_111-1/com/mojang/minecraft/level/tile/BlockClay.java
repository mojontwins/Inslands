package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockClay extends Block
{
    public BlockClay(final int i, final int j) {
        super(i, j, Material.clay);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.clay.shiftedIndex;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 4;
    }
}
