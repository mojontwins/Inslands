package com.mojang.minecraft.level.tile.phys;

public class ClippingHelper
{
    public float[][] field_1688_a;
    public float[] field_1687_b;
    public float[] field_1690_c;
    public float[] field_1689_d;
    
    public ClippingHelper() {
        this.field_1688_a = new float[16][16];
        this.field_1687_b = new float[16];
        this.field_1690_c = new float[16];
        this.field_1689_d = new float[16];
    }
    
    public boolean func_1152_a(final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        for (int i = 0; i < 6; ++i) {
            if (this.field_1688_a[i][0] * d + this.field_1688_a[i][1] * d1 + this.field_1688_a[i][2] * d2 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d3 + this.field_1688_a[i][1] * d1 + this.field_1688_a[i][2] * d2 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d + this.field_1688_a[i][1] * d4 + this.field_1688_a[i][2] * d2 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d3 + this.field_1688_a[i][1] * d4 + this.field_1688_a[i][2] * d2 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d + this.field_1688_a[i][1] * d1 + this.field_1688_a[i][2] * d5 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d3 + this.field_1688_a[i][1] * d1 + this.field_1688_a[i][2] * d5 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d + this.field_1688_a[i][1] * d4 + this.field_1688_a[i][2] * d5 + this.field_1688_a[i][3] <= 0.0 && this.field_1688_a[i][0] * d3 + this.field_1688_a[i][1] * d4 + this.field_1688_a[i][2] * d5 + this.field_1688_a[i][3] <= 0.0) {
                return false;
            }
        }
        return true;
    }
}
