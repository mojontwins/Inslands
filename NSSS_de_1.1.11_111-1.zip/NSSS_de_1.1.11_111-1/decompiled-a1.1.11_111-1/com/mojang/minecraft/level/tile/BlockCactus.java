package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.*;

public class BlockCactus extends Block
{
    protected BlockCactus(final int i, final int j) {
        super(i, j, Material.cactus);
        this.setTickOnLoad(true);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockId(i, j + 1, k) == 0) {
            int l;
            for (l = 1; world.getBlockId(i, j - l, k) == this.blockID; ++l) {}
            if (l < 3) {
                final int i2 = world.getBlockMetadata(i, j, k);
                if (i2 == 15) {
                    world.setBlockWithNotify(i, j + 1, k, this.blockID);
                    world.setBlockMetadataWithNotify(i, j, k, 0);
                }
                else {
                    world.setBlockMetadataWithNotify(i, j, k, i2 + 1);
                }
            }
        }
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        final float f = 0.0625f;
        return AxisAlignedBB.getBoundingBoxFromPool(i + f, j, k + f, i + 1 - f, j + 1 - f, k + 1 - f);
    }
    
    @Override
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        final float f = 0.0625f;
        return AxisAlignedBB.getBoundingBoxFromPool(i + f, j, k + f, i + 1 - f, j + 1, k + 1 - f);
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return this.blockIndexInTexture - 1;
        }
        if (i == 0) {
            return this.blockIndexInTexture + 1;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 13;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return super.canPlace(world, i, j, k) && this.canBlockStay(world, i, j, k);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (!this.canBlockStay(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }
    
    @Override
    public boolean canBlockStay(final World world, final int i, final int j, final int k) {
        if (world.getMaterialXYZ(i - 1, j, k).isSolidMaterial()) {
            return false;
        }
        if (world.getMaterialXYZ(i + 1, j, k).isSolidMaterial()) {
            return false;
        }
        if (world.getMaterialXYZ(i, j, k - 1).isSolidMaterial()) {
            return false;
        }
        if (world.getMaterialXYZ(i, j, k + 1).isSolidMaterial()) {
            return false;
        }
        final int l = world.getBlockId(i, j - 1, k);
        return l == Block.cactus.blockID || l == Block.sand.blockID;
    }
    
    @Override
    public void onEntityCollidedWithBlock(final World world, final int i, final int j, final int k, final Entity entity) {
        entity.attackEntityFrom(null, 1);
    }
}
