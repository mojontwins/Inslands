package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;

public class BlockStone extends Block
{
    public BlockStone(final int i, final int j) {
        super(i, j, Material.rock);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.cobblestone.blockID;
    }
}
