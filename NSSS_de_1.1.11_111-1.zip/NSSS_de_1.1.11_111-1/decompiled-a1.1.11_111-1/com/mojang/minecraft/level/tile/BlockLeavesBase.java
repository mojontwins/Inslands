package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockLeavesBase extends Block
{
    protected int graphicsLevel;
    
    protected BlockLeavesBase(final int i, final int j, final Material material, final int level) {
        super(i, j, material);
        this.graphicsLevel = level;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        final int i2 = iblockaccess.getBlockId(i, j, k);
        if (this.graphicsLevel == 0 && i2 == this.blockID) {
            return false;
        }
        if (this.graphicsLevel == 1 && i2 == this.blockID) {
            return false;
        }
        if (this.graphicsLevel == 2) {
            return iblockaccess.isTouchingAir(i, j, k);
        }
        return super.shouldSideBeRendered(iblockaccess, i, j, k, l);
    }
}
