package com.mojang.minecraft.level.tile.phys;

import java.util.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class AxisAlignedBB
{
    private static List<AxisAlignedBB> field_1700_g;
    private static int field_1699_h;
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;
    
    static {
        AxisAlignedBB.field_1700_g = new ArrayList<AxisAlignedBB>();
        AxisAlignedBB.field_1699_h = 0;
    }
    
    public static AxisAlignedBB getBoundingBox(final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        return new AxisAlignedBB(d, d1, d2, d3, d4, d5);
    }
    
    public static void clearBoundingBoxPool() {
        AxisAlignedBB.field_1699_h = 0;
    }
    
    public static AxisAlignedBB getBoundingBoxFromPool(final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        if (AxisAlignedBB.field_1699_h >= AxisAlignedBB.field_1700_g.size()) {
            AxisAlignedBB.field_1700_g.add(getBoundingBox(0.0, 0.0, 0.0, 0.0, 0.0, 0.0));
        }
        return AxisAlignedBB.field_1700_g.get(AxisAlignedBB.field_1699_h++).setBounds(d, d1, d2, d3, d4, d5);
    }
    
    private AxisAlignedBB(final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        this.minX = d;
        this.minY = d1;
        this.minZ = d2;
        this.maxX = d3;
        this.maxY = d4;
        this.maxZ = d5;
    }
    
    public AxisAlignedBB setBounds(final double d, final double d1, final double d2, final double d3, final double d4, final double d5) {
        this.minX = d;
        this.minY = d1;
        this.minZ = d2;
        this.maxX = d3;
        this.maxY = d4;
        this.maxZ = d5;
        return this;
    }
    
    public AxisAlignedBB addCoord(final double d, final double d1, final double d2) {
        double d3 = this.minX;
        double d4 = this.minY;
        double d5 = this.minZ;
        double d6 = this.maxX;
        double d7 = this.maxY;
        double d8 = this.maxZ;
        if (d < 0.0) {
            d3 += d;
        }
        if (d > 0.0) {
            d6 += d;
        }
        if (d1 < 0.0) {
            d4 += d1;
        }
        if (d1 > 0.0) {
            d7 += d1;
        }
        if (d2 < 0.0) {
            d5 += d2;
        }
        if (d2 > 0.0) {
            d8 += d2;
        }
        return getBoundingBoxFromPool(d3, d4, d5, d6, d7, d8);
    }
    
    public AxisAlignedBB expand(final double d, final double d1, final double d2) {
        final double d3 = this.minX - d;
        final double d4 = this.minY - d1;
        final double d5 = this.minZ - d2;
        final double d6 = this.maxX + d;
        final double d7 = this.maxY + d1;
        final double d8 = this.maxZ + d2;
        return getBoundingBoxFromPool(d3, d4, d5, d6, d7, d8);
    }
    
    public AxisAlignedBB getOffsetBoundingBox(final double d, final double d1, final double d2) {
        return getBoundingBoxFromPool(this.minX + d, this.minY + d1, this.minZ + d2, this.maxX + d, this.maxY + d1, this.maxZ + d2);
    }
    
    public double calculateXOffset(final AxisAlignedBB axisalignedbb, double d) {
        if (axisalignedbb.maxY <= this.minY || axisalignedbb.minY >= this.maxY) {
            return d;
        }
        if (axisalignedbb.maxZ <= this.minZ || axisalignedbb.minZ >= this.maxZ) {
            return d;
        }
        if (d > 0.0 && axisalignedbb.maxX <= this.minX) {
            final double d2 = this.minX - axisalignedbb.maxX;
            if (d2 < d) {
                d = d2;
            }
        }
        if (d < 0.0 && axisalignedbb.minX >= this.maxX) {
            final double d3 = this.maxX - axisalignedbb.minX;
            if (d3 > d) {
                d = d3;
            }
        }
        return d;
    }
    
    public double calculateYOffset(final AxisAlignedBB axisalignedbb, double d) {
        if (axisalignedbb.maxX <= this.minX || axisalignedbb.minX >= this.maxX) {
            return d;
        }
        if (axisalignedbb.maxZ <= this.minZ || axisalignedbb.minZ >= this.maxZ) {
            return d;
        }
        if (d > 0.0 && axisalignedbb.maxY <= this.minY) {
            final double d2 = this.minY - axisalignedbb.maxY;
            if (d2 < d) {
                d = d2;
            }
        }
        if (d < 0.0 && axisalignedbb.minY >= this.maxY) {
            final double d3 = this.maxY - axisalignedbb.minY;
            if (d3 > d) {
                d = d3;
            }
        }
        return d;
    }
    
    public double calculateZOffset(final AxisAlignedBB axisalignedbb, double d) {
        if (axisalignedbb.maxX <= this.minX || axisalignedbb.minX >= this.maxX) {
            return d;
        }
        if (axisalignedbb.maxY <= this.minY || axisalignedbb.minY >= this.maxY) {
            return d;
        }
        if (d > 0.0 && axisalignedbb.maxZ <= this.minZ) {
            final double d2 = this.minZ - axisalignedbb.maxZ;
            if (d2 < d) {
                d = d2;
            }
        }
        if (d < 0.0 && axisalignedbb.minZ >= this.maxZ) {
            final double d3 = this.maxZ - axisalignedbb.minZ;
            if (d3 > d) {
                d = d3;
            }
        }
        return d;
    }
    
    public boolean intersectsWith(final AxisAlignedBB axisalignedbb) {
        return axisalignedbb.maxX > this.minX && axisalignedbb.minX < this.maxX && axisalignedbb.maxY > this.minY && axisalignedbb.minY < this.maxY && (axisalignedbb.maxZ > this.minZ && axisalignedbb.minZ < this.maxZ);
    }
    
    public AxisAlignedBB offset(final double d, final double d1, final double d2) {
        this.minX += d;
        this.minY += d1;
        this.minZ += d2;
        this.maxX += d;
        this.maxY += d1;
        this.maxZ += d2;
        return this;
    }
    
    public boolean isVecInside(final Vec3D vec3d) {
        return vec3d.xCoord > this.minX && vec3d.xCoord < this.maxX && vec3d.yCoord > this.minY && vec3d.yCoord < this.maxY && (vec3d.zCoord > this.minZ && vec3d.zCoord < this.maxZ);
    }
    
    public AxisAlignedBB func_28195_e(final double d, final double d1, final double d2) {
        final double d3 = this.minX + d;
        final double d4 = this.minY + d1;
        final double d5 = this.minZ + d2;
        final double d6 = this.maxX - d;
        final double d7 = this.maxY - d1;
        final double d8 = this.maxZ - d2;
        return getBoundingBoxFromPool(d3, d4, d5, d6, d7, d8);
    }
    
    public double getAverageEdgeLength() {
        final double d = this.maxX - this.minX;
        final double d2 = this.maxY - this.minY;
        final double d3 = this.maxZ - this.minZ;
        return (d + d2 + d3) / 3.0;
    }
    
    public AxisAlignedBB copy() {
        return getBoundingBoxFromPool(this.minX, this.minY, this.minZ, this.maxX, this.maxY, this.maxZ);
    }
    
    public MovingObjectPosition func_1169_a(final Vec3D vec3d, final Vec3D vec3d1) {
        Vec3D vec3d2 = vec3d.getIntermediateWithXValue(vec3d1, this.minX);
        Vec3D vec3d3 = vec3d.getIntermediateWithXValue(vec3d1, this.maxX);
        Vec3D vec3d4 = vec3d.getIntermediateWithYValue(vec3d1, this.minY);
        Vec3D vec3d5 = vec3d.getIntermediateWithYValue(vec3d1, this.maxY);
        Vec3D vec3d6 = vec3d.getIntermediateWithZValue(vec3d1, this.minZ);
        Vec3D vec3d7 = vec3d.getIntermediateWithZValue(vec3d1, this.maxZ);
        if (!this.isVecInYZ(vec3d2)) {
            vec3d2 = null;
        }
        if (!this.isVecInYZ(vec3d3)) {
            vec3d3 = null;
        }
        if (!this.isVecInXZ(vec3d4)) {
            vec3d4 = null;
        }
        if (!this.isVecInXZ(vec3d5)) {
            vec3d5 = null;
        }
        if (!this.isVecInXY(vec3d6)) {
            vec3d6 = null;
        }
        if (!this.isVecInXY(vec3d7)) {
            vec3d7 = null;
        }
        Vec3D vec3d8 = null;
        if (vec3d2 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d2) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d2;
        }
        if (vec3d3 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d3) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d3;
        }
        if (vec3d4 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d4) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d4;
        }
        if (vec3d5 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d5) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d5;
        }
        if (vec3d6 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d6) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d6;
        }
        if (vec3d7 != null && (vec3d8 == null || vec3d.squareDistanceTo(vec3d7) < vec3d.squareDistanceTo(vec3d8))) {
            vec3d8 = vec3d7;
        }
        if (vec3d8 == null) {
            return null;
        }
        byte byte0 = -1;
        if (vec3d8 == vec3d2) {
            byte0 = 4;
        }
        if (vec3d8 == vec3d3) {
            byte0 = 5;
        }
        if (vec3d8 == vec3d4) {
            byte0 = 0;
        }
        if (vec3d8 == vec3d5) {
            byte0 = 1;
        }
        if (vec3d8 == vec3d6) {
            byte0 = 2;
        }
        if (vec3d8 == vec3d7) {
            byte0 = 3;
        }
        return new MovingObjectPosition(0, 0, 0, byte0, vec3d8);
    }
    
    private boolean isVecInYZ(final Vec3D vec3d) {
        return vec3d != null && (vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ);
    }
    
    private boolean isVecInXZ(final Vec3D vec3d) {
        return vec3d != null && (vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ);
    }
    
    private boolean isVecInXY(final Vec3D vec3d) {
        return vec3d != null && (vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY);
    }
    
    public void setBB(final AxisAlignedBB axisalignedbb) {
        this.minX = axisalignedbb.minX;
        this.minY = axisalignedbb.minY;
        this.minZ = axisalignedbb.minZ;
        this.maxX = axisalignedbb.maxX;
        this.maxY = axisalignedbb.maxY;
        this.maxZ = axisalignedbb.maxZ;
    }
}
