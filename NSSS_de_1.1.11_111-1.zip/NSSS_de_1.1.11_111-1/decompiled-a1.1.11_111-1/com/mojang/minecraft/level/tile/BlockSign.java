package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockSign extends BlockContainer
{
    private Class<?> field_455_a;
    private boolean field_454_b;
    
    protected BlockSign(final int i, final Class<?> class1, final boolean flag) {
        super(i, Material.wood);
        this.field_454_b = flag;
        this.blockIndexInTexture = 4;
        this.field_455_a = class1;
        final float f = 0.25f;
        final float f2 = 1.0f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, f2, 0.5f + f);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        this.setBlockBoundsBasedOnState(world, i, j, k);
        return super.getSelectedCollisionBoundingBoxFromPool(world, i, j, k);
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        if (this.field_454_b) {
            return;
        }
        final int l = iblockaccess.getBlockMetadata(i, j, k);
        final float f = 0.28125f;
        final float f2 = 0.78125f;
        final float f3 = 0.0f;
        final float f4 = 1.0f;
        final float f5 = 0.125f;
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        if (l == 2) {
            this.setBlockBounds(f3, f, 1.0f - f5, f4, f2, 1.0f);
        }
        if (l == 3) {
            this.setBlockBounds(f3, f, 0.0f, f4, f2, f5);
        }
        if (l == 4) {
            this.setBlockBounds(1.0f - f5, f, f3, 1.0f, f2, f4);
        }
        if (l == 5) {
            this.setBlockBounds(0.0f, f, f3, f5, f2, f4);
        }
    }
    
    @Override
    public int getRenderType() {
        return -1;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        try {
            return (TileEntity)this.field_455_a.newInstance();
        }
        catch (Exception exception) {
            throw new RuntimeException(exception);
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.sign.shiftedIndex;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        boolean flag = false;
        if (this.field_454_b) {
            if (!world.getMaterialXYZ(i, j - 1, k).isSolidMaterial()) {
                flag = true;
            }
        }
        else {
            final int i2 = world.getBlockMetadata(i, j, k);
            flag = true;
            if (i2 == 2 && world.getMaterialXYZ(i, j, k + 1).isSolidMaterial()) {
                flag = false;
            }
            if (i2 == 3 && world.getMaterialXYZ(i, j, k - 1).isSolidMaterial()) {
                flag = false;
            }
            if (i2 == 4 && world.getMaterialXYZ(i + 1, j, k).isSolidMaterial()) {
                flag = false;
            }
            if (i2 == 5 && world.getMaterialXYZ(i - 1, j, k).isSolidMaterial()) {
                flag = false;
            }
        }
        if (flag) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
        super.onNeighborBlockChange(world, i, j, k, l);
    }
}
