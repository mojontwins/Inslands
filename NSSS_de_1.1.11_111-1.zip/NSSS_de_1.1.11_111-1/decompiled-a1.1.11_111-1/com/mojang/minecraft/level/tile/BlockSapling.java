package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.generate.*;

public class BlockSapling extends BlockFlower
{
    protected BlockSapling(final int i, final int j) {
        super(i, j);
        final float f = 0.4f;
        this.setBlockBounds(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, f * 2.0f, 0.5f + f);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.multiplayerWorld) {
            return;
        }
        super.updateTick(world, i, j, k, random);
        if (world.getBlockLightValue(i, j + 1, k) >= 9 && random.nextInt(5) == 0) {
            final int l = world.getBlockMetadata(i, j, k);
            if (l < 15) {
                world.setBlockMetadataWithNotify(i, j, k, l + 1);
            }
            else {
                world.setBlock(i, j, k, 0);
                Object obj = new WorldGenTrees();
                if (random.nextInt(10) == 0) {
                    obj = new WorldGenBigTree();
                }
                if (!((WorldGenerator)obj).generate(world, random, i, j, k)) {
                    world.setBlock(i, j, k, this.blockID);
                }
            }
        }
    }
    
    public void growTree(final World world, final int i, final int j, final int k, final Random random) {
        final int l = world.getBlockMetadata(i, j, k) & 0x3;
        world.setBlock(i, j, k, 0);
        Object obj = null;
        obj = new WorldGenTrees();
        if (random.nextInt(10) == 0) {
            obj = new WorldGenBigTree();
        }
        if (!((WorldGenerator)obj).generate(world, random, i, j, k)) {
            world.setBlockAndMetadata(i, j, k, this.blockID, l);
        }
    }
}
