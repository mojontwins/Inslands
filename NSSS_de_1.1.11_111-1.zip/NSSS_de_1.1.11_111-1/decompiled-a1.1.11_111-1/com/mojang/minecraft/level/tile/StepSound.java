package com.mojang.minecraft.level.tile;

public class StepSound
{
    public final String field_1678_a;
    public final float volume;
    public final float pitch;
    
    public StepSound(final String s, final float f, final float f1) {
        this.field_1678_a = s;
        this.volume = f;
        this.pitch = f1;
    }
    
    public float getVolume() {
        return this.volume;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public String stepSoundDir() {
        return "step." + this.field_1678_a;
    }
    
    public String func_1145_d() {
        return "step." + this.field_1678_a;
    }
}
