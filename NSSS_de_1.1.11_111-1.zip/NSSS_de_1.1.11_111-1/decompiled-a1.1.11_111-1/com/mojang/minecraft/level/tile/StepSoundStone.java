package com.mojang.minecraft.level.tile;

final class StepSoundStone extends StepSound
{
    StepSoundStone(final String s, final float f, final float f1) {
        super(s, f, f1);
    }
    
    @Override
    public String stepSoundDir() {
        return "random.glass";
    }
}
