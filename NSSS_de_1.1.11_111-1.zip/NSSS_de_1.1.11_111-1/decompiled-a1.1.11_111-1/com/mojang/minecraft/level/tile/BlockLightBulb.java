package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockLightBulb extends Block
{
    protected BlockLightBulb(final int i) {
        super(i, Material.glass);
        this.blockIndexInTexture = i + 5;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return true;
    }
    
    @Override
    public void onBlockAdded(final World world, final int a, final int b, final int c) {
        super.onBlockAdded(world, a, b, c);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        final boolean power = this.isReceivingRedstonePower(world, i, j, k, l);
        if (power) {
            world.setBlock(i, j, k, 98);
        }
        else {
            world.setBlock(i, j, k, 97);
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.lightBulb.blockID;
    }
    
    public static boolean isPowered(final int i) {
        return (i & 0x8) != 0x0;
    }
    
    @Override
    public void updateTick(final World world, final int a, final int b, final int c, final Random random) {
        super.updateTick(world, a, b, c, random);
    }
    
    private boolean isReceivingRedstonePower(final World world, final int i, final int j, final int k, final int l) {
        return (l != 0 && world.isBlockIndirectlyProvidingPowerTo(i, j - 1, k, 0)) || (l != 1 && world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k, 1)) || (l != 2 && world.isBlockIndirectlyProvidingPowerTo(i, j, k - 1, 2)) || (l != 3 && world.isBlockIndirectlyProvidingPowerTo(i, j, k + 1, 3)) || (l != 5 && world.isBlockIndirectlyProvidingPowerTo(i + 1, j, k, 5)) || (l != 4 && world.isBlockIndirectlyProvidingPowerTo(i - 1, j, k, 4)) || world.isBlockIndirectlyProvidingPowerTo(i, j, k, 0) || world.isBlockIndirectlyProvidingPowerTo(i, j + 2, k, 1) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k - 1, 2) || world.isBlockIndirectlyProvidingPowerTo(i, j + 1, k + 1, 3) || world.isBlockIndirectlyProvidingPowerTo(i - 1, j + 1, k, 4) || world.isBlockIndirectlyProvidingPowerTo(i + 1, j + 1, k, 5);
    }
    
    @Override
    public void dropBlockAsItemWithChance(final World world, final int a, final int b, final int c, final int bid) {
        super.dropBlockAsItemWithChance(world, a, b, c, bid);
    }
}
