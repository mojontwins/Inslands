package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;

public class Block
{
    public static final StepSound soundPowderFootstep;
    public static final StepSound soundWoodFootstep;
    public static final StepSound soundGravelFootstep;
    public static final StepSound soundGrassFootstep;
    public static final StepSound soundStoneFootstep;
    public static final StepSound soundMetalFootstep;
    public static final StepSound soundGlassFootstep;
    public static final StepSound soundClothFootstep;
    public static final StepSound soundSandFootstep;
    public static final StepSound soundNoFootstep;
    public static final Block[] allBlocks;
    public static final boolean[] tickOnLoad;
    public static final boolean[] opaqueCubeLookup;
    public static final boolean[] isBlockContainer;
    public static final int[] lightOpacity;
    public static final boolean[] field_340_s;
    public static final int[] lightValue;
    public static final Block stone;
    public static final BlockGrass grass;
    public static final Block dirt;
    public static final Block cobblestone;
    public static final Block planks;
    public static final Block sapling;
    public static final Block bedrock;
    public static final Block waterMoving;
    public static final Block waterStill;
    public static final Block lavaMoving;
    public static final Block lavaStill;
    public static final Block sand;
    public static final Block gravel;
    public static final Block oreGold;
    public static final Block oreIron;
    public static final Block oreCoal;
    public static final Block wood;
    public static final BlockLeaves leaves;
    public static final Block sponge;
    public static final Block glass;
    public static final Block cloth_red;
    public static final Block cloth_orange;
    public static final Block cloth_yellow;
    public static final Block cloth_lime;
    public static final Block cloth_green;
    public static final Block cloth_teal;
    public static final Block cloth_cyan;
    public static final Block cloth_blue;
    public static final Block cloth_indigo;
    public static final Block cloth_violet;
    public static final Block cloth_lilac;
    public static final Block cloth_pink;
    public static final Block cloth_magenta;
    public static final Block cloth_darkgray;
    public static final Block cloth;
    public static final Block cloth_lightgray;
    public static final BlockFlower plantYellow;
    public static final BlockFlower plantRed;
    public static final BlockFlower mushroomBrown;
    public static final BlockFlower mushroomRed;
    public static final Block blockGold;
    public static final Block blockSteel;
    public static final Block stairDouble;
    public static final Block stairSingle;
    public static final Block brick;
    public static final Block tnt;
    public static final Block bookShelf;
    public static final Block cobblestoneMossy;
    public static final Block obsidian;
    public static final Block torchWood;
    public static final BlockFire fire;
    public static final Block mobSpawner;
    public static final Block stairCompact_Wood;
    public static final Block crate;
    public static final Block redstoneWire;
    public static final Block oreDiamond;
    public static final Block blockDiamond;
    public static final Block workbench;
    public static final Block crops;
    public static final Block tilledField;
    public static final Block stoneOvenIdle;
    public static final Block stoneOvenActive;
    public static final Block signPost;
    public static final Block doorWood;
    public static final Block ladder;
    public static final Block minecartTrack;
    public static final Block stairCompactStone;
    public static final Block pressurePlateWoodIdle;
    public static final Block lever;
    public static final Block pressurePlateStone;
    public static final Block doorSteel;
    public static final Block pressurePlateWood;
    public static final Block oreRed;
    public static final Block oreRedstoneGlowing;
    public static final Block torchRedstoneIdle;
    public static final Block torchRedstoneActive;
    public static final Block button;
    public static final Block snow;
    public static final Block ice;
    public static final Block blockSnow;
    public static final Block cactus;
    public static final Block blockClay;
    public static final Block reed;
    public static final Block jukebox;
    public static final Block fence;
    public static final Block gear;
    public static final Block spongeInactive;
    public static final BlockFlower plantBlue;
    public static final Block oreCopper;
    public static final Block motor;
    public static final Block generator;
    public static final Block blockCopper;
    public static final Block brickMossy;
    public static final Block bleedingObsidian;
    public static final Block web;
    public static final Block pressurePlateSteel;
    public static final Block lightBulb;
    public static final Block lightBulbOn;
    public static final Block pyramidion;
    public static final Block test;
    public int blockIndexInTexture;
    public final int blockID;
    protected float blockHardness;
    protected float blockResistance;
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;
    public StepSound stepSound;
    public float field_357_bm;
    public final Material blockMaterial;
    public float slipperiness;
    public int blockGearPower;
    public int primaryColor;
    public int secondaryColor;
    
    static {
        tickOnLoad = new boolean[256];
        opaqueCubeLookup = new boolean[256];
        isBlockContainer = new boolean[256];
        lightOpacity = new int[256];
        field_340_s = new boolean[256];
        lightValue = new int[256];
        soundPowderFootstep = new StepSound("stone", 1.0f, 1.0f);
        soundWoodFootstep = new StepSound("wood", 1.0f, 1.0f);
        soundGravelFootstep = new StepSound("gravel", 1.0f, 1.0f);
        soundGrassFootstep = new StepSound("grass", 1.0f, 1.0f);
        soundStoneFootstep = new StepSound("stone", 1.0f, 1.0f);
        soundMetalFootstep = new StepSound("stone", 1.0f, 1.5f);
        soundGlassFootstep = new StepSoundStone("stone", 1.0f, 1.0f);
        soundClothFootstep = new StepSound("cloth", 1.0f, 1.0f);
        soundSandFootstep = new StepSoundSand("sand", 1.0f, 1.0f);
        soundNoFootstep = new StepSound("stone", 0.0f, 0.0f);
        allBlocks = new Block[256];
        stone = new BlockStone(1, 1).setHardness(1.5f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988);
        grass = (BlockGrass)new BlockGrass(2).setHardness(0.6f).setStepSound(Block.soundGrassFootstep).setColor(7845709);
        dirt = new BlockDirt(3, 2).setHardness(0.5f).setStepSound(Block.soundGravelFootstep).setColor(7951674);
        cobblestone = new Block(4, 16, Material.rock).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(6316128);
        planks = new Block(5, 4, Material.wood).setHardness(2.0f).setResistance(5.0f).setStepSound(Block.soundWoodFootstep).setColor(12359778);
        sapling = new BlockSapling(6, 15).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(25600);
        bedrock = new Block(7, 17, Material.rock).setHardness(-1.0f).setResistance(6000000.0f).setStepSound(Block.soundStoneFootstep).setColor(3355443);
        waterMoving = new BlockFlowing(8, Material.water).setHardness(100.0f).setLightOpacity(3).setStepSound(Block.soundNoFootstep).setColor(1987581);
        waterStill = new BlockStationary(9, Material.water).setHardness(100.0f).setLightOpacity(3).setStepSound(Block.soundNoFootstep).setColor(1987581);
        lavaMoving = new BlockFlowing(10, Material.lava).setHardness(0.0f).setLightValue(1.0f).setLightOpacity(255).setStepSound(Block.soundNoFootstep).setColor(16537344);
        lavaStill = new BlockStationary(11, Material.lava).setHardness(100.0f).setLightValue(1.0f).setLightOpacity(255).setStepSound(Block.soundNoFootstep).setColor(16537344);
        sand = new BlockSand(12, 18).setHardness(0.5f).setStepSound(Block.soundSandFootstep).setColor(15129006);
        gravel = new BlockGravel(13, 19).setHardness(0.6f).setStepSound(Block.soundGravelFootstep).setColor(10786456);
        oreGold = new BlockOre(14, 32).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 16773444);
        oreIron = new BlockOre(15, 33).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 15329769);
        oreCoal = new BlockOre(16, 34).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 6938586);
        wood = new BlockLog(17).setHardness(2.0f).setStepSound(Block.soundWoodFootstep).setColor(6705456);
        leaves = (BlockLeaves)new BlockLeaves(18, 52).setHardness(0.2f).setLightOpacity(1).setStepSound(Block.soundGrassFootstep).setColor(4180006);
        sponge = new BlockSponge(19).setHardness(0.6f).setStepSound(Block.soundGrassFootstep).setColor(13553222);
        glass = new BlockGlass(20, 49, Material.glass, false).setHardness(0.3f).setStepSound(Block.soundGlassFootstep).setColor(0, 12645886);
        cloth_red = new Block(21, 144, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(16726586);
        cloth_orange = new Block(22, 145, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(15043636);
        cloth_yellow = new Block(23, 146, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(15855926);
        cloth_lime = new Block(24, 147, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(9695542);
        cloth_green = new Block(25, 148, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(3466548);
        cloth_teal = new Block(26, 149, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(3600787);
        cloth_cyan = new Block(27, 150, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(3533546);
        cloth_blue = new Block(28, 151, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(6923744);
        cloth_indigo = new Block(29, 152, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(7961056);
        cloth_violet = new Block(30, 153, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(8335313);
        cloth_lilac = new Block(31, 154, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(11816165);
        cloth_pink = new Block(32, 155, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(15021285);
        cloth_magenta = new Block(33, 156, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(15611538);
        cloth_darkgray = new Block(34, 157, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(5460819);
        cloth = new Block(35, 64, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(14737632);
        cloth_lightgray = new Block(36, 158, Material.cloth).setHardness(0.8f).setStepSound(Block.soundClothFootstep).setColor(10329501);
        plantYellow = (BlockFlower)new BlockFlower(37, 13).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(13423362);
        plantRed = (BlockFlower)new BlockFlower(38, 12).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(13698569);
        mushroomBrown = (BlockFlower)new BlockMushroom(39, 29).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setLightValue(0.125f).setColor(9530709);
        mushroomRed = (BlockFlower)new BlockMushroom(40, 28).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(14815762);
        blockGold = new BlockOreBlock(41, 39).setHardness(3.0f).setResistance(10.0f).setStepSound(Block.soundMetalFootstep).setColor(16773444);
        blockSteel = new BlockOreBlock(42, 38).setHardness(5.0f).setResistance(10.0f).setStepSound(Block.soundMetalFootstep).setColor(15329769);
        stairDouble = new BlockStep(43, true).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(10724259);
        stairSingle = new BlockStep(44, false).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(10724259);
        brick = new Block(45, 7, Material.rock).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(8010795, 11842740);
        tnt = new BlockTNT(46, 8).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(14369818, 0);
        bookShelf = new BlockBookshelf(47, 35).setHardness(1.5f).setStepSound(Block.soundWoodFootstep).setColor(7704081, 12359778);
        cobblestoneMossy = new Block(48, 36, Material.rock).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(6316128, 1851676);
        obsidian = new BlockObsidian(49, 37).setHardness(10.0f).setResistance(2000.0f).setStepSound(Block.soundStoneFootstep).setColor(1511716);
        torchWood = new BlockTorch(50, 80).setHardness(0.0f).setLightValue(0.9375f).setStepSound(Block.soundWoodFootstep).setColor(167739216);
        fire = (BlockFire)new BlockFire(51, 31).setHardness(0.0f).setLightValue(1.0f).setStepSound(Block.soundWoodFootstep).setColor(16748288);
        mobSpawner = new BlockMobSpawner(52, 65).setHardness(5.0f).setStepSound(Block.soundMetalFootstep).setColor(0, 1791100);
        stairCompact_Wood = new BlockStairs(53, Block.planks).setColor(12359778);
        crate = new BlockChest(54).setHardness(2.5f).setStepSound(Block.soundWoodFootstep).setColor(10972703);
        redstoneWire = new BlockRedstoneWire(55, 84).setHardness(0.0f).setStepSound(Block.soundPowderFootstep).setColor(4718592, 16580608);
        oreDiamond = new BlockOre(56, 50).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 6938586);
        blockDiamond = new BlockOreBlock(57, 40).setHardness(5.0f).setResistance(10.0f).setStepSound(Block.soundMetalFootstep).setColor(6938586);
        workbench = new BlockWorkbench(58).setHardness(2.5f).setStepSound(Block.soundWoodFootstep).setColor(11234882);
        crops = new BlockCrops(59, 88).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(1676049);
        tilledField = new BlockSoil(60).setHardness(0.6f).setStepSound(Block.soundGravelFootstep).setColor(4532501);
        stoneOvenIdle = new BlockFurnace(61, false).setHardness(3.5f).setStepSound(Block.soundStoneFootstep).setColor(7303023);
        stoneOvenActive = new BlockFurnace(62, true).setHardness(3.5f).setStepSound(Block.soundStoneFootstep).setLightValue(0.875f).setColor(7303023);
        signPost = new BlockSign(63, TileEntitySign.class, true).setHardness(1.0f).setStepSound(Block.soundWoodFootstep).setColor(12359778);
        doorWood = new BlockDoor(64, Material.wood).setHardness(3.0f).setStepSound(Block.soundWoodFootstep).setColor(9005106);
        ladder = new BlockLadder(65, 83).setHardness(0.4f).setStepSound(Block.soundWoodFootstep).setColor(0, 11307090);
        minecartTrack = new BlockMinecartTrack(66, 128).setHardness(0.7f).setStepSound(Block.soundMetalFootstep).setColor(0, 10790052);
        stairCompactStone = new BlockStairs(67, Block.cobblestone).setColor(6316128);
        pressurePlateWoodIdle = new BlockSign(68, TileEntitySign.class, false).setHardness(1.0f).setStepSound(Block.soundWoodFootstep).setColor(12359778);
        lever = new BlockLever(69, 96).setHardness(0.5f).setStepSound(Block.soundWoodFootstep).setColor(7500402);
        pressurePlateStone = new BlockPressurePlate(70, Block.stone.blockIndexInTexture, EnumMobType.mobs).setHardness(0.5f).setStepSound(Block.soundStoneFootstep).setColor(7631988);
        doorSteel = new BlockDoor(71, Material.iron).setHardness(5.0f).setStepSound(Block.soundMetalFootstep).setColor(15329769);
        pressurePlateWood = new BlockPressurePlate(72, Block.planks.blockIndexInTexture, EnumMobType.everything).setHardness(0.5f).setStepSound(Block.soundWoodFootstep).setColor(12359778);
        oreRed = new BlockRedstoneOre(73, 51, false).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 9372419);
        oreRedstoneGlowing = new BlockRedstoneOre(74, 51, true).setLightValue(0.625f).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 16711680);
        torchRedstoneIdle = new BlockRedstoneTorch(75, 115, false).setHardness(0.0f).setStepSound(Block.soundWoodFootstep).setColor(4718592);
        torchRedstoneActive = new BlockRedstoneTorch(76, 99, true).setHardness(0.0f).setLightValue(0.5f).setStepSound(Block.soundWoodFootstep).setColor(16580608);
        button = new BlockButton(77, Block.stone.blockIndexInTexture).setHardness(0.5f).setStepSound(Block.soundStoneFootstep).setColor(7631988);
        snow = new BlockSnow(78, 66).setHardness(0.1f).setStepSound(Block.soundClothFootstep).setColor(14939123);
        ice = new BlockIce(79, 67).setHardness(0.5f).setLightOpacity(3).setStepSound(Block.soundGlassFootstep).setColor(7710717);
        blockSnow = new BlockSnowBlock(80, 66).setHardness(0.2f).setStepSound(Block.soundClothFootstep).setColor(14939123);
        cactus = new BlockCactus(81, 70).setHardness(0.4f).setStepSound(Block.soundClothFootstep).setColor(1147679);
        blockClay = new BlockClay(82, 72).setHardness(0.6f).setStepSound(Block.soundGravelFootstep).setColor(10527925);
        reed = new BlockReed(83, 73).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(11197300);
        jukebox = new BlockJukeBox(84, 74).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(9525312, 4663837);
        fence = new BlockFence(85, 4).setHardness(2.0f).setResistance(5.0f).setStepSound(Block.soundWoodFootstep).setColor(12359778);
        gear = new BlockGear(86, 62).setHardness(0.5f).setResistance(5.0f).setStepSound(Block.soundPowderFootstep);
        spongeInactive = new BlockSpongeInactive(87).setHardness(0.6f).setStepSound(Block.soundGrassFootstep).setColor(13553222);
        plantBlue = (BlockFlower)new BlockFlower(88, 14).setHardness(0.0f).setStepSound(Block.soundGrassFootstep).setColor(3973835);
        oreCopper = new BlockOre(89, 76).setHardness(3.0f).setResistance(5.0f).setStepSound(Block.soundStoneFootstep).setColor(7631988, 10538147);
        motor = new BlockMotor(90, 113, Material.iron, true, 30).setHardness(3.5f).setStepSound(Block.soundMetalFootstep).setLightValue(0.875f);
        generator = new BlockMotor(91, 114, Material.iron, false, -1).setHardness(3.5f).setStepSound(Block.soundMetalFootstep).setLightValue(0.875f);
        blockCopper = new BlockOreBlock(92, 176).setHardness(5.0f).setResistance(10.0f).setStepSound(Block.soundMetalFootstep).setColor(15373137);
        brickMossy = new Block(93, 77, Material.rock).setHardness(2.0f).setResistance(10.0f).setStepSound(Block.soundStoneFootstep).setColor(8010795, 7845709);
        bleedingObsidian = new BlockBleedingObsidian(94, 116).setHardness(10.0f).setResistance(2000.0f).setStepSound(Block.soundStoneFootstep).setColor(3809868, 737702);
        web = new BlockWeb(95, 11).setHardness(2.0f).setStepSound(Block.soundClothFootstep).setColor(0, 16777215);
        pressurePlateSteel = new BlockPressurePlate(96, Block.blockSteel.blockIndexInTexture, EnumMobType.players).setHardness(0.5f).setStepSound(Block.soundMetalFootstep).setColor(15329769);
        lightBulb = new BlockLightBulb(97).setHardness(0.5f).setStepSound(Block.soundGlassFootstep).setColor(15066338, 16051672);
        lightBulbOn = new BlockLightBulb(98).setHardness(0.5f).setStepSound(Block.soundGlassFootstep).setLightValue(1.0f).setColor(16775844, 16051672);
        pyramidion = new BlockPyramidion(99, 104).setHardness(0.5f).setStepSound(Block.soundMetalFootstep).setLightValue(1.0f).setColor(8010795, 16773444);
        test = new Block(100, 88, Material.iron).setHardness(0.5f).setStepSound(Block.soundMetalFootstep).setLightValue(1.0f);
        for (int i = 0; i < 256; ++i) {
            if (Block.allBlocks[i] != null) {
                Item.itemsList[i] = new ItemBlock(i - 256);
            }
        }
    }
    
    protected Block(final int i, final Material material1) {
        this.blockGearPower = 0;
        this.primaryColor = 16777215;
        this.secondaryColor = 16777215;
        this.stepSound = Block.soundPowderFootstep;
        this.field_357_bm = 1.0f;
        this.slipperiness = 0.6f;
        if (Block.allBlocks[i] != null) {
            throw new IllegalArgumentException("Slot " + i + " is already occupied by " + Block.allBlocks[i] + " when adding " + this);
        }
        this.blockMaterial = material1;
        Block.allBlocks[i] = this;
        this.blockID = i;
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        Block.opaqueCubeLookup[i] = this.isOpaqueCube();
        Block.lightOpacity[i] = (this.isOpaqueCube() ? 255 : 0);
        Block.field_340_s[i] = this.func_212_i();
        Block.isBlockContainer[i] = false;
    }
    
    protected Block(final int i, final int j, final Material material1) {
        this(i, material1);
        this.blockIndexInTexture = j;
    }
    
    protected Block setColor(final int color) {
        this.primaryColor = color;
        return this;
    }
    
    protected Block setColor(final int color, final int color2) {
        this.primaryColor = color;
        this.secondaryColor = color2;
        return this;
    }
    
    protected Block setStepSound(final StepSound stepsound) {
        this.stepSound = stepsound;
        return this;
    }
    
    protected Block setLightOpacity(final int i) {
        Block.lightOpacity[this.blockID] = i;
        return this;
    }
    
    protected Block setLightValue(final float f) {
        Block.lightValue[this.blockID] = (int)(15.0f * f);
        return this;
    }
    
    protected Block setResistance(final float f) {
        this.blockResistance = f * 3.0f;
        return this;
    }
    
    private boolean func_212_i() {
        return false;
    }
    
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    public int getRenderType() {
        return 0;
    }
    
    protected Block setHardness(final float f) {
        this.blockHardness = f;
        if (this.blockResistance < f * 5.0f) {
            this.blockResistance = f * 5.0f;
        }
        return this;
    }
    
    protected void setTickOnLoad(final boolean flag) {
        Block.tickOnLoad[this.blockID] = flag;
    }
    
    public void setBlockBounds(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
        this.minX = f;
        this.minY = f1;
        this.minZ = f2;
        this.maxX = f3;
        this.maxY = f4;
        this.maxZ = f5;
    }
    
    public float getBlockBrightness(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return iblockaccess.getBrightness(i, j, k);
    }
    
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int x, final int y, final int z, final int face) {
        return (face != 1 || iblockaccess.getBlockId(x, y, z) != Block.snow.blockID) && ((face == 0 && this.minY > 0.0) || (face == 1 && this.maxY < 1.0) || (face == 2 && this.minZ > 0.0) || (face == 3 && this.maxZ < 1.0) || (face == 4 && this.minX > 0.0) || (face == 5 && this.maxX < 1.0) || !iblockaccess.isBlockNormalCube(x, y, z));
    }
    
    public int getTextureIndex(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return this.getBlockTextureFromSideAndMetadata(l, iblockaccess.getBlockMetadata(i, j, k));
    }
    
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        return this.getTextureIndex(i);
    }
    
    public int getTextureIndex(final int i) {
        return this.blockIndexInTexture;
    }
    
    public AxisAlignedBB getSelectedCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return AxisAlignedBB.getBoundingBoxFromPool(i + this.minX, j + this.minY, k + this.minZ, i + this.maxX, j + this.maxY, k + this.maxZ);
    }
    
    public void getCollidingBoundingBoxes(final World world, final int i, final int j, final int k, final AxisAlignedBB axisalignedbb, final ArrayList<AxisAlignedBB> arraylist) {
        final AxisAlignedBB axisalignedbb2 = this.getCollisionBoundingBoxFromPool(world, i, j, k);
        if (axisalignedbb2 != null && axisalignedbb.intersectsWith(axisalignedbb2)) {
            arraylist.add(axisalignedbb2);
        }
    }
    
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return AxisAlignedBB.getBoundingBoxFromPool(i + this.minX, j + this.minY, k + this.minZ, i + this.maxX, j + this.maxY, k + this.maxZ);
    }
    
    public boolean isOpaqueCube() {
        return true;
    }
    
    public boolean canCollideCheck(final int i, final boolean flag) {
        return this.isCollidable();
    }
    
    public boolean isCollidable() {
        return true;
    }
    
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
    }
    
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
    }
    
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l) {
    }
    
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
    }
    
    public int tickRate() {
        return 10;
    }
    
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
    }
    
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
    }
    
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    public int idDropped(final int i, final Random random) {
        return this.blockID;
    }
    
    public float blockStrength(final EntityPlayer entityplayer) {
        if (this.blockHardness < 0.0f) {
            return 0.0f;
        }
        if (!entityplayer.checkBreakBlock(this)) {
            return 1.0f / this.blockHardness / 100.0f;
        }
        return entityplayer.getMiningInhibitors(this) / this.blockHardness / 30.0f;
    }
    
    public void dropBlockAsItem(final World world, final int i, final int j, final int k, final int l) {
        this.dropBlockAsItemWithChance(world, i, j, k, l, 1.0f);
    }
    
    public void dropBlockAsItemWithChance(final World world, final int i, final int j, final int k, final int l, final float f) {
        if (world.multiplayerWorld) {
            return;
        }
        for (int i2 = this.quantityDropped(world.rand), j2 = 0; j2 < i2; ++j2) {
            if (world.rand.nextFloat() <= f) {
                final int k2 = this.idDropped(l, world.rand);
                if (k2 > 0) {
                    this.dropBlockAsItem_do(world, i, j, k, new ItemStack(k2, 1, this.damageDropped(l)));
                }
            }
        }
    }
    
    public void dropBlockGoldTouch(final World world, final int x, final int y, final int z, final int damage, final float f) {
        if (world.multiplayerWorld) {
            return;
        }
        for (int i1 = 1, j1 = 0; j1 < i1; ++j1) {
            if (world.rand.nextFloat() <= f) {
                final int id = this.blockID;
                if (id > 0 && id != Block.crops.blockID && id != Block.signPost.blockID && id != Block.pressurePlateWoodIdle.blockID && id != Block.doorWood.blockID && id != Block.doorSteel.blockID && id != Block.lightBulbOn.blockID && id != Block.pyramidion.blockID) {
                    this.dropBlockAsItem_do(world, x, y, z, new ItemStack(id, 1, this.damageDropped(damage)));
                }
                else if (id == Block.crops.blockID || id == Block.signPost.blockID || id == Block.pressurePlateWoodIdle.blockID || id == Block.doorWood.blockID || id == Block.doorSteel.blockID || id == Block.lightBulbOn.blockID) {
                    this.dropBlockAsItem(world, x, y, z, damage);
                }
            }
        }
    }
    
    protected void dropBlockAsItem_do(final World world, final int i, final int j, final int k, final ItemStack itemstack) {
        if (world.multiplayerWorld) {
            return;
        }
        final float f = 0.7f;
        final double d = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final double d2 = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final double d3 = world.rand.nextFloat() * f + (1.0f - f) * 0.5;
        final EntityItem entityitem = new EntityItem(world, i + d, j + d2, k + d3, itemstack);
        entityitem.delayBeforeCanPickup = 10;
        world.entityJoinedWorld(entityitem);
    }
    
    protected int damageDropped(final int i) {
        return 0;
    }
    
    public float getExplosionResistance(final Entity entity) {
        return this.blockResistance / 5.0f;
    }
    
    public MovingObjectPosition collisionRayTrace(final World world, final int x, final int y, final int z, Vec3D vec3d, Vec3D vec3d1) {
        this.setBlockBoundsBasedOnState(world, x, y, z);
        vec3d = vec3d.addVector(-x, -y, -z);
        vec3d1 = vec3d1.addVector(-x, -y, -z);
        Vec3D vec3d2 = vec3d.getIntermediateWithXValue(vec3d1, this.minX);
        Vec3D vec3d3 = vec3d.getIntermediateWithXValue(vec3d1, this.maxX);
        Vec3D vec3d4 = vec3d.getIntermediateWithYValue(vec3d1, this.minY);
        Vec3D vec3d5 = vec3d.getIntermediateWithYValue(vec3d1, this.maxY);
        Vec3D vec3d6 = vec3d.getIntermediateWithZValue(vec3d1, this.minZ);
        Vec3D vec3d7 = vec3d.getIntermediateWithZValue(vec3d1, this.maxZ);
        if (!this.isVecInsideYZBounds(vec3d2)) {
            vec3d2 = null;
        }
        if (!this.isVecInsideYZBounds(vec3d3)) {
            vec3d3 = null;
        }
        if (!this.isVecInsideXZBounds(vec3d4)) {
            vec3d4 = null;
        }
        if (!this.isVecInsideXZBounds(vec3d5)) {
            vec3d5 = null;
        }
        if (!this.isVecInsideXYBounds(vec3d6)) {
            vec3d6 = null;
        }
        if (!this.isVecInsideXYBounds(vec3d7)) {
            vec3d7 = null;
        }
        Vec3D vec3d8 = null;
        if (vec3d2 != null && (vec3d8 == null || vec3d.distanceTo(vec3d2) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d2;
        }
        if (vec3d3 != null && (vec3d8 == null || vec3d.distanceTo(vec3d3) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d3;
        }
        if (vec3d4 != null && (vec3d8 == null || vec3d.distanceTo(vec3d4) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d4;
        }
        if (vec3d5 != null && (vec3d8 == null || vec3d.distanceTo(vec3d5) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d5;
        }
        if (vec3d6 != null && (vec3d8 == null || vec3d.distanceTo(vec3d6) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d6;
        }
        if (vec3d7 != null && (vec3d8 == null || vec3d.distanceTo(vec3d7) < vec3d.distanceTo(vec3d8))) {
            vec3d8 = vec3d7;
        }
        if (vec3d8 == null) {
            return null;
        }
        byte byte0 = -1;
        if (vec3d8 == vec3d2) {
            byte0 = 4;
        }
        if (vec3d8 == vec3d3) {
            byte0 = 5;
        }
        if (vec3d8 == vec3d4) {
            byte0 = 0;
        }
        if (vec3d8 == vec3d5) {
            byte0 = 1;
        }
        if (vec3d8 == vec3d6) {
            byte0 = 2;
        }
        if (vec3d8 == vec3d7) {
            byte0 = 3;
        }
        return new MovingObjectPosition(x, y, z, byte0, vec3d8.addVector(x, y, z));
    }
    
    private boolean isVecInsideYZBounds(final Vec3D vec3d) {
        return vec3d != null && (vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ);
    }
    
    private boolean isVecInsideXZBounds(final Vec3D vec3d) {
        return vec3d != null && (vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.zCoord >= this.minZ && vec3d.zCoord <= this.maxZ);
    }
    
    private boolean isVecInsideXYBounds(final Vec3D vec3d) {
        return vec3d != null && (vec3d.xCoord >= this.minX && vec3d.xCoord <= this.maxX && vec3d.yCoord >= this.minY && vec3d.yCoord <= this.maxY);
    }
    
    public void onBlockDestroyedByExplosion(final World world, final int i, final int j, final int k) {
    }
    
    public int getRenderBlockPass() {
        return 0;
    }
    
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j, k);
        return l == 0 || Block.allBlocks[l].blockMaterial.getIsGroundCover();
    }
    
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        return false;
    }
    
    public void onEntityWalking(final World world, final int i, final int j, final int k, final Entity entity) {
    }
    
    public void onBlockPlaced(final World world, final int i, final int j, final int k, final int l) {
    }
    
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
    }
    
    public void velocityToAddToEntity(final World world, final int i, final int j, final int k, final Entity entity, final Vec3D vec3d) {
    }
    
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
    }
    
    public int colorMultiplier(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return 16777215;
    }
    
    public int colorMultiplierFlat(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return this.primaryColor;
    }
    
    public int colorMultiplierSecondary(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return this.secondaryColor;
    }
    
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return false;
    }
    
    public boolean canProvidePower() {
        return false;
    }
    
    public void onEntityCollidedWithBlock(final World world, final int i, final int j, final int k, final Entity entity) {
    }
    
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        return false;
    }
    
    public void setBlockBoundsForItemRender() {
    }
    
    public void harvestBlock(final World world, final int i, final int j, final int k, final int l) {
        this.dropBlockAsItem(world, i, j, k, l);
    }
    
    public boolean canBlockStay(final World world, final int i, final int j, final int k) {
        return true;
    }
    
    public void applyGearPower() {
    }
    
    public void removeGearPower() {
    }
    
    public boolean isGearPowered() {
        return false;
    }
    
    public int getConnectedGearsCount(final World world, final int i, final int j, final int k) {
        return 0;
    }
    
    public ArrayList<Vec3D> getConnectedGears(final World world, final int i, final int j, final int k) {
        final ArrayList<Vec3D> blocklist = new ArrayList<Vec3D>();
        if (world.getBlockId(i - 1, j, k) == Block.gear.blockID) {
            blocklist.add(Vec3D.createVectorHelper(i - 1, j, k));
        }
        if (world.getBlockId(i + 1, j, k) == Block.gear.blockID) {
            blocklist.add(Vec3D.createVectorHelper(i + 1, j, k));
        }
        if (world.getBlockId(i, j, k - 1) == Block.gear.blockID) {
            blocklist.add(Vec3D.createVectorHelper(i, j, k - 1));
        }
        if (world.getBlockId(i, j, k + 1) == Block.gear.blockID) {
            blocklist.add(Vec3D.createVectorHelper(i, j, k + 1));
        }
        return blocklist;
    }
    
    public ArrayList<Vec3D> getConnectedBlocks(final World world, final int i, final int j, final int k) {
        return new ArrayList<Vec3D>();
    }
    
    static Class<?> _mthclass$(final String s) {
        try {
            return Class.forName(s);
        }
        catch (ClassNotFoundException classnotfoundexception) {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }
    
    public void onBlockPlacedBy(final World world, final int i, final int j, final int k, final EntityLiving entityliving) {
    }
    
    public void goldTouch() {
    }
    
    public void notGoldTouch() {
    }
    
    public int getTextureIndex(final int n, final int n2, final int n3) {
        return this.getTextureIndex(0);
    }
}
