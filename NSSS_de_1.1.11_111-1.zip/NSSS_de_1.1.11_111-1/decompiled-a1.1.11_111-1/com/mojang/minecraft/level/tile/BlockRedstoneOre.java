package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockRedstoneOre extends Block
{
    private boolean field_468_a;
    
    public BlockRedstoneOre(final int i, final int j, final boolean flag) {
        super(i, j, Material.rock);
        if (flag) {
            this.setTickOnLoad(true);
        }
        this.field_468_a = flag;
    }
    
    @Override
    public int tickRate() {
        return 30;
    }
    
    @Override
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.func_320_h(world, i, j, k);
        super.onBlockClicked(world, i, j, k, entityplayer);
    }
    
    @Override
    public void onEntityWalking(final World world, final int i, final int j, final int k, final Entity entity) {
        this.func_320_h(world, i, j, k);
        super.onEntityWalking(world, i, j, k, entity);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.func_320_h(world, i, j, k);
        return super.blockActivated(world, i, j, k, entityplayer);
    }
    
    private void func_320_h(final World world, final int i, final int j, final int k) {
        this.func_319_i(world, i, j, k);
        if (this.blockID == Block.oreRed.blockID) {
            world.setBlockWithNotify(i, j, k, Block.oreRedstoneGlowing.blockID);
        }
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (this.blockID == Block.oreRedstoneGlowing.blockID) {
            world.setBlockWithNotify(i, j, k, Block.oreRed.blockID);
        }
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.redstone.shiftedIndex;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 4 + random.nextInt(2);
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (this.field_468_a) {
            this.func_319_i(world, i, j, k);
        }
    }
    
    private void func_319_i(final World world, final int i, final int j, final int k) {
        final Random random = world.rand;
        final double d = 0.0625;
        for (int l = 0; l < 6; ++l) {
            double d2 = i + random.nextFloat();
            double d3 = j + random.nextFloat();
            double d4 = k + random.nextFloat();
            if (l == 0 && !world.isBlockNormalCube(i, j + 1, k)) {
                d3 = j + 1 + d;
            }
            if (l == 1 && !world.isBlockNormalCube(i, j - 1, k)) {
                d3 = j + 0 - d;
            }
            if (l == 2 && !world.isBlockNormalCube(i, j, k + 1)) {
                d4 = k + 1 + d;
            }
            if (l == 3 && !world.isBlockNormalCube(i, j, k - 1)) {
                d4 = k + 0 - d;
            }
            if (l == 4 && !world.isBlockNormalCube(i + 1, j, k)) {
                d2 = i + 1 + d;
            }
            if (l == 5 && !world.isBlockNormalCube(i - 1, j, k)) {
                d2 = i + 0 - d;
            }
            if (d2 < i || d2 > i + 1 || d3 < 0.0 || d3 > j + 1 || d4 < k || d4 > k + 1) {
                world.spawnParticle("reddust", d2, d3, d4, 0.0, 0.0, 0.0);
            }
        }
    }
}
