package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.*;

class FlowThread extends Thread
{
    World world;
    BlockSponge sponge;
    int x;
    int y;
    int z;
    int sx;
    int sy;
    int sz;
    
    public FlowThread(final World world, final BlockSponge sponge, final int x, final int y, final int z, final int sx, final int sy, final int sz) {
        this.world = world;
        this.sponge = sponge;
        this.x = x;
        this.y = y;
        this.z = z;
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
    }
    
    @Override
    public void run() {
        this.flowWater(this.world, this.x, this.y, this.z, this.sx, this.sy, this.sz);
    }
    
    public void dropWater(final World world, final int x, final int y, final int z) {
        for (int i = y; i > y - 3 && (world.getBlockId(x, i, z) == 0 || world.getBlockId(x, i, z) == Block.waterStill.blockID); --i) {
            if (!BlockSponge.getSurroundSponge(world, x, i, z)) {
                world.setBlockWithNotify(x, i, z, Block.waterMoving.blockID);
            }
        }
    }
    
    public void flowWater(final World world, final int x, final int y, final int z, final int sx, final int sy, final int sz) {
        final int radius = 3;
        if ((world.getBlockId(x, y, z) == 0 || world.getBlockId(x, y, z) == Block.waterStill.blockID) && !BlockSponge.getSurroundSponge(world, x, y, z)) {
            world.setBlockWithNotify(x, y, z, Block.waterMoving.blockID);
            this.dropWater(world, x, y, z);
            if (x + 1 < sx + radius && (world.getBlockId(x + 1, y, z) == 0 || world.getBlockId(x + 1, y, z) == Block.waterStill.blockID) && !BlockSponge.getSurroundSponge(world, x + 1, y, z)) {
                this.flowWater(world, x + 1, y, z, sx, sy, sz);
            }
            if (z + 1 < sz + radius && (world.getBlockId(x, y, z + 1) == 0 || world.getBlockId(x, y, z + 1) == Block.waterStill.blockID) && !BlockSponge.getSurroundSponge(world, x, y, z + 1)) {
                this.flowWater(world, x, y, z + 1, sx, sy, sz);
            }
            if (x - 1 > sx - radius && (world.getBlockId(x - 1, y, z) == 0 || world.getBlockId(x - 1, y, z) == Block.waterStill.blockID) && !BlockSponge.getSurroundSponge(world, x - 1, y, z)) {
                this.flowWater(world, x - 1, y, z, sx, sy, sz);
            }
            if (z - 1 > sz - radius && (world.getBlockId(x, y, z - 1) == 0 || world.getBlockId(x, y, z - 1) == Block.waterStill.blockID) && !BlockSponge.getSurroundSponge(world, x, y, z - 1)) {
                this.flowWater(world, x, y, z - 1, sx, sy, sz);
            }
            try {
                Thread.sleep(1000L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
