package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.render.*;
import org.lwjgl.opengl.*;

public class TextureFX
{
    public byte[] field_1127_a;
    public int texIndex;
    public boolean field_1131_c;
    public int size;
    public int prevSize;
    public int tile;
    protected int[] imageData;
    
    public TextureFX(final int textureIndex) {
        this.field_1127_a = new byte[1024];
        this.field_1131_c = false;
        this.size = 0;
        this.prevSize = 1;
        this.tile = 0;
        this.texIndex = textureIndex;
    }
    
    public void render() {
    }
    
    protected void updateSize() {
        this.imageData = new int[this.size * this.size];
    }
    
    public void bindTextureFXToTexture(final RenderEngine renderengine) {
        if (this.tile == 0) {
            GL11.glBindTexture(3553, renderengine.getTex("/terrain.png"));
        }
        else if (this.tile == 1) {
            GL11.glBindTexture(3553, renderengine.getTex("/gui/items.png"));
        }
        if (this.tile == 3) {
            GL11.glBindTexture(3553, renderengine.getTex("/water.png"));
        }
    }
}
