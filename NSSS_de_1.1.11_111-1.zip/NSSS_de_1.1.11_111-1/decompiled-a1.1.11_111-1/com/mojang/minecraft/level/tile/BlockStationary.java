package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;

public class BlockStationary extends BlockFluids
{
    protected BlockStationary(final int i, final Material material) {
        super(i, material);
        this.setTickOnLoad(false);
        if (material == Material.lava) {
            this.setTickOnLoad(true);
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        super.onNeighborBlockChange(world, i, j, k, l);
        if (world.getBlockId(i, j, k) == this.blockID) {
            this.func_302_j(world, i, j, k);
        }
    }
    
    private void func_302_j(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        world.etitingBlocks = true;
        world.setBlockAndMetadata(i, j, k, this.blockID - 1, l);
        world.markBlocksDirty(i, j, k, i, j, k);
        world.scheduleUpdateTick(i, j, k, this.blockID - 1);
        world.etitingBlocks = false;
    }
    
    @Override
    public void updateTick(final World world, int i, int j, int k, final Random random) {
        if (this.blockMaterial == Material.lava) {
            for (int l = random.nextInt(3), i2 = 0; i2 < l; ++i2) {
                i += random.nextInt(3) - 1;
                ++j;
                k += random.nextInt(3) - 1;
                final int j2 = world.getBlockId(i, j, k);
                if (j2 == 0) {
                    if (this.func_301_k(world, i - 1, j, k) || this.func_301_k(world, i + 1, j, k) || this.func_301_k(world, i, j, k - 1) || this.func_301_k(world, i, j, k + 1) || this.func_301_k(world, i, j - 1, k) || this.func_301_k(world, i, j + 1, k)) {
                        world.setBlockWithNotify(i, j, k, Block.fire.blockID);
                        return;
                    }
                }
                else if (Block.allBlocks[j2].blockMaterial.blocksMovement()) {
                    return;
                }
            }
        }
    }
    
    private boolean func_301_k(final World world, final int i, final int j, final int k) {
        return world.getMaterialXYZ(i, j, k).getBurning();
    }
}
