package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;

public class BlockDirt extends Block
{
    protected BlockDirt(final int i, final int j) {
        super(i, j, Material.ground);
    }
}
