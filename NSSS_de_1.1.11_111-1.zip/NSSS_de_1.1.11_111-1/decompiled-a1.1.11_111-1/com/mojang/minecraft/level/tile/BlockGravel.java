package com.mojang.minecraft.level.tile;

import java.util.*;
import com.mojang.minecraft.entity.item.*;

public class BlockGravel extends BlockSand
{
    public BlockGravel(final int i, final int j) {
        super(i, j);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        if (random.nextInt(10) == 0) {
            return Item.flint.shiftedIndex;
        }
        return this.blockID;
    }
}
