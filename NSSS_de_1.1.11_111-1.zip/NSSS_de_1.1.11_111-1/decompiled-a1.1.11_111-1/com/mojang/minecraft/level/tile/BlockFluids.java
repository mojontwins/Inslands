package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public abstract class BlockFluids extends Block
{
    protected int field_458_d;
    protected static boolean isStationary;
    
    protected BlockFluids(final int i, final Material material) {
        super(i, ((material != Material.lava) ? 12 : 14) * 16 + 13, material);
        this.field_458_d = 1;
        final float f = 0.0f;
        final float f2 = 0.0f;
        BlockFluids.isStationary = true;
        if (material == Material.lava) {
            this.field_458_d = 2;
        }
        this.setBlockBounds(0.0f + f2, 0.0f + f, 0.0f + f2, 1.0f + f2, 1.0f + f, 1.0f + f2);
        this.setTickOnLoad(true);
    }
    
    public static float getFluidLevel(int i) {
        if (i >= 8) {
            i = 0;
        }
        final float f = (i + 1) / 9.0f;
        return f;
    }
    
    @Override
    public int getTextureIndex(final IBlockAccess iblockaccess, final int x, final int y, final int z, final int side) {
        if (isFlowing(iblockaccess, x, y, z)) {
            return this.blockIndexInTexture + 1;
        }
        return this.blockIndexInTexture;
    }
    
    public boolean getIsStationary(final IBlockAccess world, final int x, final int y, final int z) {
        final Vec3D flowDir = this.getFlowDirectionVector(world, x, y, z);
        return flowDir.yCoord >= 0.0;
    }
    
    protected int func_290_h(final World world, final int i, final int j, final int k) {
        if (world.getMaterialXYZ(i, j, k) != this.blockMaterial) {
            return -1;
        }
        return world.getBlockMetadata(i, j, k);
    }
    
    protected int getIfSameMaterialAndHeight(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        if (iblockaccess.getMaterialXYZ(i, j, k) != this.blockMaterial) {
            return -1;
        }
        int l = iblockaccess.getBlockMetadata(i, j, k);
        if (l >= 8) {
            l = 0;
        }
        return l;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return true;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean canCollideCheck(final int i, final boolean flag) {
        return flag && i == 0;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        final Material material = iblockaccess.getMaterialXYZ(i, j, k);
        return material != this.blockMaterial && material != Material.ice && (l == 1 || super.shouldSideBeRendered(iblockaccess, i, j, k, l));
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int getRenderType() {
        return 4;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return 0;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    private Vec3D getFlowDirectionVector(final IBlockAccess iblockaccess, final int x, final int y, final int z) {
        Vec3D vec3d = Vec3D.createVector(0.0, 0.0, 0.0);
        final int materialAndHeightCheck = this.getIfSameMaterialAndHeight(iblockaccess, x, y, z);
        for (int sideCheck = 0; sideCheck < 4; ++sideCheck) {
            int sideCheckX = x;
            final int sideCheckY = y;
            int sideCheckZ = z;
            if (sideCheck == 0) {
                --sideCheckX;
            }
            if (sideCheck == 1) {
                --sideCheckZ;
            }
            if (sideCheck == 2) {
                ++sideCheckX;
            }
            if (sideCheck == 3) {
                ++sideCheckZ;
            }
            int materialAndHeightCheckSides = this.getIfSameMaterialAndHeight(iblockaccess, sideCheckX, sideCheckY, sideCheckZ);
            if (materialAndHeightCheckSides < 0) {
                if (!iblockaccess.getMaterialXYZ(sideCheckX, sideCheckY, sideCheckZ).blocksMovement()) {
                    materialAndHeightCheckSides = this.getIfSameMaterialAndHeight(iblockaccess, sideCheckX, sideCheckY - 1, sideCheckZ);
                    if (materialAndHeightCheckSides >= 0) {
                        final int heightDifference = materialAndHeightCheckSides - (materialAndHeightCheck - 8);
                        vec3d = vec3d.addVector((sideCheckX - x) * heightDifference, (sideCheckY - y) * heightDifference, (sideCheckZ - z) * heightDifference);
                    }
                }
            }
            else if (materialAndHeightCheckSides >= 0) {
                final int heightDifference2 = materialAndHeightCheckSides - materialAndHeightCheck;
                vec3d = vec3d.addVector((sideCheckX - x) * heightDifference2, (sideCheckY - y) * heightDifference2, (sideCheckZ - z) * heightDifference2);
            }
        }
        if (iblockaccess.getBlockMetadata(x, y, z) >= 8) {
            boolean flag = false;
            if (flag || this.shouldSideBeRendered(iblockaccess, x, y, z - 1, 2)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x, y, z + 1, 3)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x - 1, y, z, 4)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x + 1, y, z, 5)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x, y + 1, z - 1, 2)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x, y + 1, z + 1, 3)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x - 1, y + 1, z, 4)) {
                flag = true;
            }
            if (flag || this.shouldSideBeRendered(iblockaccess, x + 1, y + 1, z, 5)) {
                flag = true;
            }
            if (flag) {
                vec3d = vec3d.normalize().addVector(0.0, -6.0, 0.0);
            }
        }
        vec3d = vec3d.normalize();
        return vec3d;
    }
    
    @Override
    public void velocityToAddToEntity(final World world, final int i, final int j, final int k, final Entity entity, final Vec3D vec3d) {
        final Vec3D vec3d2 = this.getFlowDirectionVector(world, i, j, k);
        vec3d.xCoord += vec3d2.xCoord;
        vec3d.yCoord += vec3d2.yCoord;
        vec3d.zCoord += vec3d2.zCoord;
    }
    
    @Override
    public int tickRate() {
        if (this.blockMaterial == Material.water) {
            return 5;
        }
        return (this.blockMaterial != Material.lava) ? 0 : 30;
    }
    
    @Override
    public float getBlockBrightness(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final float f = iblockaccess.getBrightness(i, j, k);
        final float f2 = iblockaccess.getBrightness(i, j + 1, k);
        return (f <= f2) ? f2 : f;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        super.updateTick(world, i, j, k, random);
    }
    
    @Override
    public int getRenderBlockPass() {
        return (this.blockMaterial == Material.water) ? 1 : 0;
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (this.blockMaterial == Material.water && random.nextInt(64) == 0) {
            final int l = world.getBlockMetadata(i, j, k);
            if (l > 0 && l < 8) {
                world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "liquid.water", random.nextFloat() * 0.25f + 0.75f, random.nextFloat() * 1.0f + 0.5f);
            }
        }
        if (this.blockMaterial == Material.lava && world.getMaterialXYZ(i, j + 1, k) == Material.air && !world.isBlockNormalCube(i, j + 1, k) && random.nextInt(100) == 0) {
            final double d = i + random.nextFloat();
            final double d2 = j + this.maxY;
            final double d3 = k + random.nextFloat();
            world.spawnParticle("lava", d, d2, d3, 0.0, 0.0, 0.0);
            final int m = world.getBlockMetadata(i, j, k);
            if (m > 0 && m < 8) {
                world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "liquid.lava", random.nextFloat() * 0.25f + 0.75f, random.nextFloat() * 1.0f + 0.5f);
            }
        }
    }
    
    public static double getFlowDirectionRadians(final IBlockAccess iblockaccess, final int i, final int j, final int k, final Material material) {
        Vec3D vec3d = null;
        if (material == Material.water) {
            vec3d = ((BlockFluids)Block.waterMoving).getFlowDirectionVector(iblockaccess, i, j, k);
        }
        if (material == Material.lava) {
            vec3d = ((BlockFluids)Block.lavaMoving).getFlowDirectionVector(iblockaccess, i, j, k);
        }
        if (vec3d.xCoord == 0.0 && vec3d.zCoord == 0.0) {
            return -1000.0;
        }
        return Math.atan2(vec3d.zCoord, vec3d.xCoord) - 1.5707963267948966;
    }
    
    public static boolean isFlowing(final IBlockAccess world, final int x, final int y, final int z) {
        Vec3D vec = ((BlockFluids)Block.waterStill).getFlowDirectionVector(world, x, y, z);
        if (world.getBlockId(x, y, z) == Block.lavaStill.blockID || world.getBlockId(x, y, z) == Block.lavaMoving.blockID) {
            vec = ((BlockFluids)Block.lavaStill).getFlowDirectionVector(world, x, y, z);
        }
        return vec.xCoord != 0.0 || vec.yCoord != 0.0 || vec.zCoord != 0.0;
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        this.func_287_j(world, i, j, k);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        this.func_287_j(world, i, j, k);
    }
    
    private void func_287_j(final World world, final int i, final int j, final int k) {
        if (world.getBlockId(i, j, k) != this.blockID) {
            return;
        }
        if (this.blockMaterial == Material.lava) {
            boolean flag = false;
            if (flag || world.getMaterialXYZ(i, j, k - 1) == Material.water) {
                flag = true;
            }
            if (flag || world.getMaterialXYZ(i, j, k + 1) == Material.water) {
                flag = true;
            }
            if (flag || world.getMaterialXYZ(i - 1, j, k) == Material.water) {
                flag = true;
            }
            if (flag || world.getMaterialXYZ(i + 1, j, k) == Material.water) {
                flag = true;
            }
            if (flag || world.getMaterialXYZ(i, j + 1, k) == Material.water) {
                flag = true;
            }
            if (flag) {
                final int l = world.getBlockMetadata(i, j, k);
                if (l == 0) {
                    world.setBlockWithNotify(i, j, k, Block.obsidian.blockID);
                    if (new Random().nextInt(500) == 1) {
                        world.setBlockWithNotify(i, j, k, Block.bleedingObsidian.blockID);
                    }
                }
                else if (l <= 4) {
                    world.setBlockWithNotify(i, j, k, Block.cobblestone.blockID);
                }
                this.triggerLavaMixEffects(world, i, j, k);
            }
        }
    }
    
    protected void triggerLavaMixEffects(final World world, final int i, final int j, final int k) {
        world.playSoundEffect(i + 0.5f, j + 0.5f, k + 0.5f, "random.fizz", 0.5f, 2.6f + (world.rand.nextFloat() - world.rand.nextFloat()) * 0.8f);
        for (int l = 0; l < 8; ++l) {
            world.spawnParticle("largesmoke", i + Math.random(), j + 1.2, k + Math.random(), 0.0, 0.0, 0.0);
        }
    }
}
