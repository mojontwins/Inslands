package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.enums.*;

public class BlockIce extends BlockBreakable
{
    public BlockIce(final int i, final int j) {
        super(i, j, Material.ice, false);
        this.slipperiness = 0.98f;
        this.setTickOnLoad(true);
    }
    
    @Override
    public int getRenderBlockPass() {
        return 1;
    }
    
    @Override
    public boolean shouldSideBeRendered(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return super.shouldSideBeRendered(iblockaccess, i, j, k, 1 - l);
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final Material material = world.getMaterialXYZ(i, j - 1, k);
        if (material.blocksMovement() || material.getIsGroundCover()) {
            world.setBlockWithNotify(i, j, k, Block.waterMoving.blockID);
        }
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 0;
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockLighting(EnumSkyBlock.Block, i, j, k) > 11 - Block.lightOpacity[this.blockID]) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, Block.waterStill.blockID);
        }
    }
}
