package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.*;

public class BlockLever extends Block
{
    protected BlockLever(final int i, final int j) {
        super(i, j, Material.circuits);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int getRenderType() {
        return 12;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    public boolean isACube() {
        return false;
    }
    
    public boolean canPlaceBlockOnSide(final World world, final int i, final int j, final int k, final int l) {
        return (l == 1 && world.isBlockNormalCube(i, j - 1, k)) || (l == 2 && world.isBlockNormalCube(i, j, k + 1)) || (l == 3 && world.isBlockNormalCube(i, j, k - 1)) || (l == 4 && world.isBlockNormalCube(i + 1, j, k)) || (l == 5 && world.isBlockNormalCube(i - 1, j, k));
    }
    
    public boolean canPlaceBlockAt(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i - 1, j, k) || world.isBlockNormalCube(i + 1, j, k) || world.isBlockNormalCube(i, j, k - 1) || world.isBlockNormalCube(i, j, k + 1) || world.isBlockNormalCube(i, j - 1, k);
    }
    
    @Override
    public void onBlockPlaced(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getBlockMetadata(i, j, k);
        final int j2 = i2 & 0x8;
        i2 &= 0x7;
        i2 = -1;
        if (l == 1 && world.isBlockNormalCube(i, j - 1, k)) {
            i2 = 5 + world.rand.nextInt(2);
        }
        if (l == 2 && world.isBlockNormalCube(i, j, k + 1)) {
            i2 = 4;
        }
        if (l == 3 && world.isBlockNormalCube(i, j, k - 1)) {
            i2 = 3;
        }
        if (l == 4 && world.isBlockNormalCube(i + 1, j, k)) {
            i2 = 2;
        }
        if (l == 5 && world.isBlockNormalCube(i - 1, j, k)) {
            i2 = 1;
        }
        if (i2 == -1) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return;
        }
        world.setBlockMetadataWithNotify(i, j, k, i2 + j2);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (this.checkIfAttachedToBlock(world, i, j, k)) {
            final int i2 = world.getBlockMetadata(i, j, k) & 0x7;
            boolean flag = false;
            if (!world.isBlockNormalCube(i - 1, j, k) && i2 == 1) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i + 1, j, k) && i2 == 2) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k - 1) && i2 == 3) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j, k + 1) && i2 == 4) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j - 1, k) && i2 == 5) {
                flag = true;
            }
            if (!world.isBlockNormalCube(i, j - 1, k) && i2 == 6) {
                flag = true;
            }
            if (flag) {
                this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
                world.setBlockWithNotify(i, j, k, 0);
            }
        }
    }
    
    private boolean checkIfAttachedToBlock(final World world, final int i, final int j, final int k) {
        if (!this.canPlaceBlockAt(world, i, j, k)) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getBlockMetadata(i, j, k) & 0x7;
        final float f = 0.1875f;
        if (l == 1) {
            this.setBlockBounds(0.0f, 0.2f, 0.5f - f, f * 2.0f, 0.8f, 0.5f + f);
        }
        else if (l == 2) {
            this.setBlockBounds(1.0f - f * 2.0f, 0.2f, 0.5f - f, 1.0f, 0.8f, 0.5f + f);
        }
        else if (l == 3) {
            this.setBlockBounds(0.5f - f, 0.2f, 0.0f, 0.5f + f, 0.8f, f * 2.0f);
        }
        else if (l == 4) {
            this.setBlockBounds(0.5f - f, 0.2f, 1.0f - f * 2.0f, 0.5f + f, 0.8f, 1.0f);
        }
        else {
            final float f2 = 0.25f;
            this.setBlockBounds(0.5f - f2, 0.0f, 0.5f - f2, 0.5f + f2, 0.6f, 0.5f + f2);
        }
    }
    
    @Override
    public void onBlockClicked(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        this.blockActivated(world, i, j, k, entityplayer);
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        final int l = world.getBlockMetadata(i, j, k);
        final int i2 = l & 0x7;
        final int j2 = 8 - (l & 0x8);
        world.setBlockMetadataWithNotify(i, j, k, i2 + j2);
        world.markBlocksDirty(i, j, k, i, j, k);
        world.playSoundEffect(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, (j2 <= 0) ? 0.5f : 0.6f);
        if (world.multiplayerWorld) {
            return true;
        }
        world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
        if (i2 == 1) {
            world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
        }
        else if (i2 == 2) {
            world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
        }
        else if (i2 == 3) {
            world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
        }
        else if (i2 == 4) {
            world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        }
        else {
            world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        }
        return true;
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        if ((l & 0x8) > 0) {
            world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
            final int i2 = l & 0x7;
            if (i2 == 1) {
                world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
            }
            else if (i2 == 2) {
                world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
            }
            else if (i2 == 3) {
                world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
            }
            else if (i2 == 4) {
                world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
            }
            else {
                world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
            }
        }
        super.onBlockRemoval(world, i, j, k);
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return (iblockaccess.getBlockMetadata(i, j, k) & 0x8) > 0;
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getBlockMetadata(i, j, k);
        if ((i2 & 0x8) == 0x0) {
            return false;
        }
        final int j2 = i2 & 0x7;
        return (j2 == 6 && l == 1) || (j2 == 5 && l == 1) || (j2 == 4 && l == 2) || (j2 == 3 && l == 3) || (j2 == 2 && l == 4) || (j2 == 1 && l == 5);
    }
    
    @Override
    public boolean canProvidePower() {
        return true;
    }
}
