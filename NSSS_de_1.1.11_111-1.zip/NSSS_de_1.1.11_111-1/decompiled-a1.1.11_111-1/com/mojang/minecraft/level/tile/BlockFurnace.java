package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import java.util.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockFurnace extends BlockContainer
{
    private final boolean field_456_a;
    
    protected BlockFurnace(final int i, final boolean flag) {
        super(i, Material.rock);
        this.field_456_a = flag;
        this.blockIndexInTexture = 45;
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Block.stoneOvenIdle.blockID;
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
    }
    
    @Override
    public void onBlockPlacedBy(final World world, final int i, final int j, final int k, final EntityLiving entityliving) {
        final int l = MathHelper.floor_double(entityliving.rotationYaw * 4.0f / 360.0f + 0.5) & 0x3;
        if (l == 0) {
            world.setBlockMetadataWithNotify(i, j, k, 2);
        }
        if (l == 1) {
            world.setBlockMetadataWithNotify(i, j, k, 5);
        }
        if (l == 2) {
            world.setBlockMetadataWithNotify(i, j, k, 3);
        }
        if (l == 3) {
            world.setBlockMetadataWithNotify(i, j, k, 4);
        }
    }
    
    private void func_284_h(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j, k - 1);
        final int i2 = world.getBlockId(i, j, k + 1);
        final int j2 = world.getBlockId(i - 1, j, k);
        final int k2 = world.getBlockId(i + 1, j, k);
        byte byte0 = 3;
        if (Block.opaqueCubeLookup[l] && !Block.opaqueCubeLookup[i2]) {
            byte0 = 3;
        }
        if (Block.opaqueCubeLookup[i2] && !Block.opaqueCubeLookup[l]) {
            byte0 = 2;
        }
        if (Block.opaqueCubeLookup[j2] && !Block.opaqueCubeLookup[k2]) {
            byte0 = 5;
        }
        if (Block.opaqueCubeLookup[k2] && !Block.opaqueCubeLookup[j2]) {
            byte0 = 4;
        }
        world.setBlockMetadataWithNotify(i, j, k, byte0);
    }
    
    @Override
    public int getTextureIndex(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (l == 1) {
            return Block.stone.blockIndexInTexture;
        }
        if (l == 0) {
            return Block.stone.blockIndexInTexture;
        }
        final int i2 = iblockaccess.getBlockMetadata(i, j, k);
        if (l != i2) {
            return this.blockIndexInTexture;
        }
        if (this.field_456_a) {
            return this.blockIndexInTexture + 16;
        }
        return this.blockIndexInTexture - 1;
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (!this.field_456_a) {
            return;
        }
        final int l = world.getBlockMetadata(i, j, k);
        final float f = i + 0.5f;
        final float f2 = j + 0.0f + random.nextFloat() * 6.0f / 16.0f;
        final float f3 = k + 0.5f;
        final float f4 = 0.52f;
        final float f5 = random.nextFloat() * 0.6f - 0.3f;
        if (l == 4) {
            world.spawnParticle("smoke", f - f4, f2, f3 + f5, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", f - f4, f2, f3 + f5, 0.0, 0.0, 0.0);
        }
        else if (l == 5) {
            world.spawnParticle("smoke", f + f4, f2, f3 + f5, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", f + f4, f2, f3 + f5, 0.0, 0.0, 0.0);
        }
        else if (l == 2) {
            world.spawnParticle("smoke", f + f5, f2, f3 - f4, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", f + f5, f2, f3 - f4, 0.0, 0.0, 0.0);
        }
        else if (l == 3) {
            world.spawnParticle("smoke", f + f5, f2, f3 + f4, 0.0, 0.0, 0.0);
            world.spawnParticle("flame", f + f5, f2, f3 + f4, 0.0, 0.0, 0.0);
        }
    }
    
    @Override
    public int getTextureIndex(final int i) {
        if (i == 1) {
            return Block.stone.blockID;
        }
        if (i == 0) {
            return Block.stone.blockID;
        }
        if (i == 3) {
            return this.blockIndexInTexture - 1;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public boolean blockActivated(final World world, final int i, final int j, final int k, final EntityPlayer entityplayer) {
        if (world.multiplayerWorld) {
            return true;
        }
        final TileEntityFurnace tileentityfurnace = (TileEntityFurnace)world.getBlockTileEntity(i, j, k);
        entityplayer.displayGUIFurnace(tileentityfurnace);
        return true;
    }
    
    public static void func_285_a(final boolean flag, final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        final TileEntity tileentity = world.getBlockTileEntity(i, j, k);
        if (flag) {
            world.setBlockWithNotify(i, j, k, Block.stoneOvenActive.blockID);
        }
        else {
            world.setBlockWithNotify(i, j, k, Block.stoneOvenIdle.blockID);
        }
        world.setBlockMetadataWithNotify(i, j, k, l);
        world.func_654_a(i, j, k, tileentity);
    }
    
    @Override
    protected TileEntity getBlockEntity() {
        return new TileEntityFurnace();
    }
}
