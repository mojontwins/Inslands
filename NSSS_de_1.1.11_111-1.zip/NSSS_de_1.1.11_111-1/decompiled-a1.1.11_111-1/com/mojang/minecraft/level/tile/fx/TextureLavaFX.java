package com.mojang.minecraft.level.tile.fx;

import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.util.*;

public class TextureLavaFX extends TextureFX
{
    protected float[] field_1147_g;
    protected float[] field_1146_h;
    protected float[] field_1145_i;
    protected float[] field_1144_j;
    
    public TextureLavaFX() {
        super(Block.lavaMoving.blockIndexInTexture);
        this.field_1147_g = new float[256];
        this.field_1146_h = new float[256];
        this.field_1145_i = new float[256];
        this.field_1144_j = new float[256];
    }
    
    @Override
    public void render() {
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                float f = 0.0f;
                final int l = (int)(MathHelper.sin(j * 3.141593f * 2.0f / 16.0f) * 1.2f);
                final int i2 = (int)(MathHelper.sin(i * 3.141593f * 2.0f / 16.0f) * 1.2f);
                for (int k1 = i - 1; k1 <= i + 1; ++k1) {
                    for (int i3 = j - 1; i3 <= j + 1; ++i3) {
                        final int k2 = k1 + l & 0xF;
                        final int i4 = i3 + i2 & 0xF;
                        f += this.field_1147_g[k2 + i4 * 16];
                    }
                }
                this.field_1146_h[i + j * 16] = f / 10.0f + (this.field_1145_i[(i + 0 & 0xF) + (j + 0 & 0xF) * 16] + this.field_1145_i[(i + 1 & 0xF) + (j + 0 & 0xF) * 16] + this.field_1145_i[(i + 1 & 0xF) + (j + 1 & 0xF) * 16] + this.field_1145_i[(i + 0 & 0xF) + (j + 1 & 0xF) * 16]) / 4.0f * 0.8f;
                final float[] field_1145_i = this.field_1145_i;
                final int n = i + j * 16;
                field_1145_i[n] += this.field_1144_j[i + j * 16] * 0.01f;
                if (this.field_1145_i[i + j * 16] < 0.0f) {
                    this.field_1145_i[i + j * 16] = 0.0f;
                }
                final float[] field_1144_j = this.field_1144_j;
                final int n2 = i + j * 16;
                field_1144_j[n2] -= 0.06f;
                if (Math.random() < 0.005) {
                    this.field_1144_j[i + j * 16] = 1.5f;
                }
            }
        }
        final float[] af = this.field_1146_h;
        this.field_1146_h = this.field_1147_g;
        this.field_1147_g = af;
        for (int m = 0; m < 256; ++m) {
            float f2 = this.field_1147_g[m] * 2.0f;
            if (f2 > 1.0f) {
                f2 = 1.0f;
            }
            if (f2 < 0.0f) {
                f2 = 0.0f;
            }
            final float f3 = f2;
            int j2 = (int)(f3 * 100.0f + 155.0f);
            int l2 = (int)(f3 * f3 * 255.0f);
            int j3 = (int)(f3 * f3 * f3 * f3 * 128.0f);
            if (this.field_1131_c) {
                final int l3 = (j2 * 30 + l2 * 59 + j3 * 11) / 100;
                final int j4 = (j2 * 30 + l2 * 70) / 100;
                final int k3 = (j2 * 30 + j3 * 70) / 100;
                j2 = l3;
                l2 = j4;
                j3 = k3;
            }
            this.field_1127_a[m * 4 + 0] = (byte)j2;
            this.field_1127_a[m * 4 + 1] = (byte)l2;
            this.field_1127_a[m * 4 + 2] = (byte)j3;
            this.field_1127_a[m * 4 + 3] = -1;
        }
    }
}
