package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.entity.*;

public class BlockSand extends Block
{
    public static boolean fallInstantly;
    
    static {
        BlockSand.fallInstantly = false;
    }
    
    public BlockSand(final int i, final int j) {
        super(i, j, Material.sand);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        world.scheduleUpdateTick(i, j, k, this.blockID);
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        world.scheduleUpdateTick(i, j, k, this.blockID);
    }
    
    @Override
    public void updateTick(final World world, final int i, final int j, final int k, final Random random) {
        this.func_315_h(world, i, j, k);
    }
    
    private void func_315_h(final World world, final int i, final int j, final int k) {
        final int l = i;
        final int i2 = j;
        final int j2 = k;
        if (func_316_a_(world, l, i2 - 1, j2) && i2 >= 0 && Math.abs(i) < 8388608 && Math.abs(j) < 8388608 && Math.abs(k) < 8388608) {
            final EntityFallingSand entityfallingsand = new EntityFallingSand(world, i + 0.5f, j + 0.5f, k + 0.5f, this.blockID);
            if (BlockSand.fallInstantly) {
                while (!entityfallingsand.isDead) {
                    entityfallingsand.onUpdate();
                }
            }
            else {
                world.entityJoinedWorld(entityfallingsand);
            }
        }
    }
    
    @Override
    public int tickRate() {
        return 3;
    }
    
    public static boolean func_316_a_(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockId(i, j, k);
        if (l == 0) {
            return true;
        }
        if (l == Block.fire.blockID) {
            return true;
        }
        final Material material = Block.allBlocks[l].blockMaterial;
        return material == Material.water || material == Material.lava;
    }
}
