package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;
import com.mojang.minecraft.entity.item.*;
import com.mojang.minecraft.entity.tile.*;

public class BlockRedstoneWire extends Block
{
    private boolean wiresProvidePower;
    
    public BlockRedstoneWire(final int i, final int j) {
        super(i, j, Material.circuits);
        this.wiresProvidePower = true;
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.0625f, 1.0f);
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        return this.blockIndexInTexture + ((j <= 0) ? 0 : 16);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 5;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i, j - 1, k);
    }
    
    private void func_280_h(final World world, final int i, final int j, final int k) {
        final int l = world.getBlockMetadata(i, j, k);
        int i2 = 0;
        this.wiresProvidePower = false;
        final boolean flag = world.isBlockIndirectlyGettingPowered(i, j, k);
        this.wiresProvidePower = true;
        if (flag) {
            i2 = 15;
        }
        else {
            for (int j2 = 0; j2 < 4; ++j2) {
                int l2 = i;
                int j3 = k;
                if (j2 == 0) {
                    --l2;
                }
                if (j2 == 1) {
                    ++l2;
                }
                if (j2 == 2) {
                    --j3;
                }
                if (j2 == 3) {
                    ++j3;
                }
                i2 = this.getMaxCurrentStrength(world, l2, j, j3, i2);
                if (world.isBlockNormalCube(l2, j, j3) && !world.isBlockNormalCube(i, j + 1, k)) {
                    i2 = this.getMaxCurrentStrength(world, l2, j + 1, j3, i2);
                }
                else if (!world.isBlockNormalCube(l2, j, j3)) {
                    i2 = this.getMaxCurrentStrength(world, l2, j - 1, j3, i2);
                }
            }
            if (i2 > 0) {
                --i2;
            }
            else {
                i2 = 0;
            }
        }
        if (l != i2) {
            world.setBlockMetadataWithNotify(i, j, k, i2);
            world.markBlocksDirty(i, j, k, i, j, k);
            if (i2 > 0) {
                --i2;
            }
            for (int k2 = 0; k2 < 4; ++k2) {
                int i3 = i;
                int k3 = k;
                int l3 = j - 1;
                if (k2 == 0) {
                    --i3;
                }
                if (k2 == 1) {
                    ++i3;
                }
                if (k2 == 2) {
                    --k3;
                }
                if (k2 == 3) {
                    ++k3;
                }
                if (world.isBlockNormalCube(i3, j, k3)) {
                    l3 += 2;
                }
                int i4 = this.getMaxCurrentStrength(world, i3, j, k3, -1);
                if (i4 >= 0 && i4 != i2) {
                    this.func_280_h(world, i3, j, k3);
                }
                i4 = this.getMaxCurrentStrength(world, i3, l3, k3, -1);
                if (i4 >= 0 && i4 != i2) {
                    this.func_280_h(world, i3, l3, k3);
                }
            }
            if (l == 0 || i2 == 0) {
                world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
                world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
                world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
                world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
                world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
                world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
                world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
            }
        }
    }
    
    private void notifyWireNeighborsOfNeighborChange(final World world, final int i, final int j, final int k) {
        if (world.getBlockId(i, j, k) != this.blockID) {
            return;
        }
        world.notifyBlocksOfNeighborChange(i, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i - 1, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i + 1, j, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j, k - 1, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j, k + 1, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        super.onBlockAdded(world, i, j, k);
        if (world.multiplayerWorld) {
            return;
        }
        this.func_280_h(world, i, j, k);
        world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        this.notifyWireNeighborsOfNeighborChange(world, i - 1, j, k);
        this.notifyWireNeighborsOfNeighborChange(world, i + 1, j, k);
        this.notifyWireNeighborsOfNeighborChange(world, i, j, k - 1);
        this.notifyWireNeighborsOfNeighborChange(world, i, j, k + 1);
        if (world.isBlockNormalCube(i - 1, j, k)) {
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j + 1, k);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j - 1, k);
        }
        if (world.isBlockNormalCube(i + 1, j, k)) {
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j + 1, k);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j - 1, k);
        }
        if (world.isBlockNormalCube(i, j, k - 1)) {
            this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k - 1);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k - 1);
        }
        if (world.isBlockNormalCube(i, j, k + 1)) {
            this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k + 1);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k + 1);
        }
    }
    
    @Override
    public void onBlockRemoval(final World world, final int i, final int j, final int k) {
        super.onBlockRemoval(world, i, j, k);
        if (world.multiplayerWorld) {
            return;
        }
        world.notifyBlocksOfNeighborChange(i, j + 1, k, this.blockID);
        world.notifyBlocksOfNeighborChange(i, j - 1, k, this.blockID);
        this.func_280_h(world, i, j, k);
        this.notifyWireNeighborsOfNeighborChange(world, i - 1, j, k);
        this.notifyWireNeighborsOfNeighborChange(world, i + 1, j, k);
        this.notifyWireNeighborsOfNeighborChange(world, i, j, k - 1);
        this.notifyWireNeighborsOfNeighborChange(world, i, j, k + 1);
        if (world.isBlockNormalCube(i - 1, j, k)) {
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j + 1, k);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j - 1, k);
        }
        if (world.isBlockNormalCube(i + 1, j, k)) {
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j + 1, k);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j - 1, k);
        }
        if (world.isBlockNormalCube(i, j, k - 1)) {
            this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k - 1);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k - 1);
        }
        if (world.isBlockNormalCube(i, j, k + 1)) {
            this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k + 1);
        }
        else {
            this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k + 1);
        }
    }
    
    private int getMaxCurrentStrength(final World world, final int i, final int j, final int k, final int l) {
        if (world.getBlockId(i, j, k) != this.blockID) {
            return l;
        }
        final int i2 = world.getBlockMetadata(i, j, k);
        if (i2 > l) {
            return i2;
        }
        return l;
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (world.multiplayerWorld) {
            return;
        }
        final int i2 = world.getBlockMetadata(i, j, k);
        final boolean flag = this.canPlace(world, i, j, k);
        if (!flag) {
            this.dropBlockAsItem(world, i, j, k, i2);
            world.setBlockWithNotify(i, j, k, 0);
        }
        else {
            this.func_280_h(world, i, j, k);
        }
        super.onNeighborBlockChange(world, i, j, k, l);
    }
    
    @Override
    public int idDropped(final int i, final Random random) {
        return Item.redstone.shiftedIndex;
    }
    
    @Override
    public boolean isIndirectlyPoweringTo(final World world, final int i, final int j, final int k, final int l) {
        return this.wiresProvidePower && this.isPoweringTo(world, i, j, k, l);
    }
    
    @Override
    public boolean isPoweringTo(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (!this.wiresProvidePower) {
            return false;
        }
        if (iblockaccess.getBlockMetadata(i, j, k) == 0) {
            return false;
        }
        if (l == 1) {
            return true;
        }
        boolean flag = isPowerProviderOrWire(iblockaccess, i - 1, j, k) || (!iblockaccess.isBlockNormalCube(i - 1, j, k) && isPowerProviderOrWire(iblockaccess, i - 1, j - 1, k));
        boolean flag2 = isPowerProviderOrWire(iblockaccess, i + 1, j, k) || (!iblockaccess.isBlockNormalCube(i + 1, j, k) && isPowerProviderOrWire(iblockaccess, i + 1, j - 1, k));
        boolean flag3 = isPowerProviderOrWire(iblockaccess, i, j, k - 1) || (!iblockaccess.isBlockNormalCube(i, j, k - 1) && isPowerProviderOrWire(iblockaccess, i, j - 1, k - 1));
        boolean flag4 = isPowerProviderOrWire(iblockaccess, i, j, k + 1) || (!iblockaccess.isBlockNormalCube(i, j, k + 1) && isPowerProviderOrWire(iblockaccess, i, j - 1, k + 1));
        if (!iblockaccess.isBlockNormalCube(i, j + 1, k)) {
            if (iblockaccess.isBlockNormalCube(i - 1, j, k) && isPowerProviderOrWire(iblockaccess, i - 1, j + 1, k)) {
                flag = true;
            }
            if (iblockaccess.isBlockNormalCube(i + 1, j, k) && isPowerProviderOrWire(iblockaccess, i + 1, j + 1, k)) {
                flag2 = true;
            }
            if (iblockaccess.isBlockNormalCube(i, j, k - 1) && isPowerProviderOrWire(iblockaccess, i, j + 1, k - 1)) {
                flag3 = true;
            }
            if (iblockaccess.isBlockNormalCube(i, j, k + 1) && isPowerProviderOrWire(iblockaccess, i, j + 1, k + 1)) {
                flag4 = true;
            }
        }
        return (!flag3 && !flag2 && !flag && !flag4 && l >= 2 && l <= 5) || (l == 2 && flag3 && !flag && !flag2) || (l == 3 && flag4 && !flag && !flag2) || (l == 4 && flag && !flag3 && !flag4) || (l == 5 && flag2 && !flag3 && !flag4);
    }
    
    @Override
    public boolean canProvidePower() {
        return this.wiresProvidePower;
    }
    
    @Override
    public void randomDisplayTick(final World world, final int i, final int j, final int k, final Random random) {
        if (world.getBlockMetadata(i, j, k) > 0) {
            final double d = i + 0.5 + (random.nextFloat() - 0.5) * 0.2;
            final double d2 = j + 0.0625f;
            final double d3 = k + 0.5 + (random.nextFloat() - 0.5) * 0.2;
            world.spawnParticle("reddust", d, d2, d3, 0.0, 0.0, 0.0);
        }
    }
    
    public static boolean isPowerProviderOrWire(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getBlockId(i, j, k);
        return l == Block.redstoneWire.blockID || (l != 0 && Block.allBlocks[l].canProvidePower());
    }
}
