package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.phys.*;
import com.mojang.minecraft.render.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;

public class BlockMinecartTrack extends Block
{
    protected BlockMinecartTrack(final int i, final int j) {
        super(i, j, Material.circuits);
        this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
    }
    
    @Override
    public AxisAlignedBB getCollisionBoundingBoxFromPool(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean isOpaqueCube() {
        return false;
    }
    
    @Override
    public MovingObjectPosition collisionRayTrace(final World world, final int i, final int j, final int k, final Vec3D vec3d, final Vec3D vec3d1) {
        this.setBlockBoundsBasedOnState(world, i, j, k);
        return super.collisionRayTrace(world, i, j, k, vec3d, vec3d1);
    }
    
    @Override
    public void setBlockBoundsBasedOnState(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getBlockMetadata(i, j, k);
        if (l >= 2 && l <= 5) {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.625f, 1.0f);
        }
        else {
            this.setBlockBounds(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
        }
    }
    
    @Override
    public int getBlockTextureFromSideAndMetadata(final int i, final int j) {
        if (j >= 6) {
            return this.blockIndexInTexture - 16;
        }
        return this.blockIndexInTexture;
    }
    
    @Override
    public boolean renderAsNormalBlock() {
        return false;
    }
    
    @Override
    public int getRenderType() {
        return 9;
    }
    
    @Override
    public int quantityDropped(final Random random) {
        return 1;
    }
    
    @Override
    public boolean canPlace(final World world, final int i, final int j, final int k) {
        return world.isBlockNormalCube(i, j - 1, k);
    }
    
    @Override
    public void onBlockAdded(final World world, final int i, final int j, final int k) {
        if (!world.multiplayerWorld) {
            world.setBlockMetadataWithNotify(i, j, k, 15);
            this.func_304_h(world, i, j, k);
        }
    }
    
    @Override
    public void onNeighborBlockChange(final World world, final int i, final int j, final int k, final int l) {
        if (world.multiplayerWorld) {
            return;
        }
        final int i2 = world.getBlockMetadata(i, j, k);
        boolean flag = false;
        if (!world.isBlockNormalCube(i, j - 1, k)) {
            flag = true;
        }
        if (i2 == 2 && !world.isBlockNormalCube(i + 1, j, k)) {
            flag = true;
        }
        if (i2 == 3 && !world.isBlockNormalCube(i - 1, j, k)) {
            flag = true;
        }
        if (i2 == 4 && !world.isBlockNormalCube(i, j, k - 1)) {
            flag = true;
        }
        if (i2 == 5 && !world.isBlockNormalCube(i, j, k + 1)) {
            flag = true;
        }
        if (flag) {
            this.dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
        else if (l > 0 && Block.allBlocks[l].canProvidePower() && MinecartTrackLogic.func_791_a(new MinecartTrackLogic(this, world, i, j, k)) == 3) {
            this.func_304_h(world, i, j, k);
        }
    }
    
    private void func_304_h(final World world, final int i, final int j, final int k) {
        if (world.multiplayerWorld) {
            return;
        }
        new MinecartTrackLogic(this, world, i, j, k).func_792_a(world.isBlockIndirectlyGettingPowered(i, j, k));
    }
}
