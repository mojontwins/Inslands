package com.mojang.minecraft.level;

class WorldBlockPositionType
{
    int bPosX;
    int bPosY;
    int bPosZ;
    int field_1206_d;
    int field_1205_e;
    int field_1204_f;
    final WorldClient field_1203_g;
    
    public WorldBlockPositionType(final WorldClient worldclient, final int i, final int j, final int k, final int l, final int i1) {
        this.field_1203_g = worldclient;
        this.bPosX = i;
        this.bPosY = j;
        this.bPosZ = k;
        this.field_1206_d = 80;
        this.field_1205_e = l;
        this.field_1204_f = i1;
    }
}
