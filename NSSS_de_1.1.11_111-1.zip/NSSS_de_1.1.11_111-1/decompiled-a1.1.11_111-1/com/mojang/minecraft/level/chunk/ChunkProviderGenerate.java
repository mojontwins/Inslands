package com.mojang.minecraft.level.chunk;

import java.util.*;
import com.mojang.minecraft.level.generate.noise.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.tile.material.*;
import com.mojang.minecraft.gui.*;

public class ChunkProviderGenerate implements IChunkProvider
{
    protected Random genRandom;
    protected NoiseGeneratorOctaves noiseGen1;
    protected NoiseGeneratorOctaves noiseGen2;
    protected NoiseGeneratorOctaves noiseGen3;
    protected NoiseGeneratorOctaves beachNoise;
    protected NoiseGeneratorOctaves soilNoise;
    protected InfdevOldNoiseGeneratorOctaves noiseGen1a;
    protected InfdevOldNoiseGeneratorOctaves noiseGen2a;
    protected InfdevOldNoiseGeneratorOctaves noiseGen3a;
    protected InfdevOldNoiseGeneratorOctaves noiseGen4a;
    protected InfdevOldNoiseGeneratorOctaves noiseGen5a;
    protected InfdevOldNoiseGeneratorOctaves noiseGen6a;
    public NoiseGeneratorOctaves noiseGen6;
    public NoiseGeneratorOctaves noiseGen7;
    public NoiseGeneratorOctaves treeNoise;
    protected World worldObj;
    protected double[] densities;
    protected double[] sandBeachNoise;
    protected double[] gravelBeachNoise;
    protected double[] soilThicknessNoise;
    protected MapGenBase mapGenBase;
    double[] noiseData1;
    double[] noiseData2;
    double[] noiseData3;
    double[] heightBias1;
    double[] heightBias2;
    int[][] blockArray;
    
    public ChunkProviderGenerate(final World world, final long inputSeed) {
        if (!(this instanceof ChunkProviderSky)) {
            this.sandBeachNoise = new double[256];
            this.gravelBeachNoise = new double[256];
            this.soilThicknessNoise = new double[256];
            this.mapGenBase = new MapGenCaves();
            this.blockArray = new int[32][32];
            this.worldObj = world;
            this.genRandom = new Random(inputSeed);
            this.noiseGen1 = new NoiseGeneratorOctaves(this.genRandom, 16);
            this.noiseGen2 = new NoiseGeneratorOctaves(this.genRandom, 16);
            this.noiseGen3 = new NoiseGeneratorOctaves(this.genRandom, 8);
            this.beachNoise = new NoiseGeneratorOctaves(this.genRandom, 4);
            this.soilNoise = new NoiseGeneratorOctaves(this.genRandom, 4);
            this.noiseGen6 = new NoiseGeneratorOctaves(this.genRandom, 10);
            this.noiseGen7 = new NoiseGeneratorOctaves(this.genRandom, 16);
            this.treeNoise = new NoiseGeneratorOctaves(this.genRandom, 8);
            world.cloudHeight = 108.0f;
        }
    }
    
    public void generateTerrain(final int chunkX, final int chunkZ, final byte[] blockArray) {
        final byte byte0 = 4;
        final byte seaLevel = 64;
        final int k = byte0 + 1;
        final byte byte2 = 17;
        final int l = byte0 + 1;
        this.densities = this.initializeNoiseField(this.densities, chunkX * byte0, 0, chunkZ * byte0, k, byte2, l);
        for (int genBlockSomething = 0; genBlockSomething < byte0; ++genBlockSomething) {
            for (int j1 = 0; j1 < byte0; ++j1) {
                for (int k2 = 0; k2 < 16; ++k2) {
                    final double d = 0.125;
                    double d2 = this.densities[((genBlockSomething + 0) * l + (j1 + 0)) * byte2 + (k2 + 0)];
                    double d3 = this.densities[((genBlockSomething + 0) * l + (j1 + 1)) * byte2 + (k2 + 0)];
                    double d4 = this.densities[((genBlockSomething + 1) * l + (j1 + 0)) * byte2 + (k2 + 0)];
                    double d5 = this.densities[((genBlockSomething + 1) * l + (j1 + 1)) * byte2 + (k2 + 0)];
                    final double d6 = (this.densities[((genBlockSomething + 0) * l + (j1 + 0)) * byte2 + (k2 + 1)] - d2) * d;
                    final double d7 = (this.densities[((genBlockSomething + 0) * l + (j1 + 1)) * byte2 + (k2 + 1)] - d3) * d;
                    final double d8 = (this.densities[((genBlockSomething + 1) * l + (j1 + 0)) * byte2 + (k2 + 1)] - d4) * d;
                    final double d9 = (this.densities[((genBlockSomething + 1) * l + (j1 + 1)) * byte2 + (k2 + 1)] - d5) * d;
                    for (int l2 = 0; l2 < 8; ++l2) {
                        final double d10 = 0.25;
                        double d11 = d2;
                        double d12 = d3;
                        final double d13 = (d4 - d2) * d10;
                        final double d14 = (d5 - d3) * d10;
                        for (int i2 = 0; i2 < 4; ++i2) {
                            int j2 = i2 + genBlockSomething * 4 << 11 | 0 + j1 * 4 << 7 | k2 * 8 + l2;
                            final char c = '\u0080';
                            final double d15 = 0.25;
                            double d16 = d11;
                            final double d17 = (d12 - d11) * d15;
                            for (int k3 = 0; k3 < 4; ++k3) {
                                int l3 = 0;
                                if (k2 * 8 + l2 < seaLevel) {
                                    if (this.worldObj.snowCovered && k2 * 8 + l2 >= seaLevel - 1) {
                                        l3 = Block.ice.blockID;
                                    }
                                    else {
                                        l3 = Block.waterStill.blockID;
                                    }
                                }
                                if (d16 > 0.0) {
                                    l3 = Block.stone.blockID;
                                }
                                blockArray[j2] = (byte)l3;
                                j2 += c;
                                d16 += d17;
                            }
                            d11 += d13;
                            d12 += d14;
                        }
                        d2 += d6;
                        d3 += d7;
                        d4 += d8;
                        d5 += d9;
                    }
                }
            }
        }
    }
    
    public void replaceBlocksForBiome(final int chunkX, final int chunkZ, final byte[] blockArray) {
        final byte seaLevel = 64;
        final double d = 0.03125;
        this.sandBeachNoise = this.beachNoise.generateNoiseOctaves_2(this.sandBeachNoise, chunkX * 16, chunkZ * 16, 0.0, 16, 16, 1, d, d, 1.0);
        this.gravelBeachNoise = this.beachNoise.generateNoiseOctaves_2(this.gravelBeachNoise, chunkZ * 16, 109.0134, chunkX * 16, 16, 1, 16, d, 1.0, d);
        this.soilThicknessNoise = this.soilNoise.generateNoiseOctaves_2(this.soilThicknessNoise, chunkX * 16, chunkZ * 16, 0.0, 16, 16, 1, d * 2.0, d * 2.0, d * 2.0);
        for (int xIndex = 0; xIndex < 16; ++xIndex) {
            for (int zIndex = 0; zIndex < 16; ++zIndex) {
                final boolean genSandBeach = this.sandBeachNoise[zIndex + xIndex * 16] + this.genRandom.nextDouble() * 0.2 > 0.0;
                final boolean genGravelBeach = this.gravelBeachNoise[xIndex + zIndex * 16] + this.genRandom.nextDouble() * 0.2 > 3.0;
                final int soilThickness = (int)(this.soilThicknessNoise[zIndex + xIndex * 16] / 3.0 + 3.0 + this.genRandom.nextDouble() * 0.25);
                int surfaceIterator = -1;
                byte topLayerBlock = (byte)Block.grass.blockID;
                byte subsurfaceLayerBlock = (byte)Block.dirt.blockID;
                for (int yLevelIndex = 127; yLevelIndex >= 0; --yLevelIndex) {
                    final int currentBlock = (xIndex * 16 + zIndex) * 128 + yLevelIndex;
                    if (yLevelIndex <= 0 + this.genRandom.nextInt(6) - 1) {
                        blockArray[currentBlock] = (byte)Block.bedrock.blockID;
                    }
                    else {
                        final byte byte3 = blockArray[currentBlock];
                        if (byte3 == 0) {
                            surfaceIterator = -1;
                        }
                        else if (byte3 == Block.stone.blockID) {
                            if (surfaceIterator == -1) {
                                if (soilThickness <= 0) {
                                    topLayerBlock = 0;
                                    subsurfaceLayerBlock = (byte)Block.stone.blockID;
                                }
                                else if (yLevelIndex >= seaLevel - 4 && yLevelIndex <= seaLevel + 1) {
                                    topLayerBlock = (byte)Block.grass.blockID;
                                    subsurfaceLayerBlock = (byte)Block.dirt.blockID;
                                    if (genGravelBeach) {
                                        topLayerBlock = 0;
                                    }
                                    if (genGravelBeach) {
                                        subsurfaceLayerBlock = (byte)Block.gravel.blockID;
                                    }
                                    if (genSandBeach) {
                                        topLayerBlock = (byte)Block.sand.blockID;
                                    }
                                    if (genSandBeach) {
                                        subsurfaceLayerBlock = (byte)Block.sand.blockID;
                                    }
                                }
                                if (yLevelIndex < seaLevel && topLayerBlock == 0) {
                                    topLayerBlock = (byte)Block.waterStill.blockID;
                                }
                                surfaceIterator = soilThickness;
                                if (yLevelIndex >= seaLevel - 1) {
                                    blockArray[currentBlock] = topLayerBlock;
                                }
                                else {
                                    blockArray[currentBlock] = subsurfaceLayerBlock;
                                }
                            }
                            else if (surfaceIterator > 0) {
                                --surfaceIterator;
                                blockArray[currentBlock] = subsurfaceLayerBlock;
                            }
                        }
                    }
                }
            }
        }
    }
    
    public Chunk provideChunk(final int chunkX, final int chunkZ) {
        this.genRandom.setSeed(chunkX * 341873128712L + chunkZ * 132897987541L);
        final byte[] blockArray = new byte[32768];
        final Chunk chunk = new Chunk(this.worldObj, blockArray, chunkX, chunkZ);
        this.generateTerrain(chunkX, chunkZ, blockArray);
        this.replaceBlocksForBiome(chunkX, chunkZ, blockArray);
        this.mapGenBase.func_867_a(this, this.worldObj, chunkX, chunkZ, blockArray);
        chunk.func_1024_c();
        return chunk;
    }
    
    protected double[] initializeNoiseField(double[] densityToInitialize, final int chunkX, final int chunkY, final int chunkZ, final int l, final int i1, final int j1) {
        final double noiseScaleX = 80.0;
        final double noiseScaleY = 160.0;
        final double noiseScaleZ = 80.0;
        final double floatyness = 0.0;
        if (densityToInitialize == null) {
            densityToInitialize = new double[l * i1 * j1];
        }
        final double coordinateScale = 684.412;
        final double heightScale = 684.412;
        this.heightBias1 = this.noiseGen6.generateNoiseOctaves(this.heightBias1, chunkX, chunkY, chunkZ, l, 1, j1, 1.0, 0.0, 1.0);
        this.heightBias2 = this.noiseGen7.generateNoiseOctaves(this.heightBias2, chunkX, chunkY, chunkZ, l, 1, j1, 100.0, 0.0, 100.0);
        this.noiseData1 = this.noiseGen3.generateNoiseOctaves(this.noiseData1, chunkX, chunkY, chunkZ, l, i1, j1, coordinateScale / noiseScaleX, heightScale / noiseScaleY, coordinateScale / noiseScaleZ);
        this.noiseData2 = this.noiseGen1.generateNoiseOctaves(this.noiseData2, chunkX, chunkY, chunkZ, l, i1, j1, coordinateScale, heightScale, coordinateScale);
        this.noiseData3 = this.noiseGen2.generateNoiseOctaves(this.noiseData3, chunkX, chunkY, chunkZ, l, i1, j1, coordinateScale, heightScale, coordinateScale);
        int k1 = 0;
        int l2 = 0;
        for (int i2 = 0; i2 < l; ++i2) {
            for (int j2 = 0; j2 < j1; ++j2) {
                double monolithNess = (this.heightBias1[l2] + 256.0) / 512.0;
                if (monolithNess > 1.0) {
                    monolithNess = 1.0;
                }
                final double d3 = floatyness;
                double heightBias = this.heightBias2[l2] / 8000.0;
                if (heightBias < 0.0) {
                    heightBias = -heightBias;
                }
                heightBias = heightBias * 3.0 - 3.0;
                if (heightBias < 0.0) {
                    heightBias /= 2.0;
                    if (heightBias < -1.0) {
                        heightBias = -1.0;
                    }
                    heightBias /= 1.4;
                    heightBias /= 2.0;
                    monolithNess = 0.0;
                }
                else {
                    if (heightBias > 1.0) {
                        heightBias = 1.0;
                    }
                    heightBias /= 6.0;
                }
                monolithNess += 0.5;
                heightBias = heightBias * i1 / 16.0;
                final double d4 = i1 / 2.0 + heightBias * 4.0;
                ++l2;
                for (int k2 = 0; k2 < i1; ++k2) {
                    double d5 = 0.0;
                    double d6 = (k2 - d4) * 12.0 / monolithNess;
                    if (d6 < 0.0) {
                        d6 *= 4.0;
                    }
                    final double d7 = this.noiseData2[k1] / 512.0;
                    final double d8 = this.noiseData3[k1] / 512.0;
                    final double d9 = (this.noiseData1[k1] / 10.0 + 1.0) / 2.0;
                    if (d9 < 0.0) {
                        d5 = d7;
                    }
                    else if (d9 > 1.0) {
                        d5 = d8;
                    }
                    else {
                        d5 = d7 + (d8 - d7) * d9;
                    }
                    d5 -= d6;
                    if (k2 > i1 - 4) {
                        final double d10 = (k2 - (i1 - 4)) / 3.0f;
                        d5 = d5 * (1.0 - d10) + -10.0 * d10;
                    }
                    if (k2 < d3) {
                        double d11 = (d3 - k2) / 4.0;
                        if (d11 < 0.0) {
                            d11 = 0.0;
                        }
                        if (d11 > 1.0) {
                            d11 = 1.0;
                        }
                        d5 = d5 * (1.0 - d11) + -10.0 * d11;
                    }
                    densityToInitialize[k1] = d5;
                    ++k1;
                }
            }
        }
        return densityToInitialize;
    }
    
    public boolean chunkExists(final int i, final int j) {
        return true;
    }
    
    public void generateStructures(final IChunkProvider ichunkprovider, final int i, final int j) {
        BlockSand.fallInstantly = true;
        final int tryX = i * 16;
        final int tryZ = j * 16;
        this.genRandom.setSeed(this.worldObj.randomSeed);
        final long l1 = this.genRandom.nextLong() / 2L * 2L + 1L;
        final long l2 = this.genRandom.nextLong() / 2L * 2L + 1L;
        this.genRandom.setSeed(i * l1 + j * l2 ^ this.worldObj.randomSeed);
        double d = 0.25;
        for (int i2 = 0; i2 < 8; ++i2) {
            final int i3 = tryX + this.genRandom.nextInt(16) + 8;
            final int j2 = this.genRandom.nextInt(128);
            final int i4 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenDungeons().generate(this.worldObj, this.genRandom, i3, j2, i4);
        }
        if ((tryX > 3000 || tryX < -3000 || tryZ > 3000 || tryZ < -3000) && this.genRandom.nextInt(10000) == 2) {
            final int pyrX = tryX + this.genRandom.nextInt(16) + 8;
            final int pyrY = this.genRandom.nextInt(128);
            final int pyrZ = tryZ + this.genRandom.nextInt(16) + 8;
            new aaa().generate(this.worldObj, this.genRandom, pyrX, pyrY, pyrZ);
        }
        for (int i2 = 0; i2 < 8; ++i2) {
            final int i3 = tryX + this.genRandom.nextInt(16) + 8;
            final int j2 = this.genRandom.nextInt(512);
            final int i4 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenWaterDungeons().generate(this.worldObj, this.genRandom, i3, j2, i4);
        }
        for (int i2 = 0; i2 < 128; ++i2) {
            final int i3 = tryX + this.genRandom.nextInt(16) + 8;
            final int j2 = this.genRandom.nextInt(128);
            final int i4 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenCobWebs().generate(this.worldObj, this.genRandom, i3, j2, i4);
        }
        for (int j3 = 0; j3 < 10; ++j3) {
            final int j4 = tryX + this.genRandom.nextInt(16);
            final int k6 = this.genRandom.nextInt(64);
            final int j5 = tryZ + this.genRandom.nextInt(16);
            new WorldGenClay(8).generate(this.worldObj, this.genRandom, j4, k6, j5);
        }
        for (int k7 = 0; k7 < 20; ++k7) {
            final int k8 = tryX + this.genRandom.nextInt(16);
            final int l3 = this.genRandom.nextInt(128);
            final int k9 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.dirt.blockID, 32).generate(this.worldObj, this.genRandom, k8, l3, k9);
        }
        for (int i5 = 0; i5 < 10; ++i5) {
            final int l4 = tryX + this.genRandom.nextInt(16);
            final int i6 = this.genRandom.nextInt(128);
            final int l5 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.gravel.blockID, 32).generate(this.worldObj, this.genRandom, l4, i6, l5);
        }
        for (int j6 = 0; j6 < 20; ++j6) {
            final int i7 = tryX + this.genRandom.nextInt(16);
            final int j7 = this.genRandom.nextInt(128);
            final int i8 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCoal.blockID, 16).generate(this.worldObj, this.genRandom, i7, j7, i8);
        }
        for (int k10 = 0; k10 < 20; ++k10) {
            final int j8 = tryX + this.genRandom.nextInt(16);
            final int k11 = this.genRandom.nextInt(64);
            final int j9 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreIron.blockID, 8).generate(this.worldObj, this.genRandom, j8, k11, j9);
        }
        for (int i9 = 0; i9 < 2; ++i9) {
            final int k12 = tryX + this.genRandom.nextInt(16);
            final int l6 = this.genRandom.nextInt(32);
            final int k13 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreGold.blockID, 8).generate(this.worldObj, this.genRandom, k12, l6, k13);
        }
        for (int i9 = 0; i9 < 6; ++i9) {
            final int k12 = tryX + this.genRandom.nextInt(16);
            final int l6 = this.genRandom.nextInt(32);
            final int k13 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCopper.blockID, 8).generate(this.worldObj, this.genRandom, k12, l6, k13);
        }
        for (int j10 = 0; j10 < 8; ++j10) {
            final int l7 = tryX + this.genRandom.nextInt(16);
            final int i10 = this.genRandom.nextInt(16);
            final int l8 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreRed.blockID, 7).generate(this.worldObj, this.genRandom, l7, i10, l8);
        }
        for (int k14 = 0; k14 < 1; ++k14) {
            final int i11 = tryX + this.genRandom.nextInt(16);
            final int j11 = this.genRandom.nextInt(16);
            final int i12 = tryZ + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreDiamond.blockID, 7).generate(this.worldObj, this.genRandom, i11, j11, i12);
        }
        d = 0.5;
        int treeGenChance = (int)((this.treeNoise.func_806_a(tryX * d, tryZ * d) / 8.0 + this.genRandom.nextDouble() * 4.0 + 4.0) / 3.0);
        if (treeGenChance < 0) {
            treeGenChance = 0;
        }
        if (this.genRandom.nextInt(10) == 0) {
            ++treeGenChance;
        }
        Object treeGenerator = new WorldGenTrees();
        if (this.genRandom.nextInt(10) == 0) {
            treeGenerator = new WorldGenBigTree();
        }
        for (int k15 = 0; k15 < treeGenChance; ++k15) {
            final int j12 = tryX + this.genRandom.nextInt(16) + 8;
            final int l9 = tryZ + this.genRandom.nextInt(16) + 8;
            ((WorldGenerator)treeGenerator).func_517_a(1.0, 1.0, 1.0);
            ((WorldGenerator)treeGenerator).generate(this.worldObj, this.genRandom, j12, this.worldObj.getHeightValue(j12, l9), l9);
        }
        for (int l10 = 0; l10 < 2; ++l10) {
            final int k16 = tryX + this.genRandom.nextInt(16) + 8;
            final int i13 = this.genRandom.nextInt(128);
            final int j13 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantYellow.blockID).generate(this.worldObj, this.genRandom, k16, i13, j13);
        }
        if (this.genRandom.nextInt(2) == 0) {
            final int i14 = tryX + this.genRandom.nextInt(16) + 8;
            final int l11 = this.genRandom.nextInt(128);
            final int j14 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantRed.blockID).generate(this.worldObj, this.genRandom, i14, l11, j14);
        }
        if (this.genRandom.nextInt(1) == 0) {
            final int i14 = tryX + this.genRandom.nextInt(16) + 8;
            final int l11 = this.genRandom.nextInt(128);
            final int j14 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantBlue.blockID).generate(this.worldObj, this.genRandom, i14, l11, j14);
        }
        if (this.genRandom.nextInt(4) == 0) {
            final int j15 = tryX + this.genRandom.nextInt(16) + 8;
            final int i15 = this.genRandom.nextInt(128);
            final int k17 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomBrown.blockID).generate(this.worldObj, this.genRandom, j15, i15, k17);
        }
        if (this.genRandom.nextInt(8) == 0) {
            final int k18 = tryX + this.genRandom.nextInt(16) + 8;
            final int j16 = this.genRandom.nextInt(128);
            final int l12 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomRed.blockID).generate(this.worldObj, this.genRandom, k18, j16, l12);
        }
        for (int l13 = 0; l13 < 10; ++l13) {
            final int k19 = tryX + this.genRandom.nextInt(16) + 8;
            final int i16 = this.genRandom.nextInt(128);
            final int k20 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenReed().generate(this.worldObj, this.genRandom, k19, i16, k20);
        }
        for (int i17 = 0; i17 < 1; ++i17) {
            final int l14 = tryX + this.genRandom.nextInt(16) + 8;
            final int j17 = this.genRandom.nextInt(128);
            final int l15 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenCactus().generate(this.worldObj, this.genRandom, l14, j17, l15);
        }
        for (int j18 = 0; j18 < 50; ++j18) {
            final int i18 = tryX + this.genRandom.nextInt(16) + 8;
            final int k21 = this.genRandom.nextInt(this.genRandom.nextInt(120) + 8);
            final int i19 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.waterMoving.blockID).generate(this.worldObj, this.genRandom, i18, k21, i19);
        }
        for (int k22 = 0; k22 < 20; ++k22) {
            final int j19 = tryX + this.genRandom.nextInt(16) + 8;
            final int l16 = this.genRandom.nextInt(this.genRandom.nextInt(this.genRandom.nextInt(112) + 8) + 8);
            final int j20 = tryZ + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.lavaMoving.blockID).generate(this.worldObj, this.genRandom, j19, l16, j20);
        }
        for (int l17 = tryX + 8 + 0; l17 < tryX + 8 + 16; ++l17) {
            for (int k23 = tryZ + 8 + 0; k23 < tryZ + 8 + 16; ++k23) {
                final int i20 = this.worldObj.getTopSolidOrLiquidBlock(l17, k23);
                if (this.worldObj.snowCovered && i20 > 0 && i20 < 128 && this.worldObj.getBlockId(l17, i20, k23) == 0 && this.worldObj.getMaterialXYZ(l17, i20 - 1, k23).blocksMovement() && this.worldObj.getMaterialXYZ(l17, i20 - 1, k23) != Material.ice) {
                    this.worldObj.setBlockWithNotify(l17, i20, k23, Block.snow.blockID);
                }
            }
        }
        BlockSand.fallInstantly = false;
    }
    
    public boolean saveChunks(final boolean flag, final IProgressUpdate iprogressupdate) {
        return true;
    }
    
    public boolean unload100OldestChunks() {
        return false;
    }
    
    public boolean canSave() {
        return true;
    }
}
