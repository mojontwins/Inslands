package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.region.*;
import com.mojang.minecraft.util.*;
import java.io.*;
import com.mojang.minecraft.nbt.*;
import com.mojang.minecraft.entity.tile.*;
import java.util.*;
import com.mojang.minecraft.level.generate.noise.*;
import com.mojang.minecraft.entity.*;

public class ChunkLoader implements IChunkLoader
{
    private File basePath;
    
    public ChunkLoader(final File file, final boolean flag) {
        this.basePath = file;
    }
    
    private File getChunkFile(final int i, final int j) {
        final String s = "c." + Integer.toString(i, 36) + "." + Integer.toString(j, 36) + ".dat";
        final String s2 = Integer.toString(i & 0x3F, 36);
        final String s3 = Integer.toString(j & 0x3F, 36);
        File file = new File(this.basePath, s2);
        file = new File(file, s3);
        file = new File(file, s);
        return file;
    }
    
    public Chunk loadChunkFromFile(final World world, final int x, final int z) throws IOException {
        final DataInputStream regionChunkInputStream = RegionFileCache.getChunkDataInputStream(this.basePath, x, z);
        final File chunkFile = this.getChunkFile(x, z);
        NBTTagCompound nbt = null;
        Label_0079: {
            if (regionChunkInputStream == null) {
                if (chunkFile.exists()) {
                    try {
                        final FileInputStream inputStream = new FileInputStream(chunkFile);
                        nbt = CompressedStreamTools.func_1138_a(inputStream);
                        inputStream.close();
                        break Label_0079;
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                        return null;
                    }
                }
                return null;
            }
            nbt = CompressedStreamTools.func_1138_a(regionChunkInputStream);
        }
        if (!nbt.hasKey("Level")) {
            System.out.println("Chunk file at " + x + "," + z + " is missing level data, skipping");
            regionChunkInputStream.close();
            return null;
        }
        if (!nbt.getCompoundTag("Level").hasKey("Blocks")) {
            System.out.println("Chunk file at " + x + "," + z + " is missing block data, skipping");
            regionChunkInputStream.close();
            return null;
        }
        Chunk chunk = loadChunkIntoWorldFromCompound(world, nbt.getCompoundTag("Level"));
        if (!chunk.isAtLocation(x, z)) {
            System.out.println("Chunk file at " + x + "," + z + " is in the wrong location; relocating. (Expected " + x + ", " + z + ", got " + chunk.xPosition + ", " + chunk.zPosition + ")");
            nbt.setInteger("xPos", x);
            nbt.setInteger("zPos", z);
            chunk = loadChunkIntoWorldFromCompound(world, nbt.getCompoundTag("Level"));
        }
        try {
            if (regionChunkInputStream != null) {
                regionChunkInputStream.close();
            }
        }
        catch (IOException ex) {}
        return chunk;
    }
    
    public void saveChunk(final World world, final Chunk chunk) throws IOException {
        world.checkSessionLock();
        final DataOutputStream output = RegionFileCache.getChunkDataOutputStream(this.basePath, chunk.xPosition, chunk.zPosition);
        final NBTTagCompound var6 = new NBTTagCompound();
        final NBTTagCompound var7 = new NBTTagCompound();
        var6.func_762_a("Level", var7);
        this.storeChunkInCompound(chunk, world, var7);
        CompressedStreamTools.writeGzippedCompoundToOutputStream(var6, output);
        try {
            output.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        world.sizeOnDisk += RegionFileCache.getSizeDelta(this.basePath, chunk.xPosition, chunk.zPosition);
    }
    
    public void storeChunkInCompound(final Chunk chunk, final World world, final NBTTagCompound nbttagcompound) {
        world.checkSessionLock();
        nbttagcompound.setInteger("xPos", chunk.xPosition);
        nbttagcompound.setInteger("zPos", chunk.zPosition);
        nbttagcompound.setLong("LastUpdate", world.worldTime);
        nbttagcompound.func_747_a("Blocks", chunk.blocks);
        nbttagcompound.func_747_a("Data", chunk.data.data);
        nbttagcompound.func_747_a("SkyLight", chunk.skylightMap.data);
        nbttagcompound.func_747_a("BlockLight", chunk.blocklightMap.data);
        nbttagcompound.func_747_a("HeightMap", chunk.heightMap);
        nbttagcompound.setBool("TerrainPopulated", chunk.isTerrainPopulated);
        chunk.hasEntities = false;
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < chunk.entities.length; ++i) {
            for (final Entity entity : chunk.entities[i]) {
                chunk.hasEntities = true;
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                if (entity.addEntityID(nbttagcompound2)) {
                    nbttaglist.setTag(nbttagcompound2);
                }
            }
        }
        nbttagcompound.func_762_a("Entities", nbttaglist);
        final NBTTagList nbttaglist2 = new NBTTagList();
        for (final TileEntity tileentity : chunk.chunkTileEntityMap.values()) {
            final NBTTagCompound nbttagcompound3 = new NBTTagCompound();
            tileentity.func_481_b(nbttagcompound3);
            nbttaglist2.setTag(nbttagcompound3);
        }
        nbttagcompound.func_762_a("TileEntities", nbttaglist2);
    }
    
    public static Chunk loadChunkIntoWorldFromCompound(final World world, final NBTTagCompound nbttagcompound) {
        final int i = nbttagcompound.getInteger("xPos");
        final int j = nbttagcompound.getInteger("zPos");
        final Chunk chunk = new Chunk(world, i, j);
        chunk.blocks = nbttagcompound.getByteArray("Blocks");
        chunk.data = new NibbleArray(nbttagcompound.getByteArray("Data"));
        chunk.skylightMap = new NibbleArray(nbttagcompound.getByteArray("SkyLight"));
        chunk.blocklightMap = new NibbleArray(nbttagcompound.getByteArray("BlockLight"));
        chunk.heightMap = nbttagcompound.getByteArray("HeightMap");
        chunk.isTerrainPopulated = nbttagcompound.getBoolean("TerrainPopulated");
        if (!chunk.data.isValid()) {
            chunk.data = new NibbleArray(chunk.blocks.length);
        }
        if (chunk.heightMap == null || !chunk.skylightMap.isValid()) {
            chunk.heightMap = new byte[256];
            chunk.skylightMap = new NibbleArray(chunk.blocks.length);
            chunk.func_1024_c();
        }
        if (!chunk.blocklightMap.isValid()) {
            chunk.blocklightMap = new NibbleArray(chunk.blocks.length);
            chunk.func_1014_a();
        }
        final NBTTagList nbttaglist = nbttagcompound.getTagList("Entities");
        if (nbttaglist != null) {
            for (int k = 0; k < nbttaglist.tagCount(); ++k) {
                final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.tagAt(k);
                final Entity entity = EntityList.createEntityFromNBT(nbttagcompound2, world);
                chunk.hasEntities = true;
                if (entity != null) {
                    chunk.addEntity(entity);
                }
            }
        }
        final NBTTagList nbttaglist2 = nbttagcompound.getTagList("TileEntities");
        if (nbttaglist2 != null) {
            for (int l = 0; l < nbttaglist2.tagCount(); ++l) {
                final NBTTagCompound nbttagcompound3 = (NBTTagCompound)nbttaglist2.tagAt(l);
                final TileEntity tileentity = TileEntity.createAndLoadEntity(nbttagcompound3);
                if (tileentity != null) {
                    chunk.addTileEntity(tileentity);
                }
            }
        }
        return chunk;
    }
    
    public void func_814_a() {
    }
    
    public void saveExtraData() {
    }
    
    public void saveExtraChunkData(final World world, final Chunk chunk) {
    }
}
