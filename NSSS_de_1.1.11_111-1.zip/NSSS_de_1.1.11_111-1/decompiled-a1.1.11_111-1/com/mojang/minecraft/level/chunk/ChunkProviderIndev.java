package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.generate.noise.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.tile.material.*;

public class ChunkProviderIndev extends ChunkProviderGenerate
{
    public ChunkProviderIndev(final World world, final long l) {
        super(world, l);
        world.cloudHeight = 108.0f;
        this.noiseGen1a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 16);
        this.noiseGen2a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 16);
        this.noiseGen3a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 8);
        this.noiseGen4a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 4);
        this.noiseGen5a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 4);
        this.noiseGen6a = new InfdevOldNoiseGeneratorOctaves(this.genRandom, 5);
        new InfdevOldNoiseGeneratorOctaves(this.genRandom, 3);
        new InfdevOldNoiseGeneratorOctaves(this.genRandom, 3);
        new InfdevOldNoiseGeneratorOctaves(this.genRandom, 3);
    }
    
    @Override
    public void generateTerrain(final int chunkX, final int chunkZ, final byte[] blockArray) {
        final int blockX = chunkX << 4;
        final int blockZ = chunkZ << 4;
        int j = 0;
        for (int genBlockX = blockX; genBlockX < blockX + 16; ++genBlockX) {
            for (int genBlockZ = blockZ; genBlockZ < blockZ + 16; ++genBlockZ) {
                float heightValue = (float)(this.noiseGen1a.a(genBlockX / 0.03125f, 0.0, genBlockZ / 0.03125f) - this.noiseGen2a.a(genBlockX / 0.015625f, 0.0, genBlockZ / 0.015625f)) / 512.0f / 4.0f;
                float f2 = (float)this.noiseGen4a.func_806_a(genBlockX / 4.0f, genBlockZ / 4.0f);
                final float f3 = (float)this.noiseGen6a.func_806_a(genBlockX / 8.0f, genBlockZ / 8.0f) / 8.0f;
                f2 = ((f2 <= 0.0f) ? ((float)(this.noiseGen5a.func_806_a(genBlockX * 0.2571428f, genBlockZ * 0.2571428f) * f3)) : ((float)(this.noiseGen3a.func_806_a(genBlockX * 0.2571428f * 2.0f, genBlockZ * 0.2571428f * 2.0f) * f3 / 4.0)));
                heightValue = (float)(int)(heightValue + 64.0f + f2);
                if ((float)this.noiseGen5a.func_806_a(genBlockX, genBlockZ) < 0.0f) {
                    heightValue = (float)((int)heightValue / 2 << 1);
                    if ((float)this.noiseGen5a.func_806_a(genBlockX / 5.0, genBlockZ / 5.0) < 0.0f) {
                        ++heightValue;
                    }
                }
                for (int genBlockY = 0; genBlockY < 128; ++genBlockY) {
                    int l1 = 0;
                    if (((genBlockX == 0 && chunkX == 0) || (genBlockZ == 0 && chunkZ == 0)) && genBlockY <= heightValue) {
                        l1 = Block.stone.blockID;
                    }
                    if (genBlockY == heightValue + 1.0f && heightValue >= 64.0f && Math.random() < 0.02) {
                        l1 = 0;
                    }
                    else if (genBlockY == heightValue && heightValue >= 64.0f) {
                        l1 = Block.stone.blockID;
                    }
                    else if (genBlockY <= heightValue - 2.0f) {
                        l1 = Block.stone.blockID;
                    }
                    else if (genBlockY <= heightValue) {
                        l1 = Block.stone.blockID;
                    }
                    else if (genBlockY <= 64) {
                        l1 = Block.waterStill.blockID;
                        if (this.worldObj.snowCovered && genBlockY == 64) {
                            l1 = Block.ice.blockID;
                        }
                    }
                    this.genRandom.setSeed(chunkX + chunkZ * 13871);
                    int i2 = (chunkX << 10) + 128 + this.genRandom.nextInt(512);
                    int j2 = (chunkZ << 10) + 128 + this.genRandom.nextInt(512);
                    i2 = genBlockX - i2;
                    j2 = genBlockZ - j2;
                    if (i2 < 0) {
                        i2 = -i2;
                    }
                    if (j2 < 0) {
                        j2 = -j2;
                    }
                    if (j2 > i2) {
                        i2 = j2;
                    }
                    if ((i2 = 127 - i2) == 255) {
                        i2 = 1;
                    }
                    if (i2 < heightValue) {
                        i2 = (int)heightValue;
                    }
                    if (genBlockY <= i2 && (l1 == 0 || l1 == Block.waterStill.blockID || l1 == Block.lavaStill.blockID)) {
                        l1 = Block.brick.blockID;
                    }
                    if (l1 < 0) {
                        l1 = 0;
                    }
                    blockArray[j++] = (byte)l1;
                }
            }
        }
    }
    
    @Override
    public void replaceBlocksForBiome(final int i, final int j, final byte[] abyte0) {
        final byte seaLevel = 64;
        final double d = 0.03125;
        this.sandBeachNoise = this.beachNoise.generateNoiseOctaves(this.sandBeachNoise, i * 16, j * 16, 0.0, 16, 16, 1, d, d, 1.0);
        this.gravelBeachNoise = this.beachNoise.generateNoiseOctaves(this.gravelBeachNoise, j * 16, 109.0134, i * 16, 16, 1, 16, d, 1.0, d);
        this.soilThicknessNoise = this.soilNoise.generateNoiseOctaves(this.soilThicknessNoise, i * 16, j * 16, 0.0, 16, 16, 1, d * 2.0, d * 2.0, d * 2.0);
        for (int k = 0; k < 16; ++k) {
            for (int l = 0; l < 16; ++l) {
                final boolean flag = this.sandBeachNoise[k + l * 16] + this.genRandom.nextDouble() * 0.2 > 0.0;
                final boolean flag2 = this.gravelBeachNoise[k + l * 16] + this.genRandom.nextDouble() * 0.2 > 3.0;
                final int i2 = (int)(this.soilThicknessNoise[k + l * 16] / 3.0 + 3.0 + this.genRandom.nextDouble() * 0.25);
                int j2 = -1;
                byte byte1 = (byte)Block.grass.blockID;
                byte byte2 = (byte)Block.dirt.blockID;
                for (int k2 = 127; k2 >= 0; --k2) {
                    final int l2 = (k * 16 + l) * 128 + k2;
                    if (k2 <= 0 + this.genRandom.nextInt(6) - 1) {
                        abyte0[l2] = (byte)Block.bedrock.blockID;
                    }
                    else {
                        final byte byte3 = abyte0[l2];
                        if (byte3 == 0) {
                            j2 = -1;
                        }
                        else if (byte3 == Block.stone.blockID) {
                            if (j2 == -1) {
                                if (i2 <= 0) {
                                    byte1 = 0;
                                    byte2 = (byte)Block.stone.blockID;
                                }
                                else if (k2 >= seaLevel - 4 && k2 <= seaLevel + 1) {
                                    if (flag2) {
                                        byte1 = 0;
                                    }
                                    if (flag2) {
                                        byte2 = (byte)Block.gravel.blockID;
                                    }
                                    if (flag) {
                                        byte1 = (byte)Block.sand.blockID;
                                    }
                                    if (flag) {
                                        byte2 = (byte)Block.sand.blockID;
                                    }
                                }
                                if (k2 < seaLevel && byte1 == 0) {
                                    byte1 = (byte)Block.waterStill.blockID;
                                }
                                j2 = i2;
                                if (k2 >= seaLevel - 1) {
                                    abyte0[l2] = byte1;
                                }
                                else {
                                    abyte0[l2] = byte2;
                                }
                            }
                            else if (j2 > 0) {
                                --j2;
                                abyte0[l2] = byte2;
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    protected double[] initializeNoiseField(final double[] ad, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        return ad;
    }
    
    @Override
    public boolean chunkExists(final int i, final int j) {
        return true;
    }
    
    @Override
    public void generateStructures(final IChunkProvider ichunkprovider, final int i, final int j) {
        BlockSand.fallInstantly = true;
        final int k = i * 16;
        final int l = j * 16;
        this.genRandom.setSeed(this.worldObj.randomSeed);
        final long l2 = this.genRandom.nextLong() / 2L * 2L + 1L;
        final long l3 = this.genRandom.nextLong() / 2L * 2L + 1L;
        this.genRandom.setSeed(i * l2 + j * l3 ^ this.worldObj.randomSeed);
        double d = 0.25;
        for (int i2 = 0; i2 < 8; ++i2) {
            final int i3 = k + this.genRandom.nextInt(16) + 8;
            final int j2 = this.genRandom.nextInt(128);
            final int i4 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenDungeons().generate(this.worldObj, this.genRandom, i3, j2, i4);
        }
        if ((k > 1000 || k < -1000) && (l > 1000 || l < -1000) && this.genRandom.nextInt(4000) == 2) {
            for (short y = 0; y < 128; ++y) {
                final short inc = (short)(y - 128);
                for (int x = k + inc + 1; x < k - inc; ++x) {
                    for (int z = l + inc + 1; z < l - inc; ++z) {
                        if (!this.worldObj.isBlockNormalCube(x, y, z) && Math.abs(x) > 999 && Math.abs(z) > 999) {
                            this.worldObj.setBlockWithNotify(x, y, z, Block.brick.blockID);
                        }
                    }
                }
            }
        }
        for (int i2 = 0; i2 < 8; ++i2) {
            final int i3 = k + this.genRandom.nextInt(16) + 8;
            final int j2 = this.genRandom.nextInt(512);
            final int i4 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenWaterDungeons().generate(this.worldObj, this.genRandom, i3, j2, i4);
        }
        for (int j3 = 0; j3 < 10; ++j3) {
            final int j4 = k + this.genRandom.nextInt(16);
            final int k2 = this.genRandom.nextInt(64);
            final int j5 = l + this.genRandom.nextInt(16);
            new WorldGenClay(8, new int[] { Block.grass.blockID, Block.dirt.blockID }).generate(this.worldObj, this.genRandom, j4, k2, j5);
        }
        for (int k3 = 0; k3 < 20; ++k3) {
            final int k4 = k + this.genRandom.nextInt(16);
            final int l4 = this.genRandom.nextInt(128);
            final int k5 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.dirt.blockID, 32).generate(this.worldObj, this.genRandom, k4, l4, k5);
        }
        for (int i5 = 0; i5 < 10; ++i5) {
            final int l5 = k + this.genRandom.nextInt(16);
            final int i6 = this.genRandom.nextInt(128);
            final int l6 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.gravel.blockID, 32).generate(this.worldObj, this.genRandom, l5, i6, l6);
        }
        for (int j6 = 0; j6 < 20; ++j6) {
            final int i7 = k + this.genRandom.nextInt(16);
            final int j7 = this.genRandom.nextInt(128);
            final int i8 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCoal.blockID, 16).generate(this.worldObj, this.genRandom, i7, j7, i8);
        }
        for (int k6 = 0; k6 < 20; ++k6) {
            final int j8 = k + this.genRandom.nextInt(16);
            final int k7 = this.genRandom.nextInt(64);
            final int j9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreIron.blockID, 8).generate(this.worldObj, this.genRandom, j8, k7, j9);
        }
        for (int i9 = 0; i9 < 2; ++i9) {
            final int k8 = k + this.genRandom.nextInt(16);
            final int l7 = this.genRandom.nextInt(32);
            final int k9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreGold.blockID, 8).generate(this.worldObj, this.genRandom, k8, l7, k9);
        }
        for (int i9 = 0; i9 < 6; ++i9) {
            final int k8 = k + this.genRandom.nextInt(16);
            final int l7 = this.genRandom.nextInt(32);
            final int k9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCopper.blockID, 8).generate(this.worldObj, this.genRandom, k8, l7, k9);
        }
        for (int j10 = 0; j10 < 8; ++j10) {
            final int l8 = k + this.genRandom.nextInt(16);
            final int i10 = this.genRandom.nextInt(16);
            final int l9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreRed.blockID, 7).generate(this.worldObj, this.genRandom, l8, i10, l9);
        }
        for (int k10 = 0; k10 < 1; ++k10) {
            final int i11 = k + this.genRandom.nextInt(16);
            final int j11 = this.genRandom.nextInt(16);
            final int i12 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreDiamond.blockID, 7).generate(this.worldObj, this.genRandom, i11, j11, i12);
        }
        d = 0.5;
        int l10 = (int)((this.treeNoise.func_806_a(k * d, l * d) / 8.0 + this.genRandom.nextDouble() * 4.0 + 4.0) / 3.0);
        if (l10 < 0) {
            l10 = 0;
        }
        if (this.genRandom.nextInt(10) == 0) {
            ++l10;
        }
        Object obj = new WorldGenTrees();
        if (this.genRandom.nextInt(10) == 0) {
            obj = new WorldGenBigTree();
        }
        for (int k11 = 0; k11 < l10; ++k11) {
            final int j12 = k + this.genRandom.nextInt(16) + 8;
            final int l11 = l + this.genRandom.nextInt(16) + 8;
            ((WorldGenerator)obj).func_517_a(1.0, 1.0, 1.0);
            ((WorldGenerator)obj).generate(this.worldObj, this.genRandom, j12, this.worldObj.getHeightValue(j12, l11), l11);
        }
        for (int l12 = 0; l12 < 2; ++l12) {
            final int k12 = k + this.genRandom.nextInt(16) + 8;
            final int i13 = this.genRandom.nextInt(128);
            final int j13 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantYellow.blockID).generate(this.worldObj, this.genRandom, k12, i13, j13);
        }
        if (this.genRandom.nextInt(2) == 0) {
            final int i14 = k + this.genRandom.nextInt(16) + 8;
            final int l13 = this.genRandom.nextInt(128);
            final int j14 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantRed.blockID).generate(this.worldObj, this.genRandom, i14, l13, j14);
        }
        if (this.genRandom.nextInt(1) == 0) {
            final int i14 = k + this.genRandom.nextInt(16) + 8;
            final int l13 = this.genRandom.nextInt(128);
            final int j14 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantBlue.blockID).generate(this.worldObj, this.genRandom, i14, l13, j14);
        }
        if (this.genRandom.nextInt(4) == 0) {
            final int j15 = k + this.genRandom.nextInt(16) + 8;
            final int i15 = this.genRandom.nextInt(128);
            final int k13 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomBrown.blockID).generate(this.worldObj, this.genRandom, j15, i15, k13);
        }
        if (this.genRandom.nextInt(8) == 0) {
            final int k14 = k + this.genRandom.nextInt(16) + 8;
            final int j16 = this.genRandom.nextInt(128);
            final int l14 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomRed.blockID).generate(this.worldObj, this.genRandom, k14, j16, l14);
        }
        for (int l15 = 0; l15 < 10; ++l15) {
            final int k15 = k + this.genRandom.nextInt(16) + 8;
            final int i16 = this.genRandom.nextInt(128);
            final int k16 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenReed().generate(this.worldObj, this.genRandom, k15, i16, k16);
        }
        for (int i17 = 0; i17 < 10; ++i17) {
            final int l16 = k + this.genRandom.nextInt(16) + 8;
            final int j17 = this.genRandom.nextInt(128);
            final int l17 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenCactus().generate(this.worldObj, this.genRandom, l16, j17, l17);
        }
        for (int j18 = 0; j18 < 50; ++j18) {
            final int i18 = k + this.genRandom.nextInt(16) + 8;
            final int k17 = this.genRandom.nextInt(this.genRandom.nextInt(120) + 8);
            final int i19 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.waterMoving.blockID).generate(this.worldObj, this.genRandom, i18, k17, i19);
        }
        for (int k18 = 0; k18 < 20; ++k18) {
            final int j19 = k + this.genRandom.nextInt(16) + 8;
            final int l18 = this.genRandom.nextInt(this.genRandom.nextInt(this.genRandom.nextInt(112) + 8) + 8);
            final int j20 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.lavaMoving.blockID).generate(this.worldObj, this.genRandom, j19, l18, j20);
        }
        for (int l19 = k + 8 + 0; l19 < k + 8 + 16; ++l19) {
            for (int k19 = l + 8 + 0; k19 < l + 8 + 16; ++k19) {
                final int i20 = this.worldObj.getTopSolidOrLiquidBlock(l19, k19);
                if (this.worldObj.snowCovered && i20 > 0 && i20 < 128 && this.worldObj.getBlockId(l19, i20, k19) == 0 && this.worldObj.getMaterialXYZ(l19, i20 - 1, k19).blocksMovement() && this.worldObj.getMaterialXYZ(l19, i20 - 1, k19) != Material.ice) {
                    this.worldObj.setBlockWithNotify(l19, i20, k19, Block.snow.blockID);
                }
            }
        }
        BlockSand.fallInstantly = false;
    }
}
