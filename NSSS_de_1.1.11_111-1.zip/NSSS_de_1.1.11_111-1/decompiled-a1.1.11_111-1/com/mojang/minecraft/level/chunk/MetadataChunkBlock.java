package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.tile.*;

public class MetadataChunkBlock
{
    public final EnumSkyBlock field_1299_a;
    public int field_1298_b;
    public int field_1304_c;
    public int field_1303_d;
    public int field_1302_e;
    public int field_1301_f;
    public int field_1300_g;
    
    public MetadataChunkBlock(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        this.field_1299_a = enumskyblock;
        this.field_1298_b = i;
        this.field_1304_c = j;
        this.field_1303_d = k;
        this.field_1302_e = l;
        this.field_1301_f = i1;
        this.field_1300_g = j1;
    }
    
    public void func_865_a(final World world) {
        final int i = this.field_1302_e - this.field_1298_b;
        final int j = this.field_1301_f - this.field_1304_c;
        final int k = this.field_1300_g - this.field_1303_d;
        final int l = i * j * k;
        if (l > 32768) {
            return;
        }
        for (int i2 = this.field_1298_b; i2 <= this.field_1302_e; ++i2) {
            for (int j2 = this.field_1303_d; j2 <= this.field_1300_g; ++j2) {
                if (world.blockExists(i2, 0, j2)) {
                    for (int k2 = this.field_1304_c; k2 <= this.field_1301_f; ++k2) {
                        if (k2 >= 0) {
                            if (k2 < 128) {
                                final int l2 = world.getBlockLighting(this.field_1299_a, i2, k2, j2);
                                int i3 = 0;
                                final int j3 = world.getBlockId(i2, k2, j2);
                                int k3 = Block.lightOpacity[j3];
                                if (k3 == 0) {
                                    k3 = 1;
                                }
                                int l3 = 0;
                                if (this.field_1299_a == EnumSkyBlock.Sky) {
                                    if (world.func_708_k(i2, k2, j2)) {
                                        l3 = 15;
                                    }
                                }
                                else if (this.field_1299_a == EnumSkyBlock.Block) {
                                    l3 = Block.lightValue[j3];
                                }
                                if (k3 >= 15 && l3 == 0) {
                                    i3 = 0;
                                }
                                else {
                                    final int i4 = world.getBlockLighting(this.field_1299_a, i2 - 1, k2, j2);
                                    final int k4 = world.getBlockLighting(this.field_1299_a, i2 + 1, k2, j2);
                                    final int l4 = world.getBlockLighting(this.field_1299_a, i2, k2 - 1, j2);
                                    final int i5 = world.getBlockLighting(this.field_1299_a, i2, k2 + 1, j2);
                                    final int j4 = world.getBlockLighting(this.field_1299_a, i2, k2, j2 - 1);
                                    final int k5 = world.getBlockLighting(this.field_1299_a, i2, k2, j2 + 1);
                                    i3 = i4;
                                    if (k4 > i3) {
                                        i3 = k4;
                                    }
                                    if (l4 > i3) {
                                        i3 = l4;
                                    }
                                    if (i5 > i3) {
                                        i3 = i5;
                                    }
                                    if (j4 > i3) {
                                        i3 = j4;
                                    }
                                    if (k5 > i3) {
                                        i3 = k5;
                                    }
                                    i3 -= k3;
                                    if (i3 < 0) {
                                        i3 = 0;
                                    }
                                    if (l3 > i3) {
                                        i3 = l3;
                                    }
                                }
                                if (l2 != i3) {
                                    world.func_664_b(this.field_1299_a, i2, k2, j2, i3);
                                    int j5 = i3 - 1;
                                    if (j5 < 0) {
                                        j5 = 0;
                                    }
                                    world.func_631_a(this.field_1299_a, i2 - 1, k2, j2, j5);
                                    world.func_631_a(this.field_1299_a, i2, k2 - 1, j2, j5);
                                    world.func_631_a(this.field_1299_a, i2, k2, j2 - 1, j5);
                                    if (i2 + 1 >= this.field_1302_e) {
                                        world.func_631_a(this.field_1299_a, i2 + 1, k2, j2, j5);
                                    }
                                    if (k2 + 1 >= this.field_1301_f) {
                                        world.func_631_a(this.field_1299_a, i2, k2 + 1, j2, j5);
                                    }
                                    if (j2 + 1 >= this.field_1300_g) {
                                        world.func_631_a(this.field_1299_a, i2, k2, j2 + 1, j5);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public boolean func_866_a(int i, int j, int k, int l, int i1, int j1) {
        if (i >= this.field_1298_b && j >= this.field_1304_c && k >= this.field_1303_d && l <= this.field_1302_e && i1 <= this.field_1301_f && j1 <= this.field_1300_g) {
            return true;
        }
        final int k2 = 1;
        if (i >= this.field_1298_b - k2 && j >= this.field_1304_c - k2 && k >= this.field_1303_d - k2 && l <= this.field_1302_e + k2 && i1 <= this.field_1301_f + k2 && j1 <= this.field_1300_g + k2) {
            final int l2 = this.field_1302_e - this.field_1298_b;
            final int i2 = this.field_1301_f - this.field_1304_c;
            final int j2 = this.field_1300_g - this.field_1303_d;
            if (i > this.field_1298_b) {
                i = this.field_1298_b;
            }
            if (j > this.field_1304_c) {
                j = this.field_1304_c;
            }
            if (k > this.field_1303_d) {
                k = this.field_1303_d;
            }
            if (l < this.field_1302_e) {
                l = this.field_1302_e;
            }
            if (i1 < this.field_1301_f) {
                i1 = this.field_1301_f;
            }
            if (j1 < this.field_1300_g) {
                j1 = this.field_1300_g;
            }
            final int k3 = l - i;
            final int l3 = i1 - j;
            final int i3 = j1 - k;
            final int j3 = l2 * i2 * j2;
            final int k4 = k3 * l3 * i3;
            if (k4 - j3 <= 2) {
                this.field_1298_b = i;
                this.field_1304_c = j;
                this.field_1303_d = k;
                this.field_1302_e = l;
                this.field_1301_f = i1;
                this.field_1300_g = j1;
                return true;
            }
        }
        return false;
    }
}
