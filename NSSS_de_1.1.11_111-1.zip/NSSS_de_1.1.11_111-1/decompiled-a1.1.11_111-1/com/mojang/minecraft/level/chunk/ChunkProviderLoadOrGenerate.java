package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.*;
import java.io.*;
import com.mojang.minecraft.gui.*;

public class ChunkProviderLoadOrGenerate implements IChunkProvider
{
    private Chunk localChunk;
    private IChunkProvider chunkProvider;
    private IChunkLoader chunkLoader;
    private Chunk[] chunks;
    private World worldObj;
    int chunkX;
    int chunkZ;
    private Chunk workingChunk;
    private int curChunkX;
    private int curChunkY;
    
    public ChunkProviderLoadOrGenerate(final World world, final IChunkLoader ichunkloader, final IChunkProvider ichunkprovider) {
        this.chunks = new Chunk[1024];
        this.chunkX = -999999999;
        this.chunkZ = -999999999;
        this.localChunk = new Chunk(world, new byte[32768], 0, 0);
        this.localChunk.hasEntities2 = true;
        this.localChunk.neverSave = true;
        this.worldObj = world;
        this.chunkLoader = ichunkloader;
        this.chunkProvider = ichunkprovider;
    }
    
    public void setCurrentChunkOver(final int x, final int z) {
        this.curChunkX = x;
        this.curChunkY = z;
    }
    
    public boolean canChunkExist(final int x, final int z) {
        final byte byte0 = 15;
        return x >= this.curChunkX - byte0 && z >= this.curChunkY - byte0 && x <= this.curChunkX + byte0 && z <= this.curChunkY + byte0;
    }
    
    public boolean chunkExists(final int x, final int z) {
        if (x == this.chunkX && z == this.chunkZ && this.workingChunk != null) {
            return true;
        }
        final int k = x & 0x1F;
        final int l = z & 0x1F;
        final int i1 = k + l * 32;
        return this.chunks[i1] != null && (this.chunks[i1] == this.localChunk || this.chunks[i1].isAtLocation(x, z));
    }
    
    public Chunk provideChunk(final int x, final int j) {
        if (x == this.chunkX && j == this.chunkZ && this.workingChunk != null) {
            return this.workingChunk;
        }
        if (!this.worldObj.findingSpawnPoint && !this.canChunkExist(x, j)) {
            return this.localChunk;
        }
        final int k = x & 0x1F;
        final int l = j & 0x1F;
        final int i1 = k + l * 32;
        if (!this.chunkExists(x, j)) {
            if (this.chunks[i1] != null) {
                this.chunks[i1].onChunkUnload();
                this.saveLoadedChunk(this.chunks[i1]);
                this.saveLoadedChunkData(this.chunks[i1]);
            }
            Chunk chunk = this.provideLoadedChunk(x, j);
            if (chunk == null) {
                if (this.chunkProvider == null) {
                    chunk = this.localChunk;
                }
                else {
                    chunk = this.chunkProvider.provideChunk(x, j);
                }
            }
            this.chunks[i1] = chunk;
            if (this.chunks[i1] != null) {
                this.chunks[i1].onChunkLoad();
            }
            if (!this.chunks[i1].isTerrainPopulated && this.chunkExists(x + 1, j + 1) && this.chunkExists(x, j + 1) && this.chunkExists(x + 1, j)) {
                this.generateStructures(this, x, j);
            }
            if (this.chunkExists(x - 1, j) && !this.provideChunk(x - 1, j).isTerrainPopulated && this.chunkExists(x - 1, j + 1) && this.chunkExists(x, j + 1) && this.chunkExists(x - 1, j)) {
                this.generateStructures(this, x - 1, j);
            }
            if (this.chunkExists(x, j - 1) && !this.provideChunk(x, j - 1).isTerrainPopulated && this.chunkExists(x + 1, j - 1) && this.chunkExists(x, j - 1) && this.chunkExists(x + 1, j)) {
                this.generateStructures(this, x, j - 1);
            }
            if (this.chunkExists(x - 1, j - 1) && !this.provideChunk(x - 1, j - 1).isTerrainPopulated && this.chunkExists(x - 1, j - 1) && this.chunkExists(x, j - 1) && this.chunkExists(x - 1, j)) {
                this.generateStructures(this, x - 1, j - 1);
            }
        }
        this.chunkX = x;
        this.chunkZ = j;
        this.workingChunk = this.chunks[i1];
        return this.chunks[i1];
    }
    
    private Chunk provideLoadedChunk(final int i, final int j) {
        if (this.chunkLoader == null) {
            return null;
        }
        try {
            final Chunk chunk = this.chunkLoader.loadChunkFromFile(this.worldObj, i, j);
            if (chunk != null) {
                chunk.lastSaveTime = this.worldObj.worldTime;
            }
            return chunk;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }
    
    private void saveLoadedChunkData(final Chunk chunk) {
        if (this.chunkLoader == null) {
            return;
        }
        try {
            this.chunkLoader.saveExtraChunkData(this.worldObj, chunk);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    private void saveLoadedChunk(final Chunk chunk) {
        if (this.chunkLoader == null) {
            return;
        }
        try {
            chunk.lastSaveTime = this.worldObj.worldTime;
            this.chunkLoader.saveChunk(this.worldObj, chunk);
        }
        catch (IOException ioexception) {
            ioexception.printStackTrace();
        }
    }
    
    public void generateStructures(final IChunkProvider ichunkprovider, final int i, final int j) {
        final Chunk chunk = this.provideChunk(i, j);
        if (!chunk.isTerrainPopulated) {
            chunk.isTerrainPopulated = true;
            if (this.chunkProvider != null) {
                this.chunkProvider.generateStructures(ichunkprovider, i, j);
                chunk.setChunkModified();
            }
        }
    }
    
    public boolean saveChunks(final boolean flag, final IProgressUpdate iprogressupdate) {
        int i = 0;
        int j = 0;
        if (iprogressupdate != null) {
            for (int k = 0; k < this.chunks.length; ++k) {
                if (this.chunks[k] != null && this.chunks[k].needsSaving(flag)) {
                    ++j;
                }
            }
        }
        int l = 0;
        for (int i2 = 0; i2 < this.chunks.length; ++i2) {
            if (this.chunks[i2] != null) {
                if (flag && !this.chunks[i2].neverSave) {
                    this.saveLoadedChunkData(this.chunks[i2]);
                }
                if (this.chunks[i2].needsSaving(flag)) {
                    this.saveLoadedChunk(this.chunks[i2]);
                    this.chunks[i2].isModified = false;
                    if (++i == 2 && !flag) {
                        return false;
                    }
                    if (iprogressupdate != null && ++l % 10 == 0) {
                        iprogressupdate.setProgess(l * 100 / j);
                    }
                }
            }
        }
        if (flag) {
            if (this.chunkLoader == null) {
                return true;
            }
            this.chunkLoader.saveExtraData();
        }
        return true;
    }
    
    public boolean unload100OldestChunks() {
        if (this.chunkLoader != null) {
            this.chunkLoader.func_814_a();
        }
        return this.chunkProvider.unload100OldestChunks();
    }
    
    public boolean canSave() {
        return true;
    }
}
