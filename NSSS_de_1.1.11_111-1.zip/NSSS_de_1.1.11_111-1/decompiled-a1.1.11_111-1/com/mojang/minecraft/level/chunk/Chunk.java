package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.generate.noise.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.enums.*;
import com.mojang.minecraft.level.*;
import com.mojang.minecraft.util.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.phys.*;
import java.util.*;

public class Chunk
{
    public static boolean isLit;
    public byte[] blocks;
    public boolean isChunkLoaded;
    public World worldObj;
    public NibbleArray data;
    public NibbleArray skylightMap;
    public NibbleArray blocklightMap;
    public byte[] heightMap;
    public int field_1532_i;
    public final int xPosition;
    public final int zPosition;
    public Map<ChunkPosition, TileEntity> chunkTileEntityMap;
    public List<Entity>[] entities;
    public boolean isTerrainPopulated;
    public boolean isModified;
    public boolean neverSave;
    public boolean hasEntities2;
    public boolean hasEntities;
    public long lastSaveTime;
    
    public Chunk(final World world, final int i, final int j) {
        this.chunkTileEntityMap = new HashMap<ChunkPosition, TileEntity>();
        this.entities = (List<Entity>[])new List[8];
        this.isTerrainPopulated = false;
        this.isModified = false;
        this.hasEntities2 = false;
        this.hasEntities = false;
        this.lastSaveTime = 0L;
        this.worldObj = world;
        this.xPosition = i;
        this.zPosition = j;
        this.heightMap = new byte[256];
        for (int k = 0; k < this.entities.length; ++k) {
            this.entities[k] = new ArrayList<Entity>();
        }
    }
    
    public Chunk(final World world, final byte[] abyte0, final int i, final int j) {
        this(world, i, j);
        this.blocks = abyte0;
        this.data = new NibbleArray(abyte0.length);
        this.skylightMap = new NibbleArray(abyte0.length);
        this.blocklightMap = new NibbleArray(abyte0.length);
    }
    
    public boolean isAtLocation(final int i, final int j) {
        return i == this.xPosition && j == this.zPosition;
    }
    
    public int getHeightValue(final int i, final int j) {
        return this.heightMap[j << 4 | i] & 0xFF;
    }
    
    public void func_1014_a() {
    }
    
    public void func_1018_b() {
        int i = 127;
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                int l = 127;
                for (int i2 = j << 11 | k << 7; l > 0 && Block.lightOpacity[this.blocks[i2 + l - 1]] == 0; --l) {}
                this.heightMap[k << 4 | j] = (byte)l;
                if (l < i) {
                    i = l;
                }
            }
        }
        this.field_1532_i = i;
        this.isModified = true;
    }
    
    public void func_1024_c() {
        int i = 127;
        for (int j = 0; j < 16; ++j) {
            for (int l = 0; l < 16; ++l) {
                this.heightMap[l << 4 | j] = -128;
                this.func_1003_g(j, 127, l);
                if ((this.heightMap[l << 4 | j] & 0xFF) < i) {
                    i = (this.heightMap[l << 4 | j] & 0xFF);
                }
            }
        }
        this.field_1532_i = i;
        for (int k = 0; k < 16; ++k) {
            for (int i2 = 0; i2 < 16; ++i2) {
                this.func_996_c(k, i2);
            }
        }
        this.isModified = true;
    }
    
    private void func_996_c(final int i, final int j) {
        final int k = this.getHeightValue(i, j);
        final int l = this.xPosition * 16 + i;
        final int i2 = this.zPosition * 16 + j;
        this.func_1020_f(l - 1, i2, k);
        this.func_1020_f(l + 1, i2, k);
        this.func_1020_f(l, i2 - 1, k);
        this.func_1020_f(l, i2 + 1, k);
    }
    
    private void func_1020_f(final int i, final int j, final int k) {
        final int l = this.worldObj.getHeightValue(i, j);
        if (l > k) {
            this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, i, k, j, i, l, j);
        }
        else if (l < k) {
            this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, i, l, j, i, k, j);
        }
        this.isModified = true;
    }
    
    private void func_1003_g(final int i, final int j, final int k) {
        int i2;
        final int l = i2 = (this.heightMap[k << 4 | i] & 0xFF);
        if (j > l) {
            i2 = j;
        }
        for (int j2 = i << 11 | k << 7; i2 > 0 && Block.lightOpacity[this.blocks[j2 + i2 - 1]] == 0; --i2) {}
        if (i2 == l) {
            return;
        }
        this.worldObj.markBlocksDirtyVertical(i, k, i2, l);
        this.heightMap[k << 4 | i] = (byte)i2;
        if (i2 < this.field_1532_i) {
            this.field_1532_i = i2;
        }
        else {
            int k2 = 127;
            for (int i3 = 0; i3 < 16; ++i3) {
                for (int k3 = 0; k3 < 16; ++k3) {
                    if ((this.heightMap[k3 << 4 | i3] & 0xFF) < k2) {
                        k2 = (this.heightMap[k3 << 4 | i3] & 0xFF);
                    }
                }
            }
            this.field_1532_i = k2;
        }
        final int l2 = this.xPosition * 16 + i;
        final int j3 = this.zPosition * 16 + k;
        if (i2 < l) {
            for (int l3 = i2; l3 < l; ++l3) {
                this.skylightMap.setNibble(i, l3, k, 15);
            }
        }
        else {
            this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, l2, l, j3, l2, i2, j3);
            for (int i4 = l; i4 < i2; ++i4) {
                this.skylightMap.setNibble(i, i4, k, 0);
            }
        }
        int j4 = 15;
        final int k4 = i2;
        while (i2 > 0) {
            if (j4 <= 0) {
                break;
            }
            --i2;
            int l4 = Block.lightOpacity[this.getBlockId(i, i2, k)];
            if (l4 == 0) {
                l4 = 1;
            }
            j4 -= l4;
            if (j4 < 0) {
                j4 = 0;
            }
            this.skylightMap.setNibble(i, i2, k, j4);
        }
        while (i2 > 0 && Block.lightOpacity[this.getBlockId(i, i2 - 1, k)] == 0) {
            --i2;
        }
        if (i2 != k4) {
            this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, l2 - 1, i2, j3 - 1, l2 + 1, k4, j3 + 1);
        }
        this.isModified = true;
    }
    
    public int getBlockId(final int i, final int j, final int k) {
        return this.blocks[i << 11 | k << 7 | j];
    }
    
    public boolean setBlockIDWithMetadata(final int i, final int j, final int k, final int l, final int i1) {
        final byte byte0 = (byte)l;
        final int j2 = this.heightMap[k << 4 | i] & 0xFF;
        final int k2 = this.blocks[i << 11 | k << 7 | j] & 0xFF;
        if (k2 == l && this.data.getNibble(i, j, k) == i1) {
            return false;
        }
        final int l2 = this.xPosition * 16 + i;
        final int i2 = this.zPosition * 16 + k;
        this.blocks[i << 11 | k << 7 | j] = byte0;
        if (k2 != 0 && !this.worldObj.multiplayerWorld && !(this.worldObj instanceof WorldClient)) {
            Block.allBlocks[k2].onBlockRemoval(this.worldObj, l2, j, i2);
        }
        this.data.setNibble(i, j, k, i1);
        if (Block.lightOpacity[byte0] != 0) {
            if (j >= j2) {
                this.func_1003_g(i, j + 1, k);
            }
        }
        else if (j == j2 - 1) {
            this.func_1003_g(i, j, k);
        }
        this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, l2, j, i2, l2, j, i2);
        this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Block, l2, j, i2, l2, j, i2);
        this.func_996_c(i, k);
        if (l != 0) {
            Block.allBlocks[l].onBlockAdded(this.worldObj, l2, j, i2);
        }
        return this.isModified = true;
    }
    
    public boolean setBlockID(final int i, final int j, final int k, final int l) {
        final byte byte0 = (byte)l;
        final int i2 = this.heightMap[k << 4 | i] & 0xFF;
        final int j2 = this.blocks[i << 11 | k << 7 | j] & 0xFF;
        if (j2 == l) {
            return false;
        }
        final int k2 = this.xPosition * 16 + i;
        final int l2 = this.zPosition * 16 + k;
        this.blocks[i << 11 | k << 7 | j] = byte0;
        if (j2 != 0 && !(this.worldObj instanceof WorldClient)) {
            Block.allBlocks[j2].onBlockRemoval(this.worldObj, k2, j, l2);
        }
        this.data.setNibble(i, j, k, 0);
        if (Block.lightOpacity[byte0] != 0) {
            if (j >= i2) {
                this.func_1003_g(i, j + 1, k);
            }
        }
        else if (j == i2 - 1) {
            this.func_1003_g(i, j, k);
        }
        this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Sky, k2, j, l2, k2, j, l2);
        this.worldObj.scheduleLightingUpdate(EnumSkyBlock.Block, k2, j, l2, k2, j, l2);
        this.func_996_c(i, k);
        if (l != 0 && !this.worldObj.multiplayerWorld) {
            Block.allBlocks[l].onBlockAdded(this.worldObj, k2, j, l2);
        }
        return this.isModified = true;
    }
    
    public int getBlockMetadata(final int i, final int j, final int k) {
        return this.data.getNibble(i, j, k);
    }
    
    public void setBlockMetadata(final int i, final int j, final int k, final int l) {
        this.isModified = true;
        this.data.setNibble(i, j, k, l);
    }
    
    public int getSavedLightValue(final EnumSkyBlock enumskyblock, final int i, final int j, final int k) {
        if (enumskyblock == EnumSkyBlock.Sky) {
            return this.skylightMap.getNibble(i, j, k);
        }
        if (enumskyblock == EnumSkyBlock.Block) {
            return this.blocklightMap.getNibble(i, j, k);
        }
        return 0;
    }
    
    public void setLightValue(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l) {
        this.isModified = true;
        if (enumskyblock == EnumSkyBlock.Sky) {
            this.skylightMap.setNibble(i, j, k, l);
        }
        else {
            if (enumskyblock != EnumSkyBlock.Block) {
                return;
            }
            this.blocklightMap.setNibble(i, j, k, l);
        }
    }
    
    public int getBlockLightValue(final int i, final int j, final int k, final int l) {
        int i2 = this.skylightMap.getNibble(i, j, k);
        if (i2 > 0) {
            Chunk.isLit = true;
        }
        i2 -= l;
        final int j2 = this.blocklightMap.getNibble(i, j, k);
        if (j2 > i2) {
            i2 = j2;
        }
        return i2;
    }
    
    public void addEntity(final Entity entity) {
        if (this.hasEntities2) {
            return;
        }
        this.hasEntities = true;
        final int i = MathHelper.floor_double(entity.posX / 16.0);
        final int j = MathHelper.floor_double(entity.posZ / 16.0);
        if (i != this.xPosition || j != this.zPosition) {
            System.out.println("Wrong location! " + entity);
        }
        int k = MathHelper.floor_double(entity.posY / 16.0);
        if (k < 0) {
            k = 0;
        }
        if (k >= this.entities.length) {
            k = this.entities.length - 1;
        }
        entity.addedToChunk = true;
        entity.chunkCoordX = this.xPosition;
        entity.chunkCoordY = k;
        entity.chunkCoordZ = this.zPosition;
        this.entities[k].add(entity);
    }
    
    public void removeEntity(final Entity entity) {
        this.removeEntityAtIndex(entity, entity.chunkCoordY);
    }
    
    public void removeEntityAtIndex(final Entity entity, int i) {
        if (i < 0) {
            i = 0;
        }
        if (i >= this.entities.length) {
            i = this.entities.length - 1;
        }
        this.entities[i].remove(entity);
    }
    
    public boolean canBlockSeeTheSky(final int i, final int j, final int k) {
        return j >= (this.heightMap[k << 4 | i] & 0xFF);
    }
    
    public TileEntity getChunkBlockTileEntity(final int i, final int j, final int k) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        TileEntity tileentity = this.chunkTileEntityMap.get(chunkposition);
        if (tileentity == null) {
            final int l = this.getBlockId(i, j, k);
            if (!Block.isBlockContainer[l]) {
                return null;
            }
            final BlockContainer blockcontainer = (BlockContainer)Block.allBlocks[l];
            blockcontainer.onBlockAdded(this.worldObj, this.xPosition * 16 + i, j, this.zPosition * 16 + k);
            tileentity = this.chunkTileEntityMap.get(chunkposition);
        }
        return tileentity;
    }
    
    public void addTileEntity(final TileEntity tileentity) {
        final int i = tileentity.x - this.xPosition * 16;
        final int j = tileentity.y;
        final int k = tileentity.z - this.zPosition * 16;
        this.setChunkBlockTileEntity(i, j, k, tileentity);
    }
    
    public void setChunkBlockTileEntity(final int i, final int j, final int k, final TileEntity tileentity) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        tileentity.world = this.worldObj;
        tileentity.x = this.xPosition * 16 + i;
        tileentity.y = j;
        tileentity.z = this.zPosition * 16 + k;
        if (this.getBlockId(i, j, k) == 0 || !(Block.allBlocks[this.getBlockId(i, j, k)] instanceof BlockContainer)) {
            System.out.println("Attempted to place a tile entity where there was no entity tile!");
            return;
        }
        if (this.isChunkLoaded) {
            if (this.chunkTileEntityMap.get(chunkposition) != null) {
                this.worldObj.field_1049_b.remove(this.chunkTileEntityMap.get(chunkposition));
            }
            this.worldObj.field_1049_b.add(tileentity);
        }
        this.chunkTileEntityMap.put(chunkposition, tileentity);
    }
    
    public void removeChunkBlockTileEntity(final int i, final int j, final int k) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        if (this.isChunkLoaded) {
            this.worldObj.field_1049_b.remove(this.chunkTileEntityMap.remove(chunkposition));
        }
    }
    
    public void onChunkLoad() {
        this.isChunkLoaded = true;
        this.worldObj.field_1049_b.addAll(this.chunkTileEntityMap.values());
        for (int i = 0; i < this.entities.length; ++i) {
            this.worldObj.addLoadedEntities(this.entities[i]);
        }
    }
    
    public void onChunkUnload() {
        this.isChunkLoaded = false;
        this.worldObj.field_1049_b.removeAll(this.chunkTileEntityMap.values());
        for (int i = 0; i < this.entities.length; ++i) {
            this.worldObj.addUnloadedEntities(this.entities[i]);
        }
    }
    
    public void setChunkModified() {
        this.isModified = true;
    }
    
    public void getEntitiesWithinAABBForEntity(final Entity entity, final AxisAlignedBB axisalignedbb, final List<Entity> list) {
        int i = MathHelper.floor_double((axisalignedbb.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((axisalignedbb.maxY + 2.0) / 16.0);
        if (i < 0) {
            i = 0;
        }
        if (j >= this.entities.length) {
            j = this.entities.length - 1;
        }
        for (int k = i; k <= j; ++k) {
            final List<?> list2 = this.entities[k];
            for (int l = 0; l < list2.size(); ++l) {
                final Entity entity2 = (Entity)list2.get(l);
                if (entity2 != entity && entity2.boundingBox.intersectsWith(axisalignedbb)) {
                    list.add(entity2);
                }
            }
        }
    }
    
    public void getEntitiesOfTypeWithinAAAB(final Class<?> class1, final AxisAlignedBB axisalignedbb, final List<Entity> list) {
        int i = MathHelper.floor_double((axisalignedbb.minY - 2.0) / 16.0);
        int j = MathHelper.floor_double((axisalignedbb.maxY + 2.0) / 16.0);
        if (i < 0) {
            i = 0;
        }
        if (j >= this.entities.length) {
            j = this.entities.length - 1;
        }
        for (int k = i; k <= j; ++k) {
            final List<?> list2 = this.entities[k];
            for (int l = 0; l < list2.size(); ++l) {
                final Entity entity = (Entity)list2.get(l);
                if (class1.isAssignableFrom(entity.getClass()) && entity.boundingBox.intersectsWith(axisalignedbb)) {
                    list.add(entity);
                }
            }
        }
    }
    
    public boolean needsSaving(final boolean flag) {
        return !this.neverSave && ((this.hasEntities && this.worldObj.worldTime != this.lastSaveTime) || this.isModified);
    }
    
    public int getChunkData(final byte[] abyte0, final int i, final int j, final int k, final int l, final int i1, final int j1, int k1) {
        for (int l2 = i; l2 < l; ++l2) {
            for (int l3 = k; l3 < j1; ++l3) {
                final int l4 = l2 << 11 | l3 << 7 | j;
                final int l5 = i1 - j;
                System.arraycopy(abyte0, k1, this.blocks, l4, l5);
                k1 += l5;
            }
        }
        this.func_1018_b();
        for (int i2 = i; i2 < l; ++i2) {
            for (int i3 = k; i3 < j1; ++i3) {
                final int i4 = (i2 << 11 | i3 << 7 | j) >> 1;
                final int i5 = (i1 - j) / 2;
                System.arraycopy(abyte0, k1, this.data.data, i4, i5);
                k1 += i5;
            }
        }
        for (int j2 = i; j2 < l; ++j2) {
            for (int j3 = k; j3 < j1; ++j3) {
                final int j4 = (j2 << 11 | j3 << 7 | j) >> 1;
                final int j5 = (i1 - j) / 2;
                System.arraycopy(abyte0, k1, this.blocklightMap.data, j4, j5);
                k1 += j5;
            }
        }
        for (int k2 = i; k2 < l; ++k2) {
            for (int k3 = k; k3 < j1; ++k3) {
                final int k4 = (k2 << 11 | k3 << 7 | j) >> 1;
                final int k5 = (i1 - j) / 2;
                System.arraycopy(abyte0, k1, this.skylightMap.data, k4, k5);
                k1 += k5;
            }
        }
        return k1;
    }
    
    public Random func_997_a(final long l) {
        return new Random(this.worldObj.randomSeed + this.xPosition * this.xPosition * 4987142 + this.xPosition * 5947611 + this.zPosition * this.zPosition * 4392871L + this.zPosition * 389711 ^ l);
    }
    
    public byte[] m() {
        return null;
    }
}
