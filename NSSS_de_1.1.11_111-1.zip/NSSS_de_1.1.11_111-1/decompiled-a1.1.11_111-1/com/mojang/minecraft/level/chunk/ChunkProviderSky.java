package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.level.generate.noise.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.tile.material.*;

public class ChunkProviderSky extends ChunkProviderGenerate
{
    public ChunkProviderSky(final World par1World, final long par2) {
        super(par1World, par2);
        this.mapGenBase = new MapGenCaves();
        this.worldObj = par1World;
        this.genRandom = new Random(par2);
        this.noiseGen1 = new NoiseGeneratorOctaves(this.genRandom, 16);
        this.noiseGen2 = new NoiseGeneratorOctaves(this.genRandom, 16);
        this.noiseGen3 = new NoiseGeneratorOctaves(this.genRandom, 8);
        this.beachNoise = new NoiseGeneratorOctaves(this.genRandom, 10);
        this.soilNoise = new NoiseGeneratorOctaves(this.genRandom, 16);
        par1World.cloudHeight = 0.0f;
    }
    
    @Override
    public void generateTerrain(final int par1, final int par2, final byte[] par3ArrayOfByte) {
        final byte var5 = 2;
        final int var6 = var5 + 1;
        final byte var7 = 33;
        final int var8 = var5 + 1;
        this.densities = this.initializeNoiseField(this.densities, par1 * var5, 0, par2 * var5, var6, var7, var8);
        for (int var9 = 0; var9 < var5; ++var9) {
            for (int var10 = 0; var10 < var5; ++var10) {
                for (int var11 = 0; var11 < 32; ++var11) {
                    final double var12 = 0.25;
                    double var13 = this.densities[((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 0];
                    double var14 = this.densities[((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 0];
                    double var15 = this.densities[((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 0];
                    double var16 = this.densities[((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 0];
                    final double var17 = (this.densities[((var9 + 0) * var8 + var10 + 0) * var7 + var11 + 1] - var13) * var12;
                    final double var18 = (this.densities[((var9 + 0) * var8 + var10 + 1) * var7 + var11 + 1] - var14) * var12;
                    final double var19 = (this.densities[((var9 + 1) * var8 + var10 + 0) * var7 + var11 + 1] - var15) * var12;
                    final double var20 = (this.densities[((var9 + 1) * var8 + var10 + 1) * var7 + var11 + 1] - var16) * var12;
                    for (int var21 = 0; var21 < 4; ++var21) {
                        final double var22 = 0.125;
                        double var23 = var13;
                        double var24 = var14;
                        final double var25 = (var15 - var13) * var22;
                        final double var26 = (var16 - var14) * var22;
                        for (int var27 = 0; var27 < 8; ++var27) {
                            int var28 = var27 + var9 * 8 << 11 | 0 + var10 * 8 << 7 | var11 * 4 + var21;
                            final short var29 = 128;
                            final double var30 = 0.125;
                            double var31 = var23;
                            final double var32 = (var24 - var23) * var30;
                            for (int var33 = 0; var33 < 8; ++var33) {
                                int var34 = 0;
                                if (var31 > 0.0) {
                                    var34 = Block.stone.blockID;
                                }
                                par3ArrayOfByte[var28] = (byte)var34;
                                var28 += var29;
                                var31 += var32;
                            }
                            var23 += var25;
                            var24 += var26;
                        }
                        var13 += var17;
                        var14 += var18;
                        var15 += var19;
                        var16 += var20;
                    }
                }
            }
        }
    }
    
    @Override
    public void replaceBlocksForBiome(final int par1, final int par2, final byte[] abyte0) {
        for (int var5 = 0; var5 < 16; ++var5) {
            for (int var6 = 0; var6 < 16; ++var6) {
                final byte var7 = 1;
                int var8 = -1;
                byte var9 = (byte)Block.grass.blockID;
                byte var10 = (byte)Block.dirt.blockID;
                for (int var11 = 127; var11 >= 0; --var11) {
                    final int var12 = (var6 * 16 + var5) * 128 + var11;
                    final byte var13 = abyte0[var12];
                    if (var13 == 0) {
                        var8 = -1;
                    }
                    else if (var13 == Block.stone.blockID) {
                        if (var8 == -1) {
                            if (var7 <= 0) {
                                var9 = 0;
                                var10 = (byte)Block.stone.blockID;
                            }
                            var8 = var7;
                            abyte0[var12] = var9;
                        }
                        else if (var8 > 0) {
                            --var8;
                            abyte0[var12] = var10;
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public Chunk provideChunk(final int par1, final int par2) {
        this.genRandom.setSeed(par1 * 341873128712L + par2 * 132897987541L);
        final byte[] var3 = new byte[32768];
        final Chunk var4 = new Chunk(this.worldObj, var3, par1, par2);
        this.generateTerrain(par1, par2, var3);
        this.replaceBlocksForBiome(par1, par2, var3);
        this.mapGenBase.func_867_a(this, this.worldObj, par1, par2, var3);
        var4.func_1024_c();
        return var4;
    }
    
    @Override
    protected double[] initializeNoiseField(double[] par1ArrayOfDouble, final int par2, final int par3, final int par4, final int par5, final int par6, final int par7) {
        if (par1ArrayOfDouble == null) {
            par1ArrayOfDouble = new double[par5 * par6 * par7];
        }
        final float[] adFloat = new float[par1ArrayOfDouble.length];
        for (int i2 = 0; i2 < par1ArrayOfDouble.length; ++i2) {
            adFloat[i2] = (float)par1ArrayOfDouble[i2];
        }
        double var8 = 684.412;
        final double var9 = 684.412;
        this.heightBias1 = this.beachNoise.generateNoiseOctaves(this.heightBias1, par2, par3, par4, par5, par6, par7, 1.121, 1.121, 0.5);
        this.heightBias2 = this.soilNoise.generateNoiseOctaves(this.heightBias2, par2, par3, par4, par5, par6, par7, 200.0, 200.0, 0.5);
        var8 *= 2.0;
        this.noiseData1 = this.noiseGen3.generateNoiseOctaves(this.noiseData1, par2, par3, par4, par5, par6, par7, var8 / 80.0, var9 / 160.0, var8 / 80.0);
        this.noiseData2 = this.noiseGen1.generateNoiseOctaves(this.noiseData2, par2, par3, par4, par5, par6, par7, var8, var9, var8);
        this.noiseData3 = this.noiseGen2.generateNoiseOctaves(this.noiseData3, par2, par3, par4, par5, par6, par7, var8, var9, var8);
        int k1 = 0;
        int l1 = 0;
        final int i3 = 16 / par5;
        for (int j2 = 0; j2 < par5; ++j2) {
            final int k2 = j2 * i3 + i3 / 2;
            for (int l2 = 0; l2 < par7; ++l2) {
                final int i4 = l2 * i3 + i3 / 2;
                final double d2 = k2 * 16 + i4;
                final double d3 = (k2 * 16 + i4) * d2;
                double d4 = 1.0 - d3;
                d4 *= d4;
                d4 *= d4;
                d4 = 1.0 - d4;
                double d5 = (this.heightBias1[l1] + 256.0) / 512.0;
                d5 *= d4;
                if (d5 > 1.0) {
                    d5 = 1.0;
                }
                double d6 = this.heightBias2[l1] / 8000.0;
                if (d6 < 0.0) {
                    d6 = -d6 * 0.3;
                }
                d6 = d6 * 3.0 - 2.0;
                if (d6 > 1.0) {
                    d6 = 1.0;
                }
                d6 /= 8.0;
                d6 = 0.0;
                if (d5 < 0.0) {
                    d5 = 0.0;
                }
                d5 += 0.5;
                d6 = d6 * par6 / 16.0;
                ++l1;
                final double d7 = par6 / 2.0;
                for (int j3 = 0; j3 < par6; ++j3) {
                    double d8 = 0.0;
                    double d9 = (j3 - d7) * 8.0 / d5;
                    if (d9 < 0.0) {
                        d9 *= -1.0;
                    }
                    final double d10 = this.noiseData2[k1] / 512.0;
                    final double d11 = this.noiseData3[k1] / 512.0;
                    final double d12 = (this.noiseData1[k1] / 10.0 + 1.0) / 2.0;
                    if (d12 < 0.0) {
                        d8 = d10;
                    }
                    else if (d12 > 1.0) {
                        d8 = d11;
                    }
                    else {
                        d8 = d10 + (d11 - d10) * d12;
                    }
                    d8 -= 8.0;
                    int k3 = 32;
                    if (j3 > par6 - k3) {
                        final double d13 = (j3 - (par6 - k3)) / (k3 - 1.0f);
                        d8 = d8 * (1.0 - d13) + -30.0 * d13;
                    }
                    k3 = 8;
                    if (j3 < k3) {
                        final double d14 = (k3 - j3) / (k3 - 1.0f);
                        d8 = d8 * (1.0 - d14) + -30.0 * d14;
                    }
                    par1ArrayOfDouble[k1] = d8;
                    ++k1;
                }
            }
        }
        return par1ArrayOfDouble;
    }
    
    @Override
    public void generateStructures(final IChunkProvider par1IChunkProvider, final int par2, final int par3) {
        BlockSand.fallInstantly = true;
        final int k = par2 * 16;
        final int l = par3 * 16;
        this.genRandom.setSeed(this.worldObj.randomSeed);
        final long l2 = this.genRandom.nextLong() / 2L * 2L + 1L;
        final long l3 = this.genRandom.nextLong() / 2L * 2L + 1L;
        this.genRandom.setSeed(par2 * l2 + par3 * l3 ^ this.worldObj.randomSeed);
        double d = 0.25;
        for (int i1 = 0; i1 < 8; ++i1) {
            final int i2 = k + this.genRandom.nextInt(16) + 8;
            final int j6 = this.genRandom.nextInt(128);
            final int i3 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenDungeons().generate(this.worldObj, this.genRandom, i2, j6, i3);
        }
        if ((k > 3000 || k < -3000 || l > 3000 || l < -3000) && this.genRandom.nextInt(10000) == 2) {
            final int i4 = k + this.genRandom.nextInt(16) + 8;
            final int j7 = this.genRandom.nextInt(128);
            final int i5 = l + this.genRandom.nextInt(16) + 8;
            new aaa2().generate(this.worldObj, this.genRandom, i4, j7, i5);
        }
        for (int i1 = 0; i1 < 8; ++i1) {
            final int i2 = k + this.genRandom.nextInt(16) + 8;
            final int j6 = this.genRandom.nextInt(65536);
            final int i3 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFloatingDungeons().generate(this.worldObj, this.genRandom, i2, j6, i3);
        }
        for (int j8 = 0; j8 < 10; ++j8) {
            final int j9 = k + this.genRandom.nextInt(16);
            final int k2 = this.genRandom.nextInt(64);
            final int j10 = l + this.genRandom.nextInt(16);
            new WorldGenClay(8).generate(this.worldObj, this.genRandom, j9, k2, j10);
        }
        for (int k3 = 0; k3 < 20; ++k3) {
            final int k4 = k + this.genRandom.nextInt(16);
            final int l4 = this.genRandom.nextInt(128);
            final int k5 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.dirt.blockID, 32).generate(this.worldObj, this.genRandom, k4, l4, k5);
        }
        for (int i6 = 0; i6 < 10; ++i6) {
            final int l5 = k + this.genRandom.nextInt(16);
            final int i7 = this.genRandom.nextInt(128);
            final int l6 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.sand.blockID, 32).generate(this.worldObj, this.genRandom, l5, i7, l6);
        }
        for (int i6 = 0; i6 < 10; ++i6) {
            final int l5 = k + this.genRandom.nextInt(16);
            final int i7 = this.genRandom.nextInt(128);
            final int l6 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.gravel.blockID, 32).generate(this.worldObj, this.genRandom, l5, i7, l6);
        }
        for (int j11 = 0; j11 < 20; ++j11) {
            final int i8 = k + this.genRandom.nextInt(16);
            final int j12 = this.genRandom.nextInt(128);
            final int i9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCoal.blockID, 16).generate(this.worldObj, this.genRandom, i8, j12, i9);
        }
        for (int k6 = 0; k6 < 20; ++k6) {
            final int j13 = k + this.genRandom.nextInt(16);
            final int k7 = this.genRandom.nextInt(64);
            final int j14 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreIron.blockID, 8).generate(this.worldObj, this.genRandom, j13, k7, j14);
        }
        for (int i10 = 0; i10 < 2; ++i10) {
            final int k8 = k + this.genRandom.nextInt(16);
            final int l7 = this.genRandom.nextInt(32);
            final int k9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreGold.blockID, 8).generate(this.worldObj, this.genRandom, k8, l7, k9);
        }
        for (int i10 = 0; i10 < 6; ++i10) {
            final int k8 = k + this.genRandom.nextInt(16);
            final int l7 = this.genRandom.nextInt(32);
            final int k9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreCopper.blockID, 8).generate(this.worldObj, this.genRandom, k8, l7, k9);
        }
        for (int j15 = 0; j15 < 8; ++j15) {
            final int l8 = k + this.genRandom.nextInt(16);
            final int i11 = this.genRandom.nextInt(32);
            final int l9 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreRed.blockID, 7).generate(this.worldObj, this.genRandom, l8, i11, l9);
        }
        for (int k10 = 0; k10 < 1; ++k10) {
            final int i12 = k + this.genRandom.nextInt(16);
            final int j16 = this.genRandom.nextInt(32);
            final int i13 = l + this.genRandom.nextInt(16);
            new WorldGenMinable(Block.oreDiamond.blockID, 7).generate(this.worldObj, this.genRandom, i12, j16, i13);
        }
        d = 0.5;
        int l10 = (int)((this.noiseGen3.func_806_a(k * d, l * d) / 8.0 + this.genRandom.nextDouble() * 4.0 + 4.0) / 3.0);
        if (l10 < 0) {
            l10 = 0;
        }
        if (this.genRandom.nextInt(10) == 0) {
            ++l10;
        }
        Object obj = new WorldGenTrees();
        if (this.genRandom.nextInt(10) == 0) {
            obj = new WorldGenBigTree();
        }
        for (int k11 = 0; k11 < l10; ++k11) {
            final int j17 = k + this.genRandom.nextInt(16) + 8;
            final int l11 = l + this.genRandom.nextInt(16) + 8;
            ((WorldGenerator)obj).func_517_a(1.0, 1.0, 1.0);
            ((WorldGenerator)obj).generate(this.worldObj, this.genRandom, j17, this.worldObj.getHeightValue(j17, l11), l11);
        }
        for (int l12 = 0; l12 < 2; ++l12) {
            final int k12 = k + this.genRandom.nextInt(16) + 8;
            final int i14 = this.genRandom.nextInt(128);
            final int j18 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantYellow.blockID).generate(this.worldObj, this.genRandom, k12, i14, j18);
        }
        if (this.genRandom.nextInt(2) == 0) {
            final int i15 = k + this.genRandom.nextInt(16) + 8;
            final int l13 = this.genRandom.nextInt(128);
            final int j19 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantRed.blockID).generate(this.worldObj, this.genRandom, i15, l13, j19);
        }
        if (this.genRandom.nextInt(1) == 0) {
            final int i15 = k + this.genRandom.nextInt(16) + 8;
            final int l13 = this.genRandom.nextInt(128);
            final int j19 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.plantBlue.blockID).generate(this.worldObj, this.genRandom, i15, l13, j19);
        }
        if (this.genRandom.nextInt(4) == 0) {
            final int j20 = k + this.genRandom.nextInt(16) + 8;
            final int i16 = this.genRandom.nextInt(128);
            final int k13 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomBrown.blockID).generate(this.worldObj, this.genRandom, j20, i16, k13);
        }
        if (this.genRandom.nextInt(8) == 0) {
            final int k14 = k + this.genRandom.nextInt(16) + 8;
            final int j21 = this.genRandom.nextInt(128);
            final int l14 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenFlowers(Block.mushroomRed.blockID).generate(this.worldObj, this.genRandom, k14, j21, l14);
        }
        for (int l15 = 0; l15 < 10; ++l15) {
            final int k15 = k + this.genRandom.nextInt(16) + 8;
            final int i17 = this.genRandom.nextInt(128);
            final int k16 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenReed().generate(this.worldObj, this.genRandom, k15, i17, k16);
        }
        for (int i18 = 0; i18 < 1; ++i18) {
            final int l16 = k + this.genRandom.nextInt(16) + 8;
            final int j22 = this.genRandom.nextInt(128);
            final int l17 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenCactus().generate(this.worldObj, this.genRandom, l16, j22, l17);
        }
        for (int j23 = 0; j23 < 50; ++j23) {
            final int i19 = k + this.genRandom.nextInt(16) + 8;
            final int k17 = this.genRandom.nextInt(this.genRandom.nextInt(120) + 8);
            final int i20 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.waterMoving.blockID).generate(this.worldObj, this.genRandom, i19, k17, i20);
        }
        for (int k18 = 0; k18 < 20; ++k18) {
            final int j24 = k + this.genRandom.nextInt(16) + 8;
            final int l18 = this.genRandom.nextInt(this.genRandom.nextInt(this.genRandom.nextInt(112) + 8) + 8);
            final int j25 = l + this.genRandom.nextInt(16) + 8;
            new WorldGenLiquids(Block.lavaMoving.blockID).generate(this.worldObj, this.genRandom, j24, l18, j25);
        }
        for (int l19 = k + 8 + 0; l19 < k + 8 + 16; ++l19) {
            for (int k19 = l + 8 + 0; k19 < l + 8 + 16; ++k19) {
                final int i21 = this.worldObj.getTopSolidOrLiquidBlock(l19, k19);
                if (this.worldObj.snowCovered && i21 > 0 && i21 < 128 && this.worldObj.getBlockId(l19, i21, k19) == 0 && this.worldObj.getMaterialXYZ(l19, i21 - 1, k19).blocksMovement() && this.worldObj.getMaterialXYZ(l19, i21 - 1, k19) != Material.ice) {
                    this.worldObj.setBlockWithNotify(l19, i21, k19, Block.snow.blockID);
                }
            }
        }
        BlockSand.fallInstantly = false;
    }
}
