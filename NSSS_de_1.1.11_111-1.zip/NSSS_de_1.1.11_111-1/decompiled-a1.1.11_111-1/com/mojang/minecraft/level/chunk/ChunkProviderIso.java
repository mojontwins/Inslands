package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.level.generate.*;
import java.io.*;
import com.mojang.minecraft.gui.*;

public class ChunkProviderIso implements IChunkProvider
{
    private Chunk[] field_898_b;
    private World field_901_c;
    private IChunkLoader field_900_d;
    byte[] field_899_a;
    
    public ChunkProviderIso(final World world, final IChunkLoader ichunkloader) {
        this.field_898_b = new Chunk[256];
        this.field_899_a = new byte[32768];
        this.field_901_c = world;
        this.field_900_d = ichunkloader;
    }
    
    public boolean chunkExists(final int i, final int j) {
        final int k = (i & 0xF) | (j & 0xF) * 16;
        return this.field_898_b[k] != null && this.field_898_b[k].isAtLocation(i, j);
    }
    
    public Chunk provideChunk(final int i, final int j) {
        final int k = (i & 0xF) | (j & 0xF) * 16;
        try {
            if (!this.chunkExists(i, j)) {
                Chunk chunk = this.func_543_c(i, j);
                if (chunk == null) {
                    chunk = new Chunk(this.field_901_c, this.field_899_a, i, j);
                    chunk.hasEntities2 = true;
                    chunk.neverSave = true;
                }
                this.field_898_b[k] = chunk;
            }
            return this.field_898_b[k];
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }
    
    private synchronized Chunk func_543_c(final int i, final int j) {
        try {
            return this.field_900_d.loadChunkFromFile(this.field_901_c, i, j);
        }
        catch (IOException ioexception) {
            ioexception.printStackTrace();
            return null;
        }
    }
    
    public void generateStructures(final IChunkProvider ichunkprovider, final int i, final int j) {
    }
    
    public boolean saveChunks(final boolean flag, final IProgressUpdate iprogressupdate) {
        return true;
    }
    
    public boolean unload100OldestChunks() {
        return false;
    }
    
    public boolean canSave() {
        return false;
    }
}
