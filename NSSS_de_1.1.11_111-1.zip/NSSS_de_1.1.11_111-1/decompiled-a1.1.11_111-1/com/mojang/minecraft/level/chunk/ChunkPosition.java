package com.mojang.minecraft.level.chunk;

public class ChunkPosition
{
    public final int x;
    public final int y;
    public final int z;
    
    public ChunkPosition(final int i, final int j, final int k) {
        this.x = i;
        this.y = j;
        this.z = k;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof ChunkPosition) {
            final ChunkPosition chunkposition = (ChunkPosition)obj;
            return chunkposition.x == this.x && chunkposition.y == this.y && chunkposition.z == this.z;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.x * 8976890 + this.y * 981131 + this.z;
    }
}
