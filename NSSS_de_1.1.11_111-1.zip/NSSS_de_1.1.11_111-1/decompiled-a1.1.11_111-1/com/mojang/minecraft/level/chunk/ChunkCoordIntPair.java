package com.mojang.minecraft.level.chunk;

public class ChunkCoordIntPair
{
    public int chunkX;
    public int chunkZ;
    
    public ChunkCoordIntPair(final int i, final int j) {
        this.chunkX = i;
        this.chunkZ = j;
    }
    
    @Override
    public int hashCode() {
        return this.chunkX << 8 | this.chunkZ;
    }
    
    @Override
    public boolean equals(final Object obj) {
        final ChunkCoordIntPair chunkcoordintpair = (ChunkCoordIntPair)obj;
        return chunkcoordintpair.chunkX == this.chunkX && chunkcoordintpair.chunkZ == this.chunkZ;
    }
}
