package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.generate.*;
import com.mojang.minecraft.level.*;
import java.util.*;
import com.mojang.minecraft.gui.*;

public class ChunkProviderClient implements IChunkProvider
{
    private Chunk field_887_a;
    private Map<ChunkCoordinates, Chunk> field_886_b;
    private List<?> field_889_c;
    private World field_888_d;
    
    public ChunkProviderClient(final World world) {
        this.field_886_b = new HashMap<ChunkCoordinates, Chunk>();
        this.field_889_c = new ArrayList<Object>();
        this.field_887_a = new Chunk(world, new byte[32768], 0, 0);
        this.field_887_a.hasEntities2 = true;
        this.field_887_a.neverSave = true;
        this.field_888_d = world;
    }
    
    public boolean chunkExists(final int i, final int j) {
        final ChunkCoordinates chunkcoordinates = new ChunkCoordinates(i, j);
        return this.field_886_b.containsKey(chunkcoordinates);
    }
    
    public void unloadChunk(final int i, final int j) {
        final Chunk chunk = this.provideChunk(i, j);
        if (!chunk.hasEntities2) {
            chunk.onChunkUnload();
        }
        this.field_886_b.remove(new ChunkCoordinates(i, j));
        this.field_889_c.remove(chunk);
    }
    
    public Chunk prepareChunk(final int i, final int j) {
        final ChunkCoordinates chunkcoordinates = new ChunkCoordinates(i, j);
        final byte[] abyte0 = new byte[32768];
        final Chunk chunk = new Chunk(this.field_888_d, abyte0, i, j);
        Arrays.fill(chunk.skylightMap.data, (byte)(-1));
        this.field_886_b.put(chunkcoordinates, chunk);
        chunk.isChunkLoaded = true;
        return chunk;
    }
    
    public Chunk provideChunk(final int i, final int j) {
        final ChunkCoordinates chunkcoordinates = new ChunkCoordinates(i, j);
        final Chunk chunk = this.field_886_b.get(chunkcoordinates);
        if (chunk == null) {
            return this.field_887_a;
        }
        return chunk;
    }
    
    public boolean saveChunks(final boolean flag, final IProgressUpdate iprogressupdate) {
        return true;
    }
    
    public boolean unload100OldestChunks() {
        return false;
    }
    
    public boolean canSave() {
        return false;
    }
    
    public void generateStructures(final IChunkProvider ichunkprovider, final int i, final int j) {
    }
}
