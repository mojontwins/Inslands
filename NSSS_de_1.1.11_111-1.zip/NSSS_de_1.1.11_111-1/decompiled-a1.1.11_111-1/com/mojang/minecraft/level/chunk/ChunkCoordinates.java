package com.mojang.minecraft.level.chunk;

public final class ChunkCoordinates
{
    public final int x;
    public final int z;
    public final int y;
    
    public ChunkCoordinates(final int i, final int j) {
        this.x = i;
        this.z = j;
        this.y = 0;
    }
    
    public ChunkCoordinates(final int spawnX, final int spawnY, final int spawnZ) {
        this.x = spawnX;
        this.z = spawnZ;
        this.y = spawnY;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof ChunkCoordinates) {
            final ChunkCoordinates chunkcoordinates = (ChunkCoordinates)obj;
            return this.x == chunkcoordinates.x && this.z == chunkcoordinates.z;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.x << 16 ^ this.z;
    }
}
