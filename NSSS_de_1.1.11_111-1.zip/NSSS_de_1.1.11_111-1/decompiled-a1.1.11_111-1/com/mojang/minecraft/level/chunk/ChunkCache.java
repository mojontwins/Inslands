package com.mojang.minecraft.level.chunk;

import com.mojang.minecraft.level.*;
import com.mojang.minecraft.entity.tile.*;
import com.mojang.minecraft.level.tile.*;
import com.mojang.minecraft.level.tile.material.*;

public class ChunkCache implements IBlockAccess
{
    private int field_1060_a;
    private int field_1059_b;
    private Chunk[][] field_1062_c;
    private World field_1061_d;
    
    public ChunkCache(final World world, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        this.field_1061_d = world;
        this.field_1060_a = i >> 4;
        this.field_1059_b = k >> 4;
        final int k2 = l >> 4;
        final int l2 = j1 >> 4;
        this.field_1062_c = new Chunk[k2 - this.field_1060_a + 1][l2 - this.field_1059_b + 1];
        for (int i2 = this.field_1060_a; i2 <= k2; ++i2) {
            for (int j2 = this.field_1059_b; j2 <= l2; ++j2) {
                this.field_1062_c[i2 - this.field_1060_a][j2 - this.field_1059_b] = world.getChunkFromChunkCoords(i2, j2);
            }
        }
    }
    
    public int getBlockId(final int i, final int j, final int k) {
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            return 0;
        }
        final int l = (i >> 4) - this.field_1060_a;
        final int i2 = (k >> 4) - this.field_1059_b;
        return this.field_1062_c[l][i2].getBlockId(i & 0xF, j, k & 0xF);
    }
    
    public boolean isTouchingAir(final int x, final int y, final int z) {
        return this.getBlockId(x - 1, y, z) == 0 || this.getBlockId(x + 1, y, z) == 0 || this.getBlockId(x, y - 1, z) == 0 || this.getBlockId(x, y + 1, z) == 0 || this.getBlockId(x, y, z - 1) == 0 || this.getBlockId(x, y, z + 1) == 0;
    }
    
    public TileEntity getBlockTileEntity(final int i, final int j, final int k) {
        final int l = (i >> 4) - this.field_1060_a;
        final int i2 = (k >> 4) - this.field_1059_b;
        return this.field_1062_c[l][i2].getChunkBlockTileEntity(i & 0xF, j, k & 0xF);
    }
    
    public float getBrightness(final int i, final int j, final int k) {
        return World.field_1042_i[this.func_715_d(i, j, k)];
    }
    
    public int func_715_d(final int i, final int j, final int k) {
        return this.func_716_a(i, j, k, true);
    }
    
    public int func_716_a(final int i, final int j, final int k, final boolean flag) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return 15;
        }
        if (flag) {
            final int l = this.getBlockId(i, j, k);
            if (l == Block.stairSingle.blockID || l == Block.tilledField.blockID) {
                int k2 = this.func_716_a(i, j + 1, k, false);
                final int i2 = this.func_716_a(i + 1, j, k, false);
                final int j2 = this.func_716_a(i - 1, j, k, false);
                final int k3 = this.func_716_a(i, j, k + 1, false);
                final int l2 = this.func_716_a(i, j, k - 1, false);
                if (i2 > k2) {
                    k2 = i2;
                }
                if (j2 > k2) {
                    k2 = j2;
                }
                if (k3 > k2) {
                    k2 = k3;
                }
                if (l2 > k2) {
                    k2 = l2;
                }
                return k2;
            }
        }
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            int i3 = 15 - this.field_1061_d.skyLightSubtracted;
            if (i3 < 0) {
                i3 = 0;
            }
            return i3;
        }
        final int j3 = (i >> 4) - this.field_1060_a;
        final int l3 = (k >> 4) - this.field_1059_b;
        return this.field_1062_c[j3][l3].getBlockLightValue(i & 0xF, j, k & 0xF, this.field_1061_d.skyLightSubtracted);
    }
    
    public int getBlockMetadata(final int x, final int y, final int z) {
        if (y < 0) {
            return 0;
        }
        if (y >= 128) {
            return 0;
        }
        final int l = (x >> 4) - this.field_1060_a;
        final int i1 = (z >> 4) - this.field_1059_b;
        return this.field_1062_c[l][i1].getBlockMetadata(x & 0xF, y, z & 0xF);
    }
    
    public Material getMaterialXYZ(final int x, final int y, final int z) {
        final int l = this.getBlockId(x, y, z);
        if (l == 0) {
            return Material.air;
        }
        return Block.allBlocks[l].blockMaterial;
    }
    
    public boolean isBlockNormalCube(final int x, final int y, final int z) {
        final Block block = Block.allBlocks[this.getBlockId(x, y, z)];
        return block != null && block.isOpaqueCube();
    }
}
