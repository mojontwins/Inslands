package com.mojang.minecraft;

import java.applet.*;
import com.mojang.minecraft.entity.*;
import com.mojang.minecraft.util.*;
import java.awt.*;

public class MinecraftApplet extends Applet
{
    private static final long serialVersionUID = 1L;
    private Canvas field_132_a;
    private Minecraft field_131_b;
    private Thread field_133_c;
    
    public MinecraftApplet() {
        this.field_133_c = null;
    }
    
    @Override
    public void init() {
        this.field_132_a = new MCAppletCanvas(this);
        boolean flag = false;
        if (this.getParameter("fullscreen") != null) {
            flag = this.getParameter("fullscreen").equalsIgnoreCase("true");
        }
        this.field_131_b = new MinecraftAppletImpl(this, this, this.field_132_a, this, this.getWidth(), this.getHeight(), flag);
        this.field_131_b.field_175_j = this.getDocumentBase().getHost();
        if (this.getDocumentBase().getPort() > 0) {
            final Minecraft field_131_b = this.field_131_b;
            field_131_b.field_175_j = String.valueOf(field_131_b.field_175_j) + ":" + this.getDocumentBase().getPort();
        }
        if (this.getParameter("username") != null && this.getParameter("sessionid") != null) {
            this.field_131_b.session = new Session(this.getParameter("username"), this.getParameter("sessionid"), this.getParameter("uuid"));
            System.out.println("Setting user: " + this.field_131_b.session.username + ", " + this.field_131_b.session.token);
            if (this.getParameter("mppass") != null) {
                this.field_131_b.session.mpPassParameter = this.getParameter("mppass");
            }
        }
        else {
            this.field_131_b.session = new Session("Player", "", "");
        }
        if (this.getParameter("loadmap_user") != null && this.getParameter("loadmap_id") != null) {
            this.field_131_b.field_166_s = this.getParameter("loadmap_user");
            this.field_131_b.field_165_t = Integer.parseInt(this.getParameter("loadmap_id"));
        }
        else if (this.getParameter("server") != null && this.getParameter("port") != null) {
            this.field_131_b.setServer(this.getParameter("server"), Integer.parseInt(this.getParameter("port")));
        }
        this.field_131_b.field_173_l = true;
        this.setLayout(new BorderLayout());
        this.add(this.field_132_a, "Center");
        this.field_132_a.setFocusable(true);
        this.validate();
    }
    
    public void func_103_a() {
        if (this.field_133_c != null) {
            return;
        }
        (this.field_133_c = new Thread(this.field_131_b, "Minecraft main thread")).start();
    }
    
    @Override
    public void start() {
        if (this.field_131_b != null) {
            this.field_131_b.isGamePaused = false;
        }
    }
    
    @Override
    public void stop() {
        if (this.field_131_b != null) {
            this.field_131_b.isGamePaused = true;
        }
    }
    
    @Override
    public void destroy() {
        this.func_102_b();
    }
    
    public void func_102_b() {
        if (this.field_133_c == null) {
            return;
        }
        this.field_131_b.shutdown();
        try {
            this.field_133_c.join(10000L);
        }
        catch (InterruptedException interruptedexception) {
            try {
                this.field_131_b.shutdownMinecraftApplet();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        this.field_133_c = null;
    }
    
    public void clearApplet() {
        this.field_132_a = null;
        this.field_131_b = null;
        this.field_133_c = null;
        try {
            this.removeAll();
            this.validate();
        }
        catch (Exception ex) {}
    }
}
