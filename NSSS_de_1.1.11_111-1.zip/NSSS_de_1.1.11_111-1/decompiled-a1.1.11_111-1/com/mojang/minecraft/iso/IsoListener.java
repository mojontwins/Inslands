package com.mojang.minecraft.iso;

import com.mojang.minecraft.level.*;
import java.io.*;
import com.mojang.minecraft.enums.*;
import java.util.*;
import com.mojang.minecraft.render.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;

public class IsoListener extends Canvas implements KeyListener, MouseListener, MouseMotionListener, Runnable
{
    private static final long serialVersionUID = 1L;
    private int field_1793_a;
    private int field_1792_b;
    private boolean field_1791_c;
    private World field_1790_d;
    private File dataFolder;
    private boolean field_1788_f;
    private List<IsoImageBuffer> field_1787_g;
    private IsoImageBuffer[][] field_1786_h;
    private int field_1785_i;
    private int field_1784_j;
    private int field_1783_k;
    private int field_1782_l;
    
    public File func_1263_a() {
        if (this.dataFolder == null) {
            this.dataFolder = this.func_1264_a("minecraft");
        }
        return this.dataFolder;
    }
    
    public File func_1264_a(final String s) {
        final String s2 = System.getProperty("user.home", ".");
        File file = null;
        switch (OsMap.field_1193_a[func_1269_e().ordinal()]) {
            case 1:
            case 2: {
                file = new File(s2, '.' + s + '/');
                break;
            }
            case 3: {
                final String s3 = System.getenv("APPDATA");
                if (s3 != null) {
                    file = new File(s3, "." + s + '/');
                    break;
                }
                file = new File(s2, '.' + s + '/');
                break;
            }
            case 4: {
                file = new File(s2, "Library/Application Support/" + s);
                break;
            }
            default: {
                file = new File(s2, s + '/');
                break;
            }
        }
        if (!file.exists() && !file.mkdirs()) {
            throw new RuntimeException("The working directory could not be created: " + file);
        }
        return file;
    }
    
    private static EnumOS1 func_1269_e() {
        final String s = System.getProperty("os.name").toLowerCase();
        if (s.contains("win")) {
            return EnumOS1.windows;
        }
        if (s.contains("mac")) {
            if (s.contains("os 9")) {
                return EnumOS1.macos9;
            }
            return EnumOS1.macos;
        }
        else {
            if (s.contains("solaris")) {
                return EnumOS1.solaris;
            }
            if (s.contains("sunos")) {
                return EnumOS1.solaris;
            }
            if (s.contains("linux")) {
                return EnumOS1.linux;
            }
            if (s.contains("unix")) {
                return EnumOS1.linux;
            }
            if (s.contains("irix")) {
                return EnumOS1.irix;
            }
            return EnumOS1.unknown;
        }
    }
    
    public IsoListener() {
        this.field_1793_a = 0;
        this.field_1792_b = 2;
        this.field_1791_c = true;
        this.field_1788_f = true;
        this.field_1787_g = Collections.synchronizedList(new LinkedList<IsoImageBuffer>());
        this.field_1786_h = new IsoImageBuffer[64][64];
        this.dataFolder = this.func_1263_a();
        for (int i = 0; i < 64; ++i) {
            for (int j = 0; j < 64; ++j) {
                this.field_1786_h[i][j] = new IsoImageBuffer(null, i, j);
            }
        }
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.addKeyListener(this);
        this.setFocusable(true);
        this.requestFocus();
        this.setBackground(Color.red);
    }
    
    public void func_1270_b(final String s) {
        final int n = 0;
        this.field_1784_j = n;
        this.field_1785_i = n;
        this.field_1790_d = new WorldIso(this, new File(this.dataFolder, "NSSSsaves"), s);
        this.field_1790_d.skyLightSubtracted = 0;
        synchronized (this.field_1787_g) {
            this.field_1787_g.clear();
            for (int i = 0; i < 64; ++i) {
                for (int j = 0; j < 64; ++j) {
                    this.field_1786_h[i][j].func_888_a(this.field_1790_d, i, j);
                }
            }
        }
        // monitorexit(this.field_1787_g)
    }
    
    private void func_1266_a(final int i) {
        synchronized (this.field_1787_g) {
            this.field_1790_d.skyLightSubtracted = i;
            this.field_1787_g.clear();
            for (int j = 0; j < 64; ++j) {
                for (int k = 0; k < 64; ++k) {
                    this.field_1786_h[j][k].func_888_a(this.field_1790_d, j, k);
                }
            }
        }
        // monitorexit(this.field_1787_g)
    }
    
    public void func_1272_b() {
        new ThreadRunIsoClient(this).start();
        for (int i = 0; i < 8; ++i) {
            new Thread(this).start();
        }
    }
    
    public void func_1273_c() {
        this.field_1788_f = false;
    }
    
    private IsoImageBuffer func_1267_a(final int i, final int j) {
        final int k = i & 0x3F;
        final int l = j & 0x3F;
        final IsoImageBuffer isoimagebuffer = this.field_1786_h[k][l];
        if (isoimagebuffer.viewPosX == i && isoimagebuffer.viewPosZ == j) {
            return isoimagebuffer;
        }
        synchronized (this.field_1787_g) {
            this.field_1787_g.remove(isoimagebuffer);
        }
        // monitorexit(this.field_1787_g)
        isoimagebuffer.func_889_a(i, j);
        return isoimagebuffer;
    }
    
    public void run() {
        final TerrainTextureManager terraintexturemanager = new TerrainTextureManager();
        while (this.field_1788_f) {
            IsoImageBuffer isoimagebuffer = null;
            synchronized (this.field_1787_g) {
                if (this.field_1787_g.size() > 0) {
                    isoimagebuffer = this.field_1787_g.remove(0);
                }
            }
            // monitorexit(this.field_1787_g)
            if (isoimagebuffer != null) {
                if (this.field_1793_a - isoimagebuffer.field_1350_g < 2) {
                    terraintexturemanager.handleIsoTexture(isoimagebuffer);
                    this.repaint();
                }
                else {
                    isoimagebuffer.field_1349_h = false;
                }
            }
            try {
                Thread.sleep(2L);
            }
            catch (InterruptedException interruptedexception) {
                interruptedexception.printStackTrace();
            }
        }
    }
    
    @Override
    public void update(final Graphics g) {
    }
    
    @Override
    public void paint(final Graphics g) {
    }
    
    public void func_1265_d() {
        final BufferStrategy bufferstrategy = this.getBufferStrategy();
        if (bufferstrategy == null) {
            this.createBufferStrategy(2);
            return;
        }
        this.func_1268_a((Graphics2D)bufferstrategy.getDrawGraphics());
        bufferstrategy.show();
    }
    
    public void func_1268_a(final Graphics2D graphics2d) {
        ++this.field_1793_a;
        final AffineTransform affinetransform = graphics2d.getTransform();
        graphics2d.setClip(0, 0, this.getWidth(), this.getHeight());
        graphics2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        graphics2d.translate(this.getWidth() / 2, this.getHeight() / 2);
        graphics2d.scale(this.field_1792_b, this.field_1792_b);
        graphics2d.translate(this.field_1785_i, this.field_1784_j);
        if (this.field_1790_d != null) {
            graphics2d.translate(-(this.field_1790_d.spawnX + this.field_1790_d.spawnZ), -(-this.field_1790_d.spawnX + this.field_1790_d.spawnZ) + 64);
        }
        final Rectangle rectangle = graphics2d.getClipBounds();
        graphics2d.setColor(new Color(-15724512));
        graphics2d.fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
        final byte byte0 = 16;
        final byte byte2 = 3;
        final int i = rectangle.x / byte0 / 2 - 2 - byte2;
        final int j = (rectangle.x + rectangle.width) / byte0 / 2 + 1 + byte2;
        final int k = rectangle.y / byte0 - 1 - byte2 * 2;
        for (int l = (rectangle.y + rectangle.height + 16 + 128) / byte0 + 1 + byte2 * 2, i2 = k; i2 <= l; ++i2) {
            for (int k2 = i; k2 <= j; ++k2) {
                final int l2 = k2 - (i2 >> 1);
                final int i3 = k2 + (i2 + 1 >> 1);
                final IsoImageBuffer isoimagebuffer = this.func_1267_a(l2, i3);
                isoimagebuffer.field_1350_g = this.field_1793_a;
                if (!isoimagebuffer.field_1352_e) {
                    if (!isoimagebuffer.field_1349_h) {
                        isoimagebuffer.field_1349_h = true;
                        this.field_1787_g.add(isoimagebuffer);
                    }
                }
                else {
                    isoimagebuffer.field_1349_h = false;
                    if (!isoimagebuffer.field_1351_f) {
                        final int j2 = k2 * byte0 * 2 + (i2 & 0x1) * byte0;
                        final int k3 = i2 * byte0 - 128 - 16;
                        graphics2d.drawImage(isoimagebuffer.isoImageBuffer, j2, k3, null);
                    }
                }
            }
        }
        if (this.field_1791_c) {
            graphics2d.setTransform(affinetransform);
            final int j3 = this.getHeight() - 32 - 4;
            graphics2d.setColor(new Color(Integer.MIN_VALUE, true));
            graphics2d.fillRect(4, this.getHeight() - 32 - 4, this.getWidth() - 8, 32);
            graphics2d.setColor(Color.WHITE);
            final String s = "F1 - F5: load levels   |   0-9: Set time of day   |   Space: return to spawn   |   Double click: zoom   |   Escape: hide this text";
            graphics2d.drawString(s, this.getWidth() / 2 - graphics2d.getFontMetrics().stringWidth(s) / 2, j3 + 20);
        }
        graphics2d.dispose();
    }
    
    public void mouseDragged(final MouseEvent mouseevent) {
        final int i = mouseevent.getX() / this.field_1792_b;
        final int j = mouseevent.getY() / this.field_1792_b;
        this.field_1785_i += i - this.field_1783_k;
        this.field_1784_j += j - this.field_1782_l;
        this.field_1783_k = i;
        this.field_1782_l = j;
        this.repaint();
    }
    
    public void mouseMoved(final MouseEvent mouseevent) {
    }
    
    public void mouseClicked(final MouseEvent mouseevent) {
        if (mouseevent.getClickCount() == 2) {
            this.field_1792_b = 3 - this.field_1792_b;
            this.repaint();
        }
    }
    
    public void mouseEntered(final MouseEvent mouseevent) {
    }
    
    public void mouseExited(final MouseEvent mouseevent) {
    }
    
    public void mousePressed(final MouseEvent mouseevent) {
        final int i = mouseevent.getX() / this.field_1792_b;
        final int j = mouseevent.getY() / this.field_1792_b;
        this.field_1783_k = i;
        this.field_1782_l = j;
    }
    
    public void mouseReleased(final MouseEvent mouseevent) {
    }
    
    public void keyPressed(final KeyEvent keyevent) {
        if (keyevent.getKeyCode() == 48) {
            this.func_1266_a(11);
        }
        if (keyevent.getKeyCode() == 49) {
            this.func_1266_a(10);
        }
        if (keyevent.getKeyCode() == 50) {
            this.func_1266_a(9);
        }
        if (keyevent.getKeyCode() == 51) {
            this.func_1266_a(7);
        }
        if (keyevent.getKeyCode() == 52) {
            this.func_1266_a(6);
        }
        if (keyevent.getKeyCode() == 53) {
            this.func_1266_a(5);
        }
        if (keyevent.getKeyCode() == 54) {
            this.func_1266_a(3);
        }
        if (keyevent.getKeyCode() == 55) {
            this.func_1266_a(2);
        }
        if (keyevent.getKeyCode() == 56) {
            this.func_1266_a(1);
        }
        if (keyevent.getKeyCode() == 57) {
            this.func_1266_a(0);
        }
        if (keyevent.getKeyCode() == 112) {
            this.func_1270_b("World1");
        }
        if (keyevent.getKeyCode() == 113) {
            this.func_1270_b("World2");
        }
        if (keyevent.getKeyCode() == 114) {
            this.func_1270_b("World3");
        }
        if (keyevent.getKeyCode() == 115) {
            this.func_1270_b("World4");
        }
        if (keyevent.getKeyCode() == 116) {
            this.func_1270_b("World5");
        }
        if (keyevent.getKeyCode() == 32) {
            final int n = 0;
            this.field_1784_j = n;
            this.field_1785_i = n;
        }
        if (keyevent.getKeyCode() == 27) {
            this.field_1791_c = !this.field_1791_c;
        }
        this.repaint();
    }
    
    public void keyReleased(final KeyEvent keyevent) {
    }
    
    public void keyTyped(final KeyEvent keyevent) {
    }
    
    static boolean func_1271_a(final IsoListener isolistener) {
        return isolistener.field_1788_f;
    }
}
