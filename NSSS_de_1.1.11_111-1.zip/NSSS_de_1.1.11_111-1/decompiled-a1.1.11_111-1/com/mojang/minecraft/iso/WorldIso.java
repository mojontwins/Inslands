package com.mojang.minecraft.iso;

import com.mojang.minecraft.level.*;
import java.io.*;
import java.util.*;
import com.mojang.minecraft.*;
import com.mojang.minecraft.level.chunk.*;
import com.mojang.minecraft.level.generate.*;

class WorldIso extends World
{
    final IsoListener field_1051_z;
    
    WorldIso(final IsoListener isolistener, final File file, final String s) {
        super(file, s, new Random().nextInt() == 4, true, 0, null);
        this.field_1051_z = isolistener;
    }
    
    @Override
    protected IChunkProvider getWorldChunkProvider(final File file) {
        return new ChunkProviderIso(this, new ChunkLoader(file, false));
    }
}
