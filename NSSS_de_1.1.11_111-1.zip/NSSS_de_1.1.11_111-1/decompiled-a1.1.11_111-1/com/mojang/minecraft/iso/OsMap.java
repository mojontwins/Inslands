package com.mojang.minecraft.iso;

import com.mojang.minecraft.enums.*;

class OsMap
{
    static final int[] field_1193_a;
    
    static {
        field_1193_a = new int[EnumOS1.values().length];
        try {
            OsMap.field_1193_a[EnumOS1.linux.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            OsMap.field_1193_a[EnumOS1.solaris.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError2) {}
        try {
            OsMap.field_1193_a[EnumOS1.windows.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError3) {}
        try {
            OsMap.field_1193_a[EnumOS1.macos.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError4) {}
        try {
            OsMap.field_1193_a[EnumOS1.macos9.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError5) {}
        try {
            OsMap.field_1193_a[EnumOS1.irix.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError6) {}
    }
}
