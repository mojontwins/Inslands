package com.mojang.minecraft.iso;

class ThreadRunIsoClient extends Thread
{
    final IsoListener field_1197_a;
    
    ThreadRunIsoClient(final IsoListener isolistener) {
        this.field_1197_a = isolistener;
    }
    
    @Override
    public void run() {
        while (IsoListener.func_1271_a(this.field_1197_a)) {
            this.field_1197_a.func_1265_d();
            try {
                Thread.sleep(1L);
            }
            catch (Exception ex) {}
        }
    }
}
