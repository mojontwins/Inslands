package com.mojang.minecraft.iso;

import java.applet.*;
import java.awt.*;

public class IsomPreviewApplet extends Applet
{
    private static final long serialVersionUID = 1L;
    private IsoListener a;
    
    public IsomPreviewApplet() {
        this.a = new IsoListener();
        this.setLayout(new BorderLayout());
        this.add(this.a, "Center");
    }
    
    @Override
    public void start() {
        this.a.func_1272_b();
    }
    
    @Override
    public void stop() {
        this.a.func_1273_c();
    }
}
