package net.minecraft.src;

public interface IReach {
	boolean reachItemMatches(ItemStack itemStack1);

	float getReach(ItemStack itemStack1);
}
