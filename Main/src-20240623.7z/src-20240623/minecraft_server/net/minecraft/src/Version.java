package net.minecraft.src;

public class Version {
	private static final String version = "InSlands v240612";
	private static final String date = "20240612";
	
	public static String getVersion () { 
		return version;
	}

	public static String getDate() {
		return date;
	}
}
