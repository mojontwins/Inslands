package net.minecraft.src;

public class CityChunkDescriptor {
	public int forceBuild = 0;
}
