package net.minecraft.src;

public interface EntityTameable {

	boolean isTamed();

	EntityLiving getOwner();

}
