package net.minecraft.src;

public interface IInvBasic {
	void onInventoryChanged(InventoryBasic inventoryBasic1);
}
