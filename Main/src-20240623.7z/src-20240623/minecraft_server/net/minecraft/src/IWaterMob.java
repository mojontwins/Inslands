package net.minecraft.src;

public interface IWaterMob extends IAnimals {
}
