package net.minecraft.src;

public interface ISentient {

	// Entities which implement this interface will be attacked by zombies.
	
}
