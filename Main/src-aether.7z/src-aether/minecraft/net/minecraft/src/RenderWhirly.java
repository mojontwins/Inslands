package net.minecraft.src;

public class RenderWhirly extends Render {
	public void doRender(Entity entity, double d, double d1, double d2, float f, float f1) {
	}
}
