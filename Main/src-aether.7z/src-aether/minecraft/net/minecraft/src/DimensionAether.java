package net.minecraft.src;

public class DimensionAether extends DimensionBase {
	public DimensionAether() {
		super(3, WorldProviderAether.class, TeleporterAether.class);
	}
}
