package net.minecraft.src;

public enum EnumJsonNodeType {
	OBJECT,
	ARRAY,
	STRING,
	NUMBER,
	TRUE,
	FALSE,
	NULL;
}
