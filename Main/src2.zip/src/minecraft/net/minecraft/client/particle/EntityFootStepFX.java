package net.minecraft.client.particle;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.renderer.RenderEngine;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.MathHelper;
import net.minecraft.world.level.World;

public class EntityFootStepFX extends EntityFX {
	private int ticksAlive = 0;
	private int ticksToLive = 0;
	private RenderEngine currentFootSteps;

	public EntityFootStepFX(RenderEngine renderEngine1, World world2, double d3, double d5, double d7) {
		super(world2, d3, d5, d7, 0.0D, 0.0D, 0.0D);
		this.currentFootSteps = renderEngine1;
		this.motionX = this.motionY = this.motionZ = 0.0D;
		this.ticksToLive = 200;
	}

	public void renderParticle(Tessellator tessellator1, float f2, float f3, float f4, float f5, float f6, float f7) {
		float f8 = ((float)this.ticksAlive + f2) / (float)this.ticksToLive;
		f8 *= f8;
		float f9 = 2.0F - f8 * 2.0F;
		if(f9 > 1.0F) {
			f9 = 1.0F;
		}

		f9 *= 0.2F;
		GL11.glDisable(GL11.GL_LIGHTING);
		float f10 = 0.125F;
		float f11 = (float)(this.posX - interpPosX);
		float f12 = (float)(this.posY - interpPosY);
		float f13 = (float)(this.posZ - interpPosZ);
		float f14 = this.worldObj.getLightBrightness(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ));
		this.currentFootSteps.bindTexture(this.currentFootSteps.getTexture("/misc/footprint.png"));
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		tessellator1.startDrawingQuads();
		tessellator1.setColorRGBA_F(f14, f14, f14, f9);
		tessellator1.addVertexWithUV((double)(f11 - f10), (double)f12, (double)(f13 + f10), 0.0D, 1.0D);
		tessellator1.addVertexWithUV((double)(f11 + f10), (double)f12, (double)(f13 + f10), 1.0D, 1.0D);
		tessellator1.addVertexWithUV((double)(f11 + f10), (double)f12, (double)(f13 - f10), 1.0D, 0.0D);
		tessellator1.addVertexWithUV((double)(f11 - f10), (double)f12, (double)(f13 - f10), 0.0D, 0.0D);
		tessellator1.draw();
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_LIGHTING);
	}

	public void onUpdate() {
		++this.ticksAlive;
		if(this.ticksAlive == this.ticksToLive) {
			this.setEntityDead();
		}

	}

	public int getFXLayer() {
		return 3;
	}
}
