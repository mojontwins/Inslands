package net.minecraft.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import net.minecraft.client.multiplayer.ThreadStatSyncherReceive;
import net.minecraft.client.multiplayer.ThreadStatSyncherSend;

@SuppressWarnings("rawtypes")
public class StatsSyncher {
	private volatile boolean isBusy = false;	
	private volatile Map field_27437_b = null;
	private volatile Map field_27436_c = null;
	private StatFileWriter statFileWriter;
	private File unsentDataFile;
	private File dataFile;
	private File unsentTempFile;
	private File tempFile;
	private File unsentOldFile;
	private File oldFile;
	private User theSession;
	private int field_27427_l = 0;
	private int field_27426_m = 0;

	@SuppressWarnings("unchecked")
	public StatsSyncher(User session1, StatFileWriter statFileWriter2, File file3) {
		this.unsentDataFile = new File(file3, "stats_" + session1.username.toLowerCase() + "_unsent.dat");
		this.dataFile = new File(file3, "stats_" + session1.username.toLowerCase() + ".dat");
		this.unsentOldFile = new File(file3, "stats_" + session1.username.toLowerCase() + "_unsent.old");
		this.oldFile = new File(file3, "stats_" + session1.username.toLowerCase() + ".old");
		this.unsentTempFile = new File(file3, "stats_" + session1.username.toLowerCase() + "_unsent.tmp");
		this.tempFile = new File(file3, "stats_" + session1.username.toLowerCase() + ".tmp");
		if(!session1.username.toLowerCase().equals(session1.username)) {
			this.func_28214_a(file3, "stats_" + session1.username + "_unsent.dat", this.unsentDataFile);
			this.func_28214_a(file3, "stats_" + session1.username + ".dat", this.dataFile);
			this.func_28214_a(file3, "stats_" + session1.username + "_unsent.old", this.unsentOldFile);
			this.func_28214_a(file3, "stats_" + session1.username + ".old", this.oldFile);
			this.func_28214_a(file3, "stats_" + session1.username + "_unsent.tmp", this.unsentTempFile);
			this.func_28214_a(file3, "stats_" + session1.username + ".tmp", this.tempFile);
		}

		this.statFileWriter = statFileWriter2;
		this.theSession = session1;
		if(this.unsentDataFile.exists()) {
			statFileWriter2.func_27179_a(this.func_27415_a(this.unsentDataFile, this.unsentTempFile, this.unsentOldFile));
		}

		this.beginReceiveStats();
	}

	private void func_28214_a(File file1, String string2, File file3) {
		File file4 = new File(file1, string2);
		if(file4.exists() && !file4.isDirectory() && !file3.exists()) {
			file4.renameTo(file3);
		}

	}

	private Map func_27415_a(File file1, File file2, File file3) {
		return file1.exists() ? this.func_27408_a(file1) : (file3.exists() ? this.func_27408_a(file3) : (file2.exists() ? this.func_27408_a(file2) : null));
	}

	private Map func_27408_a(File file1) {
		BufferedReader bufferedReader2 = null;

		try {
			bufferedReader2 = new BufferedReader(new FileReader(file1));
			String string3 = "";
			StringBuilder stringBuilder4 = new StringBuilder();

			while((string3 = bufferedReader2.readLine()) != null) {
				stringBuilder4.append(string3);
			}

			Map map5 = StatFileWriter.func_27177_a(stringBuilder4.toString());
			return map5;
		} catch (Exception exception15) {
			exception15.printStackTrace();
		} finally {
			if(bufferedReader2 != null) {
				try {
					bufferedReader2.close();
				} catch (Exception exception14) {
					exception14.printStackTrace();
				}
			}

		}

		return null;
	}

	private void func_27410_a(Map map1, File file2, File file3, File file4) throws IOException {
		PrintWriter printWriter5 = new PrintWriter(new FileWriter(file3, false));

		try {
			printWriter5.print(StatFileWriter.func_27185_a(this.theSession.username, "local", map1));
		} finally {
			printWriter5.close();
		}

		if(file4.exists()) {
			file4.delete();
		}

		if(file2.exists()) {
			file2.renameTo(file4);
		}

		file3.renameTo(file2);
	}

	public void beginReceiveStats() {
		if(this.isBusy) {
			throw new IllegalStateException("Can\'t get stats from server while StatsSyncher is busy!");
		} else {
			this.field_27427_l = 100;
			this.isBusy = true;
			(new ThreadStatSyncherReceive(this)).start();
		}
	}

	public void beginSendStats(Map map1) {
		if(this.isBusy) {
			throw new IllegalStateException("Can\'t save stats while StatsSyncher is busy!");
		} else {
			this.field_27427_l = 100;
			this.isBusy = true;
			(new ThreadStatSyncherSend(this, map1)).start();
		}
	}

	public void syncStatsFileWithMap(Map map1) {
		int i2 = 30;

		while(this.isBusy) {
			--i2;
			if(i2 <= 0) {
				break;
			}

			try {
				Thread.sleep(100L);
			} catch (InterruptedException interruptedException10) {
				interruptedException10.printStackTrace();
			}
		}

		this.isBusy = true;

		try {
			this.func_27410_a(map1, this.unsentDataFile, this.unsentTempFile, this.unsentOldFile);
		} catch (Exception exception8) {
			exception8.printStackTrace();
		} finally {
			this.isBusy = false;
		}

	}

	public boolean func_27420_b() {
		return this.field_27427_l <= 0 && !this.isBusy && this.field_27436_c == null;
	}

	@SuppressWarnings("unchecked")
	public void func_27425_c() {
		if(this.field_27427_l > 0) {
			--this.field_27427_l;
		}

		if(this.field_27426_m > 0) {
			--this.field_27426_m;
		}

		if(this.field_27436_c != null) {
			this.statFileWriter.func_27187_c(this.field_27436_c);
			this.field_27436_c = null;
		}

		if(this.field_27437_b != null) {
			this.statFileWriter.func_27180_b(this.field_27437_b);
			this.field_27437_b = null;
		}

	}

	public static Map func_27422_a(StatsSyncher statsSyncher0) {
		return statsSyncher0.field_27437_b;
	}

	public static File func_27423_b(StatsSyncher statsSyncher0) {
		return statsSyncher0.dataFile;
	}

	public static File func_27411_c(StatsSyncher statsSyncher0) {
		return statsSyncher0.tempFile;
	}

	public static File func_27413_d(StatsSyncher statsSyncher0) {
		return statsSyncher0.oldFile;
	}

	public static void func_27412_a(StatsSyncher statsSyncher0, Map map1, File file2, File file3, File file4) throws IOException {
		statsSyncher0.func_27410_a(map1, file2, file3, file4);
	}

	public static Map func_27421_a(StatsSyncher statsSyncher0, Map map1) {
		return statsSyncher0.field_27437_b = map1;
	}

	public static Map func_27409_a(StatsSyncher statsSyncher0, File file1, File file2, File file3) {
		return statsSyncher0.func_27415_a(file1, file2, file3);
	}

	public static boolean setBusy(StatsSyncher statsSyncher0, boolean z1) {
		return statsSyncher0.isBusy = z1;
	}

	public static File getUnsentDataFile(StatsSyncher statsSyncher0) {
		return statsSyncher0.unsentDataFile;
	}

	public static File getUnsentTempFile(StatsSyncher statsSyncher0) {
		return statsSyncher0.unsentTempFile;
	}

	public static File getUnsentOldFile(StatsSyncher statsSyncher0) {
		return statsSyncher0.unsentOldFile;
	}
}
