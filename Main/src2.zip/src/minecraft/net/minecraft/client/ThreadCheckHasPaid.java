package net.minecraft.client;

import java.net.HttpURLConnection;
import java.net.URL;

public class ThreadCheckHasPaid extends Thread {
	final Minecraft mc;

	public ThreadCheckHasPaid(Minecraft minecraft1) {
		this.mc = minecraft1;
	}

	public void run() {
		try {
			HttpURLConnection httpURLConnection1 = (HttpURLConnection)(new URL("https://login.minecraft.net/session?name=" + this.mc.session.username + "&session=" + this.mc.session.sessionId)).openConnection();
			httpURLConnection1.connect();
			if(httpURLConnection1.getResponseCode() == 400) {
				Minecraft.hasPaidCheckTime = System.currentTimeMillis();
			}

			httpURLConnection1.disconnect();
		} catch (Exception exception2) {
			exception2.printStackTrace();
		}

	}
}
