package net.minecraft.client.renderer;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.tile.RenderBlockClassicPiston;
import net.minecraft.client.renderer.tile.RenderBlockHollowLog;
import net.minecraft.client.renderer.tile.RenderBlockModel;
import net.minecraft.client.renderer.util.Idx2uvF;
import net.minecraft.client.renderer.util.Texels;
import net.minecraft.client.renderer.util.TextureAtlasSize;
import net.minecraft.util.MathHelper;
import net.minecraft.world.Direction;
import net.minecraft.world.level.IBlockAccess;
import net.minecraft.world.level.World;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.tile.Block;
import net.minecraft.world.level.tile.BlockBed;
import net.minecraft.world.level.tile.BlockFlower;
import net.minecraft.world.level.tile.BlockFluid;
import net.minecraft.world.level.tile.BlockPane;
import net.minecraft.world.level.tile.BlockRail;
import net.minecraft.world.level.tile.BlockRedstoneRepeater;
import net.minecraft.world.level.tile.BlockRedstoneWire;
import net.minecraft.world.level.tile.BlockTallGrass;
import net.minecraft.world.phys.Vec3D;

public class RenderBlocks {
	public IBlockAccess blockAccess;
	private int overrideBlockTexture = -1;
	private boolean flipTexture = false;
	private boolean renderAllFaces = false;
	public static boolean fancyGrass = false;
	public boolean useInventoryTint = true;
	private int uvRotateEast = 0;
	private int uvRotateWest = 0;
	private int uvRotateSouth = 0;
	private int uvRotateNorth = 0;
	private int uvRotateTop = 0;
	private int uvRotateBottom = 0;
	private boolean enableAO;
	private float lightValueOwn;
	private float aoLightValueXNeg;
	private float aoLightValueYNeg;
	private float aoLightValueZNeg;
	private float aoLightValueXPos;
	private float aoLightValueYPos;
	private float aoLightValueZPos;
	private float aoLightValueScratchXYZNNN;
	private float aoLightValueScratchXYNN;
	private float aoLightValueScratchXYZNNP;
	private float aoLightValueScratchYZNN;
	private float aoLightValueScratchYZNP;
	private float aoLightValueScratchXYZPNN;
	private float aoLightValueScratchXYPN;
	private float aoLightValueScratchXYZPNP;
	private float aoLightValueScratchXYZNPN;
	private float aoLightValueScratchXYNP;
	private float aoLightValueScratchXYZNPP;
	private float aoLightValueScratchYZPN;
	private float aoLightValueScratchXYZPPN;
	private float aoLightValueScratchXYPP;
	private float aoLightValueScratchYZPP;
	private float aoLightValueScratchXYZPPP;
	private float aoLightValueScratchXZNN;
	private float aoLightValueScratchXZPN;
	private float aoLightValueScratchXZNP;
	private float aoLightValueScratchXZPP;
	private int aoBrightnessXYZNNN;
	private int aoBrightnessXYNN;
	private int aoBrightnessXYZNNP;
	private int aoBrightnessYZNN;
	private int aoBrightnessYZNP;
	private int aoBrightnessXYZPNN;
	private int aoBrightnessXYPN;
	private int aoBrightnessXYZPNP;
	private int aoBrightnessXYZNPN;
	private int aoBrightnessXYNP;
	private int aoBrightnessXYZNPP;
	private int aoBrightnessYZPN;
	private int aoBrightnessXYZPPN;
	private int aoBrightnessXYPP;
	private int aoBrightnessYZPP;
	private int aoBrightnessXYZPPP;
	private int aoBrightnessXZNN;
	private int aoBrightnessXZPN;
	private int aoBrightnessXZNP;
	private int aoBrightnessXZPP;
	private int aoType = 1;
	private int brightnessTopLeft;
	private int brightnessBottomLeft;
	private int brightnessBottomRight;
	private int brightnessTopRight;
	private float colorRedTopLeft;
	private float colorRedBottomLeft;
	private float colorRedBottomRight;
	private float colorRedTopRight;
	private float colorGreenTopLeft;
	private float colorGreenBottomLeft;
	private float colorGreenBottomRight;
	private float colorGreenTopRight;
	private float colorBlueTopLeft;
	private float colorBlueBottomLeft;
	private float colorBlueBottomRight;
	private float colorBlueTopRight;
	private boolean aoGrassXYZCPN;
	private boolean aoGrassXYZPPC;
	private boolean aoGrassXYZNPC;
	private boolean aoGrassXYZCPP;
	private boolean aoGrassXYZNCN;
	private boolean aoGrassXYZPCP;
	private boolean aoGrassXYZNCP;
	private boolean aoGrassXYZPCN;
	private boolean aoGrassXYZCNN;
	private boolean aoGrassXYZPNC;
	private boolean aoGrassXYZNNC;
	private boolean aoGrassXYZCNP;
	
	private int activeRenderPass = 0;

	public static float[][] redstoneColors = new float[16][];
	
	public RenderBlocks(IBlockAccess iBlockAccess1) {
		this.blockAccess = iBlockAccess1;
	}

	public RenderBlocks() {
	}
	
	public int getActiveRenderPass() {
		return activeRenderPass;
	}

	public void setActiveRenderPass(int activeRenderPass) {
		this.activeRenderPass = activeRenderPass;
	}

	public void renderBlockUsingTexture(Block block1, int i2, int i3, int i4, int i5) {
		this.overrideBlockTexture = i5;
		this.renderBlockByRenderType(block1, i2, i3, i4);
		this.overrideBlockTexture = -1;
	}

	public void func_31075_a(Block block1, int i2, int i3, int i4) {
		this.renderAllFaces = true;
		this.renderBlockByRenderType(block1, i2, i3, i4);
		this.renderAllFaces = false;
	}

	public boolean renderBlockByRenderType(Block block, int x, int y, int z) {
		int i5 = block.getRenderType();
		block.setBlockBoundsBasedOnState(this.blockAccess, x, y, z);

		switch(i5) {
			case 0: return this.renderStandardBlock(block, x, y, z);
			case 1: return this.drawCrossedSquares(block, x, y, z);
			case 2: return this.renderBlockTorch(block, x, y, z);
			case 3: return this.renderBlockFire(block, x, y, z);
			case 4: return this.renderBlockFluids(block, x, y, z);
			case 5: return this.renderBlockRedstoneWire(block, x, y, z);
			case 6: return this.renderBlockCrops(block, x, y, z);
			case 7: return this.renderBlockDoor(block, x, y, z);
			case 8: return this.renderBlockLadder(block, x, y, z);
			case 9: return this.renderBlockMinecartTrack((BlockRail)block, x, y, z);
			case 10: return this.renderBlockStairs(block, x, y, z);
			case 11: return this.renderBlockFence(block, x, y, z);
			case 12: return this.renderBlockLever(block, x, y, z);
			case 13: return this.renderBlockCactus(block, x, y, z); 
			case 14: return this.renderBlockBed(block, x, y, z);
			case 15: return this.renderBlockRepeater(block, x, y, z);
			case 18: return this.renderBlockPane((BlockPane)block, x, y, z);
			case 20: return this.renderBlockVine(block, x, y, z);
			case 23: return this.renderBlockLilyPad(block, x, y, z);
			case 100: return this.renderBlockWall(block, x, y, z);
			case 101: return this.renderBarbedWire(block, x, y, z);
			case 102: return this.renderHollowTrunk(block, x, y, z);
			case 103: return this.renderBlockDirtPath(block, x, y, z);
			case 104: return this.renderBlockStreetLantern(block, x, y, z);
			case 105: return this.renderBlockChippedWood(block, x, y, z);
			case 106: return this.renderBlockSlime(block, x, y, z);
			case 107: return this.renderBlockAxisOriented(block, x, y, z);
			case 108: return this.renderBlockWoodOriented(block, x, y, z);
			case 109: return this.renderBlockClassicPiston(block, x, y, z);
			case 110: return this.renderBlockChain(block, x, y, z);
			case 111: return this.renderBlockSnowloggedPlant(block, x, y, z);
			case 112: return this.renderBlockThinFeature(block, x, y, z);
			case 250: return this.renderBlockModel(block, x, y, z);
			default: return false;
		}
	}

	private boolean renderBlockThinFeature(Block block, int x, int y, int z) {
		long l = (long)(x * 0x2fc20f) ^ (long)z * 0x6ebfff5L ^ (long)y;
		l = l * l * 0x285b825L + l * 11L;
		int i1 = (int)(l >> 16 & 7L);
		this.uvRotateTop = i1 & 3;
		this.renderStandardBlock(block, x, y, z);	
		this.uvRotateTop = 0;
		return true;
	}

	private boolean renderBlockSnowloggedPlant(Block block, int x, int y, int z) {
		// 1st render the plant
		
		Tessellator tessellator = Tessellator.instance;
		tessellator.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));
		int colorMultiplier = block.colorMultiplier(this.blockAccess, x, y, z);

		float r = (float)(colorMultiplier >> 16 & 255) / 255.0F;
		float g = (float)(colorMultiplier >> 8 & 255) / 255.0F;
		float b = (float)(colorMultiplier & 255) / 255.0F;

		tessellator.setColorOpaque_F(r, g, b);

		double xD = (double)x;
		double yD = (double)y;
		double zD = (double)z;

		long noise = (long)(x * 3129871) ^ (long)z * 116129781L ^ (long)y;
		noise = noise * noise * 42317861L + noise * 11L;
		xD += ((double)((float)(noise >> 16 & 15L) / 15.0F) - 0.5D) * 0.5D;
		yD += ((double)((float)(noise >> 20 & 15L) / 15.0F) - 1.0D) * 0.2D;
		zD += ((double)((float)(noise >> 24 & 15L) / 15.0F) - 0.5D) * 0.5D;

		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		if(block instanceof BlockTallGrass) {
			int grassType = (meta >> 4) & 7;
			if(((meta >> 4) & 8) != 0) {
				this.drawCrossedSquaresDoubleHeight(block, grassType, xD, yD, zD);
			} else {
				this.drawCrossedSquares(block, grassType, xD, yD, zD);
			}
		} else {
			this.drawCrossedSquares(block, meta, xD, yD, zD);
		}
		// now render a layer of snow
		int snowHeight = meta & 15;
		if(snowHeight > 0) {
			block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, (float)(snowHeight + 1) / 16.0F, 1.0F);
			this.overrideBlockTexture = Block.snow.blockIndexInTexture;
			this.renderStandardBlockWithColorMultiplier(block, x, y, z, 1F, 1F, 1F);
			this.overrideBlockTexture = -1;
			((BlockFlower)block).setMyBlockBounds();
		}
		return true;
	}

	private boolean renderBlockChain(Block block, int x, int y, int z) {
		Tessellator tessellator9 = Tessellator.instance;
		
		tessellator9.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));
		tessellator9.setColorOpaque_F(1, 1, 1);
		
		int i10 = block.getBlockTextureFromSideAndMetadata(0, this.blockAccess.getBlockMetadata(x, y, z));
		if(this.overrideBlockTexture >= 0) {
			i10 = this.overrideBlockTexture;
		}
		
		/*
		int i11 = (i10 & 15) << 4;
		int i12 = i10 & 240;
		double u1 = (double)((float)i11 / 256.0F);
		double u2 = (double)(((float)i11 + 15.99F) / 256.0F);
		double v1 = (double)((float)i12 / 256.0F);
		double v2 = (double)(((float)i12 + 15.99F) / 256.0F);
		*/
		
		Idx2uvF.calc(i10);
		double u1 = Idx2uvF.u1;
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;
		
		double x1 = (double)x + 0.5D - (double)0.45F;
		double x2 = (double)x + 0.5D + (double)0.45F;
		double z1 = (double)z + 0.5D - (double)0.45F;
		double z2 = (double)z + 0.5D + (double)0.45F;
		double yy = (double)y;
		
		// Square 1
		
		tessellator9.addVertexWithUV(x1, yy + 1.0D, z1,  u1, v2);
		tessellator9.addVertexWithUV(x1, yy + 0.0D, z1,  u1, v1);
		tessellator9.addVertexWithUV(x2, yy + 0.0D, z2,  u2, v1);
		tessellator9.addVertexWithUV(x2, yy + 1.0D, z2,  u2, v2)
		;
		tessellator9.addVertexWithUV(x2, yy + 1.0D, z2,  u1, v2);
		tessellator9.addVertexWithUV(x2, yy + 0.0D, z2,  u1, v1);
		tessellator9.addVertexWithUV(x1, yy + 0.0D, z1,  u2, v1);
		tessellator9.addVertexWithUV(x1, yy + 1.0D, z1,  u2, v2);
		
		// Square 2 [upside down]
		
		tessellator9.addVertexWithUV(x1, yy + 1.0D, z2,  u1, v1);
		tessellator9.addVertexWithUV(x1, yy + 0.0D, z2,  u1, v2);
		tessellator9.addVertexWithUV(x2, yy + 0.0D, z1,  u2, v2);
		tessellator9.addVertexWithUV(x2, yy + 1.0D, z1,  u2, v1);
		
		tessellator9.addVertexWithUV(x2, yy + 1.0D, z1,  u1, v1);
		tessellator9.addVertexWithUV(x2, yy + 0.0D, z1,  u1, v2);
		tessellator9.addVertexWithUV(x1, yy + 0.0D, z2,  u2, v2);
		tessellator9.addVertexWithUV(x1, yy + 1.0D, z2,  u2, v1);
	
		return true;
	}

	private boolean renderBlockBed(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i7 = BlockBed.getDirectionFromMetadata(i6);
		boolean z8 = BlockBed.isBlockFootOfBed(i6);
		float f9 = 0.5F;
		float f10 = 1.0F;
		float f11 = 0.8F;
		float f12 = 0.6F;
		
		int i25 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4);
		tessellator5.setBrightness(i25);
		tessellator5.setColorOpaque_F(f9, f9, f9);
		
		int i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0);

		/*
		int i28 = (i27 & 15) << 4;
		int i29 = i27 & 0xff0;
		
		double d30 = (double)((float)i28 / 256F);
		double d32 = ((double)(i28 + 16) - 0.01D) / 256D;
		double d34 = (double)((float)i29 / 256F);
		double d36 = ((double)(i29 + 16) - 0.01D) / 256D;
		*/
		Idx2uvF.calc(i27);
		double d30 = Idx2uvF.u1;
		double d32 = Idx2uvF.u2;
		double d34 = Idx2uvF.v1;
		double d36 = Idx2uvF.v2;
		
		double d38 = (double)i2 + block1.minX;
		double d40 = (double)i2 + block1.maxX;
		double d42 = (double)i3 + block1.minY + 0.1875D;
		double d44 = (double)i4 + block1.minZ;
		double d46 = (double)i4 + block1.maxZ;
		tessellator5.addVertexWithUV(d38, d42, d46, d30, d36);
		tessellator5.addVertexWithUV(d38, d42, d44, d30, d34);
		tessellator5.addVertexWithUV(d40, d42, d44, d32, d34);
		tessellator5.addVertexWithUV(d40, d42, d46, d32, d36);
		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4));
		tessellator5.setColorOpaque_F(f10, f10, f10);
		i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1);
		
		/*
		i28 = (i27 & 15) << 4;
		i29 = i27 & 0xff0;
		d30 = (double)((float)i28 / 256F);
		d32 = ((double)(i28 + 16) - 0.01D) / 256D;
		d34 = (double)((float)i29 / 256F);
		d36 = ((double)(i29 + 16) - 0.01D) / 256D;
		*/
		Idx2uvF.calc(i27);
		d30 = Idx2uvF.u1;
		d32 = Idx2uvF.u2;
		d34 = Idx2uvF.v1;
		d36 = Idx2uvF.v2;
		
		d38 = d30;
		d40 = d32;
		d42 = d34;
		d44 = d34;
		d46 = d30;
		double d48 = d32;
		double d50 = d36;
		double d52 = d36;
		if(i7 == 0) {
			d40 = d30;
			d42 = d36;
			d46 = d32;
			d52 = d34;
		} else if(i7 == 2) {
			d38 = d32;
			d44 = d36;
			d48 = d30;
			d50 = d34;
		} else if(i7 == 3) {
			d38 = d32;
			d44 = d36;
			d48 = d30;
			d50 = d34;
			d40 = d30;
			d42 = d36;
			d46 = d32;
			d52 = d34;
		}

		double d54 = (double)i2 + block1.minX;
		double d56 = (double)i2 + block1.maxX;
		double d58 = (double)i3 + block1.maxY;
		double d60 = (double)i4 + block1.minZ;
		double d62 = (double)i4 + block1.maxZ;
		tessellator5.addVertexWithUV(d56, d58, d62, d46, d50);
		tessellator5.addVertexWithUV(d56, d58, d60, d38, d42);
		tessellator5.addVertexWithUV(d54, d58, d60, d40, d44);
		tessellator5.addVertexWithUV(d54, d58, d62, d48, d52);
		i27 = Direction.headInvisibleFace[i7];
		if(z8) {
			i27 = Direction.headInvisibleFace[Direction.footInvisibleFaceRemap[i7]];
		}

		byte b64 = 4;
		switch(i7) {
		case 0:
			b64 = 5;
			break;
		case 1:
			b64 = 3;
		case 2:
		default:
			break;
		case 3:
			b64 = 2;
		}

		if(i27 != 2 && (this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2))) {
			tessellator5.setBrightness(block1.minZ > 0.0D ? i25 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1));
			tessellator5.setColorOpaque_F(f11, f11, f11);
			this.flipTexture = b64 == 2;
			this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2));
		}

		if(i27 != 3 && (this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3))) {
			tessellator5.setBrightness(block1.maxZ < 1.0D ? i25 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1));
			tessellator5.setColorOpaque_F(f11, f11, f11);
			this.flipTexture = b64 == 3;
			this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3));
		}

		if(i27 != 4 && (this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4))) {
			tessellator5.setBrightness(block1.minZ > 0.0D ? i25 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4));
			tessellator5.setColorOpaque_F(f12, f12, f12);
			this.flipTexture = b64 == 4;
			this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4));
		}

		if(i27 != 5 && (this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5))) {
			tessellator5.setBrightness(block1.maxZ < 1.0D ? i25 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4));
			tessellator5.setColorOpaque_F(f12, f12, f12);
			this.flipTexture = b64 == 5;
			this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5));
		}

		this.flipTexture = false;
		return true;
	}

	public boolean renderBlockTorch(Block block1, int i2, int i3, int i4) {
		int i5 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		Tessellator tessellator6 = Tessellator.instance;
		tessellator6.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		tessellator6.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		double d7 = (double)0.4F;
		double d9 = 0.5D - d7;
		double d11 = (double)0.2F;
		if(i5 == 1) {
			this.renderTorchAtAngle(block1, (double)i2 - d9, (double)i3 + d11, (double)i4, -d7, 0.0D);
		} else if(i5 == 2) {
			this.renderTorchAtAngle(block1, (double)i2 + d9, (double)i3 + d11, (double)i4, d7, 0.0D);
		} else if(i5 == 3) {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3 + d11, (double)i4 - d9, 0.0D, -d7);
		} else if(i5 == 4) {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3 + d11, (double)i4 + d9, 0.0D, d7);
		} else {
			this.renderTorchAtAngle(block1, (double)i2, (double)i3, (double)i4, 0.0D, 0.0D);
		}

		return true;
	}

	private boolean renderBlockRepeater(Block block1, int i2, int i3, int i4) {
		int i5 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i6 = i5 & 3;
		int i7 = (i5 & 12) >> 2;
		this.renderStandardBlock(block1, i2, i3, i4);
		Tessellator tessellator8 = Tessellator.instance;
		tessellator8.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		tessellator8.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		double d9 = -0.1875D;
		double d11 = 0.0D;
		double d13 = 0.0D;
		double d15 = 0.0D;
		double d17 = 0.0D;
		switch(i6) {
		case 0:
			d17 = -0.3125D;
			d13 = BlockRedstoneRepeater.repeaterTorchOffset[i7];
			break;
		case 1:
			d15 = 0.3125D;
			d11 = -BlockRedstoneRepeater.repeaterTorchOffset[i7];
			break;
		case 2:
			d17 = 0.3125D;
			d13 = -BlockRedstoneRepeater.repeaterTorchOffset[i7];
			break;
		case 3:
			d15 = -0.3125D;
			d11 = BlockRedstoneRepeater.repeaterTorchOffset[i7];
		}

		this.renderTorchAtAngle(block1, (double)i2 + d11, (double)i3 + d9, (double)i4 + d13, 0.0D, 0.0D);
		this.renderTorchAtAngle(block1, (double)i2 + d15, (double)i3 + d9, (double)i4 + d17, 0.0D, 0.0D);
		int i19 = block1.getBlockTextureFromSide(1);
		
		/*
		int i20 = (i19 & 15) << 4;
		int i21 = i19 & 0xff0;
		double u1 = (double)((float)i20 / 256F);
		double u2 = (double)(((float)i20 + 15.99F) / 256F);
		double v1 = (double)((float)i21 / 256F);
		double v2 = (double)(((float)i21 + 15.99F) / 256F);
		*/
		Idx2uvF.calc(i19);
		double u1 = Idx2uvF.u1;
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;

		double d30 = 0.125D;
		double d32 = (double)(i2 + 1);
		double d34 = (double)(i2 + 1);
		double d36 = (double)(i2 + 0);
		double d38 = (double)(i2 + 0);
		double d40 = (double)(i4 + 0);
		double d42 = (double)(i4 + 1);
		double d44 = (double)(i4 + 1);
		double d46 = (double)(i4 + 0);
		double d48 = (double)i3 + d30;
		if(i6 == 2) {
			d32 = d34 = (double)(i2 + 0);
			d36 = d38 = (double)(i2 + 1);
			d40 = d46 = (double)(i4 + 1);
			d42 = d44 = (double)(i4 + 0);
		} else if(i6 == 3) {
			d32 = d38 = (double)(i2 + 0);
			d34 = d36 = (double)(i2 + 1);
			d40 = d42 = (double)(i4 + 0);
			d44 = d46 = (double)(i4 + 1);
		} else if(i6 == 1) {
			d32 = d38 = (double)(i2 + 1);
			d34 = d36 = (double)(i2 + 0);
			d40 = d42 = (double)(i4 + 1);
			d44 = d46 = (double)(i4 + 0);
		}

		tessellator8.addVertexWithUV(d38, d48, d46, u1, v1);
		tessellator8.addVertexWithUV(d36, d48, d44, u1, v2);
		tessellator8.addVertexWithUV(d34, d48, d42, u2, v2);
		tessellator8.addVertexWithUV(d32, d48, d40, u2, v1);
		return true;
	}



	public boolean renderBlockLever(Block block1, int i2, int i3, int i4) {
		int i5 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i6 = i5 & 7;
		boolean z7 = (i5 & 8) > 0;
		Tessellator tessellator8 = Tessellator.instance;
		boolean z9 = this.overrideBlockTexture >= 0;
		if(!z9) {
			this.overrideBlockTexture = Block.cobblestone.blockIndexInTexture;
		}

		float f10 = 0.25F;
		float f11 = 0.1875F;
		float f12 = 0.1875F;
		if(i6 == 5) {
			block1.setBlockBounds(0.5F - f11, 0.0F, 0.5F - f10, 0.5F + f11, f12, 0.5F + f10);
		} else if(i6 == 6) {
			block1.setBlockBounds(0.5F - f10, 0.0F, 0.5F - f11, 0.5F + f10, f12, 0.5F + f11);
		} else if(i6 == 4) {
			block1.setBlockBounds(0.5F - f11, 0.5F - f10, 1.0F - f12, 0.5F + f11, 0.5F + f10, 1.0F);
		} else if(i6 == 3) {
			block1.setBlockBounds(0.5F - f11, 0.5F - f10, 0.0F, 0.5F + f11, 0.5F + f10, f12);
		} else if(i6 == 2) {
			block1.setBlockBounds(1.0F - f12, 0.5F - f10, 0.5F - f11, 1.0F, 0.5F + f10, 0.5F + f11);
		} else if(i6 == 1) {
			block1.setBlockBounds(0.0F, 0.5F - f10, 0.5F - f11, f12, 0.5F + f10, 0.5F + f11);
		}

		this.renderStandardBlock(block1, i2, i3, i4);
		if(!z9) {
			this.overrideBlockTexture = -1;
		}

		tessellator8.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		float f13 = 1.0F;
		tessellator8.setColorOpaque_F(f13, f13, f13);
		int i14 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i14 = this.overrideBlockTexture;
		}

		/*
		int i15 = (i14 & 15) << 4;
		int i16 = i14 & 0xff0;
		float f17 = (float)i15 / 256F;
		float f18 = ((float)i15 + 15.99F) / 256F;
		float f19 = (float)i16 / 256F;
		float f20 = ((float)i16 + 15.99F) / 256F;
		*/
		Idx2uvF.calc(i14);

		double f17 = (double)Idx2uvF.u1;
		double f18 = (double)Idx2uvF.u2;
		double f19 = (double)Idx2uvF.v1;
		double f20 = (double)Idx2uvF.v2;
		
		Vec3D[] vec3D21 = new Vec3D[8];
		float f22 = 0.0625F;
		float f23 = 0.0625F;
		float f24 = 0.625F;
		vec3D21[0] = Vec3D.createVector((double)(-f22), 0.0D, (double)(-f23));
		vec3D21[1] = Vec3D.createVector((double)f22, 0.0D, (double)(-f23));
		vec3D21[2] = Vec3D.createVector((double)f22, 0.0D, (double)f23);
		vec3D21[3] = Vec3D.createVector((double)(-f22), 0.0D, (double)f23);
		vec3D21[4] = Vec3D.createVector((double)(-f22), (double)f24, (double)(-f23));
		vec3D21[5] = Vec3D.createVector((double)f22, (double)f24, (double)(-f23));
		vec3D21[6] = Vec3D.createVector((double)f22, (double)f24, (double)f23);
		vec3D21[7] = Vec3D.createVector((double)(-f22), (double)f24, (double)f23);

		for(int i25 = 0; i25 < 8; ++i25) {
			if(z7) {
				vec3D21[i25].zCoord -= 0.0625D;
				vec3D21[i25].rotateAroundX((float)Math.PI / 4.5F);
			} else {
				vec3D21[i25].zCoord += 0.0625D;
				vec3D21[i25].rotateAroundX(-0.69813174F);
			}

			if(i6 == 6) {
				vec3D21[i25].rotateAroundY((float)Math.PI / 2F);
			}

			if(i6 < 5) {
				vec3D21[i25].yCoord -= 0.375D;
				vec3D21[i25].rotateAroundX((float)Math.PI / 2F);
				if(i6 == 4) {
					vec3D21[i25].rotateAroundY(0.0F);
				}

				if(i6 == 3) {
					vec3D21[i25].rotateAroundY((float)Math.PI);
				}

				if(i6 == 2) {
					vec3D21[i25].rotateAroundY((float)Math.PI / 2F);
				}

				if(i6 == 1) {
					vec3D21[i25].rotateAroundY(-1.5707964F);
				}

				vec3D21[i25].xCoord += (double)i2 + 0.5D;
				vec3D21[i25].yCoord += (double)((float)i3 + 0.5F);
				vec3D21[i25].zCoord += (double)i4 + 0.5D;
			} else {
				vec3D21[i25].xCoord += (double)i2 + 0.5D;
				vec3D21[i25].yCoord += (double)((float)i3 + 0.125F);
				vec3D21[i25].zCoord += (double)i4 + 0.5D;
			}
		}

		Vec3D vec3D30 = null;
		Vec3D vec3D26 = null;
		Vec3D vec3D27 = null;
		Vec3D vec3D28 = null;

		for(int i29 = 0; i29 < 6; ++i29) {
			if(i29 == 0) {
				/*
				f17 = (float)(i15 + 7) / 256F;
				f18 = ((float)(i15 + 9) - 0.01F) / 256F;
				f19 = (float)(i16 + 6) / 256F;
				f20 = ((float)(i16 + 8) - 0.01F) / 256F;
				*/
				f17 = Idx2uvF.u1 + Texels.texelsU(7.0F);
				f18 = Idx2uvF.u1 + Texels.texelsU(9.0F);
				f19 = Idx2uvF.v1 + Texels.texelsV(6.0F);
				f20 = Idx2uvF.v1 + Texels.texelsV(8.0F);
			} else if(i29 == 2) {
				/*
				f17 = (float)(i15 + 7) / 256F;
				f18 = ((float)(i15 + 9) - 0.01F) / 256F;
				f19 = (float)(i16 + 6) / 256F;
				f20 = ((float)(i16 + 16) - 0.01F) / 256F;
				*/
				f17 = Idx2uvF.u1 + Texels.texelsU(7.0F);
				f18 = Idx2uvF.u1 + Texels.texelsU(9.0F);
				f19 = Idx2uvF.v1 + Texels.texelsV(6.0F);
				f20 = Idx2uvF.v1 + Texels.texelsV(16.0F);
			}

			if(i29 == 0) {
				vec3D30 = vec3D21[0];
				vec3D26 = vec3D21[1];
				vec3D27 = vec3D21[2];
				vec3D28 = vec3D21[3];
			} else if(i29 == 1) {
				vec3D30 = vec3D21[7];
				vec3D26 = vec3D21[6];
				vec3D27 = vec3D21[5];
				vec3D28 = vec3D21[4];
			} else if(i29 == 2) {
				vec3D30 = vec3D21[1];
				vec3D26 = vec3D21[0];
				vec3D27 = vec3D21[4];
				vec3D28 = vec3D21[5];
			} else if(i29 == 3) {
				vec3D30 = vec3D21[2];
				vec3D26 = vec3D21[1];
				vec3D27 = vec3D21[5];
				vec3D28 = vec3D21[6];
			} else if(i29 == 4) {
				vec3D30 = vec3D21[3];
				vec3D26 = vec3D21[2];
				vec3D27 = vec3D21[6];
				vec3D28 = vec3D21[7];
			} else if(i29 == 5) {
				vec3D30 = vec3D21[0];
				vec3D26 = vec3D21[3];
				vec3D27 = vec3D21[7];
				vec3D28 = vec3D21[4];
			}

			tessellator8.addVertexWithUV(vec3D30.xCoord, vec3D30.yCoord, vec3D30.zCoord, (double)f17, (double)f20);
			tessellator8.addVertexWithUV(vec3D26.xCoord, vec3D26.yCoord, vec3D26.zCoord, (double)f18, (double)f20);
			tessellator8.addVertexWithUV(vec3D27.xCoord, vec3D27.yCoord, vec3D27.zCoord, (double)f18, (double)f19);
			tessellator8.addVertexWithUV(vec3D28.xCoord, vec3D28.yCoord, vec3D28.zCoord, (double)f17, (double)f19);
		}

		return true;
	}

	public boolean renderBlockFire(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		tessellator5.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		
		/*
		int i7 = (i6 & 15) << 4;
		int i8 = i6 & 0xff0;
		double d9 = (double)((float)i7 / 256F);
		double d11 = (double)(((float)i7 + 15.99F) / 256F);
		double d13 = (double)((float)i8 / 256F);
		double d15 = (double)(((float)i8 + 15.99F) / 256F);
		*/
		
		Idx2uvF.calc(i6);

		double d9 = (double)Idx2uvF.u1;
		double d11 = (double)Idx2uvF.u2;
		double d13 = (double)Idx2uvF.v1;
		double d15 = (double)Idx2uvF.v2;
		
		float f17 = 1.4F;
		double d20;
		double d22;
		double d24;
		double d26;
		double d28;
		double d30;
		double d32;
		if(!this.blockAccess.isBlockNormalCube(i2, i3 - 1, i4) && !Block.fire.canBlockCatchFire(this.blockAccess, i2, i3 - 1, i4)) {
			float f36 = 0.2F;
			float f19 = 0.0625F;
			if((i2 + i3 + i4 & 1) == 1) {
				/*
				d9 = (double)((float)i7 / 256F);
				d11 = (double)(((float)i7 + 15.99F) / 256F);
				d13 = (double)((float)(i8 + 16) / 256F);
				d15 = (double)(((float)i8 + 15.99F + 16.0F) / 256F);
				*/
				d13 = (double)Idx2uvF.v1 + Texels.texelsV(16.0F);
				d15 = (double)Idx2uvF.v2 + Texels.texelsV(16.0F);
			}

			if((i2 / 2 + i3 / 2 + i4 / 2 & 1) == 1) {
				d20 = d11;
				d11 = d9;
				d9 = d20;
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2 - 1, i3, i4)) {
				tessellator5.addVertexWithUV((double)((float)i2 + f36), (double)((float)i3 + f17 + f19), (double)(i4 + 1), d11, d13);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)((float)i2 + f36), (double)((float)i3 + f17 + f19), (double)(i4 + 0), d9, d13);
				tessellator5.addVertexWithUV((double)((float)i2 + f36), (double)((float)i3 + f17 + f19), (double)(i4 + 0), d9, d13);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1), d11, d15);
				tessellator5.addVertexWithUV((double)((float)i2 + f36), (double)((float)i3 + f17 + f19), (double)(i4 + 1), d11, d13);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2 + 1, i3, i4)) {
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f36), (double)((float)i3 + f17 + f19), (double)(i4 + 0), d9, d13);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1), d11, d15);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f36), (double)((float)i3 + f17 + f19), (double)(i4 + 1), d11, d13);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f36), (double)((float)i3 + f17 + f19), (double)(i4 + 1), d11, d13);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1 - 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)((float)(i2 + 1) - f36), (double)((float)i3 + f17 + f19), (double)(i4 + 0), d9, d13);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3, i4 - 1)) {
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17 + f19), (double)((float)i4 + f36), d11, d13);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17 + f19), (double)((float)i4 + f36), d9, d13);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17 + f19), (double)((float)i4 + f36), d9, d13);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 0), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17 + f19), (double)((float)i4 + f36), d11, d13);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3, i4 + 1)) {
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17 + f19), (double)((float)(i4 + 1) - f36), d9, d13);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f19), (double)(i4 + 1 - 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1 - 0), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17 + f19), (double)((float)(i4 + 1) - f36), d11, d13);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17 + f19), (double)((float)(i4 + 1) - f36), d11, d13);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 0) + f19), (double)(i4 + 1 - 0), d11, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 0) + f19), (double)(i4 + 1 - 0), d9, d15);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17 + f19), (double)((float)(i4 + 1) - f36), d9, d13);
			}

			if(Block.fire.canBlockCatchFire(this.blockAccess, i2, i3 + 1, i4)) {
				d20 = (double)i2 + 0.5D + 0.5D;
				d22 = (double)i2 + 0.5D - 0.5D;
				d24 = (double)i4 + 0.5D + 0.5D;
				d26 = (double)i4 + 0.5D - 0.5D;
				d28 = (double)i2 + 0.5D - 0.5D;
				d30 = (double)i2 + 0.5D + 0.5D;
				d32 = (double)i4 + 0.5D - 0.5D;
				double d34 = (double)i4 + 0.5D + 0.5D;
				
				/*
				d9 = (double)((float)i7 / 256F);
				d11 = (double)(((float)i7 + 15.99F) / 256F);
				d13 = (double)((float)i8 / 256F);
				d15 = (double)(((float)i8 + 15.99F) / 256F);
				*/
				d9 = (double)Idx2uvF.u1;
				d11 = (double)Idx2uvF.u2;
				d13 = (double)Idx2uvF.v1;
				d15 = (double)Idx2uvF.v2;
				
				++i3;
				f17 = -0.2F;
				if((i2 + i3 + i4 & 1) == 0) {
					tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 0), d11, d13);
					tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 0), d11, d15);
					tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 1), d9, d15);
					tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 1), d9, d13);
					
					/*
					d9 = (double)((float)i7 / 256F);
					d11 = (double)(((float)i7 + 15.99F) / 256F);
					d13 = (double)((float)(i8 + 16) / 256F);
					d15 = (double)(((float)i8 + 15.99F + 16.0F) / 256F);
					*/
					d13 = (double)Idx2uvF.v1 + Texels.texelsV(16.0F);
					d15 = (double)Idx2uvF.v2 + Texels.texelsV(16.0F);
					
					tessellator5.addVertexWithUV(d30, (double)((float)i3 + f17), (double)(i4 + 1), d11, d13);
					tessellator5.addVertexWithUV(d22, (double)(i3 + 0), (double)(i4 + 1), d11, d15);
					tessellator5.addVertexWithUV(d22, (double)(i3 + 0), (double)(i4 + 0), d9, d15);
					tessellator5.addVertexWithUV(d30, (double)((float)i3 + f17), (double)(i4 + 0), d9, d13);
				} else {
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d34, d11, d13);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d26, d11, d15);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d26, d9, d15);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d34, d9, d13);
					/*
					d9 = (double)((float)i7 / 256F);
					d11 = (double)(((float)i7 + 15.99F) / 256F);
					d13 = (double)((float)(i8 + 16) / 256F);
					d15 = (double)(((float)i8 + 15.99F + 16.0F) / 256F);
					*/
					d13 = (double)Idx2uvF.v1 + Texels.texelsV(16.0F);
					d15 = (double)Idx2uvF.v2 + Texels.texelsV(16.0F);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d32, d11, d13);
					tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d24, d11, d15);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d24, d9, d15);
					tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d32, d9, d13);
				}
			}
		} else {
			double d18 = (double)i2 + 0.5D + 0.2D;
			d20 = (double)i2 + 0.5D - 0.2D;
			d22 = (double)i4 + 0.5D + 0.2D;
			d24 = (double)i4 + 0.5D - 0.2D;
			d26 = (double)i2 + 0.5D - 0.3D;
			d28 = (double)i2 + 0.5D + 0.3D;
			d30 = (double)i4 + 0.5D - 0.3D;
			d32 = (double)i4 + 0.5D + 0.3D;
			tessellator5.addVertexWithUV(d26, (double)((float)i3 + f17), (double)(i4 + 1), d11, d13);
			tessellator5.addVertexWithUV(d18, (double)(i3 + 0), (double)(i4 + 1), d11, d15);
			tessellator5.addVertexWithUV(d18, (double)(i3 + 0), (double)(i4 + 0), d9, d15);
			tessellator5.addVertexWithUV(d26, (double)((float)i3 + f17), (double)(i4 + 0), d9, d13);
			tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 0), d11, d13);
			tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 0), d11, d15);
			tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 1), d9, d15);
			tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 1), d9, d13);
			
			/*
			d9 = (double)((float)i7 / 256F);
			d11 = (double)(((float)i7 + 15.99F) / 256F);
			d13 = (double)((float)(i8 + 16) / 256F);
			d15 = (double)(((float)i8 + 15.99F + 16.0F) / 256F);
			*/
			d13 = (double)Idx2uvF.v1 + Texels.texelsV(16.0F);
			d15 = (double)Idx2uvF.v2 + Texels.texelsV(16.0F);
			
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d32, d11, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d24, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d24, d9, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d32, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d30, d11, d13);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d22, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d22, d9, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d30, d9, d13);
			d18 = (double)i2 + 0.5D - 0.5D;
			d20 = (double)i2 + 0.5D + 0.5D;
			d22 = (double)i4 + 0.5D - 0.5D;
			d24 = (double)i4 + 0.5D + 0.5D;
			d26 = (double)i2 + 0.5D - 0.4D;
			d28 = (double)i2 + 0.5D + 0.4D;
			d30 = (double)i4 + 0.5D - 0.4D;
			d32 = (double)i4 + 0.5D + 0.4D;
			tessellator5.addVertexWithUV(d26, (double)((float)i3 + f17), (double)(i4 + 0), d9, d13);
			tessellator5.addVertexWithUV(d18, (double)(i3 + 0), (double)(i4 + 0), d9, d15);
			tessellator5.addVertexWithUV(d18, (double)(i3 + 0), (double)(i4 + 1), d11, d15);
			tessellator5.addVertexWithUV(d26, (double)((float)i3 + f17), (double)(i4 + 1), d11, d13);
			tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 1), d9, d13);
			tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 1), d9, d15);
			tessellator5.addVertexWithUV(d20, (double)(i3 + 0), (double)(i4 + 0), d11, d15);
			tessellator5.addVertexWithUV(d28, (double)((float)i3 + f17), (double)(i4 + 0), d11, d13);
			
			/*
			d9 = (double)((float)i7 / 256F);
			d11 = (double)(((float)i7 + 15.99F) / 256F);
			d13 = (double)((float)i8 / 256F);
			d15 = (double)(((float)i8 + 15.99F) / 256F);
			*/
			d13 = (double)Idx2uvF.v1;
			d15 = (double)Idx2uvF.v2;
			
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d32, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d24, d9, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d24, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d32, d11, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)i3 + f17), d30, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), d22, d9, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), d22, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)i3 + f17), d30, d11, d13);
		}

		return true;
	}

	public boolean renderBlockRedstoneWire(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		
		int i7 = block1.getBlockTextureFromSideAndMetadata(1, i6);
		if(this.overrideBlockTexture >= 0) {
			i7 = this.overrideBlockTexture;
		}

		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		float f8 = 1.0F;
		float f9 = (float)i6 / 15.0F;
		float f10 = f9 * 0.6F + 0.4F;
		if(i6 == 0) {
			f10 = 0.3F;
		}

		float f11 = f9 * f9 * 0.7F - 0.5F;
		float f12 = f9 * f9 * 0.6F - 0.7F;
		if(f11 < 0.0F) {
			f11 = 0.0F;
		}

		if(f12 < 0.0F) {
			f12 = 0.0F;
		}

		tessellator5.setColorOpaque_F(f10, f11, f12);
		/*
		int i13 = (i7 & 15) << 4;
		int i14 = i7 & 0xff0;
		double u1 = (double)((float)i13 / TextureAtlasSize.w);
		double u2 = (double)(((float)i13 + 15.99F) / TextureAtlasSize.w);
		double v1 = (double)((float)i14 / TextureAtlasSize.h);
		double v2 = (double)(((float)i14 + 15.99F) / TextureAtlasSize.h);
		*/
		Idx2uvF.calc(i7);

		double u1 = (double)Idx2uvF.u1;
		double u2 = (double)Idx2uvF.u2;
		double v1 = (double)Idx2uvF.v1;
		double v2 = (double)Idx2uvF.v2;
		
		double u10 = u1; 
		double u20 = u2;	
		
		boolean z29 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3, i4, 1) || !this.blockAccess.isBlockNormalCube(i2 - 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3 - 1, i4, -1);
		boolean z30 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3, i4, 3) || !this.blockAccess.isBlockNormalCube(i2 + 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3 - 1, i4, -1);
		boolean z31 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3, i4 - 1, 2) || !this.blockAccess.isBlockNormalCube(i2, i3, i4 - 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 - 1, i4 - 1, -1);
		boolean z32 = BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3, i4 + 1, 0) || !this.blockAccess.isBlockNormalCube(i2, i3, i4 + 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 - 1, i4 + 1, -1);
		if(!this.blockAccess.isBlockNormalCube(i2, i3 + 1, i4)) {
			if(this.blockAccess.isBlockNormalCube(i2 - 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 - 1, i3 + 1, i4, -1)) {
				z29 = true;
			}

			if(this.blockAccess.isBlockNormalCube(i2 + 1, i3, i4) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2 + 1, i3 + 1, i4, -1)) {
				z30 = true;
			}

			if(this.blockAccess.isBlockNormalCube(i2, i3, i4 - 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 + 1, i4 - 1, -1)) {
				z31 = true;
			}

			if(this.blockAccess.isBlockNormalCube(i2, i3, i4 + 1) && BlockRedstoneWire.isPowerProviderOrWire(this.blockAccess, i2, i3 + 1, i4 + 1, -1)) {
				z32 = true;
			}
		}

		float f34 = (float)(i2 + 0);
		float f35 = (float)(i2 + 1);
		float f36 = (float)(i4 + 0);
		float f37 = (float)(i4 + 1);
		byte b38 = 0;
		if((z29 || z30) && !z31 && !z32) {
			b38 = 1;
		}

		if((z31 || z32) && !z30 && !z29) {
			b38 = 2;
		}

		if(b38 != 0) {
			u1 = u10 + Texels.texelsU(16.0F);
			u2 = u20 + Texels.texelsU(16.0F);
		}

		if(b38 == 0) {
			if(!z29) {
				f34 += 0.3125F;
				}

			if(!z29) {
				u1 += Texels.texelsU(5); // 0.01953125D;
				}

			if(!z30) {
				f35 -= 0.3125F;
				}

			if(!z30) {
				u2 -= Texels.texelsU(5); // 0.01953125D;
				}

			if(!z31) {
				f36 += 0.3125F;
				}

			if(!z31) {
				v1 += Texels.texelsV(5); // 0.01953125D;
				}

			if(!z32) {
				f37 -= 0.3125F;
				}

			if(!z32) {
				v2 -= Texels.texelsV(5); // 0.01953125D;
			}

			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f37, u2, v2);
			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f36, u2, v1);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f36, u1, v1);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f37, u1, v2);
		} else if(b38 == 1) {
			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f37, u2, v2);
			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f36, u2, v1);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f36, u1, v1);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f37, u1, v2);
		} else if(b38 == 2) {
			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f37, u2, v2);
			tessellator5.addVertexWithUV((double)f35, (double)i3 + 0.015625D, (double)f36, u1, v2);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f36, u1, v1);
			tessellator5.addVertexWithUV((double)f34, (double)i3 + 0.015625D, (double)f37, u2, v1);
		}

		if(!this.blockAccess.isBlockNormalCube(i2, i3 + 1, i4)) {
			u1 = u10 + Texels.texelsU(16.0F);
			u2 = u20 + Texels.texelsU(16.0F);
			
			if(this.blockAccess.isBlockNormalCube(i2 - 1, i3, i4) && this.blockAccess.getBlockID(i2 - 1, i3 + 1, i4) == Block.redstoneWire.blockID) {
				tessellator5.setColorOpaque_F(f8 * f10, f8 * f11, f8 * f12);
				tessellator5.addVertexWithUV((double)i2 + 0.015625D, (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 1), u2, v1);
				tessellator5.addVertexWithUV((double)i2 + 0.015625D, (double)(i3 + 0), (double)(i4 + 1), u1, v1);
				tessellator5.addVertexWithUV((double)i2 + 0.015625D, (double)(i3 + 0), (double)(i4 + 0), u1, v2);
				tessellator5.addVertexWithUV((double)i2 + 0.015625D, (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 0), u2, v2);
			}

			if(this.blockAccess.isBlockNormalCube(i2 + 1, i3, i4) && this.blockAccess.getBlockID(i2 + 1, i3 + 1, i4) == Block.redstoneWire.blockID) {
				tessellator5.setColorOpaque_F(f8 * f10, f8 * f11, f8 * f12);
				tessellator5.addVertexWithUV((double)(i2 + 1) - 0.015625D, (double)(i3 + 0), (double)(i4 + 1), u1, v2);
				tessellator5.addVertexWithUV((double)(i2 + 1) - 0.015625D, (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 1), u2, v2);
				tessellator5.addVertexWithUV((double)(i2 + 1) - 0.015625D, (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 0), u2, v1);
				tessellator5.addVertexWithUV((double)(i2 + 1) - 0.015625D, (double)(i3 + 0), (double)(i4 + 0), u1, v1);
			}

			if(this.blockAccess.isBlockNormalCube(i2, i3, i4 - 1) && this.blockAccess.getBlockID(i2, i3 + 1, i4 - 1) == Block.redstoneWire.blockID) {
				tessellator5.setColorOpaque_F(f8 * f10, f8 * f11, f8 * f12);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), (double)i4 + 0.015625D, u1, v2);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 1) + 0.021875F), (double)i4 + 0.015625D, u2, v2);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 1) + 0.021875F), (double)i4 + 0.015625D, u2, v1);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), (double)i4 + 0.015625D, u1, v1);
			}

			if(this.blockAccess.isBlockNormalCube(i2, i3, i4 + 1) && this.blockAccess.getBlockID(i2, i3 + 1, i4 + 1) == Block.redstoneWire.blockID) {
				tessellator5.setColorOpaque_F(f8 * f10, f8 * f11, f8 * f12);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 1) - 0.015625D, u2, v1);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)(i3 + 0), (double)(i4 + 1) - 0.015625D, u1, v1);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)(i3 + 0), (double)(i4 + 1) - 0.015625D, u1, v2);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)((float)(i3 + 1) + 0.021875F), (double)(i4 + 1) - 0.015625D, u2, v2);
			}
		}

		return true;
	}

	public boolean renderBlockMinecartTrack(BlockRail blockRail1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		int i7 = blockRail1.getBlockTextureFromSideAndMetadata(0, i6);
		if(this.overrideBlockTexture >= 0) {
			i7 = this.overrideBlockTexture;
		}

		if(blockRail1.isPowered()) {
			i6 &= 7;
		}

		tessellator5.setBrightness(blockRail1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		tessellator5.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		/*
		int i8 = (i7 & 15) << 4;
		int i9 = i7 & 0xff0;
		double d10 = (double)((float)i8 / 256F);
		double d12 = (double)(((float)i8 + 15.99F) / 256F);
		double d14 = (double)((float)i9 / 256F);
		double d16 = (double)(((float)i9 + 15.99F) / 256F);
		*/
		Idx2uvF.calc(i7);
		double d10 = Idx2uvF.u1;
		double d12 = Idx2uvF.u2;
		double d14 = Idx2uvF.v1;
		double d16 = Idx2uvF.v2;
		
		double d18 = 0.0625D;
		double d20 = (double)(i2 + 1);
		double d22 = (double)(i2 + 1);
		double d24 = (double)(i2 + 0);
		double d26 = (double)(i2 + 0);
		double d28 = (double)(i4 + 0);
		double d30 = (double)(i4 + 1);
		double d32 = (double)(i4 + 1);
		double d34 = (double)(i4 + 0);
		double d36 = (double)i3 + d18;
		double d38 = (double)i3 + d18;
		double d40 = (double)i3 + d18;
		double d42 = (double)i3 + d18;
		if(i6 != 1 && i6 != 2 && i6 != 3 && i6 != 7) {
			if(i6 == 8) {
				d20 = d22 = (double)(i2 + 0);
				d24 = d26 = (double)(i2 + 1);
				d28 = d34 = (double)(i4 + 1);
				d30 = d32 = (double)(i4 + 0);
			} else if(i6 == 9) {
				d20 = d26 = (double)(i2 + 0);
				d22 = d24 = (double)(i2 + 1);
				d28 = d30 = (double)(i4 + 0);
				d32 = d34 = (double)(i4 + 1);
			}
		} else {
			d20 = d26 = (double)(i2 + 1);
			d22 = d24 = (double)(i2 + 0);
			d28 = d30 = (double)(i4 + 1);
			d32 = d34 = (double)(i4 + 0);
		}

		if(i6 != 2 && i6 != 4) {
			if(i6 == 3 || i6 == 5) {
				++d38;
				++d40;
			}
		} else {
			++d36;
			++d42;
		}

		tessellator5.addVertexWithUV(d20, d36, d28, d12, d14);
		tessellator5.addVertexWithUV(d22, d38, d30, d12, d16);
		tessellator5.addVertexWithUV(d24, d40, d32, d10, d16);
		tessellator5.addVertexWithUV(d26, d42, d34, d10, d14);
		tessellator5.addVertexWithUV(d26, d42, d34, d10, d14);
		tessellator5.addVertexWithUV(d24, d40, d32, d10, d16);
		tessellator5.addVertexWithUV(d22, d38, d30, d12, d16);
		tessellator5.addVertexWithUV(d20, d36, d28, d12, d14);
		return true;
	}

	public boolean renderBlockLadder(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		float f7 = 1.0F;
		tessellator5.setColorOpaque_F(f7, f7, f7);
		
		/*
		int i22 = (i6 & 15) << 4;
		int i8 = i6 & 0xff0;
		double d9 = (double)((float)i22 / 256F);
		double d11 = (double)(((float)i22 + 15.99F) / 256F);
		double d13 = (double)((float)i8 / 256F);
		double d15 = (double)(((float)i8 + 15.99F) / 256F);
		*/
		
		Idx2uvF.calc(i6);
		double d9 = Idx2uvF.u1;
		double d11 = Idx2uvF.u2;
		double d13 = Idx2uvF.v1;
		double d15 = Idx2uvF.v2;
		
		int i17 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		double d18 = 0.0D;
		double d20 = (double)0.05F;
		if(i17 == 5) {
			tessellator5.addVertexWithUV((double)i2 + d20, (double)(i3 + 1) + d18, (double)(i4 + 1) + d18, d9, d13);
			tessellator5.addVertexWithUV((double)i2 + d20, (double)(i3 + 0) - d18, (double)(i4 + 1) + d18, d9, d15);
			tessellator5.addVertexWithUV((double)i2 + d20, (double)(i3 + 0) - d18, (double)(i4 + 0) - d18, d11, d15);
			tessellator5.addVertexWithUV((double)i2 + d20, (double)(i3 + 1) + d18, (double)(i4 + 0) - d18, d11, d13);
		}

		if(i17 == 4) {
			tessellator5.addVertexWithUV((double)(i2 + 1) - d20, (double)(i3 + 0) - d18, (double)(i4 + 1) + d18, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1) - d20, (double)(i3 + 1) + d18, (double)(i4 + 1) + d18, d11, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1) - d20, (double)(i3 + 1) + d18, (double)(i4 + 0) - d18, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1) - d20, (double)(i3 + 0) - d18, (double)(i4 + 0) - d18, d9, d15);
		}

		if(i17 == 3) {
			tessellator5.addVertexWithUV((double)(i2 + 1) + d18, (double)(i3 + 0) - d18, (double)i4 + d20, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 1) + d18, (double)(i3 + 1) + d18, (double)i4 + d20, d11, d13);
			tessellator5.addVertexWithUV((double)(i2 + 0) - d18, (double)(i3 + 1) + d18, (double)i4 + d20, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 0) - d18, (double)(i3 + 0) - d18, (double)i4 + d20, d9, d15);
		}

		if(i17 == 2) {
			tessellator5.addVertexWithUV((double)(i2 + 1) + d18, (double)(i3 + 1) + d18, (double)(i4 + 1) - d20, d9, d13);
			tessellator5.addVertexWithUV((double)(i2 + 1) + d18, (double)(i3 + 0) - d18, (double)(i4 + 1) - d20, d9, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0) - d18, (double)(i3 + 0) - d18, (double)(i4 + 1) - d20, d11, d15);
			tessellator5.addVertexWithUV((double)(i2 + 0) - d18, (double)(i3 + 1) + d18, (double)(i4 + 1) - d20, d11, d13);
		}

		return true;
	}
	
	public boolean renderBlockVine(Block block, int i, int j, int k) {
		Tessellator tessellator = Tessellator.instance;
		int l = block.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			l = this.overrideBlockTexture;
		}

		tessellator.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, i, j, k));
		
		int var7 = block.colorMultiplier(this.blockAccess, i, j, k);
		float var8 = (float)(var7 >> 16 & 255) / 255.0F;
		float var9 = (float)(var7 >> 8 & 255) / 255.0F;
		float var10 = (float)(var7 & 255) / 255.0F;
		
		tessellator.setColorOpaque_F(var8, var9, var10);
		
		/*
		int i11 = (l & 15) << 4;
		int i12 = l & 240;
		double d = (double)((float)i11 / 256.0F);
		double d1 = (double)(((float)i11 + 15.99F) / 256.0F);
		double d2 = (double)((float)i12 / 256.0F);
		double d3 = (double)(((float)i12 + 15.99F) / 256.0F);
		*/
		Idx2uvF.calc(l);
		double d = Idx2uvF.u1;
		double d1 = Idx2uvF.u2;
		double d2 = Idx2uvF.v1;
		double d3 = Idx2uvF.v2;
		
		double d4 = 0.05D;
		
		int meta = this.blockAccess.getBlockMetadata(i, j, k);
		
		if ((meta & 2) != 0) {
			tessellator.addVertexWithUV((double)i + d4, j + 1, k + 1, d, d2);
			tessellator.addVertexWithUV((double)i + d4, j + 0, k + 1, d, d3);
			tessellator.addVertexWithUV((double)i + d4, j + 0, k + 0, d1, d3);
			tessellator.addVertexWithUV((double)i + d4, j + 1, k + 0, d1, d2);
			tessellator.addVertexWithUV((double)i + d4, j + 1, k + 0, d1, d2);
			tessellator.addVertexWithUV((double)i + d4, j + 0, k + 0, d1, d3);
			tessellator.addVertexWithUV((double)i + d4, j + 0, k + 1, d, d3);
			tessellator.addVertexWithUV((double)i + d4, j + 1, k + 1, d, d2);
		}

		if ((meta & 8) != 0) {
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 0, k + 1, d1, d3);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 1, k + 1, d1, d2);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 1, k + 0, d, d2);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 0, k + 0, d, d3);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 0, k + 0, d, d3);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 1, k + 0, d, d2);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 1, k + 1, d1, d2);
			tessellator.addVertexWithUV((double)(i + 1) - d4, j + 0, k + 1, d1, d3);
		}

		if ((meta & 4) != 0) {
			tessellator.addVertexWithUV(i + 1, j + 0, (double)k + d4, d1, d3);
			tessellator.addVertexWithUV(i + 1, j + 1, (double)k + d4, d1, d2);
			tessellator.addVertexWithUV(i + 0, j + 1, (double)k + d4, d, d2);
			tessellator.addVertexWithUV(i + 0, j + 0, (double)k + d4, d, d3);
			tessellator.addVertexWithUV(i + 0, j + 0, (double)k + d4, d, d3);
			tessellator.addVertexWithUV(i + 0, j + 1, (double)k + d4, d, d2);
			tessellator.addVertexWithUV(i + 1, j + 1, (double)k + d4, d1, d2);
			tessellator.addVertexWithUV(i + 1, j + 0, (double)k + d4, d1, d3);
		}

		if ((meta & 1) != 0) {
			tessellator.addVertexWithUV(i + 1, j + 1, (double)(k + 1) - d4, d, d2);
			tessellator.addVertexWithUV(i + 1, j + 0, (double)(k + 1) - d4, d, d3);
			tessellator.addVertexWithUV(i + 0, j + 0, (double)(k + 1) - d4, d1, d3);
			tessellator.addVertexWithUV(i + 0, j + 1, (double)(k + 1) - d4, d1, d2);
			tessellator.addVertexWithUV(i + 0, j + 1, (double)(k + 1) - d4, d1, d2);
			tessellator.addVertexWithUV(i + 0, j + 0, (double)(k + 1) - d4, d1, d3);
			tessellator.addVertexWithUV(i + 1, j + 0, (double)(k + 1) - d4, d, d3);
			tessellator.addVertexWithUV(i + 1, j + 1, (double)(k + 1) - d4, d, d2);
		}
		
		if(this.blockAccess.isBlockNormalCube(i, j + 1, k)) {
			tessellator.addVertexWithUV((double)(i + 1), (double)(j + 1) - d4, (double)(k + 0), d, d2);
			tessellator.addVertexWithUV((double)(i + 1), (double)(j + 1) - d4, (double)(k + 1), d, d3);
			tessellator.addVertexWithUV((double)(i + 0), (double)(j + 1) - d4, (double)(k + 1), d1, d3);
			tessellator.addVertexWithUV((double)(i + 0), (double)(j + 1) - d4, (double)(k + 0), d1, d2);
		}
		
		return true;
	}
	
	public boolean renderBlockPane(BlockPane block, int x, int y, int z) { 
		int maxHeight = 128;
		Tessellator tessellator6 = Tessellator.instance;
		tessellator6.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));

		float light = 1.0F;
		int rgbai = block.colorMultiplier(this.blockAccess, x, y, z);
		float r = (float)(rgbai >> 16 & 255) / 255.0F;
		float g = (float)(rgbai >> 8 & 255) / 255.0F;
		float b = (float)(rgbai & 255) / 255.0F;
		
		tessellator6.setColorOpaque_F(light * r, light * g, light * b);
		int texFace;
		int texSide;

		if(this.overrideBlockTexture >= 0) {
			texFace = this.overrideBlockTexture;
			texSide = this.overrideBlockTexture;
		} else {
			int meta = this.blockAccess.getBlockMetadata(x, y, z);
			texFace = block.getBlockTextureFromSideAndMetadata(0, meta);
			texSide = block.getSideTextureIndex();
		}

		int texX = (texFace & 15) << 4;
		int texY = texFace & 0xff0;
		double faceU1 = (double)((float)texX / TextureAtlasSize.w);
		double faceU2 = (double)(((float)texX + 7.99F) / TextureAtlasSize.w);
		double faceU3 = (double)(((float)texX + 15.99F) / TextureAtlasSize.w);
		double faceV1 = (double)((float)texY / TextureAtlasSize.h);
		double faceV2 = (double)(((float)texY + 15.99F) / TextureAtlasSize.h);

		texX = (texSide & 15) << 4;
		texY = texSide & 0xff0;
		double sideU1 = (double)((float)(texX + 7) / TextureAtlasSize.w);
		double sideU2 = (double)(((float)texX + 8.99F) / TextureAtlasSize.w);
		double sideV3 = (double)((float)texY / TextureAtlasSize.h);
		double sideV1 = (double)((float)(texY + 8) / TextureAtlasSize.h);
		double sideV2 = (double)(((float)texY + 15.99F) / TextureAtlasSize.h);
		
		double dX1 = (double)x;
		double dXh = (double)x + 0.5D;
		double dX2 = (double)(x + 1);
		double dZ1 = (double)z;
		double dZh = (double)z + 0.5D;
		double dZ2 = (double)(z + 1);
		double dXc1 = (double)x + 0.5D - 0.0625D;
		double dXc2 = (double)x + 0.5D + 0.0625D;
		double dZc1 = (double)z + 0.5D - 0.0625D;
		double dZc2 = (double)z + 0.5D + 0.0625D;
		
		boolean connectN = block.canThisPaneConnectToThisblockID(this.blockAccess.getBlockID(x, y, z - 1));
		boolean connectS = block.canThisPaneConnectToThisblockID(this.blockAccess.getBlockID(x, y, z + 1));
		boolean connectW = block.canThisPaneConnectToThisblockID(this.blockAccess.getBlockID(x - 1, y, z));
		boolean connectE = block.canThisPaneConnectToThisblockID(this.blockAccess.getBlockID(x + 1, y, z));
		boolean renderTop = block.shouldSideBeRendered(this.blockAccess, x, y + 1, z, 1);
		boolean renderBottom = block.shouldSideBeRendered(this.blockAccess, x, y - 1, z, 0);

		if((!connectW || !connectE) && (connectW || connectE || connectN || connectS)) {
			// Not both sides W/E at the same time
			if(connectW && !connectE) {
				tessellator6.addVertexWithUV(dX1, (double)(y + 1), dZh, faceU1, faceV1);
				tessellator6.addVertexWithUV(dX1, (double)(y + 0), dZh, faceU1, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU2, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU1, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU1, faceV2);
				tessellator6.addVertexWithUV(dX1, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dX1, (double)(y + 1), dZh, faceU2, faceV1);
				if(!connectS && !connectN) {
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc2, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc1, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc1, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc2, sideU2, sideV3);
				}

				if(renderTop || y < maxHeight - 1 && this.blockAccess.isAirBlock(x - 1, y + 1, z)) {
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
				}

				if(renderBottom || y > 1 && this.blockAccess.isAirBlock(x - 1, y - 1, z)) {
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV1);
				}
			} else if(!connectW && connectE) {
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU2, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dX2, (double)(y + 0), dZh, faceU3, faceV2);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1), dZh, faceU3, faceV1);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1), dZh, faceU2, faceV1);
				tessellator6.addVertexWithUV(dX2, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU3, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU3, faceV1);
				if(!connectS && !connectN) {
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc2, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZc1, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZc1, sideU2, sideV3);
				}

				if(renderTop || y < maxHeight - 1 && this.blockAccess.isAirBlock(x + 1, y + 1, z)) {
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
				}

				if(renderBottom || y > 1 && this.blockAccess.isAirBlock(x + 1, y - 1, z)) {
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV3);
				}
			}
		} else {
			// Both sides W/E at the same time

			tessellator6.addVertexWithUV(dX1, (double)(y + 1), dZh, faceU1, faceV1);
			tessellator6.addVertexWithUV(dX1, (double)(y + 0), dZh, faceU1, faceV2);
			tessellator6.addVertexWithUV(dX2, (double)(y + 0), dZh, faceU3, faceV2);
			tessellator6.addVertexWithUV(dX2, (double)(y + 1), dZh, faceU3, faceV1);
			tessellator6.addVertexWithUV(dX2, (double)(y + 1), dZh, faceU1, faceV1);
			tessellator6.addVertexWithUV(dX2, (double)(y + 0), dZh, faceU1, faceV2);
			tessellator6.addVertexWithUV(dX1, (double)(y + 0), dZh, faceU3, faceV2);
			tessellator6.addVertexWithUV(dX1, (double)(y + 1), dZh, faceU3, faceV1);
			if(renderTop) {
				tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
			} else {
				if(y < maxHeight - 1 && this.blockAccess.isAirBlock(x - 1, y + 1, z)) {
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
				}

				if(y < maxHeight - 1 && this.blockAccess.isAirBlock(x + 1, y + 1, z)) {
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)(y + 1) + 0.01D, dZc1, sideU1, sideV3);
				}
			}

			if(renderBottom) {
				tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV2);
				tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV2);
			} else {
				if(y > 1 && this.blockAccess.isAirBlock(x - 1, y - 1, z)) {
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dX1, (double)y - 0.01D, dZc1, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV1);
				}

				if(y > 1 && this.blockAccess.isAirBlock(x + 1, y - 1, z)) {
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc2, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc2, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXh, (double)y - 0.01D, dZc1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dX2, (double)y - 0.01D, dZc1, sideU1, sideV3);
				}
			}
		}

		if((!connectN || !connectS) && (connectW || connectE || connectN || connectS)) {
			// Not both sides N/S at the same time
			if(connectN && !connectS) {
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ1, faceU1, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ1, faceU1, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU2, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU1, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU1, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ1, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ1, faceU2, faceV1);
				if(!connectE && !connectW) {
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 0), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 0), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 0), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 0), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV3);
				}

				if(renderTop || y < maxHeight - 1 && this.blockAccess.isAirBlock(x, y + 1, z - 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV3);
				}

				if(renderBottom || y > 1 && this.blockAccess.isAirBlock(x, y - 1, z - 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU1, sideV3);
				}
			} else if(!connectN && connectS) {
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU2, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ2, faceU3, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ2, faceU3, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ2, faceU2, faceV1);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ2, faceU2, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZh, faceU3, faceV2);
				tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZh, faceU3, faceV1);
				if(!connectE && !connectW) {
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 0), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 0), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 0), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 0), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV3);
				}

				if(renderTop || y < maxHeight - 1 && this.blockAccess.isAirBlock(x, y + 1, z + 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV1);
				}

				if(renderBottom || y > 1 && this.blockAccess.isAirBlock(x, y - 1, z + 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV1);
				}
			}
		} else {
			// Both sides N/S at the same time
			tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ2, faceU1, faceV1);
			tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ2, faceU1, faceV2);
			tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ1, faceU3, faceV2);
			tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ1, faceU3, faceV1);
			tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ1, faceU1, faceV1);
			tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ1, faceU1, faceV2);
			tessellator6.addVertexWithUV(dXh, (double)(y + 0), dZ2, faceU3, faceV2);
			tessellator6.addVertexWithUV(dXh, (double)(y + 1), dZ2, faceU3, faceV1);
			if(renderTop) {
				tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU2, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU2, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU1, sideV2);
			} else {
				if(y < maxHeight - 1 && this.blockAccess.isAirBlock(x, y + 1, z - 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ1, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU1, sideV3);
				}

				if(y < maxHeight - 1 && this.blockAccess.isAirBlock(x, y + 1, z + 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZ2, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)(y + 1), dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)(y + 1), dZ2, sideU2, sideV1);
				}
			}

			if(renderBottom) {
				tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU2, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU1, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU2, sideV2);
				tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV3);
				tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU1, sideV2);
			} else {
				if(y > 1 && this.blockAccess.isAirBlock(x, y - 1, z - 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU1, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU2, sideV3);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ1, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ1, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU1, sideV3);
				}

				if(y > 1 && this.blockAccess.isAirBlock(x, y - 1, z + 1)) {
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU2, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZ2, sideU1, sideV1);
					tessellator6.addVertexWithUV(dXc1, (double)y, dZh, sideU1, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZh, sideU2, sideV2);
					tessellator6.addVertexWithUV(dXc2, (double)y, dZ2, sideU2, sideV1);
				}
			}
		}

		return true;
	}

	public boolean drawCrossedSquares(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		int i7 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f8 = (float)(i7 >> 16 & 255) / 255.0F;
		float f9 = (float)(i7 >> 8 & 255) / 255.0F;
		float f10 = (float)(i7 & 255) / 255.0F;
		if(GameRenderer.anaglyphEnable) {
			float f11 = (f8 * 30.0F + f9 * 59.0F + f10 * 11.0F) / 100.0F;
			float f12 = (f8 * 30.0F + f9 * 70.0F) / 100.0F;
			float f13 = (f8 * 30.0F + f10 * 70.0F) / 100.0F;
			f8 = f11;
			f9 = f12;
			f10 = f13;
		}

		tessellator5.setColorOpaque_F(f8, f9, f10);
		double d19 = (double)i2;
		double d20 = (double)i3;
		double d15 = (double)i4;
		if(block1 == Block.tallGrass) {
			long j17 = (long)(i2 * 3129871) ^ (long)i4 * 116129781L ^ (long)i3;
			j17 = j17 * j17 * 42317861L + j17 * 11L;
			d19 += ((double)((float)(j17 >> 16 & 15L) / 15.0F) - 0.5D) * 0.5D;
			d20 += ((double)((float)(j17 >> 20 & 15L) / 15.0F) - 1.0D) * 0.2D;
			d15 += ((double)((float)(j17 >> 24 & 15L) / 15.0F) - 0.5D) * 0.5D;
		}

		this.drawCrossedSquares(block1, this.blockAccess.getBlockMetadata(i2, i3, i4), d19, d20, d15);
		return true;
	}

	public boolean renderBlockCrops(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
		tessellator5.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		this.renderBlockCropsImpl(block1, this.blockAccess.getBlockMetadata(i2, i3, i4), (double)i2, (double)((float)i3 - 0.0625F), (double)i4);
		return true;
	}

	public void renderTorchAtAngle(Block block1, double d2, double d4, double d6, double d8, double d10) {
		Tessellator tessellator12 = Tessellator.instance;
		int i13 = block1.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i13 = this.overrideBlockTexture;
		}

		/*
		int i14 = (i13 & 15) << 4;
		int i15 = i13 & 0xff0;
		
		float f16 = (float)i14 / 256F;
		float f17 = ((float)i14 + 15.99F) / 256F;
		float f18 = (float)i15 / 256F;
		float f19 = ((float)i15 + 15.99F) / 256F;
		
		double d20 = (double)f16 + 7.0D / 256D;
		double d22 = (double)f18 + 6.0D / 256D;
		double d24 = (double)f16 + 9.0D / 256D;
		double d26 = (double)f18 + 8.0D / 256D;
		*/
		Idx2uvF.calc(i13);
		
		double f16 = Idx2uvF.u1;
		double f17 = Idx2uvF.u2;
		double f18 = Idx2uvF.v1;
		double f19 = Idx2uvF.v2;
		
		double d20 = f16 + Texels.texelsU(7.0F);
		double d22 = f18 + Texels.texelsV(6.0F);
		double d24 = f16 + Texels.texelsU(9.0F);
		double d26 = f18 + Texels.texelsV(8.0F);
		
		d2 += 0.5D;
		d6 += 0.5D;
		double d28 = d2 - 0.5D;
		double d30 = d2 + 0.5D;
		double d32 = d6 - 0.5D;
		double d34 = d6 + 0.5D;
		double d36 = 0.0625D;
		double d38 = 0.625D;
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) - d36, d4 + d38, d6 + d10 * (1.0D - d38) - d36, d20, d22);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) - d36, d4 + d38, d6 + d10 * (1.0D - d38) + d36, d20, d26);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) + d36, d4 + d38, d6 + d10 * (1.0D - d38) + d36, d24, d26);
		tessellator12.addVertexWithUV(d2 + d8 * (1.0D - d38) + d36, d4 + d38, d6 + d10 * (1.0D - d38) - d36, d24, d22);
		tessellator12.addVertexWithUV(d2 - d36, d4 + 1.0D, d32, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d2 - d36 + d8, d4 + 0.0D, d32 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d2 - d36 + d8, d4 + 0.0D, d34 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d2 - d36, d4 + 1.0D, d34, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d2 + d36, d4 + 1.0D, d34, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d2 + d8 + d36, d4 + 0.0D, d34 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d2 + d8 + d36, d4 + 0.0D, d32 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d2 + d36, d4 + 1.0D, d32, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d28, d4 + 1.0D, d6 + d36, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d28 + d8, d4 + 0.0D, d6 + d36 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d30 + d8, d4 + 0.0D, d6 + d36 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d30, d4 + 1.0D, d6 + d36, (double)f17, (double)f18);
		tessellator12.addVertexWithUV(d30, d4 + 1.0D, d6 - d36, (double)f16, (double)f18);
		tessellator12.addVertexWithUV(d30 + d8, d4 + 0.0D, d6 - d36 + d10, (double)f16, (double)f19);
		tessellator12.addVertexWithUV(d28 + d8, d4 + 0.0D, d6 - d36 + d10, (double)f17, (double)f19);
		tessellator12.addVertexWithUV(d28, d4 + 1.0D, d6 - d36, (double)f17, (double)f18);
	}

	public void drawCrossedSquares(Block block, int meta, double x, double y, double z) {
		Tessellator tes = Tessellator.instance;
		int texId = block.getBlockTextureFromSideAndMetadata(0, meta);
		if(this.overrideBlockTexture >= 0) {
			texId = this.overrideBlockTexture;
		}

		/*
		int i11 = (texId & 15) << 4;
		int i12 = texId & 0xff0;
		double u1 = (double)((float)i11 / 256F);
		double u2 = (double)(((float)i11 + 15.99F) / 256F);
		double v1 = (double)((float)i12 / 256F);
		double v2 = (double)(((float)i12 + 15.99F) / 256F);
		*/
		Idx2uvF.calc(texId);
		double u1 = Idx2uvF.u1;
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;
		
		double x1 = x + 0.5D - 0.45D;
		double x2 = x + 0.5D + 0.45D;
		double z1 = z + 0.5D - 0.45D;
		double z2 = z + 0.5D + 0.45D;
		tes.addVertexWithUV(x1, y + 1.0D, z1, u1, v1);
		tes.addVertexWithUV(x1, y + 0.0D, z1, u1, v2);
		tes.addVertexWithUV(x2, y + 0.0D, z2, u2, v2);
		tes.addVertexWithUV(x2, y + 1.0D, z2, u2, v1);
		tes.addVertexWithUV(x2, y + 1.0D, z2, u1, v1);
		tes.addVertexWithUV(x2, y + 0.0D, z2, u1, v2);
		tes.addVertexWithUV(x1, y + 0.0D, z1, u2, v2);
		tes.addVertexWithUV(x1, y + 1.0D, z1, u2, v1);
		tes.addVertexWithUV(x1, y + 1.0D, z2, u1, v1);
		tes.addVertexWithUV(x1, y + 0.0D, z2, u1, v2);
		tes.addVertexWithUV(x2, y + 0.0D, z1, u2, v2);
		tes.addVertexWithUV(x2, y + 1.0D, z1, u2, v1);
		tes.addVertexWithUV(x2, y + 1.0D, z1, u1, v1);
		tes.addVertexWithUV(x2, y + 0.0D, z1, u1, v2);
		tes.addVertexWithUV(x1, y + 0.0D, z2, u2, v2);
		tes.addVertexWithUV(x1, y + 1.0D, z2, u2, v1);
	}
	
	public void drawCrossedSquaresDoubleHeight(Block block, int meta, double x, double y, double z) {
		Tessellator tes = Tessellator.instance;
		int texId = block.getBlockTextureFromSideAndMetadata(0, meta);
		if(this.overrideBlockTexture >= 0) {
			texId = this.overrideBlockTexture;
		}

		/*
		int i11 = (texId & 15) << 4;
		int i12 = texId & 240;
		double u1 = (double)((float)i11 / 256.0F);
		double u2 = (double)(((float)i11 + 15.99F) / 256.0F);
		double v1 = (double)((float)i12 / 256.0F);
		double v2 = (double)(((float)i12 + 15.99F) / 256.0F);
		*/
		Idx2uvF.calc(texId);
		double u1 = Idx2uvF.u1;
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;
		
		double x1 = x + 0.5D - (double)0.45F;
		double x2 = x + 0.5D + (double)0.45F;
		double z1 = z + 0.5D - (double)0.45F;
		double z2 = z + 0.5D + (double)0.45F;
		tes.addVertexWithUV(x1, y + 2.0D, z1, u1, v1);
		tes.addVertexWithUV(x1, y + 0.0D, z1, u1, v2);
		tes.addVertexWithUV(x2, y + 0.0D, z2, u2, v2);
		tes.addVertexWithUV(x2, y + 2.0D, z2, u2, v1);
		tes.addVertexWithUV(x2, y + 2.0D, z2, u1, v1);
		tes.addVertexWithUV(x2, y + 0.0D, z2, u1, v2);
		tes.addVertexWithUV(x1, y + 0.0D, z1, u2, v2);
		tes.addVertexWithUV(x1, y + 2.0D, z1, u2, v1);
		tes.addVertexWithUV(x1, y + 2.0D, z2, u1, v1);
		tes.addVertexWithUV(x1, y + 0.0D, z2, u1, v2);
		tes.addVertexWithUV(x2, y + 0.0D, z1, u2, v2);
		tes.addVertexWithUV(x2, y + 2.0D, z1, u2, v1);
		tes.addVertexWithUV(x2, y + 2.0D, z1, u1, v1);
		tes.addVertexWithUV(x2, y + 0.0D, z1, u1, v2);
		tes.addVertexWithUV(x1, y + 0.0D, z2, u2, v2);
		tes.addVertexWithUV(x1, y + 2.0D, z2, u2, v1);
	}

	public boolean renderBlockLilyPad(Block block, int x, int y, int z) {
		Tessellator tessellator = Tessellator.instance;
		
		int textureIndex = block.blockIndexInTexture;
		
		/*

		int j = (i & 0xf) << 4;
		int k = i & 0xff0;
		
		float f = 0.015625F;
		
		float d = (float)j / 256F;
		float d1 = ((float)j + 15.99F) / 256F;
		float d2 = (float)k / 256F;
		float d3 = ((float)k + 15.99F) / 256F;
		*/
		Idx2uvF.calc(textureIndex);
		double u1 = Idx2uvF.u1;
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;
		
		long coordinateHash = (long)(x * 3129871) ^ (long)z * 116129781L ^ (long)y;
		coordinateHash = coordinateHash * coordinateHash * 42317861L + coordinateHash * 11L;
		int variation = (int)((coordinateHash >> 16) & 7L);
		tessellator.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));

		float fX = (float)x + 0.5F;
		float fZ = (float)z + 0.5F;
		float fR1 = (float)(variation & 1) * 0.5F * (float)(1 - variation / 2 % 2 * 2);
		float fR2 = (float)(variation + 1 & 1) * 0.5F * (float)(1 - (variation + 1) / 2 % 2 * 2);
		double fY = (double)y + 0.015625F;
		
		tessellator.addVertexWithUV((double)(fX + fR1 - fR2), fY, (double)(fZ + fR1 + fR2), u1, v1);
		tessellator.addVertexWithUV((double)(fX + fR1 + fR2), fY, (double)(fZ - fR1 + fR2), u2, v1);
		tessellator.addVertexWithUV((double)(fX - fR1 + fR2), fY, (double)(fZ - fR1 - fR2), u2, v2);
		tessellator.addVertexWithUV((double)(fX - fR1 - fR2), fY, (double)(fZ + fR1 - fR2), u1, v2);
		tessellator.addVertexWithUV((double)(fX - fR1 - fR2), fY, (double)(fZ + fR1 - fR2), u1, v2);
		tessellator.addVertexWithUV((double)(fX - fR1 + fR2), fY, (double)(fZ - fR1 - fR2), u2, v2);
		tessellator.addVertexWithUV((double)(fX + fR1 + fR2), fY, (double)(fZ - fR1 + fR2), u2, v1);
		tessellator.addVertexWithUV((double)(fX + fR1 - fR2), fY, (double)(fZ + fR1 + fR2), u1, v1);
		
		// Render a lily flower on top
		if((variation & 4) != 0) {
			this.overrideBlockTexture = 12 * 16 + 2;
			this.drawCrossedSquares(block, x, y, z);
			this.overrideBlockTexture = -1;
		}
		
		return true;
	}

	public void renderBlockCropsImpl(Block block1, int i2, double d3, double d5, double d7) {
		Tessellator tessellator9 = Tessellator.instance;
		int i10 = block1.getBlockTextureFromSideAndMetadata(0, i2);
		if(this.overrideBlockTexture >= 0) {
			i10 = this.overrideBlockTexture;
		}

		/*
		int i11 = (i10 & 15) << 4;
		int i12 = i10 & 0xff0;
		double d13 = (double)((float)i11 / 256F);
		double d15 = (double)(((float)i11 + 15.99F) / 256F);
		double d17 = (double)((float)i12 / 256F);
		double d19 = (double)(((float)i12 + 15.99F) / 256F);
		*/
		Idx2uvF.calc(i10);
		double d13 = Idx2uvF.u1;
		double d15 = Idx2uvF.u2;
		double d17 = Idx2uvF.v1;
		double d19 = Idx2uvF.v2;
		
		double d21 = d3 + 0.5D - 0.25D;
		double d23 = d3 + 0.5D + 0.25D;
		double d25 = d7 + 0.5D - 0.5D;
		double d27 = d7 + 0.5D + 0.5D;
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d15, d17);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d15, d17);
		d21 = d3 + 0.5D - 0.5D;
		d23 = d3 + 0.5D + 0.5D;
		d25 = d7 + 0.5D - 0.25D;
		d27 = d7 + 0.5D + 0.25D;
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d25, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d25, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d25, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d25, d15, d17);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d15, d17);
		tessellator9.addVertexWithUV(d21, d5 + 1.0D, d27, d13, d17);
		tessellator9.addVertexWithUV(d21, d5 + 0.0D, d27, d13, d19);
		tessellator9.addVertexWithUV(d23, d5 + 0.0D, d27, d15, d19);
		tessellator9.addVertexWithUV(d23, d5 + 1.0D, d27, d15, d17);
	}

	public boolean renderBlockFluids(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f7 = (float)(i6 >> 16 & 255) / 255.0F;
		float f8 = (float)(i6 >> 8 & 255) / 255.0F;
		float f9 = (float)(i6 & 255) / 255.0F;
		boolean z10 = block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1);
		boolean z11 = block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0);
		boolean[] z12 = new boolean[]{block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2), block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3), block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4), block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)};
		if(!z10 && !z11 && !z12[0] && !z12[1] && !z12[2] && !z12[3]) {
			return false;
		} else {
			boolean z13 = false;
			float f14 = 0.5F;
			float f15 = 1.0F;
			float f16 = 0.8F;
			float f17 = 0.6F;
			double d18 = 0.0D;
			double d20 = 1.0D;
			Material material22 = block1.blockMaterial;
			int i23 = this.blockAccess.getBlockMetadata(i2, i3, i4);
			
			double d24 = (double)this.getFluidHeight(i2, i3, i4, material22);
			double d26 = (double)this.getFluidHeight(i2, i3, i4 + 1, material22);
			double d28 = (double)this.getFluidHeight(i2 + 1, i3, i4 + 1, material22);
			double d30 = (double)this.getFluidHeight(i2 + 1, i3, i4, material22);

			double d32 = 0.0010000000474974513D;
			int i34;
			int i37;
			if(this.renderAllFaces || z10) {
				z13 = true;
				i34 = block1.getBlockTextureFromSideAndMetadata(1, i23);
				float f35 = (float)BlockFluid.func_293_a(this.blockAccess, i2, i3, i4, material22);
				if(f35 > -999.0F) {
					i34 = block1.getBlockTextureFromSideAndMetadata(2, i23);
				}

				d24 -= d32;
				d26 -= d32;
				d28 -= d32;
				d30 -= d32;

				int i36 = (i34 & 15) << 4;
				    i37 = i34 & 0xff0;

				double uCenter, vCenter;
				
				if(f35 < -999.0F) {
					f35 = 0.0F;
					uCenter = ((double)i36 + 8.0D) / TextureAtlasSize.w;
					vCenter = ((double)i37 + 8.0D) / TextureAtlasSize.h;
				} else {
					uCenter = (double)((float)(i36 + 16) / TextureAtlasSize.w);
					vCenter = (double)((float)(i37 + 16) / TextureAtlasSize.h);
				}

				double d42 = (double)(MathHelper.sin(f35) * 8.0F);
				double d44 = (double)(MathHelper.cos(f35) * 8.0F);

				double u1 = (d44 - d42) / TextureAtlasSize.w;
				double u2 = (d44 + d42) / TextureAtlasSize.w;
				double v1 = (d44 - d42) / TextureAtlasSize.h;
				double v2 = (d44 + d42) / TextureAtlasSize.h;

				tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4));
				float f46 = 1.0F;
				tessellator5.setColorOpaque_F(f15 * f46 * f7, f15 * f46 * f8, f15 * f46 * f9);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)i3 + d24, (double)(i4 + 0), uCenter - u2, vCenter - v1);
				tessellator5.addVertexWithUV((double)(i2 + 0), (double)i3 + d26, (double)(i4 + 1), uCenter - u1, vCenter + v2);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)i3 + d28, (double)(i4 + 1), uCenter + u2, vCenter + v1);
				tessellator5.addVertexWithUV((double)(i2 + 1), (double)i3 + d30, (double)(i4 + 0), uCenter + u1, vCenter - v2);
			}

			if(this.renderAllFaces || z11) {
				tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4));
				float f64 = 1.0F;
				tessellator5.setColorOpaque_F(f14 * f64 * f7, f14 * f64 * f8, f14 * f64 * f9);
				this.renderBottomFace(block1, (double)i2, (double)i3 + d32, (double)i4, block1.getBlockTextureFromSide(0));
				z13 = true;
			}

			for(i34 = 0; i34 < 4; ++i34) {
				int i65 = i2;
				i37 = i4;
				if(i34 == 0) {
					i37 = i4 - 1;
				}

				if(i34 == 1) {
					++i37;
				}

				if(i34 == 2) {
					i65 = i2 - 1;
				}

				if(i34 == 3) {
					++i65;
				}

				if(this.renderAllFaces || z12[i34]) {
					double d41;
					double d43;
					double d45;
					double d47;
					double d49;
					double d51;
					if(i34 == 0) {
						d41 = d24;
						d43 = d30;
						d45 = (double)i2;
						d49 = (double)(i2 + 1);
						d47 = (double)i4 + d32;
						d51 = (double)i4 + d32;
					} else if(i34 == 1) {
						d41 = d28;
						d43 = d26;
						d45 = (double)(i2 + 1);
						d49 = (double)i2;
						d47 = (double)(i4 + 1) - d32;
						d51 = (double)(i4 + 1) - d32;
					} else if(i34 == 2) {
						d41 = d26;
						d43 = d24;
						d45 = (double)i2 + d32;
						d49 = (double)i2 + d32;
						d47 = (double)(i4 + 1);
						d51 = (double)i4;
					} else {
						d41 = d30;
						d43 = d28;
						d45 = (double)(i2 + 1) - d32;
						d49 = (double)(i2 + 1) - d32;
						d47 = (double)i4;
						d51 = (double)(i4 + 1);
					}

					z13 = true;
					int i66 = block1.getBlockTextureFromSideAndMetadata(i34 + 2, i23);
					
					int i39 = (i66 & 15) << 4;
					int i67 = i66 & 0xff0;

					double d53 = (double)((float)(i39 + 0) / TextureAtlasSize.w);
					double d55 = ((double)(i39 + 16) - 0.01D) / TextureAtlasSize.w;
					double d57 = ((double)i67 + (1.0D - d41) * 16.0D) / TextureAtlasSize.h;
					double d59 = ((double)i67 + (1.0D - d43) * 16.0D) / TextureAtlasSize.h;
					double d61 = ((double)(i67 + 16) - 0.01D) / TextureAtlasSize.h;
					
					tessellator5.setBrightness(block1.getMixedBrightnessForBlock(this.blockAccess, i65, i3, i37));
					float f63 = 1.0F;
					if(i34 < 2) {
						f63 *= f16;
					} else {
						f63 *= f17;
					}

					tessellator5.setColorOpaque_F(f15 * f63 * f7, f15 * f63 * f8, f15 * f63 * f9);
					tessellator5.addVertexWithUV(d45, (double)i3 + d41, d47, d53, d57);
					tessellator5.addVertexWithUV(d49, (double)i3 + d43, d51, d55, d59);
					tessellator5.addVertexWithUV(d49, (double)(i3 + 0), d51, d55, d61);
					tessellator5.addVertexWithUV(d45, (double)(i3 + 0), d47, d53, d61);
				}
			}

			block1.minY = d18;
			block1.maxY = d20;
			return z13;
		}
	}

	private float getFluidHeight(int i1, int i2, int i3, Material material4) {
		int i5 = 0;
		float f6 = 0.0F;

		for(int i7 = 0; i7 < 4; ++i7) {
			int i8 = i1 - (i7 & 1);
			int i10 = i3 - (i7 >> 1 & 1);
			if(this.blockAccess.getBlockMaterial(i8, i2 + 1, i10) == material4) {
				return 1.0F;
			}

			Material material11 = this.blockAccess.getBlockMaterial(i8, i2, i10);
			if(material11 != material4) {
				if(!material11.isSolid()) {
					++f6;
					++i5;
				}
			} else {
				int i12 = this.blockAccess.getBlockMetadata(i8, i2, i10);
				if(i12 >= 8 || i12 == 0) {
					f6 += BlockFluid.getFluidHeightPercent(i12) * 10.0F;
					i5 += 10;
				}

				f6 += BlockFluid.getFluidHeightPercent(i12);
				++i5;
			}
		}

		return 1.0F - f6 / (float)i5;
	}

	public void renderBlockFallingSand(Block block1, World world2, int i3, int i4, int i5) {
		float f6 = 0.5F;
		float f7 = 1.0F;
		float f8 = 0.8F;
		float f9 = 0.6F;
		Tessellator tessellator10 = Tessellator.instance;
		tessellator10.startDrawingQuads();
		tessellator10.setBrightness(block1.getMixedBrightnessForBlock(world2, i3, i4, i5));

		tessellator10.setColorOpaque_F(f6, f6, f6);
		this.renderBottomFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(0));
		
		tessellator10.setColorOpaque_F(f7, f7, f7);
		this.renderTopFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(1));
		
		tessellator10.setColorOpaque_F(f8, f8, f8);
		this.renderEastFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(2));
		
		tessellator10.setColorOpaque_F(f8, f8, f8);
		this.renderWestFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(3));

		tessellator10.setColorOpaque_F(f9, f9, f9);
		this.renderNorthFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(4));
		
		tessellator10.setColorOpaque_F(f9, f9, f9);
		this.renderSouthFace(block1, -0.5D, -0.5D, -0.5D, block1.getBlockTextureFromSide(5));
		tessellator10.draw();
	}

	public boolean renderStandardBlock(Block block1, int i2, int i3, int i4) {
		int i5 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f6 = (float)(i5 >> 16 & 255) / 255.0F;
		float f7 = (float)(i5 >> 8 & 255) / 255.0F;
		float f8 = (float)(i5 & 255) / 255.0F;
		if(GameRenderer.anaglyphEnable) {
			float f9 = (f6 * 30.0F + f7 * 59.0F + f8 * 11.0F) / 100.0F;
			float f10 = (f6 * 30.0F + f7 * 70.0F) / 100.0F;
			float f11 = (f6 * 30.0F + f8 * 70.0F) / 100.0F;
			f6 = f9;
			f7 = f10;
			f8 = f11;
		}

		return Minecraft.isAmbientOcclusionEnabled() && Block.lightValue[block1.blockID] == 0 ? 
				this.renderStandardBlockWithAmbientOcclusion(block1, i2, i3, i4, f6, f7, f8) 
			: 
				this.renderStandardBlockWithColorMultiplier(block1, i2, i3, i4, f6, f7, f8);
	}

	public boolean renderStandardBlockWithAmbientOcclusion(Block block1, int i2, int i3, int i4, float f5, float f6, float f7) {
		this.enableAO = true;
		boolean z8 = false;
		float f9 = this.lightValueOwn;
		float f10 = this.lightValueOwn;
		float f11 = this.lightValueOwn;
		float f12 = this.lightValueOwn;
		boolean z13 = true;
		boolean z14 = true;
		boolean z15 = true;
		boolean z16 = true;
		boolean z17 = true;
		boolean z18 = true;
		this.lightValueOwn = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4);
		this.aoLightValueXNeg = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4);
		this.aoLightValueYNeg = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4);
		this.aoLightValueZNeg = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 - 1);
		this.aoLightValueXPos = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4);
		this.aoLightValueYPos = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4);
		this.aoLightValueZPos = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 + 1);
		int i19 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4);
		int i20 = i19;
		int i21 = i19;
		int i22 = i19;
		int i23 = i19;
		int i24 = i19;
		int i25 = i19;
		if(block1.minY <= 0.0D) {
			i21 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4);
		}

		if(block1.maxY >= 1.0D) {
			i24 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4);
		}

		if(block1.minX <= 0.0D) {
			i20 = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4);
		}

		if(block1.maxX >= 1.0D) {
			i23 = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4);
		}

		if(block1.minZ <= 0.0D) {
			i22 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1);
		}

		if(block1.maxZ >= 1.0D) {
			i25 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1);
		}

		Tessellator tessellator26 = Tessellator.instance;
		tessellator26.setBrightness(983055);
		this.aoGrassXYZPPC = Block.canBlockGrass[this.blockAccess.getBlockID(i2 + 1, i3 + 1, i4)];
		this.aoGrassXYZPNC = Block.canBlockGrass[this.blockAccess.getBlockID(i2 + 1, i3 - 1, i4)];
		this.aoGrassXYZPCP = Block.canBlockGrass[this.blockAccess.getBlockID(i2 + 1, i3, i4 + 1)];
		this.aoGrassXYZPCN = Block.canBlockGrass[this.blockAccess.getBlockID(i2 + 1, i3, i4 - 1)];
		this.aoGrassXYZNPC = Block.canBlockGrass[this.blockAccess.getBlockID(i2 - 1, i3 + 1, i4)];
		this.aoGrassXYZNNC = Block.canBlockGrass[this.blockAccess.getBlockID(i2 - 1, i3 - 1, i4)];
		this.aoGrassXYZNCN = Block.canBlockGrass[this.blockAccess.getBlockID(i2 - 1, i3, i4 - 1)];
		this.aoGrassXYZNCP = Block.canBlockGrass[this.blockAccess.getBlockID(i2 - 1, i3, i4 + 1)];
		this.aoGrassXYZCPP = Block.canBlockGrass[this.blockAccess.getBlockID(i2, i3 + 1, i4 + 1)];
		this.aoGrassXYZCPN = Block.canBlockGrass[this.blockAccess.getBlockID(i2, i3 + 1, i4 - 1)];
		this.aoGrassXYZCNP = Block.canBlockGrass[this.blockAccess.getBlockID(i2, i3 - 1, i4 + 1)];
		this.aoGrassXYZCNN = Block.canBlockGrass[this.blockAccess.getBlockID(i2, i3 - 1, i4 - 1)];
		if(block1.blockIndexInTexture == 3) {
			z18 = false;
			z17 = false;
			z16 = false;
			z15 = false;
			z13 = false;
		}

		if(this.overrideBlockTexture >= 0) {
			z18 = false;
			z17 = false;
			z16 = false;
			z15 = false;
			z13 = false;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0)) {
			if(this.aoType > 0) {
				if(block1.minY <= 0.0D) {
				--i3;
				}

				this.aoBrightnessXYNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4);
				this.aoBrightnessYZNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1);
				this.aoBrightnessYZNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1);
				this.aoBrightnessXYPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4);
				this.aoLightValueScratchXYNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4);
				this.aoLightValueScratchYZNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 - 1);
				this.aoLightValueScratchYZNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 + 1);
				this.aoLightValueScratchXYPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4);
				if(!this.aoGrassXYZCNN && !this.aoGrassXYZNNC) {
					this.aoLightValueScratchXYZNNN = this.aoLightValueScratchXYNN;
					this.aoBrightnessXYZNNN = this.aoBrightnessXYNN;
				} else {
					this.aoLightValueScratchXYZNNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4 - 1);
					this.aoBrightnessXYZNNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4 - 1);
				}

				if(!this.aoGrassXYZCNP && !this.aoGrassXYZNNC) {
					this.aoLightValueScratchXYZNNP = this.aoLightValueScratchXYNN;
					this.aoBrightnessXYZNNP = this.aoBrightnessXYNN;
				} else {
					this.aoLightValueScratchXYZNNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4 + 1);
					this.aoBrightnessXYZNNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4 + 1);
				}

				if(!this.aoGrassXYZCNN && !this.aoGrassXYZPNC) {
					this.aoLightValueScratchXYZPNN = this.aoLightValueScratchXYPN;
					this.aoBrightnessXYZPNN = this.aoBrightnessXYPN;
				} else {
					this.aoLightValueScratchXYZPNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4 - 1);
					this.aoBrightnessXYZPNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4 - 1);
				}

				if(!this.aoGrassXYZCNP && !this.aoGrassXYZPNC) {
					this.aoLightValueScratchXYZPNP = this.aoLightValueScratchXYPN;
					this.aoBrightnessXYZPNP = this.aoBrightnessXYPN;
				} else {
					this.aoLightValueScratchXYZPNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4 + 1);
					this.aoBrightnessXYZPNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4 + 1);
				}

				if(block1.minY <= 0.0D) {
					++i3;
				}

				f9 = (this.aoLightValueScratchXYZNNP + this.aoLightValueScratchXYNN + this.aoLightValueScratchYZNP + this.aoLightValueYNeg) / 4.0F;
				f12 = (this.aoLightValueScratchYZNP + this.aoLightValueYNeg + this.aoLightValueScratchXYZPNP + this.aoLightValueScratchXYPN) / 4.0F;
				f11 = (this.aoLightValueYNeg + this.aoLightValueScratchYZNN + this.aoLightValueScratchXYPN + this.aoLightValueScratchXYZPNN) / 4.0F;
				f10 = (this.aoLightValueScratchXYNN + this.aoLightValueScratchXYZNNN + this.aoLightValueYNeg + this.aoLightValueScratchYZNN) / 4.0F;
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessXYZNNP, this.aoBrightnessXYNN, this.aoBrightnessYZNP, i21);
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessYZNP, this.aoBrightnessXYZPNP, this.aoBrightnessXYPN, i21);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessYZNN, this.aoBrightnessXYPN, this.aoBrightnessXYZPNN, i21);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessXYNN, this.aoBrightnessXYZNNN, this.aoBrightnessYZNN, i21);
			} else {
				f12 = this.aoLightValueYNeg;
				f11 = this.aoLightValueYNeg;
				f10 = this.aoLightValueYNeg;
				f9 = this.aoLightValueYNeg;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = this.aoBrightnessXYNN;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = (z13 ? f5 : 1.0F) * 0.5F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = (z13 ? f6 : 1.0F) * 0.5F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = (z13 ? f7 : 1.0F) * 0.5F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
			z8 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1)) {
			if(this.aoType > 0) {
				if(block1.maxY >= 1.0D) {
				++i3;
				}

				this.aoBrightnessXYNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4);
				this.aoBrightnessXYPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4);
				this.aoBrightnessYZPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1);
				this.aoBrightnessYZPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1);
				this.aoLightValueScratchXYNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4);
				this.aoLightValueScratchXYPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4);
				this.aoLightValueScratchYZPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 - 1);
				this.aoLightValueScratchYZPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 + 1);
				if(!this.aoGrassXYZCPN && !this.aoGrassXYZNPC) {
					this.aoLightValueScratchXYZNPN = this.aoLightValueScratchXYNP;
					this.aoBrightnessXYZNPN = this.aoBrightnessXYNP;
				} else {
					this.aoLightValueScratchXYZNPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4 - 1);
					this.aoBrightnessXYZNPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4 - 1);
				}

				if(!this.aoGrassXYZCPN && !this.aoGrassXYZPPC) {
					this.aoLightValueScratchXYZPPN = this.aoLightValueScratchXYPP;
					this.aoBrightnessXYZPPN = this.aoBrightnessXYPP;
				} else {
					this.aoLightValueScratchXYZPPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4 - 1);
					this.aoBrightnessXYZPPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4 - 1);
				}

				if(!this.aoGrassXYZCPP && !this.aoGrassXYZNPC) {
					this.aoLightValueScratchXYZNPP = this.aoLightValueScratchXYNP;
					this.aoBrightnessXYZNPP = this.aoBrightnessXYNP;
				} else {
					this.aoLightValueScratchXYZNPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4 + 1);
					this.aoBrightnessXYZNPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4 + 1);
				}

				if(!this.aoGrassXYZCPP && !this.aoGrassXYZPPC) {
					this.aoLightValueScratchXYZPPP = this.aoLightValueScratchXYPP;
					this.aoBrightnessXYZPPP = this.aoBrightnessXYPP;
				} else {
					this.aoLightValueScratchXYZPPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4 + 1);
					this.aoBrightnessXYZPPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4 + 1);
				}

				if(block1.maxY >= 1.0D) {
					--i3;
				}

				f12 = (this.aoLightValueScratchXYZNPP + this.aoLightValueScratchXYNP + this.aoLightValueScratchYZPP + this.aoLightValueYPos) / 4.0F;
				f9 = (this.aoLightValueScratchYZPP + this.aoLightValueYPos + this.aoLightValueScratchXYZPPP + this.aoLightValueScratchXYPP) / 4.0F;
				f10 = (this.aoLightValueYPos + this.aoLightValueScratchYZPN + this.aoLightValueScratchXYPP + this.aoLightValueScratchXYZPPN) / 4.0F;
				f11 = (this.aoLightValueScratchXYNP + this.aoLightValueScratchXYZNPN + this.aoLightValueYPos + this.aoLightValueScratchYZPN) / 4.0F;
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessXYZNPP, this.aoBrightnessXYNP, this.aoBrightnessYZPP, i24);
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessYZPP, this.aoBrightnessXYZPPP, this.aoBrightnessXYPP, i24);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessYZPN, this.aoBrightnessXYPP, this.aoBrightnessXYZPPN, i24);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessXYNP, this.aoBrightnessXYZNPN, this.aoBrightnessYZPN, i24);
			} else {
				f12 = this.aoLightValueYPos;
				f11 = this.aoLightValueYPos;
				f10 = this.aoLightValueYPos;
				f9 = this.aoLightValueYPos;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = i24;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = z14 ? f5 : 1.0F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = z14 ? f6 : 1.0F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = z14 ? f7 : 1.0F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
			z8 = true;
		}
		
		int i27;
		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2)) {
			if(this.aoType > 0) {
				if(block1.minZ <= 0.0D) {
				--i4;
				}

				this.aoLightValueScratchXZNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4);
				this.aoLightValueScratchYZNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4);
				this.aoLightValueScratchYZPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4);
				this.aoLightValueScratchXZPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4);
				this.aoBrightnessXZNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4);
				this.aoBrightnessYZNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4);
				this.aoBrightnessYZPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4);
				this.aoBrightnessXZPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4);
				if(!this.aoGrassXYZNCN && !this.aoGrassXYZCNN) {
					this.aoLightValueScratchXYZNNN = this.aoLightValueScratchXZNN;
					this.aoBrightnessXYZNNN = this.aoBrightnessXZNN;
				} else {
					this.aoLightValueScratchXYZNNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3 - 1, i4);
					this.aoBrightnessXYZNNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3 - 1, i4);
				}

				if(!this.aoGrassXYZNCN && !this.aoGrassXYZCPN) {
					this.aoLightValueScratchXYZNPN = this.aoLightValueScratchXZNN;
					this.aoBrightnessXYZNPN = this.aoBrightnessXZNN;
				} else {
					this.aoLightValueScratchXYZNPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3 + 1, i4);
					this.aoBrightnessXYZNPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3 + 1, i4);
				}

				if(!this.aoGrassXYZPCN && !this.aoGrassXYZCNN) {
					this.aoLightValueScratchXYZPNN = this.aoLightValueScratchXZPN;
					this.aoBrightnessXYZPNN = this.aoBrightnessXZPN;
				} else {
					this.aoLightValueScratchXYZPNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3 - 1, i4);
					this.aoBrightnessXYZPNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3 - 1, i4);
				}

				if(!this.aoGrassXYZPCN && !this.aoGrassXYZCPN) {
					this.aoLightValueScratchXYZPPN = this.aoLightValueScratchXZPN;
					this.aoBrightnessXYZPPN = this.aoBrightnessXZPN;
				} else {
					this.aoLightValueScratchXYZPPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3 + 1, i4);
					this.aoBrightnessXYZPPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3 + 1, i4);
				}

				if(block1.minZ <= 0.0D) {
					++i4;
				}

				f9 = (this.aoLightValueScratchXZNN + this.aoLightValueScratchXYZNPN + this.aoLightValueZNeg + this.aoLightValueScratchYZPN) / 4.0F;
				f10 = (this.aoLightValueZNeg + this.aoLightValueScratchYZPN + this.aoLightValueScratchXZPN + this.aoLightValueScratchXYZPPN) / 4.0F;
				f11 = (this.aoLightValueScratchYZNN + this.aoLightValueZNeg + this.aoLightValueScratchXYZPNN + this.aoLightValueScratchXZPN) / 4.0F;
				f12 = (this.aoLightValueScratchXYZNNN + this.aoLightValueScratchXZNN + this.aoLightValueScratchYZNN + this.aoLightValueZNeg) / 4.0F;
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessXZNN, this.aoBrightnessXYZNPN, this.aoBrightnessYZPN, i22);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessYZPN, this.aoBrightnessXZPN, this.aoBrightnessXYZPPN, i22);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessYZNN, this.aoBrightnessXYZPNN, this.aoBrightnessXZPN, i22);
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessXYZNNN, this.aoBrightnessXZNN, this.aoBrightnessYZNN, i22);
			} else {
				f12 = this.aoLightValueZNeg;
				f11 = this.aoLightValueZNeg;
				f10 = this.aoLightValueZNeg;
				f9 = this.aoLightValueZNeg;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = i22;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = (z15 ? f5 : 1.0F) * 0.8F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = (z15 ? f6 : 1.0F) * 0.8F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = (z15 ? f7 : 1.0F) * 0.8F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2);
			this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, i27);
			if(fancyGrass && i27 == 3 && this.overrideBlockTexture < 0) {
				this.colorRedTopLeft *= f5;
				this.colorRedBottomLeft *= f5;
				this.colorRedBottomRight *= f5;
				this.colorRedTopRight *= f5;
				this.colorGreenTopLeft *= f6;
				this.colorGreenBottomLeft *= f6;
				this.colorGreenBottomRight *= f6;
				this.colorGreenTopRight *= f6;
				this.colorBlueTopLeft *= f7;
				this.colorBlueBottomLeft *= f7;
				this.colorBlueBottomRight *= f7;
				this.colorBlueTopRight *= f7;
				this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, 16*9+5);
			}

			z8 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3)) {
			if(this.aoType > 0) {
				if(block1.maxZ >= 1.0D) {
				++i4;
				}

				this.aoLightValueScratchXZNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3, i4);
				this.aoLightValueScratchXZPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3, i4);
				this.aoLightValueScratchYZNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4);
				this.aoLightValueScratchYZPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4);
				this.aoBrightnessXZNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4);
				this.aoBrightnessXZPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4);
				this.aoBrightnessYZNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4);
				this.aoBrightnessYZPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4);
				if(!this.aoGrassXYZNCP && !this.aoGrassXYZCNP) {
					this.aoLightValueScratchXYZNNP = this.aoLightValueScratchXZNP;
					this.aoBrightnessXYZNNP = this.aoBrightnessXZNP;
				} else {
					this.aoLightValueScratchXYZNNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3 - 1, i4);
					this.aoBrightnessXYZNNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3 - 1, i4);
				}

				if(!this.aoGrassXYZNCP && !this.aoGrassXYZCPP) {
					this.aoLightValueScratchXYZNPP = this.aoLightValueScratchXZNP;
					this.aoBrightnessXYZNPP = this.aoBrightnessXZNP;
				} else {
					this.aoLightValueScratchXYZNPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 - 1, i3 + 1, i4);
					this.aoBrightnessXYZNPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3 + 1, i4);
				}

				if(!this.aoGrassXYZPCP && !this.aoGrassXYZCNP) {
					this.aoLightValueScratchXYZPNP = this.aoLightValueScratchXZPP;
					this.aoBrightnessXYZPNP = this.aoBrightnessXZPP;
				} else {
					this.aoLightValueScratchXYZPNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3 - 1, i4);
					this.aoBrightnessXYZPNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3 - 1, i4);
				}

				if(!this.aoGrassXYZPCP && !this.aoGrassXYZCPP) {
					this.aoLightValueScratchXYZPPP = this.aoLightValueScratchXZPP;
					this.aoBrightnessXYZPPP = this.aoBrightnessXZPP;
				} else {
					this.aoLightValueScratchXYZPPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2 + 1, i3 + 1, i4);
					this.aoBrightnessXYZPPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3 + 1, i4);
				}

				if(block1.maxZ >= 1.0D) {
					--i4;
				}

				f9 = (this.aoLightValueScratchXZNP + this.aoLightValueScratchXYZNPP + this.aoLightValueZPos + this.aoLightValueScratchYZPP) / 4.0F;
				f12 = (this.aoLightValueZPos + this.aoLightValueScratchYZPP + this.aoLightValueScratchXZPP + this.aoLightValueScratchXYZPPP) / 4.0F;
				f11 = (this.aoLightValueScratchYZNP + this.aoLightValueZPos + this.aoLightValueScratchXYZPNP + this.aoLightValueScratchXZPP) / 4.0F;
				f10 = (this.aoLightValueScratchXYZNNP + this.aoLightValueScratchXZNP + this.aoLightValueScratchYZNP + this.aoLightValueZPos) / 4.0F;
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessXZNP, this.aoBrightnessXYZNPP, this.aoBrightnessYZPP, i25);
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessYZPP, this.aoBrightnessXZPP, this.aoBrightnessXYZPPP, i25);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessYZNP, this.aoBrightnessXYZPNP, this.aoBrightnessXZPP, i25);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessXYZNNP, this.aoBrightnessXZNP, this.aoBrightnessYZNP, i25);
			} else {
				f12 = this.aoLightValueZPos;
				f11 = this.aoLightValueZPos;
				f10 = this.aoLightValueZPos;
				f9 = this.aoLightValueZPos;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = i25;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = (z16 ? f5 : 1.0F) * 0.8F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = (z16 ? f6 : 1.0F) * 0.8F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = (z16 ? f7 : 1.0F) * 0.8F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3);
			this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3));
			if(fancyGrass && i27 == 3 && this.overrideBlockTexture < 0) {
				this.colorRedTopLeft *= f5;
				this.colorRedBottomLeft *= f5;
				this.colorRedBottomRight *= f5;
				this.colorRedTopRight *= f5;
				this.colorGreenTopLeft *= f6;
				this.colorGreenBottomLeft *= f6;
				this.colorGreenBottomRight *= f6;
				this.colorGreenTopRight *= f6;
				this.colorBlueTopLeft *= f7;
				this.colorBlueBottomLeft *= f7;
				this.colorBlueBottomRight *= f7;
				this.colorBlueTopRight *= f7;
				this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, 16*9+5);
			}

			z8 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4)) {
			if(this.aoType > 0) {
				if(block1.minX <= 0.0D) {
				--i2;
				}

				this.aoLightValueScratchXYNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4);
				this.aoLightValueScratchXZNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 - 1);
				this.aoLightValueScratchXZNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 + 1);
				this.aoLightValueScratchXYNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4);
				this.aoBrightnessXYNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4);
				this.aoBrightnessXZNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1);
				this.aoBrightnessXZNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1);
				this.aoBrightnessXYNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4);
				if(!this.aoGrassXYZNCN && !this.aoGrassXYZNNC) {
					this.aoLightValueScratchXYZNNN = this.aoLightValueScratchXZNN;
					this.aoBrightnessXYZNNN = this.aoBrightnessXZNN;
				} else {
					this.aoLightValueScratchXYZNNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4 - 1);
					this.aoBrightnessXYZNNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4 - 1);
				}

				if(!this.aoGrassXYZNCP && !this.aoGrassXYZNNC) {
					this.aoLightValueScratchXYZNNP = this.aoLightValueScratchXZNP;
					this.aoBrightnessXYZNNP = this.aoBrightnessXZNP;
				} else {
					this.aoLightValueScratchXYZNNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4 + 1);
					this.aoBrightnessXYZNNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4 + 1);
				}

				if(!this.aoGrassXYZNCN && !this.aoGrassXYZNPC) {
					this.aoLightValueScratchXYZNPN = this.aoLightValueScratchXZNN;
					this.aoBrightnessXYZNPN = this.aoBrightnessXZNN;
				} else {
					this.aoLightValueScratchXYZNPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4 - 1);
					this.aoBrightnessXYZNPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4 - 1);
				}

				if(!this.aoGrassXYZNCP && !this.aoGrassXYZNPC) {
					this.aoLightValueScratchXYZNPP = this.aoLightValueScratchXZNP;
					this.aoBrightnessXYZNPP = this.aoBrightnessXZNP;
				} else {
					this.aoLightValueScratchXYZNPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4 + 1);
					this.aoBrightnessXYZNPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4 + 1);
				}

				if(block1.minX <= 0.0D) {
					++i2;
				}

				f12 = (this.aoLightValueScratchXYNN + this.aoLightValueScratchXYZNNP + this.aoLightValueXNeg + this.aoLightValueScratchXZNP) / 4.0F;
				f9 = (this.aoLightValueXNeg + this.aoLightValueScratchXZNP + this.aoLightValueScratchXYNP + this.aoLightValueScratchXYZNPP) / 4.0F;
				f10 = (this.aoLightValueScratchXZNN + this.aoLightValueXNeg + this.aoLightValueScratchXYZNPN + this.aoLightValueScratchXYNP) / 4.0F;
				f11 = (this.aoLightValueScratchXYZNNN + this.aoLightValueScratchXYNN + this.aoLightValueScratchXZNN + this.aoLightValueXNeg) / 4.0F;
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessXYNN, this.aoBrightnessXYZNNP, this.aoBrightnessXZNP, i20);
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessXZNP, this.aoBrightnessXYNP, this.aoBrightnessXYZNPP, i20);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessXZNN, this.aoBrightnessXYZNPN, this.aoBrightnessXYNP, i20);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessXYZNNN, this.aoBrightnessXYNN, this.aoBrightnessXZNN, i20);
			} else {
				f12 = this.aoLightValueXNeg;
				f11 = this.aoLightValueXNeg;
				f10 = this.aoLightValueXNeg;
				f9 = this.aoLightValueXNeg;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = i20;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = (z17 ? f5 : 1.0F) * 0.6F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = (z17 ? f6 : 1.0F) * 0.6F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = (z17 ? f7 : 1.0F) * 0.6F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4);
			this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, i27);
			if(fancyGrass && i27 == 3 && this.overrideBlockTexture < 0) {
				this.colorRedTopLeft *= f5;
				this.colorRedBottomLeft *= f5;
				this.colorRedBottomRight *= f5;
				this.colorRedTopRight *= f5;
				this.colorGreenTopLeft *= f6;
				this.colorGreenBottomLeft *= f6;
				this.colorGreenBottomRight *= f6;
				this.colorGreenTopRight *= f6;
				this.colorBlueTopLeft *= f7;
				this.colorBlueBottomLeft *= f7;
				this.colorBlueBottomRight *= f7;
				this.colorBlueTopRight *= f7;
				this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, 16*9+5);
			}

			z8 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)) {
			if(this.aoType > 0) {
				if(block1.maxX >= 1.0D) {
				++i2;
				}

				this.aoLightValueScratchXYPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4);
				this.aoLightValueScratchXZPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 - 1);
				this.aoLightValueScratchXZPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3, i4 + 1);
				this.aoLightValueScratchXYPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4);
				this.aoBrightnessXYPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4);
				this.aoBrightnessXZPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1);
				this.aoBrightnessXZPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1);
				this.aoBrightnessXYPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4);
				if(!this.aoGrassXYZPNC && !this.aoGrassXYZPCN) {
					this.aoLightValueScratchXYZPNN = this.aoLightValueScratchXZPN;
					this.aoBrightnessXYZPNN = this.aoBrightnessXZPN;
				} else {
					this.aoLightValueScratchXYZPNN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4 - 1);
					this.aoBrightnessXYZPNN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4 - 1);
				}

				if(!this.aoGrassXYZPNC && !this.aoGrassXYZPCP) {
					this.aoLightValueScratchXYZPNP = this.aoLightValueScratchXZPP;
					this.aoBrightnessXYZPNP = this.aoBrightnessXZPP;
				} else {
					this.aoLightValueScratchXYZPNP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 - 1, i4 + 1);
					this.aoBrightnessXYZPNP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4 + 1);
				}

				if(!this.aoGrassXYZPPC && !this.aoGrassXYZPCN) {
					this.aoLightValueScratchXYZPPN = this.aoLightValueScratchXZPN;
					this.aoBrightnessXYZPPN = this.aoBrightnessXZPN;
				} else {
					this.aoLightValueScratchXYZPPN = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4 - 1);
					this.aoBrightnessXYZPPN = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4 - 1);
				}

				if(!this.aoGrassXYZPPC && !this.aoGrassXYZPCP) {
					this.aoLightValueScratchXYZPPP = this.aoLightValueScratchXZPP;
					this.aoBrightnessXYZPPP = this.aoBrightnessXZPP;
				} else {
					this.aoLightValueScratchXYZPPP = block1.getAmbientOcclusionLightValue(this.blockAccess, i2, i3 + 1, i4 + 1);
					this.aoBrightnessXYZPPP = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4 + 1);
				}

				if(block1.maxX >= 1.0D) {
					--i2;
				}

				f9 = (this.aoLightValueScratchXYPN + this.aoLightValueScratchXYZPNP + this.aoLightValueXPos + this.aoLightValueScratchXZPP) / 4.0F;
				f12 = (this.aoLightValueXPos + this.aoLightValueScratchXZPP + this.aoLightValueScratchXYPP + this.aoLightValueScratchXYZPPP) / 4.0F;
				f11 = (this.aoLightValueScratchXZPN + this.aoLightValueXPos + this.aoLightValueScratchXYZPPN + this.aoLightValueScratchXYPP) / 4.0F;
				f10 = (this.aoLightValueScratchXYZPNN + this.aoLightValueScratchXYPN + this.aoLightValueScratchXZPN + this.aoLightValueXPos) / 4.0F;
				this.brightnessTopLeft = this.getAoBrightness(this.aoBrightnessXYPN, this.aoBrightnessXYZPNP, this.aoBrightnessXZPP, i23);
				this.brightnessTopRight = this.getAoBrightness(this.aoBrightnessXZPP, this.aoBrightnessXYPP, this.aoBrightnessXYZPPP, i23);
				this.brightnessBottomRight = this.getAoBrightness(this.aoBrightnessXZPN, this.aoBrightnessXYZPPN, this.aoBrightnessXYPP, i23);
				this.brightnessBottomLeft = this.getAoBrightness(this.aoBrightnessXYZPNN, this.aoBrightnessXYPN, this.aoBrightnessXZPN, i23);
			} else {
				f12 = this.aoLightValueXPos;
				f11 = this.aoLightValueXPos;
				f10 = this.aoLightValueXPos;
				f9 = this.aoLightValueXPos;
				this.brightnessTopLeft = this.brightnessBottomLeft = this.brightnessBottomRight = this.brightnessTopRight = i23;
			}

			this.colorRedTopLeft = this.colorRedBottomLeft = this.colorRedBottomRight = this.colorRedTopRight = (z18 ? f5 : 1.0F) * 0.6F;
			this.colorGreenTopLeft = this.colorGreenBottomLeft = this.colorGreenBottomRight = this.colorGreenTopRight = (z18 ? f6 : 1.0F) * 0.6F;
			this.colorBlueTopLeft = this.colorBlueBottomLeft = this.colorBlueBottomRight = this.colorBlueTopRight = (z18 ? f7 : 1.0F) * 0.6F;
			this.colorRedTopLeft *= f9;
			this.colorGreenTopLeft *= f9;
			this.colorBlueTopLeft *= f9;
			this.colorRedBottomLeft *= f10;
			this.colorGreenBottomLeft *= f10;
			this.colorBlueBottomLeft *= f10;
			this.colorRedBottomRight *= f11;
			this.colorGreenBottomRight *= f11;
			this.colorBlueBottomRight *= f11;
			this.colorRedTopRight *= f12;
			this.colorGreenTopRight *= f12;
			this.colorBlueTopRight *= f12;
			i27 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5);
			this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, i27);
			if(fancyGrass && i27 == 3 && this.overrideBlockTexture < 0) {
				this.colorRedTopLeft *= f5;
				this.colorRedBottomLeft *= f5;
				this.colorRedBottomRight *= f5;
				this.colorRedTopRight *= f5;
				this.colorGreenTopLeft *= f6;
				this.colorGreenBottomLeft *= f6;
				this.colorGreenBottomRight *= f6;
				this.colorGreenTopRight *= f6;
				this.colorBlueTopLeft *= f7;
				this.colorBlueBottomLeft *= f7;
				this.colorBlueBottomRight *= f7;
				this.colorBlueTopRight *= f7;
				this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, 16*9+5);
			}

			z8 = true;
		}

		this.enableAO = false;
		return z8;
	}

	private int getAoBrightness(int i1, int i2, int i3, int i4) {
		if(i1 == 0) {
			i1 = i4;
		}

		if(i2 == 0) {
			i2 = i4;
		}

		if(i3 == 0) {
			i3 = i4;
		}

		return i1 + i2 + i3 + i4 >> 2 & 16711935;
	}

	public boolean renderStandardBlockWithColorMultiplier(Block block, int x, int y, int z, float r, float g, float b) {
				
		this.enableAO = false;
		Tessellator tes = Tessellator.instance;
		boolean renderedAny = false;
		
		// Global light value for each side
		float lmBo = 0.5F;
		float lmTo = 1.0F;
		float lmEW = 0.8F;
		float lmNS = 0.6F;

		// Calculated RGB for TOP with color applied
		float rTop = lmTo * r;
		float gTop = lmTo * g;
		float bTop = lmTo * b;

		// Calculated RGB for Bottom
		float rBottom = lmBo;
		float gBottom = lmBo;
		float bBottom = lmBo;

		// Calculated RGB for EW
		float rEW = lmEW;
		float gEW = lmEW;
		float bEW = lmEW;

		// Calculated RGB for NS
		float rNS = lmNS;
		float gNS = lmNS;
		float bNS = lmNS;

		// Apply color to bottom, EW, NS if not grass
		if(block != Block.grass) {
			rBottom = lmBo * r;
			gBottom = lmBo * g;
			bBottom = lmBo * b;
			
			rEW = lmEW * r;
			gEW = lmEW * g;
			bEW = lmEW * b;
			
			rNS = lmNS * r;
			gNS = lmNS * g;
			bNS = lmNS * b;
		}

		int blockBrightness = block.getMixedBrightnessForBlock(this.blockAccess, x, y, z);

		// Render bottom
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x, y - 1, z, 0)) {
			tes.setBrightness(block.minY > 0.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x, y - 1, z));
			tes.setColorOpaque_F(rBottom, gBottom, bBottom);
			this.renderBottomFace(block, (double)x, (double)y, (double)z, block.getBlockTexture(this.blockAccess, x, y, z, 0));
			renderedAny = true;
		}

		// Render top
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x, y + 1, z, 1)) {
			tes.setBrightness(block.maxY < 1.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x, y + 1, z));
			tes.setColorOpaque_F(rTop, gTop, bTop);
			this.renderTopFace(block, (double)x, (double)y, (double)z, block.getBlockTexture(this.blockAccess, x, y, z, 1));
			renderedAny = true;
		}

		int textureId;

		// Render East
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x, y, z - 1, 2)) {
			tes.setBrightness(block.minZ > 0.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x, y, z - 1));
			tes.setColorOpaque_F(rEW, gEW, bEW);
			textureId = block.getBlockTexture(this.blockAccess, x, y, z, 2);
			this.renderEastFace(block, (double)x, (double)y, (double)z, textureId);
			if(fancyGrass && textureId == 3 && this.overrideBlockTexture < 0) {
				tes.setColorOpaque_F(rEW * r, gEW * g, bEW * b);
				this.renderEastFace(block, (double)x, (double)y, (double)z, 9*16+5);
			}

			renderedAny = true;
		}

		// Render West
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x, y, z + 1, 3)) {
			tes.setBrightness(block.maxZ < 1.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x, y, z + 1));
			tes.setColorOpaque_F(rEW, gEW, bEW);
			textureId = block.getBlockTexture(this.blockAccess, x, y, z, 3);
			this.renderWestFace(block, (double)x, (double)y, (double)z, textureId);
			if(fancyGrass && textureId == 3 && this.overrideBlockTexture < 0) {
				tes.setColorOpaque_F(rEW * r, gEW * g, bEW * b);
				this.renderWestFace(block, (double)x, (double)y, (double)z, 9*16+5);
			}

			renderedAny = true;
		}

		// Render North
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x - 1, y, z, 4)) {
			tes.setBrightness(block.minX > 0.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x - 1, y, z));
			tes.setColorOpaque_F(rNS, gNS, bNS);
			textureId = block.getBlockTexture(this.blockAccess, x, y, z, 4);
			this.renderNorthFace(block, (double)x, (double)y, (double)z, textureId);
			if(fancyGrass && textureId == 3 && this.overrideBlockTexture < 0) {
				tes.setColorOpaque_F(rNS * r, gNS * g, bNS * b);
				this.renderNorthFace(block, (double)x, (double)y, (double)z, 9*16+5);
			}

			renderedAny = true;
		}

		// Render South
		if(this.renderAllFaces || block.shouldSideBeRendered(this.blockAccess, x + 1, y, z, 5)) {
			tes.setBrightness(block.maxX < 1.0D ? blockBrightness : block.getMixedBrightnessForBlock(this.blockAccess, x + 1, y, z));
			tes.setColorOpaque_F(rNS, gNS, bNS);
			textureId = block.getBlockTexture(this.blockAccess, x, y, z, 5);
			this.renderSouthFace(block, (double)x, (double)y, (double)z, textureId);
			if(fancyGrass && textureId == 3 && this.overrideBlockTexture < 0) {
				tes.setColorOpaque_F(rNS * r, gNS * g, bNS * b);
				this.renderSouthFace(block, (double)x, (double)y, (double)z, 9*16+5);
			}

			renderedAny = true;
		}

		return renderedAny;
	}

	public boolean renderBlockCactus(Block block1, int i2, int i3, int i4) {
		int i5 = block1.colorMultiplier(this.blockAccess, i2, i3, i4);
		float f6 = (float)(i5 >> 16 & 255) / 255.0F;
		float f7 = (float)(i5 >> 8 & 255) / 255.0F;
		float f8 = (float)(i5 & 255) / 255.0F;
		if(GameRenderer.anaglyphEnable) {
			float f9 = (f6 * 30.0F + f7 * 59.0F + f8 * 11.0F) / 100.0F;
			float f10 = (f6 * 30.0F + f7 * 70.0F) / 100.0F;
			float f11 = (f6 * 30.0F + f8 * 70.0F) / 100.0F;
			f6 = f9;
			f7 = f10;
			f8 = f11;
		}

		return this.renderBlockCactusImpl(block1, i2, i3, i4, f6, f7, f8);
	}

	public boolean renderBlockCactusImpl(Block block1, int i2, int i3, int i4, float f5, float f6, float f7) {
		Tessellator tessellator8 = Tessellator.instance;
		boolean z9 = false;
		float f10 = 0.5F;
		float f11 = 1.0F;
		float f12 = 0.8F;
		float f13 = 0.6F;
		float f14 = f10 * f5;
		float f15 = f11 * f5;
		float f16 = f12 * f5;
		float f17 = f13 * f5;
		float f18 = f10 * f6;
		float f19 = f11 * f6;
		float f20 = f12 * f6;
		float f21 = f13 * f6;
		float f22 = f10 * f7;
		float f23 = f11 * f7;
		float f24 = f12 * f7;
		float f25 = f13 * f7;
		float f26 = 0.0625F;
		int i28 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4);
		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 - 1, i4, 0)) {
			tessellator8.setBrightness(block1.minY > 0.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4));
			tessellator8.setColorOpaque_F(f14, f18, f22);
			this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3 + 1, i4, 1)) {
			tessellator8.setBrightness(block1.maxY < 1.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4));
			tessellator8.setColorOpaque_F(f15, f19, f23);
			this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 - 1, 2)) {
			tessellator8.setBrightness(block1.minZ > 0.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1));
			tessellator8.setColorOpaque_F(f16, f20, f24);
			tessellator8.addTranslation(0.0F, 0.0F, f26);
			this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2));
			tessellator8.addTranslation(0.0F, 0.0F, -f26);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2, i3, i4 + 1, 3)) {
			tessellator8.setBrightness(block1.maxZ < 1.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1));
			tessellator8.setColorOpaque_F(f16, f20, f24);
			tessellator8.addTranslation(0.0F, 0.0F, -f26);
			this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3));
			tessellator8.addTranslation(0.0F, 0.0F, f26);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 - 1, i3, i4, 4)) {
			tessellator8.setBrightness(block1.minX > 0.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4));
			tessellator8.setColorOpaque_F(f17, f21, f25);
			tessellator8.addTranslation(f26, 0.0F, 0.0F);
			this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4));
			tessellator8.addTranslation(-f26, 0.0F, 0.0F);
			z9 = true;
		}

		if(this.renderAllFaces || block1.shouldSideBeRendered(this.blockAccess, i2 + 1, i3, i4, 5)) {
			tessellator8.setBrightness(block1.maxX < 1.0D ? i28 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4));
			tessellator8.setColorOpaque_F(f17, f21, f25);
			tessellator8.addTranslation(-f26, 0.0F, 0.0F);
			this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5));
			tessellator8.addTranslation(f26, 0.0F, 0.0F);
			z9 = true;
		}

		return z9;
	}

	public boolean renderBlockFence(Block block, int x, int y, int z) {
		
		float min = 0.375F;
		float max = 0.625F;
		block.setBlockBounds(min, 0.0F, min, max, 1.0F, max);
		this.renderStandardBlock(block, x, y, z);
		
		boolean connectEorW = false;
		boolean connectNorS = false;
		if(this.blockAccess.getBlockID(x - 1, y, z) == block.blockID || this.blockAccess.getBlockID(x + 1, y, z) == block.blockID) {
			connectEorW = true;
		}

		if(this.blockAccess.getBlockID(x, y, z - 1) == block.blockID || this.blockAccess.getBlockID(x, y, z + 1) == block.blockID) {
			connectNorS = true;
		}

		boolean connectE = this.blockAccess.getBlockID(x - 1, y, z) == block.blockID;
		boolean connectW = this.blockAccess.getBlockID(x + 1, y, z) == block.blockID;
		boolean connectN = this.blockAccess.getBlockID(x, y, z - 1) == block.blockID;
		boolean connectS = this.blockAccess.getBlockID(x, y, z + 1) == block.blockID;
		if(!connectEorW && !connectNorS) {
			connectEorW = true;
		}

		min = 0.4375F;
		max = 0.5625F;
		float minY = 0.75F;
		float maxY = 0.9375F;
		float minX = connectE ? 0.0F : min;
		float maxX = connectW ? 1.0F : max;
		float minZ = connectN ? 0.0F : min;
		float maxZ = connectS ? 1.0F : max;
		
		if(connectEorW) {
			block.setBlockBounds(minX, minY, min, maxX, maxY, max);
			this.renderStandardBlock(block, x, y, z);
		}

		if(connectNorS) {
			block.setBlockBounds(min, minY, minZ, max, maxY, maxZ);
			this.renderStandardBlock(block, x, y, z);
		}

		minY = 0.375F;
		maxY = 0.5625F;
		if(connectEorW) {
			block.setBlockBounds(minX, minY, min, maxX, maxY, max);
			this.renderStandardBlock(block, x, y, z);
		}

		if(connectNorS) {
			block.setBlockBounds(min, minY, minZ, max, maxY, maxZ);
			this.renderStandardBlock(block, x, y, z);
		}

		//block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		block.setBlockBoundsBasedOnState(this.blockAccess, x, y, z);
		
		return true;
	}

	public boolean renderBlockStairs(Block block1, int i2, int i3, int i4) {
		boolean z5 = false;
		int i6 = this.blockAccess.getBlockMetadata(i2, i3, i4);
		boolean upsideDown = (i6 & 8) != 0;
		i6 &= 7;
		
		if(upsideDown) {
			if(i6 == 0) {
				block1.setBlockBounds(0.0F, 0.5F, 0.0F, 0.5F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 1) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.5F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 2) {
				block1.setBlockBounds(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 0.5F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 3) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.0F, 0.5F, 0.5F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			}
		} else {
			if(i6 == 0) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 0.5F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 1) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 0.5F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.5F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 2) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 0.5F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 1.0F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			} else if(i6 == 3) {
				block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
				this.renderStandardBlock(block1, i2, i3, i4);
				block1.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
				this.renderStandardBlock(block1, i2, i3, i4);
				z5 = true;
			}
		}
		
		block1.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		return z5;
	}

	public boolean renderBlockDoor(Block block1, int i2, int i3, int i4) {
		Tessellator tessellator5 = Tessellator.instance;
		boolean z7 = false;
		float f8 = 0.5F;
		float f9 = 1.0F;
		float f10 = 0.8F;
		float f11 = 0.6F;
		int i12 = block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4);
		tessellator5.setBrightness(block1.minY > 0.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 - 1, i4));
		tessellator5.setColorOpaque_F(f8, f8, f8);
		this.renderBottomFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 0));
		z7 = true;
		tessellator5.setBrightness(block1.maxY < 1.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3 + 1, i4));
		tessellator5.setColorOpaque_F(f9, f9, f9);
		this.renderTopFace(block1, (double)i2, (double)i3, (double)i4, block1.getBlockTexture(this.blockAccess, i2, i3, i4, 1));
		z7 = true;
		tessellator5.setBrightness(block1.minZ > 0.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 - 1));
		tessellator5.setColorOpaque_F(f10, f10, f10);
		int i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 2);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderEastFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		tessellator5.setBrightness(block1.maxZ < 1.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2, i3, i4 + 1));
		tessellator5.setColorOpaque_F(f10, f10, f10);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 3);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderWestFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		tessellator5.setBrightness(block1.minX > 0.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 - 1, i3, i4));
		tessellator5.setColorOpaque_F(f11, f11, f11);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 4);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderNorthFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		tessellator5.setBrightness(block1.maxX < 1.0D ? i12 : block1.getMixedBrightnessForBlock(this.blockAccess, i2 + 1, i3, i4));
		tessellator5.setColorOpaque_F(f11, f11, f11);
		i14 = block1.getBlockTexture(this.blockAccess, i2, i3, i4, 5);
		if(i14 < 0) {
			this.flipTexture = true;
			i14 = -i14;
		}

		this.renderSouthFace(block1, (double)i2, (double)i3, (double)i4, i14);
		z7 = true;
		this.flipTexture = false;
		return z7;
	}

	public void renderBottomFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
				;
		if(this.uvRotateBottom == 2) {
			u1 = ((double)i10 + block1.minZ * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxX * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxZ * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.minX * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateBottom == 1) {
			u1 = ((double)(i10 + 16) - block1.maxZ * 16.0D) / taw;
			v1 = ((double)i11 + block1.minX * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minZ * 16.0D) / taw;
			v2 = ((double)i11 + block1.maxX * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateBottom == 3) {
			u1 = ((double)(i10 + 16) - block1.minX * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.minZ * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.maxZ * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minX * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.minZ * 16.0D) / tah;
			v2 = ((double)i11 + block1.maxZ * 16.0D - 0.01D) / tah;
			
			if(block1.minX < 0.0D || block1.maxX > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.minX;
		double d30 = d2 + block1.maxX;
		double d32 = d4 + block1.minY;
		double d34 = d6 + block1.minZ;
		double d36 = d6 + block1.maxZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d30, d32, d34, ru2, rv1);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
		} else {
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.addVertexWithUV(d30, d32, d34, ru2, rv1);
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
		}

	}

	public void renderTopFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;
		
		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
	
		if(this.uvRotateTop == 1) {
			u1 = ((double)i10 + block1.minZ * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxX * 16.0D) / tah;
			u2 = ((double)i10 + block1.maxZ * 16.0D) / taw;
			v2 = ((double)(i11 + 16) - block1.minX * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateTop == 2) {
			u1 = ((double)(i10 + 16) - block1.maxZ * 16.0D) / taw;
			v1 = ((double)i11 + block1.minX * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minZ * 16.0D) / taw;
			v2 = ((double)i11 + block1.maxX * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateTop == 3) {
			u1 = ((double)(i10 + 16) - block1.minX * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.minZ * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.maxZ * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minX * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.minZ * 16.0D) / tah;
			v2 = ((double)i11 + block1.maxZ * 16.0D - 0.01D) / tah;
			if(block1.minX < 0.0D || block1.maxX > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.minX;
		double d30 = d2 + block1.maxX;
		double d32 = d4 + block1.maxY;
		double d34 = d6 + block1.minZ;
		double d36 = d6 + block1.maxZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d30, d32, d34, ru2, rv1);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomRight);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
		} else {
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
			tessellator9.addVertexWithUV(d30, d32, d34, ru2, rv1);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
		}

	}

	public void renderEastFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
		
		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;
		
		if(this.uvRotateEast == 2) {
			u1 = ((double)i10 + block1.minY * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.minX * 16.0D) / tah;
			u2 = ((double)i10 + block1.maxY * 16.0D) / taw;
			v2 = ((double)(i11 + 16) - block1.maxX * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateEast == 1) {
			u1 = ((double)(i10 + 16) - block1.maxY * 16.0D) / taw;
			v1 = ((double)i11 + block1.maxX * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minY * 16.0D) / taw;
			v2 = ((double)i11 + block1.minX * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateEast == 3) {
			u1 = ((double)(i10 + 16) - block1.minX * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.maxY * 16.0D) / tah;
			v2 = ((double)i11 + block1.minY * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minX * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxY * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.minY * 16.0D - 0.01D) / tah;

			if(this.flipTexture) {
				ru2 = u1;
				u1 = u2;
				u2 = ru2;
			}

			if(block1.minX < 0.0D || block1.maxX > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minY < 0.0D || block1.maxY > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.minX;
		double d30 = d2 + block1.maxX;
		double d32 = d4 + block1.minY;
		double d34 = d4 + block1.maxY;
		double d36 = d6 + block1.minZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d28, d34, d36, ru2, rv1);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d30, d34, d36, u1, v1);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomRight);
			tessellator9.addVertexWithUV(d30, d32, d36, ru1, rv2);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d28, d32, d36, u2, v2);
		} else {
			tessellator9.addVertexWithUV(d28, d34, d36, ru2, rv1);
			tessellator9.addVertexWithUV(d30, d34, d36, u1, v1);
			tessellator9.addVertexWithUV(d30, d32, d36, ru1, rv2);
			tessellator9.addVertexWithUV(d28, d32, d36, u2, v2);
		}

	}

	public void renderWestFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
		
		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;
		
		if(this.uvRotateWest == 1) {
			u1 = ((double)i10 + block1.minY * 16.0D) / taw;
			v2 = ((double)(i11 + 16) - block1.minX * 16.0D) / tah;
			u2 = ((double)i10 + block1.maxY * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxX * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateWest == 2) {
			u1 = ((double)(i10 + 16) - block1.maxY * 16.0D) / taw;
			v1 = ((double)i11 + block1.minX * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minY * 16.0D) / taw;
			v2 = ((double)i11 + block1.maxX * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateWest == 3) {
			u1 = ((double)(i10 + 16) - block1.minX * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.maxY * 16.0D) / tah;
			v2 = ((double)i11 + block1.minY * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minX * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxX * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxY * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.minY * 16.0D - 0.01D) / tah;
			if(this.flipTexture) {
				ru2 = u1;
				u1 = u2;
				u2 = ru2;
			}

			if(block1.minX < 0.0D || block1.maxX > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minY < 0.0D || block1.maxY > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.minX;
		double d30 = d2 + block1.maxX;
		double d32 = d4 + block1.minY;
		double d34 = d4 + block1.maxY;
		double d36 = d6 + block1.maxZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d28, d34, d36, u1, v1);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomRight);
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d30, d34, d36, ru2, rv1);
		} else {
			tessellator9.addVertexWithUV(d28, d34, d36, u1, v1);
			tessellator9.addVertexWithUV(d28, d32, d36, ru1, rv2);
			tessellator9.addVertexWithUV(d30, d32, d36, u2, v2);
			tessellator9.addVertexWithUV(d30, d34, d36, ru2, rv1);
		}

	}

	public void renderNorthFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
		
		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;
		
		if(this.uvRotateNorth == 1) {
			u1 = ((double)i10 + block1.minY * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxZ * 16.0D) / tah;
			u2 = ((double)i10 + block1.maxY * 16.0D) / taw;
			v2 = ((double)(i11 + 16) - block1.minZ * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateNorth == 2) {
			u1 = ((double)(i10 + 16) - block1.maxY * 16.0D) / taw;
			v1 = ((double)i11 + block1.minZ * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minY * 16.0D) / taw;
			v2 = ((double)i11 + block1.maxZ * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateNorth == 3) {
			u1 = ((double)(i10 + 16) - block1.minZ * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxZ * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.maxY * 16.0D) / tah;
			v2 = ((double)i11 + block1.minY * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minZ * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxZ * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxY * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.minY * 16.0D - 0.01D) / tah;

			if(this.flipTexture) {
				ru2 = u1;
				u1 = u2;
				u2 = ru2;
			}

			if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minY < 0.0D || block1.maxY > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.minX;
		double d30 = d4 + block1.minY;
		double d32 = d4 + block1.maxY;
		double d34 = d6 + block1.minZ;
		double d36 = d6 + block1.maxZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d28, d32, d36, ru2, rv1);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomRight);
			tessellator9.addVertexWithUV(d28, d30, d34, ru1, rv2);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d28, d30, d36, u2, v2);
		} else {
			tessellator9.addVertexWithUV(d28, d32, d36, ru2, rv1);
			tessellator9.addVertexWithUV(d28, d32, d34, u1, v1);
			tessellator9.addVertexWithUV(d28, d30, d34, ru1, rv2);
			tessellator9.addVertexWithUV(d28, d30, d36, u2, v2);
		}

	}

	public void renderSouthFace(Block block1, double d2, double d4, double d6, int i8) {
		Tessellator tessellator9 = Tessellator.instance;
		if(this.overrideBlockTexture >= 0) {
			i8 = this.overrideBlockTexture;
		}

		int i10 = (i8 & 15) << 4;
		int i11 = i8 & 0xff0;
		
		final double taw = TextureAtlasSize.w;
		final double tah = TextureAtlasSize.h;
		
		double u1, u2, v1, v2;
		double ru2, ru1, rv1, rv2;
		
		if(this.uvRotateSouth == 2) {
			u1 = ((double)i10 + block1.minY * 16.0D) / taw;
			v1 = ((double)(i11 + 16) - block1.minZ * 16.0D) / tah;
			u2 = ((double)i10 + block1.maxY * 16.0D) / taw;
			v2 = ((double)(i11 + 16) - block1.maxZ * 16.0D) / tah;
			rv1 = v1;
			rv2 = v2;
			ru2 = u1;
			ru1 = u2;
			v1 = v2;
			v2 = rv1;
		} else if(this.uvRotateSouth == 1) {
			u1 = ((double)(i10 + 16) - block1.maxY * 16.0D) / taw;
			v1 = ((double)i11 + block1.maxZ * 16.0D) / tah;
			u2 = ((double)(i10 + 16) - block1.minY * 16.0D) / taw;
			v2 = ((double)i11 + block1.minZ * 16.0D) / tah;
			ru2 = u2;
			ru1 = u1;
			u1 = u2;
			u2 = ru1;
			rv1 = v2;
			rv2 = v1;
		} else if(this.uvRotateSouth == 3) {
			u1 = ((double)(i10 + 16) - block1.minZ * 16.0D) / taw;
			u2 = ((double)(i10 + 16) - block1.maxZ * 16.0D - 0.01D) / taw;
			v1 = ((double)i11 + block1.maxY * 16.0D) / tah;
			v2 = ((double)i11 + block1.minY * 16.0D - 0.01D) / tah;
			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		} else {
			u1 = ((double)i10 + block1.minZ * 16.0D) / taw;
			u2 = ((double)i10 + block1.maxZ * 16.0D - 0.01D) / taw;
			v1 = ((double)(i11 + 16) - block1.maxY * 16.0D) / tah;
			v2 = ((double)(i11 + 16) - block1.minY * 16.0D - 0.01D) / tah;

			if(this.flipTexture) {
				ru2 = u1;
				u1 = u2;
				u2 = ru2;
			}

			if(block1.minZ < 0.0D || block1.maxZ > 1.0D) {
				u1 = (double)(((float)i10 + 0.0F) / taw);
				u2 = (double)(((float)i10 + 15.99F) / taw);
			}

			if(block1.minY < 0.0D || block1.maxY > 1.0D) {
				v1 = (double)(((float)i11 + 0.0F) / tah);
				v2 = (double)(((float)i11 + 15.99F) / tah);
			}

			ru2 = u2;
			ru1 = u1;
			rv1 = v1;
			rv2 = v2;
		}

		double d28 = d2 + block1.maxX;
		double d30 = d4 + block1.minY;
		double d32 = d4 + block1.maxY;
		double d34 = d6 + block1.minZ;
		double d36 = d6 + block1.maxZ;
		if(this.enableAO) {
			tessellator9.setColorOpaque_F(this.colorRedTopLeft, this.colorGreenTopLeft, this.colorBlueTopLeft);
			tessellator9.setBrightness(this.brightnessTopLeft);
			tessellator9.addVertexWithUV(d28, d30, d36, ru1, rv2);
			tessellator9.setColorOpaque_F(this.colorRedBottomLeft, this.colorGreenBottomLeft, this.colorBlueBottomLeft);
			tessellator9.setBrightness(this.brightnessBottomLeft);
			tessellator9.addVertexWithUV(d28, d30, d34, u2, v2);
			tessellator9.setColorOpaque_F(this.colorRedBottomRight, this.colorGreenBottomRight, this.colorBlueBottomRight);
			tessellator9.setBrightness(this.brightnessBottomRight);
			tessellator9.addVertexWithUV(d28, d32, d34, ru2, rv1);
			tessellator9.setColorOpaque_F(this.colorRedTopRight, this.colorGreenTopRight, this.colorBlueTopRight);
			tessellator9.setBrightness(this.brightnessTopRight);
			tessellator9.addVertexWithUV(d28, d32, d36, u1, v1);
		} else {
			tessellator9.addVertexWithUV(d28, d30, d36, ru1, rv2);
			tessellator9.addVertexWithUV(d28, d30, d34, u2, v2);
			tessellator9.addVertexWithUV(d28, d32, d34, ru2, rv1);
			tessellator9.addVertexWithUV(d28, d32, d36, u1, v1);
		}

	}


	// Custom renderers

	public boolean renderBlockWall(Block block, int x, int y, int z) {
		Tessellator tessellator5 = Tessellator.instance;
		int i6 = block.getBlockTextureFromSide(0);
		if(this.overrideBlockTexture >= 0) {
			i6 = this.overrideBlockTexture;
		}

		/*
		float f7 = block.getBlockBrightness(this.blockAccess, x, y, z);
		tessellator5.setColorOpaque_F(f7, f7, f7);
		*/
		tessellator5.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));
		tessellator5.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		
		/*
		int i8 = (i6 & 15) << 4;
		int i9 = i6 & 240;
		double d10 = (double)((float)i8 / 256.0F);
		double d12 = (double)(((float)i8 + 15.99F) / 256.0F);
		double d14 = (double)((float)i9 / 256.0F);
		double d16 = (double)(((float)i9 + 15.99F) / 256.0F);
		*/
		Idx2uvF.calc(i6);
		double d10 = Idx2uvF.u1;
		double d12 = Idx2uvF.u2;
		double d14 = Idx2uvF.v1;
		double d16 = Idx2uvF.v2;
		
		int i18 = this.blockAccess.getBlockMetadata(x, y, z);
		
		float of1 = 0.49F; 
		float of2 = 0.51F;
		
		if(i18 == 4 || i18 == 5) {
			tessellator5.addVertexWithUV((double)((float)x + of1), (double)(y + 1), (double)(z + 1), d10, d14);
			tessellator5.addVertexWithUV((double)((float)x + of1), (double)(y + 0), (double)(z + 1), d10, d16);
			tessellator5.addVertexWithUV((double)((float)x + of1), (double)(y + 0), (double)(z + 0), d12, d16);
			tessellator5.addVertexWithUV((double)((float)x + of1), (double)(y + 1), (double)(z + 0), d12, d14);
			
			tessellator5.addVertexWithUV((double)((float)x + of2), (double)(y + 1), (double)(z + 0), d12, d14);
			tessellator5.addVertexWithUV((double)((float)x + of2), (double)(y + 0), (double)(z + 0), d12, d16);
			tessellator5.addVertexWithUV((double)((float)x + of2), (double)(y + 0), (double)(z + 1), d10, d16);
			tessellator5.addVertexWithUV((double)((float)x + of2), (double)(y + 1), (double)(z + 1), d10, d14);
		}

		if(i18 == 2 || i18 == 3) {
			tessellator5.addVertexWithUV((double)(x + 1), (double)(y + 0), (double)((float)z + of1), d12, d16);
			tessellator5.addVertexWithUV((double)(x + 1), (double)(y + 1), (double)((float)z + of1), d12, d14);
			tessellator5.addVertexWithUV((double)(x + 0), (double)(y + 1), (double)((float)z + of1), d10, d14);
			tessellator5.addVertexWithUV((double)(x + 0), (double)(y + 0), (double)((float)z + of1), d10, d16);
			
			tessellator5.addVertexWithUV((double)(x + 0), (double)(y + 0), (double)((float)z + of1), d10, d16);
			tessellator5.addVertexWithUV((double)(x + 0), (double)(y + 1), (double)((float)z + of1), d10, d14);
			tessellator5.addVertexWithUV((double)(x + 1), (double)(y + 1), (double)((float)z + of1), d12, d14);
			tessellator5.addVertexWithUV((double)(x + 1), (double)(y + 0), (double)((float)z + of1), d12, d16);
		}

		return true;
	}
	
	public boolean renderBarbedWire(Block block, int x, int y, int z) {
		Tessellator tessellator = Tessellator.instance;		
		
		/*
		float blockBrightness = block.getBlockBrightness(this.blockAccess, x, y, z);
		tessellator.setColorOpaque_F(blockBrightness, blockBrightness, blockBrightness);
		*/
		
		tessellator.setBrightness(block.getMixedBrightnessForBlock(this.blockAccess, x, y, z));
		tessellator.setColorOpaque_F(1.0F, 1.0F, 1.0F);
		
		int textureIndex = block.getBlockTextureFromSide(2);
		if(this.overrideBlockTexture >= 0) {
			textureIndex = this.overrideBlockTexture;
		}
		
		/*
		int u0 = (textureIndex & 15) << 4;
		int v0 = textureIndex & 0xf0;
		
		double u1 = (double)((float)u0 / 256.0F);
		double uh = (double)(((float)u0 + 8.00F) / 256.0F);
		double u2 = (double)(((float)u0 + 15.99F) / 256.0F);
		
		double v1 = (double)((float)v0 / 256.0F);
		double v2 = (double)(((float)v0 + 15.99F) / 256.0F);		
		*/
		Idx2uvF.calc(textureIndex);
		double u1 = Idx2uvF.u1;
		double uh = u1 + Texels.texelsV(8F);
		double u2 = Idx2uvF.u2;
		double v1 = Idx2uvF.v1;
		double v2 = Idx2uvF.v2;
		
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		
		if (meta == 4 || meta == 5) {
			// half 1, side 1, add vertexes CCW
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 0.0F, (double)z + 1.0F, uh, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 1.0F, (double)z + 0.5F, u1, v1);
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 1.0F, u1, v2);
		
			// half 1, side 2, add vertexes CW
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 1.0F, u1, v2);
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 1.0F, (double)z + 0.5F, u1, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 0.0F, (double)z + 1.0F, uh, v2);			

			// half 2, side 1, add vertexes CCW
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.0F, u2, v2);
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 1.0F, (double)z + 0.5F, u2, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 0.0F, (double)z + 0.0F, uh, v2);
					
			// half 2, side 2, add vertexes CW
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 0.0F, (double)z + 0.0F, uh, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 1.0F, (double)z + 0.5F, u2, v1);
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.0F, u2, v2);
		} else if (meta == 2 || meta == 3) {
			
			// half 1, side 1, add vertexes CCW
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.5F, uh, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.0F, u1, v1);
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.0F, u1, v2);
			
			// half 1, side 2, add vertexes CW
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.0F, u1, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.0F, u1, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 1.0F, (double)y + 0.0F, (double)z + 0.5F, uh, v2);		
			
			// half 2, side 1, add vertexes CCW
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 1.0F, u2, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 1.0F, u2, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 0.5F, uh, v2);
			
			// half 2, side 2, add vertexes CW
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 0.5F, uh, v2);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 0.5F, uh, v1);
			tessellator.addVertexWithUV((double)x + 0.5F, (double)y + 1.0F, (double)z + 1.0F, u2, v1);
			tessellator.addVertexWithUV((double)x + 0.0F, (double)y + 0.0F, (double)z + 1.0F, u2, v2);		
			
		}
		
		return true;
	}
	
	public boolean renderHollowTrunk(Block block, int x, int y, int z) {
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		
		int ti_0, ti_1, ti_2;
		if(this.overrideBlockTexture >= 0) {
			ti_0 = ti_1 = ti_2 = overrideBlockTexture;
		} else {
			ti_0 = block.getBlockTextureFromSide(0);
			ti_1 = block.getBlockTextureFromSide(1);
			ti_2 = block.getBlockTextureFromSide(2);
		}
			
		RenderBlockHollowLog.renderBlock(this.blockAccess, block, meta, x, y, z, ti_0, ti_1, ti_2);
		return true;
	}
	
	public boolean renderBlockDirtPath(Block block, int x, int y, int z) {
		block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 15.0F * (1 / 16.0F), 1.0F);
		return this.renderStandardBlock(block, x, y, z);
	}
	
	
	public boolean renderBlockChippedWood(Block block, int x, int y, int z) {
		float x1, y1, z1, x2, y2, z2;
		float u1, v1, u2, v2;
		
		Tessellator tessellator = Tessellator.instance;
		
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		
		if((meta & 4) == 0) {
			block.setBlockBounds((1 / 16.0F), 0.0F, (1 / 16.0F), 15 * (1 / 16.0F), 1.0F, 15 * (1 / 16.0F));
			this.renderStandardBlock(block, x, y, z);
			block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
			return true;
		} else if((meta & 8) != 0) { 
			// facing North/South
			
			// Texture #1 (ends)
			int ti_1 = block.getBlockTexture(blockAccess, x, y, z, 1); 	// CUSTOM : side = 1 means "ends"
			if(this.overrideBlockTexture >= 0) ti_1 = this.overrideBlockTexture;
			
			float t1_u = (float) ((ti_1 & 0x0f) << 4) / TextureAtlasSize.w;
			float t1_v = (float) (ti_1 & 0xff0) / TextureAtlasSize.h;

			// Texture #2 (sides)
			int ti_2 = block.getBlockTexture(blockAccess, x, y, z, 0); 	// CUSTOM : side = 1 means "sides"
			if(this.overrideBlockTexture >= 0) ti_2 = this.overrideBlockTexture;
			
			float t2_u = (float) ((ti_2 & 0x0f) << 4) / TextureAtlasSize.w;
			float t2_v = (float) (ti_2 & 0xff0) / TextureAtlasSize.h;
			
			x1 = x + 0.0000F;
			y1 = y + 0.0625F;
			z1 = z + 0.0625F;
			x2 = x + 1.0000F;
			y2 = y + 0.9375F;
			z2 = z + 0.9375F;

			setLightValue(tessellator, blockAccess, block, x, y + 1, z, 1.0F);
			u1 = t2_u; //  + 0.0000000F;
			v1 = t2_v; //  + 0.0000000F;
			u2 = t2_u + Texels.texelsU(16); // 0.0625000F;
			v2 = t2_v + Texels.texelsV(16); // 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y2, z1, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x, y - 1, z, 0.5F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x1, y1, z2, u1, v2);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u1, v1);

			setLightValue(tessellator, blockAccess, block, x, y, z - 1, 0.8F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x1, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z + 1, 0.8F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x1, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x + 1, y, z, 0.6F);
			u1 = t1_u + Texels.texelsU(1); // 0.00390625F;
			v1 = t1_v + Texels.texelsV(1); // 0.00390625F;
			u2 = t1_u + Texels.texelsU(15); // 0.05859375F;
			v2 = t1_v + Texels.texelsV(15); // 0.05859375F;
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x - 1, y, z, 0.6F);
			/*
			u1 = t1_u + 0.00390625F;
			v1 = t1_v + 0.00390625F;
			u2 = t1_u + 0.05859375F;
			v2 = t1_v + 0.05859375F;
			*/
			tessellator.addVertexWithUV(x1, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);
			
			return true;
		} else {
			// facing East/West
			
			// Texture #1 (ends)
			int ti_1 = block.getBlockTexture(blockAccess, x, y, z, 1); 	// CUSTOM : side = 1 means "ends"
			if(this.overrideBlockTexture >= 0) ti_1 = this.overrideBlockTexture;
			float t1_u = (float) ((ti_1 & 0x0f) << 4) / TextureAtlasSize.w;
			float t1_v = (float) (ti_1 & 0xff0) / TextureAtlasSize.h;

			// Texture #2 (sides)
			int ti_2 = block.getBlockTexture(blockAccess, x, y, z, 0); 	// CUSTOM : side = 1 means "sides"
			if(this.overrideBlockTexture >= 0) ti_2 = this.overrideBlockTexture;
			float t2_u = (float) ((ti_2 & 0x0f) << 4) / TextureAtlasSize.w;
			float t2_v = (float) (ti_2 & 0xff0) / TextureAtlasSize.h;
			
			x1 = x + 0.0625F;
			y1 = y + 0.0625F;
			z1 = z + 0.0000F;
			x2 = x + 0.9375F;
			y2 = y + 0.9375F;
			z2 = z + 1.0000F;

			setLightValue(tessellator, blockAccess, block, x, y + 1, z, 1.0F);
			u1 = t2_u; //  + 0.0000000F;
			v1 = t2_v; //  + 0.0000000F;
			u2 = t2_u + Texels.texelsU(16); // 0.0625000F;
			v2 = t2_v + Texels.texelsV(16); // 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x1, y2, z1, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u2, v1);

			setLightValue(tessellator, blockAccess, block, x, y - 1, z, 0.5F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x1, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);
			tessellator.addVertexWithUV(x2, y1, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y1, z2, u1, v1);

			setLightValue(tessellator, blockAccess, block, x + 1, y, z, 0.6F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x1, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x - 1, y, z, 0.6F);
			/*
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			*/
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z - 1, 0.8F);
			u1 = t1_u + Texels.texelsU(1); // 0.00390625F;
			v1 = t1_v + Texels.texelsV(1); // 0.00390625F;
			u2 = t1_u + Texels.texelsU(15); // 0.05859375F;
			v2 = t1_v + Texels.texelsV(15); // 0.05859375F;
			tessellator.addVertexWithUV(x1, y2, z1, u2, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u1, v2);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z + 1, 0.8F);
			/*
			u1 = t1_u + 0.00390625F;
			v1 = t1_v + 0.00390625F;
			u2 = t1_u + 0.05859375F;
			v2 = t1_v + 0.05859375F;
			*/
			tessellator.addVertexWithUV(x1, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u1, v2);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u2, v1);
			
			return true;
		}

	}
	
	public boolean renderBlockStreetLantern(Block block, int x, int y, int z) {
		// Add a torch for non broken street lanterns
		if(this.activeRenderPass == 0) {
			if(block.blockID == Block.streetLantern.blockID) {
				Tessellator tessellator = Tessellator.instance;
				tessellator.setColorOpaque_F(1.0F, 1.0F, 1.0F);		
				this.renderTorchAtAngle(Block.torchWood, (double)x, (double)y, (double)z, 0.0D, 0.0D);
				return true;
			} else {
				return false;
			}
		} else {
			return this.renderBlockCactus(block, x, y, z);
		}
	}
	
	public boolean renderBlockSlime(Block block, int x, int y, int z) {
		// This renderer sends different quads depending on the active renderPass
		
		if(this.activeRenderPass == 0) {
			// Set dimensions of inner block
			block.setBlockBounds(0.125F, 0.125F, 0.125F, 0.875F, 0.875F, 0.875F);
			
			// Render inner box
			boolean wasRendered = this.renderStandardBlock(block, x, y, z);
			
			// Set dimensions of outer block
			block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		
			return wasRendered;
		} else {
			// Render outer box
			return this.renderStandardBlock(block, x, y, z);
		}
	}
	
	public static void setLightValue (Tessellator tessellator, IBlockAccess blockAccess, Block block, float x, float y, float z, float factor) {
		/*
		float f;
		if (blockAccess == null) f = factor; else f = block.getBlockBrightness(blockAccess, (int) x, (int) y, (int) z) * factor;
		if (Block.lightValue[block.blockID] > 0) f = factor;
		tessellator.setColorOpaque_F(f, f, f);
		*/
		
		tessellator.setBrightness(block.getMixedBrightnessForBlock(blockAccess, (int)x, (int)y, (int)z));
		tessellator.setColorOpaque_F(factor, factor, factor);
	}
	
	/*
	public boolean renderBlockWoodOriented(Block block, int x, int y, int z) {
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		if((meta & 4) == 0) {
			return this.renderStandardBlock(block, x, y, z); 
		} else {
			int standardMeta = (meta & 8) != 0 ? 4 : 2;
			return this.renderBlockAxisOriented(block, x, y, z, standardMeta);
		}
	}
	*/
	
	public boolean renderBlockWoodOriented(Block block, int x, int y, int z) {
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		int orientation = meta & 12;
		if(orientation == 12) {
			this.uvRotateEast = 1;
			this.uvRotateWest = 1;
			this.uvRotateTop = 1;
			this.uvRotateBottom = 1;
		} else if(orientation == 4) {
			this.uvRotateSouth = 1;
			this.uvRotateNorth = 1;
		}

		boolean res = this.renderStandardBlock(block, x, y, z);
		this.uvRotateSouth = 0;
		this.uvRotateEast = 0;
		this.uvRotateWest = 0;
		this.uvRotateNorth = 0;
		this.uvRotateTop = 0;
		this.uvRotateBottom = 0;
		return res;
	}
	
	public boolean renderBlockAxisOriented(Block block, int x, int y, int z) {	
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		
		if(meta == 4 || meta == 5) {
			this.uvRotateEast = 1;
			this.uvRotateWest = 1;
			this.uvRotateTop = 1;
			this.uvRotateBottom = 1;
		} else if(meta == 2 || meta == 3) {
			this.uvRotateSouth = 1;
			this.uvRotateNorth = 1;
		}

		boolean res = this.renderStandardBlock(block, x, y, z);
		this.uvRotateSouth = 0;
		this.uvRotateEast = 0;
		this.uvRotateWest = 0;
		this.uvRotateNorth = 0;
		this.uvRotateTop = 0;
		this.uvRotateBottom = 0;
		return res;
	}
	
	/*
	public boolean renderBlockAxisOriented(Block block, int x, int y, int z) {	
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		return this.renderBlockAxisOriented(block, x, y, z, meta);
	}
	
	public boolean renderBlockAxisOriented(Block block, int x, int y, int z, int meta) {
		float x1, y1, z1, x2, y2, z2;
		float u1, v1, u2, v2;
		
		Tessellator tessellator = Tessellator.instance;
				
		if(meta == 0) {
			return this.renderStandardBlock(block, x, y, z);
		} else if(meta == 4 || meta == 5) {
			// facing North/South
			
			// Texture #1 (ends)
			int ti_1 = block.getBlockTexture(blockAccess, x, y, z, 1); 	// CUSTOM : side = 1 means "ends"
			float t1_u = (float) ((ti_1 & 0x0f) << 4) / 256.0F;
			float t1_v = (float) (ti_1 & 0xff0) / 256.0F;

			// Texture #2 (sides)
			int ti_2 = block.getBlockTexture(blockAccess, x, y, z, 0); 	// CUSTOM : side = 1 means "sides"
			float t2_u = (float) ((ti_2 & 0x0f) << 4) / 256.0F;
			float t2_v = (float) (ti_2 & 0xff0) / 256.0F;
			
			x1 = x + 0.0000F;
			y1 = y + 0.0000F;
			z1 = z + 0.0000F;
			x2 = x + 1.0000F;
			y2 = y + 1.0000F;
			z2 = z + 1.0000F;

			setLightValue(tessellator, blockAccess, block, x, y + 1, z, 1.0F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y2, z1, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x, y - 1, z, 0.5F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y1, z2, u1, v2);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u1, v1);

			setLightValue(tessellator, blockAccess, block, x, y, z - 1, 0.8F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z + 1, 0.8F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x + 1, y, z, 0.6F);
			u1 = t1_u + 0.0000000F;
			v1 = t1_v + 0.0000000F;
			u2 = t1_u + 0.0625000F;
			v2 = t1_v + 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x - 1, y, z, 0.6F);
			u1 = t1_u + 0.0000000F;
			v1 = t1_v + 0.0000000F;
			u2 = t1_u + 0.0625000F;
			v2 = t1_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);
			
			return true;
		} else if(meta == 2 || meta == 3) {
			// facing East/West
			
			// Texture #1 (ends)
			int ti_1 = block.getBlockTexture(blockAccess, x, y, z, 1); 	// CUSTOM : side = 1 means "ends"
			float t1_u = (float) ((ti_1 & 0x0f) << 4) / 256.0F;
			float t1_v = (float) (ti_1 & 0xff0) / 256.0F;

			// Texture #2 (sides)
			int ti_2 = block.getBlockTexture(blockAccess, x, y, z, 0); 	// CUSTOM : side = 1 means "sides"
			float t2_u = (float) ((ti_2 & 0x0f) << 4) / 256.0F;
			float t2_v = (float) (ti_2 & 0xff0) / 256.0F;
			
			x1 = x + 1.0000F;
			y1 = y + 0.0000F;
			z1 = z + 1.0000F;
			x2 = x + 0.0000F;
			y2 = y + 1.0000F;
			z2 = z + 0.0000F;

			setLightValue(tessellator, blockAccess, block, x, y + 1, z, 1.0F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x1, y2, z1, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u2, v1);

			setLightValue(tessellator, blockAccess, block, x, y - 1, z, 0.5F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);
			tessellator.addVertexWithUV(x2, y1, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y1, z2, u1, v1);

			setLightValue(tessellator, blockAccess, block, x + 1, y, z, 0.6F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x1, y2, z2, u1, v2);

			setLightValue(tessellator, blockAccess, block, x - 1, y, z, 0.6F);
			u1 = t2_u + 0.0000000F;
			v1 = t2_v + 0.0000000F;
			u2 = t2_u + 0.0625000F;
			v2 = t2_v + 0.0625000F;
			tessellator.addVertexWithUV(x2, y2, z1, u1, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z + 1, 0.8F);
			u1 = t1_u + 0.0000000F;
			v1 = t1_v + 0.0000000F;
			u2 = t1_u + 0.0625000F;
			v2 = t1_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z1, u2, v1);
			tessellator.addVertexWithUV(x2, y2, z1, u1, v1);
			tessellator.addVertexWithUV(x2, y1, z1, u1, v2);
			tessellator.addVertexWithUV(x1, y1, z1, u2, v2);

			setLightValue(tessellator, blockAccess, block, x, y, z - 1, 0.8F);
			u1 = t1_u + 0.0000000F;
			v1 = t1_v + 0.0000000F;
			u2 = t1_u + 0.0625000F;
			v2 = t1_v + 0.0625000F;
			tessellator.addVertexWithUV(x1, y2, z2, u1, v1);
			tessellator.addVertexWithUV(x1, y1, z2, u1, v2);
			tessellator.addVertexWithUV(x2, y1, z2, u2, v2);
			tessellator.addVertexWithUV(x2, y2, z2, u2, v1);
			
			return true;
		}
		
		return false;
	}
	*/
	
	public boolean renderBlockClassicPiston(Block block, int x, int y, int z) {
		return RenderBlockClassicPiston.RenderWorldBlock(this, this.blockAccess, x, y, z, block, 0);
	}
	
	public boolean renderBlockModel(Block block, int x, int y, int z) {
		int meta = this.blockAccess.getBlockMetadata(x, y, z);
		return RenderBlockModel.renderBlock(this.blockAccess, block, x, y, z, meta);
	}
	
	// End
	
	public void renderBlockAsItem(Block block, float brightness) {
		int renderType = block.getRenderType();
		Tessellator tes = Tessellator.instance;
		if(renderType == 0) {
			block.setBlockBoundsForItemRender();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			float f5 = 0.5F;
			float n1 = 1.0F;
			float n2 = 0.8F;
			float f8 = 0.6F;
			tes.startDrawingQuads();
			tes.setColorRGBA_F(n1, n1, n1, brightness);
			this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(0));
			tes.setColorRGBA_F(f5, f5, f5, brightness);
			this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(1));
			tes.setColorRGBA_F(n2, n2, n2, brightness);
			this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(2));
			this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(3));
			tes.setColorRGBA_F(f8, f8, f8, brightness);
			this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(4));
			this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(5));
			tes.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		} else {
			block.setBlockBoundsForItemRender();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			tes.startDrawingQuads();
			tes.setColorRGBA_F(1.0F, 1.0F, 1.0F, brightness);
			this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(0));
			tes.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		}

	}
	
	public void renderBlockOnInventory(Block block, int meta, float brightness) {
		Tessellator tes = Tessellator.instance;
		boolean isGrass = block.blockID == Block.grass.blockID;

		if(this.useInventoryTint) {
			int rgba = block.getRenderColor(meta);
			float r = (float)(rgba >> 16 & 255) / 255.0F;
			float g = (float)(rgba >> 8 & 255) / 255.0F;
			float b = (float)(rgba & 255) / 255.0F;
			GL11.glColor4f(r * brightness, g * brightness, b * brightness, 1.0F);
		}

		int renderType = block.getRenderType();
		float n1, n2;
		
		// Patch for blocks which can be rendered as cubes in the inventory
		if(
				(renderType >= 103 && renderType <= 108 && renderType != 104) ||
				renderType == 112 ||
				renderType == 255
		) renderType = 0;
		
		if(renderType == 250) {
			RenderBlockModel.renderBlockAsItem(tes, block, meta);

		} else if(renderType != 0 && renderType != 16) {
			if(renderType == 1 || renderType == 111) {
				tes.startDrawingQuads();
				tes.setNormal(0.0F, -1.0F, 0.0F);
				this.drawCrossedSquares(block, meta, -0.5D, -0.5D, -0.5D);
				tes.draw();

			} else if(renderType == 13 || renderType == 104) {
				block.setBlockBoundsForItemRender();
				GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
				n1 = 0.0625F;
				tes.startDrawingQuads();
				tes.setNormal(0.0F, -1.0F, 0.0F);
				this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(0));
				tes.draw();
				tes.startDrawingQuads();
				tes.setNormal(0.0F, 1.0F, 0.0F);
				this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(1));
				tes.draw();
				tes.startDrawingQuads();
				tes.setNormal(0.0F, 0.0F, -1.0F);
				tes.addTranslation(0.0F, 0.0F, n1);
				this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(2));
				tes.addTranslation(0.0F, 0.0F, -n1);
				tes.draw();
				tes.startDrawingQuads();
				tes.setNormal(0.0F, 0.0F, 1.0F);
				tes.addTranslation(0.0F, 0.0F, -n1);
				this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(3));
				tes.addTranslation(0.0F, 0.0F, n1);
				tes.draw();
				tes.startDrawingQuads();
				tes.setNormal(-1.0F, 0.0F, 0.0F);
				tes.addTranslation(n1, 0.0F, 0.0F);
				this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(4));
				tes.addTranslation(-n1, 0.0F, 0.0F);
				tes.draw();
				tes.startDrawingQuads();
				tes.setNormal(1.0F, 0.0F, 0.0F);
				tes.addTranslation(-n1, 0.0F, 0.0F);
				this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(5));
				tes.addTranslation(n1, 0.0F, 0.0F);
				tes.draw();
				GL11.glTranslatef(0.5F, 0.5F, 0.5F);

			} else if(renderType == 6) {
				tes.startDrawingQuads();
				tes.setNormal(0.0F, -1.0F, 0.0F);
				this.renderBlockCropsImpl(block, meta, -0.5D, -0.5D, -0.5D);
				tes.draw();

			} else if(renderType == 2) {
				tes.startDrawingQuads();
				tes.setNormal(0.0F, -1.0F, 0.0F);
				this.renderTorchAtAngle(block, -0.5D, -0.5D, -0.5D, 0.0D, 0.0D);
				tes.draw();

			} else if(renderType == 102) {
				block.setBlockBoundsForItemRender();
				GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
				tes.startDrawingQuads();
				RenderBlockHollowLog.renderAsItem(this.blockAccess, block, block.getBlockTextureFromSide(0), block.getBlockTextureFromSide(1), block.getBlockTextureFromSide(2), tes, 1.0F);
				tes.draw();
				GL11.glTranslatef(0.5F, 0.5F, 0.5F);

			} else if(renderType == 109) {
				RenderBlockClassicPiston.RenderInvBlock(this, block, 0, 0);
			
			} else {
				int i9;
				if(renderType == 10) {
					for(i9 = 0; i9 < 2; ++i9) {
						if(i9 == 0) {
							block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.5F);
						}

						if(i9 == 1) {
							block.setBlockBounds(0.0F, 0.0F, 0.5F, 1.0F, 0.5F, 1.0F);
						}

						GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
						tes.startDrawingQuads();
						tes.setNormal(0.0F, -1.0F, 0.0F);
						this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(0));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 1.0F, 0.0F);
						this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(1));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 0.0F, -1.0F);
						this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(2));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 0.0F, 1.0F);
						this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(3));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(-1.0F, 0.0F, 0.0F);
						this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(4));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(1.0F, 0.0F, 0.0F);
						this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(5));
						tes.draw();
						GL11.glTranslatef(0.5F, 0.5F, 0.5F);
					}

				} else if(renderType == 11) {
					for(i9 = 0; i9 < 4; ++i9) {
						n2 = 0.125F;
						if(i9 == 0) {
							block.setBlockBounds(0.5F - n2, 0.0F, 0.0F, 0.5F + n2, 1.0F, n2 * 2.0F);
						}

						if(i9 == 1) {
							block.setBlockBounds(0.5F - n2, 0.0F, 1.0F - n2 * 2.0F, 0.5F + n2, 1.0F, 1.0F);
						}

						n2 = 0.0625F;
						if(i9 == 2) {
							block.setBlockBounds(0.5F - n2, 1.0F - n2 * 3.0F, -n2 * 2.0F, 0.5F + n2, 1.0F - n2, 1.0F + n2 * 2.0F);
						}

						if(i9 == 3) {
							block.setBlockBounds(0.5F - n2, 0.5F - n2 * 3.0F, -n2 * 2.0F, 0.5F + n2, 0.5F - n2, 1.0F + n2 * 2.0F);
						}

						GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
						tes.startDrawingQuads();
						tes.setNormal(0.0F, -1.0F, 0.0F);
						this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(0));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 1.0F, 0.0F);
						this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(1));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 0.0F, -1.0F);
						this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(2));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(0.0F, 0.0F, 1.0F);
						this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(3));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(-1.0F, 0.0F, 0.0F);
						this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(4));
						tes.draw();
						tes.startDrawingQuads();
						tes.setNormal(1.0F, 0.0F, 0.0F);
						this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSide(5));
						tes.draw();
						GL11.glTranslatef(0.5F, 0.5F, 0.5F);
					}

					block.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);

				}
			}
		} else {
			// Normal blocks. Added the release patch for grass

			if(renderType == 16) {
				meta = 1;
			}

			block.setBlockBoundsForItemRender();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			tes.startDrawingQuads();
			tes.setNormal(0.0F, -1.0F, 0.0F);
			this.renderBottomFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(0, meta));
			tes.draw();

			if(isGrass && this.useInventoryTint) {
				int rgba = block.getRenderColor(meta);
				float r = (float)(rgba >> 16 & 255) / 255.0F;
				float g = (float)(rgba >> 8 & 255) / 255.0F;
				float b = (float)(rgba & 255) / 255.0F;
				GL11.glColor4f(r * brightness, g * brightness, b * brightness, 1.0F);
			}

			tes.startDrawingQuads();
			tes.setNormal(0.0F, 1.0F, 0.0F);
			this.renderTopFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(1, meta));
			tes.draw();

			if(isGrass && this.useInventoryTint) {
				GL11.glColor4f(brightness, brightness, brightness, 1.0F);
			}
			
			tes.startDrawingQuads();
			tes.setNormal(0.0F, 0.0F, -1.0F);
			this.renderEastFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(2, meta));
			tes.draw();
			tes.startDrawingQuads();
			tes.setNormal(0.0F, 0.0F, 1.0F);
			this.renderWestFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(3, meta));
			tes.draw();
			tes.startDrawingQuads();
			tes.setNormal(-1.0F, 0.0F, 0.0F);
			this.renderNorthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(4, meta));
			tes.draw();
			tes.startDrawingQuads();
			tes.setNormal(1.0F, 0.0F, 0.0F);
			this.renderSouthFace(block, 0.0D, 0.0D, 0.0D, block.getBlockTextureFromSideAndMetadata(5, meta));
			tes.draw();
			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
		}

	}

	public static boolean renderItemIn3d(int i0) {
		//return i0 == 0 ? true : (i0 == 13 ? true : (i0 == 10 ? true : (i0 == 11 ? true : i0 == 16)));
		return (
				i0 == 0 || 
				i0 == 13 || 
				i0 == 10 || 
				i0 == 11 || 
				i0 == 16 || 
				(i0 >= 102 && i0 <= 109) || 
				i0 == 112 || 
				i0 == 255 || 
				i0 == 250
			);
	}
	

	static {
		for(int i = 0; i < redstoneColors.length; ++i) {
			float f = (float)i / 15.0F;
			float f1 = f * 0.6F + 0.4F;
			if(i == 0) {
				f = 0.0F;
			}

			float f2 = f * f * 0.7F - 0.5F;
			float f3 = f * f * 0.6F - 0.7F;
			if(f2 < 0.0F) {
				f2 = 0.0F;
			}

			if(f3 < 0.0F) {
				f3 = 0.0F;
			}

			redstoneColors[i] = new float[]{f1, f2, f3};
		}

	}
}
