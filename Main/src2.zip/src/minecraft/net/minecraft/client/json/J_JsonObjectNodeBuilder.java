package net.minecraft.client.json;

import java.util.LinkedList;
import java.util.List;

public final class J_JsonObjectNodeBuilder implements J_JsonNodeBuilder {
	private final List<J_JsonFieldBuilder> field_27238_a = new LinkedList<J_JsonFieldBuilder>();

	public J_JsonObjectNodeBuilder func_27237_a(J_JsonFieldBuilder j_JsonFieldBuilder1) {
		this.field_27238_a.add(j_JsonFieldBuilder1);
		return this;
	}

	public J_JsonRootNode func_27235_a() {
		return J_JsonNodeFactories.func_27312_a(new J_JsonObjectNodeList(this));
	}

	public J_JsonNode func_27234_b() {
		return this.func_27235_a();
	}

	static List<J_JsonFieldBuilder> func_27236_a(J_JsonObjectNodeBuilder j_JsonObjectNodeBuilder0) {
		return j_JsonObjectNodeBuilder0.field_27238_a;
	}
}
