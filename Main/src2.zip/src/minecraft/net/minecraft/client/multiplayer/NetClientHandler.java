package net.minecraft.client.multiplayer;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiConnectFailed;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.particle.EntityPickupFX;
import net.minecraft.client.player.EntityOtherPlayerMP;
import net.minecraft.client.player.EntityPlayerSP;
import net.minecraft.network.NetHandler;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.WatchableObject;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.Packet100OpenWindow;
import net.minecraft.network.packet.Packet101CloseWindow;
import net.minecraft.network.packet.Packet103SetSlot;
import net.minecraft.network.packet.Packet104WindowItems;
import net.minecraft.network.packet.Packet105UpdateProgressbar;
import net.minecraft.network.packet.Packet106Transaction;
import net.minecraft.network.packet.Packet10Flying;
import net.minecraft.network.packet.Packet130UpdateSign;
import net.minecraft.network.packet.Packet131MapData;
import net.minecraft.network.packet.Packet17Sleep;
import net.minecraft.network.packet.Packet18Animation;
import net.minecraft.network.packet.Packet1Login;
import net.minecraft.network.packet.Packet200Statistic;
import net.minecraft.network.packet.Packet20NamedEntitySpawn;
import net.minecraft.network.packet.Packet21PickupSpawn;
import net.minecraft.network.packet.Packet22Collect;
import net.minecraft.network.packet.Packet23VehicleSpawn;
import net.minecraft.network.packet.Packet24MobSpawn;
import net.minecraft.network.packet.Packet250CustomPayload;
import net.minecraft.network.packet.Packet255KickDisconnect;
import net.minecraft.network.packet.Packet25EntityPainting;
import net.minecraft.network.packet.Packet28EntityVelocity;
import net.minecraft.network.packet.Packet29DestroyEntity;
import net.minecraft.network.packet.Packet2Handshake;
import net.minecraft.network.packet.Packet30Entity;
import net.minecraft.network.packet.Packet34EntityTeleport;
import net.minecraft.network.packet.Packet38EntityStatus;
import net.minecraft.network.packet.Packet39AttachEntity;
import net.minecraft.network.packet.Packet3Chat;
import net.minecraft.network.packet.Packet40EntityMetadata;
import net.minecraft.network.packet.Packet4UpdateTime;
import net.minecraft.network.packet.Packet50PreChunk;
import net.minecraft.network.packet.Packet51MapChunk;
import net.minecraft.network.packet.Packet52MultiBlockChange;
import net.minecraft.network.packet.Packet53BlockChange;
import net.minecraft.network.packet.Packet54PlayNoteBlock;
import net.minecraft.network.packet.Packet5PlayerInventory;
import net.minecraft.network.packet.Packet60Explosion;
import net.minecraft.network.packet.Packet61DoorChange;
import net.minecraft.network.packet.Packet6SpawnPosition;
import net.minecraft.network.packet.Packet70Bed;
import net.minecraft.network.packet.Packet71Weather;
import net.minecraft.network.packet.Packet88MovingPiston;
import net.minecraft.network.packet.Packet8UpdateHealth;
import net.minecraft.network.packet.Packet90ArmoredMobSpawn;
import net.minecraft.network.packet.Packet91UpdateAnimalName;
import net.minecraft.network.packet.Packet93FiniteWorldSettings;
import net.minecraft.network.packet.Packet94FreezeLevel;
import net.minecraft.network.packet.Packet95UpdateDayOfTheYear;
import net.minecraft.network.packet.Packet96BadMoonDecide;
import net.minecraft.network.packet.Packet98UpdateWeather;
import net.minecraft.network.packet.Packet99SetCreativeMode;
import net.minecraft.network.packet.Packet9Respawn;
import net.minecraft.util.MathHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityCreature;
import net.minecraft.world.entity.EntityLightningBolt;
import net.minecraft.world.entity.EntityList;
import net.minecraft.world.entity.EntityLiving;
import net.minecraft.world.entity.EntityPainting;
import net.minecraft.world.entity.item.EntityBoat;
import net.minecraft.world.entity.item.EntityFallingSand;
import net.minecraft.world.entity.item.EntityItem;
import net.minecraft.world.entity.item.EntityMinecart;
import net.minecraft.world.entity.item.EntityMovingPiston;
import net.minecraft.world.entity.item.EntityTNTPrimed;
import net.minecraft.world.entity.mob.EntityArmoredMob;
import net.minecraft.world.entity.projectile.EntitySnowball;
import net.minecraft.world.entity.player.EntityPlayer;
import net.minecraft.world.entity.projectile.EntityArrow;
import net.minecraft.world.entity.projectile.EntityEgg;
import net.minecraft.world.entity.projectile.EntityFireball;
import net.minecraft.world.entity.projectile.EntityFish;
import net.minecraft.world.entity.projectile.EntityPebble;
import net.minecraft.world.entity.projectile.EntityTFNatureBolt;
import net.minecraft.world.entity.projectile.EntityThrowablePotion;
import net.minecraft.world.entity.projectile.EntityThrowableToxicFungus;
import net.minecraft.world.inventory.Container;
import net.minecraft.world.inventory.InventoryBasic;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.map.ItemMap;
import net.minecraft.world.item.map.MapStorage;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.World;
import net.minecraft.world.level.WorldSettings;
import net.minecraft.world.level.WorldSize;
import net.minecraft.world.level.WorldType;
import net.minecraft.world.level.biome.BiomeGenBase;
import net.minecraft.world.level.chunk.ChunkCoordinates;
import net.minecraft.world.level.chunk.storage.ISaveHandler;
import net.minecraft.world.level.theme.LevelThemeGlobalSettings;
import net.minecraft.world.level.tile.Block;
import net.minecraft.world.level.tile.entity.TileEntity;
import net.minecraft.world.level.tile.entity.TileEntityDispenser;
import net.minecraft.world.level.tile.entity.TileEntityFurnace;
import net.minecraft.world.level.tile.entity.TileEntitySign;
import net.minecraft.world.stats.StatList;

public class NetClientHandler extends NetHandler {
	private boolean disconnected = false;
	private NetworkManager netManager;
	public String field_1209_a;
	private Minecraft mc;
	private WorldClient worldClient;
	private boolean field_1210_g = false;
	public MapStorage field_28118_b = new MapStorage((ISaveHandler) null);
	Random rand = new Random();

	public NetClientHandler(Minecraft minecraft1, String string2, int i3) throws IOException, UnknownHostException {
		this.mc = minecraft1;
		Socket socket4 = new Socket(InetAddress.getByName(string2), i3);
		this.netManager = new NetworkManager(socket4, "Client", this);
	}

	public void processReadPackets() {
		if (!this.disconnected) {
			this.netManager.processReadPackets();
		}

		this.netManager.wakeThreads();
	}

	public void handleLogin(Packet1Login packet1Login1) {
		this.mc.playerController = new PlayerControllerMP(this.mc, this);
		this.mc.statFileWriter.readStat(StatList.joinMultiplayerStat, 1);
		this.worldClient = new WorldClient(this, new WorldSettings(0L, 0, false, false, false, false, WorldType.DEFAULT),
				packet1Login1.dimension, this.mc.gameSettings);
		this.worldClient.isRemote = true;
		this.mc.changeWorld(this.worldClient);
		this.mc.thePlayer.dimension = packet1Login1.dimension;
		this.mc.displayGuiScreen(new GuiDownloadTerrain(this));
		this.mc.thePlayer.entityId = packet1Login1.protocolVersion;
	}

	public void handlePickupSpawn(Packet21PickupSpawn packet21PickupSpawn1) {
		double d2 = (double) packet21PickupSpawn1.xPosition / 32.0D;
		double d4 = (double) packet21PickupSpawn1.yPosition / 32.0D;
		double d6 = (double) packet21PickupSpawn1.zPosition / 32.0D;
		EntityItem entityItem8 = new EntityItem(this.worldClient, d2, d4, d6, new ItemStack(packet21PickupSpawn1.itemID,
				packet21PickupSpawn1.count, packet21PickupSpawn1.itemDamage));
		entityItem8.motionX = (double) packet21PickupSpawn1.rotation / 128.0D;
		entityItem8.motionY = (double) packet21PickupSpawn1.pitch / 128.0D;
		entityItem8.motionZ = (double) packet21PickupSpawn1.roll / 128.0D;
		entityItem8.serverPosX = packet21PickupSpawn1.xPosition;
		entityItem8.serverPosY = packet21PickupSpawn1.yPosition;
		entityItem8.serverPosZ = packet21PickupSpawn1.zPosition;
		this.worldClient.addEntityToWorld(packet21PickupSpawn1.entityId, entityItem8);
	}

	public void handleVehicleSpawn(Packet23VehicleSpawn packet23VehicleSpawn1) {
		double posX = (double) packet23VehicleSpawn1.xPosition / 32.0D;
		double posY = (double) packet23VehicleSpawn1.yPosition / 32.0D;
		double posZ = (double) packet23VehicleSpawn1.zPosition / 32.0D;
		Object entityToSpawn = null;

		switch (packet23VehicleSpawn1.type) {
		case 10:
			entityToSpawn = new EntityMinecart(this.worldClient, posX, posY, posZ, 0);
			break;
		case 11:
			entityToSpawn = new EntityMinecart(this.worldClient, posX, posY, posZ, 1);
			break;
		case 12:
			entityToSpawn = new EntityMinecart(this.worldClient, posX, posY, posZ, 2);
			break;
		case 90:
			entityToSpawn = new EntityFish(this.worldClient, posX, posY, posZ);
			break;
		case 60:
			entityToSpawn = new EntityArrow(this.worldClient, posX, posY, posZ);
			break;
		case 61:
			entityToSpawn = new EntitySnowball(this.worldClient, posX, posY, posZ);
			break;
		case 63:
			entityToSpawn = new EntityFireball(this.worldClient, posX, posY, posZ,
					(double) packet23VehicleSpawn1.motionXencoded / 8000.0D,
					(double) packet23VehicleSpawn1.motionYencoded / 8000.0D,
					(double) packet23VehicleSpawn1.motionZencoded / 8000.0D);
			packet23VehicleSpawn1.throwerEntityId = 0;
			break;
		case 62:
			entityToSpawn = new EntityEgg(this.worldClient, posX, posY, posZ);
			break;
		case 1:
			entityToSpawn = new EntityBoat(this.worldClient, posX, posY, posZ, false);
			break;
		case 50:
			entityToSpawn = new EntityTNTPrimed(this.worldClient, posX, posY, posZ);
			break;
		case 70:
			entityToSpawn = new EntityFallingSand(this.worldClient, posX, posY, posZ, Block.sand.blockID);
			break;
		case 71:
			entityToSpawn = new EntityFallingSand(this.worldClient, posX, posY, posZ, Block.gravel.blockID);
			break;

		// Custom

		case 100:
			entityToSpawn = new EntityPebble(this.worldClient, posX, posY, posZ);
			break;

		case 101:
			entityToSpawn = new EntityThrowablePotion(this.worldClient, posX, posY, posZ,
					packet23VehicleSpawn1.metadata);
			break;
			
		case 102:
			entityToSpawn = new EntityTFNatureBolt(this.worldClient, posX, posY, posZ);
			break;
			
		case 103:
			entityToSpawn = new EntityThrowableToxicFungus(this.worldClient, posX, posY, posZ);
			break;
			
		case 120:
			entityToSpawn = new EntityBoat(this.worldClient, posX, posY, posZ, true);
			break;

		}

		if (entityToSpawn != null) {
			((Entity) entityToSpawn).serverPosX = packet23VehicleSpawn1.xPosition;
			((Entity) entityToSpawn).serverPosY = packet23VehicleSpawn1.yPosition;
			((Entity) entityToSpawn).serverPosZ = packet23VehicleSpawn1.zPosition;
			((Entity) entityToSpawn).rotationYaw = 0.0F;
			((Entity) entityToSpawn).rotationPitch = 0.0F;
			((Entity) entityToSpawn).entityId = packet23VehicleSpawn1.entityId;
			
			this.worldClient.addEntityToWorld(packet23VehicleSpawn1.entityId, (Entity) entityToSpawn);
			
			if (packet23VehicleSpawn1.throwerEntityId > 0) {
				Entity e = this.getEntityByID(packet23VehicleSpawn1.throwerEntityId);
				if (e instanceof EntityLiving) {
					switch (packet23VehicleSpawn1.type) {
					case 60:
						((EntityArrow) entityToSpawn).shootingEntity = (EntityLiving) e;
						break;
					case 101:
						((EntityThrowablePotion) entityToSpawn).thrower = (EntityLiving) e;
						break;
					case 102:
						((EntityTFNatureBolt) entityToSpawn).thrower = (EntityLiving) e;
						break;
					case 103:
						((EntityThrowableToxicFungus) entityToSpawn).thrower = (EntityLiving) e;
						break;
					}
				}

				((Entity) entityToSpawn).setVelocity((double) packet23VehicleSpawn1.motionXencoded / 8000.0D,
						(double) packet23VehicleSpawn1.motionYencoded / 8000.0D,
						(double) packet23VehicleSpawn1.motionZencoded / 8000.0D);
			}
		}

	}
	
	@Override
	public void handleMovingPiston(Packet88MovingPiston packet) {
		EntityMovingPiston piston = new EntityMovingPiston(this.worldClient, packet.x, packet.y, packet.z, packet.sticky);
		piston.xmove = packet.xmove;
		piston.ymove = packet.ymove;
		piston.zmove = packet.zmove;
		piston.data = packet.data;
		piston.entityId = packet.entityId;
		this.worldClient.addEntityToWorld(packet.entityId, (Entity)piston);
	}

	public void handleWeather(Packet71Weather packet71Weather1) {
		double d2 = (double) packet71Weather1.encodedPosX / 32.0D;
		double d4 = (double) packet71Weather1.encodedPosY / 32.0D;
		double d6 = (double) packet71Weather1.encodedPosZ / 32.0D;
		EntityLightningBolt entityLightningBolt8 = null;
		if (packet71Weather1.lightning == 1) {
			entityLightningBolt8 = new EntityLightningBolt(this.worldClient, d2, d4, d6);
		}

		if (entityLightningBolt8 != null) {
			entityLightningBolt8.serverPosX = packet71Weather1.encodedPosX;
			entityLightningBolt8.serverPosY = packet71Weather1.encodedPosY;
			entityLightningBolt8.serverPosZ = packet71Weather1.encodedPosZ;
			entityLightningBolt8.rotationYaw = 0.0F;
			entityLightningBolt8.rotationPitch = 0.0F;
			entityLightningBolt8.entityId = packet71Weather1.entityID;
			this.worldClient.addWeatherEffect(entityLightningBolt8);
		}

	}

	public void handleEntityPainting(Packet25EntityPainting packet25EntityPainting1) {
		EntityPainting entityPainting2 = new EntityPainting(this.worldClient, packet25EntityPainting1.xPosition,
				packet25EntityPainting1.yPosition, packet25EntityPainting1.zPosition, packet25EntityPainting1.direction,
				packet25EntityPainting1.title);
		this.worldClient.addEntityToWorld(packet25EntityPainting1.entityId, entityPainting2);
	}

	public void handleEntityVelocity(Packet28EntityVelocity packet28EntityVelocity1) {
		Entity entity2 = this.getEntityByID(packet28EntityVelocity1.entityId);
		if (entity2 instanceof EntitySnowball)
			System.out.println("HandleVelocity for " + entity2.getClass() + " > " + packet28EntityVelocity1.motionY);
		if (entity2 != null) {
			entity2.setVelocity((double) packet28EntityVelocity1.motionX / 8000.0D,
					(double) packet28EntityVelocity1.motionY / 8000.0D,
					(double) packet28EntityVelocity1.motionZ / 8000.0D);
		}
	}

	public void handleEntityMetadata(Packet40EntityMetadata packet40EntityMetadata1) {
		Entity entity2 = this.getEntityByID(packet40EntityMetadata1.entityId);
		if (entity2 != null && packet40EntityMetadata1.getMetadata() != null) {
			entity2.getDataWatcher().updateWatchedObjectsFromList(packet40EntityMetadata1.getMetadata());
		}

	}

	public void handleNamedEntitySpawn(Packet20NamedEntitySpawn packet20NamedEntitySpawn1) {
		double d2 = (double) packet20NamedEntitySpawn1.xPosition / 32.0D;
		double d4 = (double) packet20NamedEntitySpawn1.yPosition / 32.0D;
		double d6 = (double) packet20NamedEntitySpawn1.zPosition / 32.0D;
		float f8 = (float) (packet20NamedEntitySpawn1.rotation * 360) / 256.0F;
		float f9 = (float) (packet20NamedEntitySpawn1.pitch * 360) / 256.0F;
		EntityOtherPlayerMP entityOtherPlayerMP10 = new EntityOtherPlayerMP(this.mc.theWorld,
				packet20NamedEntitySpawn1.name);
		entityOtherPlayerMP10.prevPosX = entityOtherPlayerMP10.lastTickPosX = (double) (entityOtherPlayerMP10.serverPosX = packet20NamedEntitySpawn1.xPosition);
		entityOtherPlayerMP10.prevPosY = entityOtherPlayerMP10.lastTickPosY = (double) (entityOtherPlayerMP10.serverPosY = packet20NamedEntitySpawn1.yPosition);
		entityOtherPlayerMP10.prevPosZ = entityOtherPlayerMP10.lastTickPosZ = (double) (entityOtherPlayerMP10.serverPosZ = packet20NamedEntitySpawn1.zPosition);
		int i11 = packet20NamedEntitySpawn1.currentItem;
		if (i11 == 0) {
			entityOtherPlayerMP10.inventory.mainInventory[entityOtherPlayerMP10.inventory.currentItem] = null;
		} else {
			entityOtherPlayerMP10.inventory.mainInventory[entityOtherPlayerMP10.inventory.currentItem] = new ItemStack(
					i11, 1, 0);
		}

		entityOtherPlayerMP10.setPositionAndRotation(d2, d4, d6, f8, f9);
		this.worldClient.addEntityToWorld(packet20NamedEntitySpawn1.entityId, entityOtherPlayerMP10);
	}

	public void handleEntityTeleport(Packet34EntityTeleport packet34EntityTeleport1) {
		Entity entity2 = this.getEntityByID(packet34EntityTeleport1.entityId);
		if (entity2 != null) {
			entity2.serverPosX = packet34EntityTeleport1.xPosition;
			entity2.serverPosY = packet34EntityTeleport1.yPosition;
			entity2.serverPosZ = packet34EntityTeleport1.zPosition;
			double d3 = (double) entity2.serverPosX / 32.0D;
			double d5 = (double) entity2.serverPosY / 32.0D + 0.015625D;
			double d7 = (double) entity2.serverPosZ / 32.0D;
			float f9 = (float) (packet34EntityTeleport1.yaw * 360) / 256.0F;
			float f10 = (float) (packet34EntityTeleport1.pitch * 360) / 256.0F;
			entity2.setPositionAndRotation(d3, d5, d7, f9, f10, 3);
		}
	}

	public void handleEntity(Packet30Entity packet30Entity1) {
		Entity entity2 = this.getEntityByID(packet30Entity1.entityId);
		if (entity2 != null) {
			entity2.serverPosX += packet30Entity1.xPosition;
			entity2.serverPosY += packet30Entity1.yPosition;
			entity2.serverPosZ += packet30Entity1.zPosition;
			double d3 = (double) entity2.serverPosX / 32.0D;
			double d5 = (double) entity2.serverPosY / 32.0D;
			double d7 = (double) entity2.serverPosZ / 32.0D;
			float f9 = packet30Entity1.rotating ? (float) (packet30Entity1.yaw * 360) / 256.0F : entity2.rotationYaw;
			float f10 = packet30Entity1.rotating ? (float) (packet30Entity1.pitch * 360) / 256.0F
					: entity2.rotationPitch;
			entity2.setPositionAndRotation(d3, d5, d7, f9, f10, 3);
		}
	}

	public void handleDestroyEntity(Packet29DestroyEntity packet29DestroyEntity1) {
		this.worldClient.removeEntityFromWorld(packet29DestroyEntity1.entityId);
	}

	public void handleFlying(Packet10Flying packet10Flying1) {
		EntityPlayerSP entityPlayerSP2 = this.mc.thePlayer;
		double d3 = entityPlayerSP2.posX;
		double d5 = entityPlayerSP2.posY;
		double d7 = entityPlayerSP2.posZ;
		float f9 = entityPlayerSP2.rotationYaw;
		float f10 = entityPlayerSP2.rotationPitch;
		if (packet10Flying1.moving) {
			d3 = packet10Flying1.xPosition;
			d5 = packet10Flying1.yPosition;
			d7 = packet10Flying1.zPosition;
		}

		if (packet10Flying1.rotating) {
			f9 = packet10Flying1.yaw;
			f10 = packet10Flying1.pitch;
		}

		entityPlayerSP2.ySize = 0.0F;
		entityPlayerSP2.motionX = entityPlayerSP2.motionY = entityPlayerSP2.motionZ = 0.0D;
		entityPlayerSP2.setPositionAndRotation(d3, d5, d7, f9, f10);
		packet10Flying1.xPosition = entityPlayerSP2.posX;
		packet10Flying1.yPosition = entityPlayerSP2.boundingBox.minY;
		packet10Flying1.zPosition = entityPlayerSP2.posZ;
		packet10Flying1.stance = entityPlayerSP2.posY;
		this.netManager.addToSendQueue(packet10Flying1);
		if (!this.field_1210_g) {
			this.mc.thePlayer.prevPosX = this.mc.thePlayer.posX;
			this.mc.thePlayer.prevPosY = this.mc.thePlayer.posY;
			this.mc.thePlayer.prevPosZ = this.mc.thePlayer.posZ;
			this.field_1210_g = true;
			this.mc.displayGuiScreen((GuiScreen) null);
		}

	}

	public void handlePreChunk(Packet50PreChunk packet50PreChunk1) {
		this.worldClient.doPreChunk(packet50PreChunk1.xPosition, packet50PreChunk1.yPosition, packet50PreChunk1.mode);
	}

	public void handleMultiBlockChange(Packet52MultiBlockChange packet52MultiBlockChange) {
		int x0 = packet52MultiBlockChange.xPosition * 16;
		int z0 = packet52MultiBlockChange.zPosition * 16;

		//System.out.println ("Getting multiblock change for chunk " + packet52MultiBlockChange.xPosition + " " + packet52MultiBlockChange.zPosition + " with " + packet52MultiBlockChange.size + " blocks" );
		
		if(packet52MultiBlockChange.encodedBlocks != null) {
			DataInputStream dataInputStream4 = new DataInputStream(new ByteArrayInputStream(packet52MultiBlockChange.encodedBlocks));

			try {
				// This had to be adapted to decode 8 bit block ID and 8 bit metadata
				for(int i = 0; i < packet52MultiBlockChange.size; ++i) {
					short encodedPos = dataInputStream4.readShort();
					short encodedBlockMeta = dataInputStream4.readShort();

					int blockID = (encodedBlockMeta >> 8) & 255;
					int metadata = encodedBlockMeta & 255;
					
					int x = encodedPos >> 12 & 15;
					int z = encodedPos >> 8 & 15;
					int y = encodedPos & 255;
					
					this.worldClient.setBlockAndMetadataAndInvalidate(x + x0, y, z + z0, blockID, metadata);
				}
			} catch (IOException iOException13) {
				// Fail silently
				System.out.println ("IO Exception");
				iOException13.printStackTrace ();
			}

		}
	}

	public void handleMapChunk(Packet51MapChunk packet51MapChunk1) {
		this.worldClient.invalidateBlockReceiveRegion(packet51MapChunk1.xPosition, packet51MapChunk1.yPosition,
				packet51MapChunk1.zPosition, packet51MapChunk1.xPosition + packet51MapChunk1.xSize - 1,
				packet51MapChunk1.yPosition + packet51MapChunk1.ySize - 1,
				packet51MapChunk1.zPosition + packet51MapChunk1.zSize - 1);
		this.worldClient.setChunkData(packet51MapChunk1.xPosition, packet51MapChunk1.yPosition,
				packet51MapChunk1.zPosition, packet51MapChunk1.xSize, packet51MapChunk1.ySize, packet51MapChunk1.zSize,
				packet51MapChunk1.chunk);
	}

	public void handleBlockChange(Packet53BlockChange packet53BlockChange1) {
		this.worldClient.setBlockAndMetadataAndInvalidate(packet53BlockChange1.xPosition,
				packet53BlockChange1.yPosition, packet53BlockChange1.zPosition, packet53BlockChange1.type,
				packet53BlockChange1.metadata);
	}

	public void handleKickDisconnect(Packet255KickDisconnect packet255KickDisconnect1) {
		this.netManager.close("disconnect.kicked", new Object[0]);
		this.disconnected = true;
		this.mc.changeWorld((World) null);
		this.mc.displayGuiScreen(new GuiConnectFailed("disconnect.disconnected", "disconnect.genericReason",
				new Object[] { packet255KickDisconnect1.reason }));
	}

	public void handleErrorMessage(String string1, Object[] object2) {
		if (!this.disconnected) {
			this.disconnected = true;
			this.mc.changeWorld((World) null);
			this.mc.displayGuiScreen(new GuiConnectFailed("disconnect.lost", string1, object2));
		}
	}

	public void func_28117_a(Packet packet1) {
		if (!this.disconnected) {
			this.netManager.addToSendQueue(packet1);
			this.netManager.serverShutdown();
		}
	}

	public void addToSendQueue(Packet packet1) {
		if (!this.disconnected) {
			this.netManager.addToSendQueue(packet1);
		}
	}

	public void handleCollect(Packet22Collect packet22Collect1) {
		Entity entity2 = this.getEntityByID(packet22Collect1.collectedEntityId);
		Object object3 = (EntityLiving) this.getEntityByID(packet22Collect1.collectorEntityId);
		if (object3 == null) {
			object3 = this.mc.thePlayer;
		}

		if (entity2 != null) {
			this.worldClient.playSoundAtEntity(entity2, "random.pop", 0.2F,
					((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
			this.mc.effectRenderer.addEffect(new EntityPickupFX(this.mc.theWorld, entity2, (Entity) object3, -0.5F));
			this.worldClient.removeEntityFromWorld(packet22Collect1.collectedEntityId);
		}

	}

	public void handleChat(Packet3Chat packet3Chat1) {
		this.mc.ingameGUI.addChatMessage(packet3Chat1.message);
	}

	public void handleArmAnimation(Packet18Animation packet18Animation1) {
		Entity entity2 = this.getEntityByID(packet18Animation1.entityId);
		if (entity2 != null) {
			EntityPlayer entityPlayer3;
			if (packet18Animation1.animate == 1) {
				entityPlayer3 = (EntityPlayer) entity2;
				entityPlayer3.swingItem();
			} else if (packet18Animation1.animate == 2) {
				entity2.performHurtAnimation();
			} else if (packet18Animation1.animate == 3) {
				entityPlayer3 = (EntityPlayer) entity2;
				entityPlayer3.wakeUpPlayer(false, false, false);
			} else if (packet18Animation1.animate == 4) {
				entityPlayer3 = (EntityPlayer) entity2;
				entityPlayer3.func_6420_o();
			}

		}
	}

	public void handleSleep(Packet17Sleep packet17Sleep1) {
		Entity entity2 = this.getEntityByID(packet17Sleep1.field_22045_a);
		if (entity2 != null) {
			if (packet17Sleep1.field_22046_e == 0) {
				EntityPlayer entityPlayer3 = (EntityPlayer) entity2;
				entityPlayer3.sleepInBedAt(packet17Sleep1.field_22044_b, packet17Sleep1.field_22048_c,
						packet17Sleep1.field_22047_d);
			}

		}
	}

	public void handleHandshake(Packet2Handshake packet2Handshake1) {
		if (packet2Handshake1.username.equals("-")) {
			this.addToSendQueue(new Packet1Login(this.mc.session.username, 14));
		} else {
			try {
				URL uRL2 = new URL("http://www.minecraft.net/game/joinserver.jsp?user=" + this.mc.session.username
						+ "&sessionId=" + this.mc.session.sessionId + "&serverId=" + packet2Handshake1.username);
				BufferedReader bufferedReader3 = new BufferedReader(new InputStreamReader(uRL2.openStream()));
				String string4 = bufferedReader3.readLine();
				bufferedReader3.close();
				if (string4.equalsIgnoreCase("ok")) {
					this.addToSendQueue(new Packet1Login(this.mc.session.username, 14));
				} else {
					this.netManager.close("disconnect.loginFailedInfo", new Object[] { string4 });
				}
			} catch (Exception exception5) {
				exception5.printStackTrace();
				this.netManager.close("disconnect.genericReason",
						new Object[] { "Internal client error: " + exception5.toString() });
			}
		}

	}

	public void disconnect() {
		this.disconnected = true;
		this.netManager.wakeThreads();
		this.netManager.close("disconnect.closed", new Object[0]);
	}

	public void handleMobSpawn(Packet24MobSpawn packet) {
		double x = (double)packet.xPosition / 32.0D;
		double y = (double)packet.yPosition / 32.0D;
		double z = (double)packet.zPosition / 32.0D;
		float yaw = (float)(packet.yaw * 360) / 256.0F;
		float pitch = (float)(packet.pitch * 360) / 256.0F;

		EntityLiving theEntity = (EntityLiving)EntityList.createEntityByID(packet.type, this.mc.theWorld);
		theEntity.serverPosX = packet.xPosition;
		theEntity.serverPosY = packet.yPosition;
		theEntity.serverPosZ = packet.zPosition;
		theEntity.entityId = packet.entityId;
		theEntity.setPositionAndRotation(x, y, z, yaw, pitch);

		this.worldClient.addEntityToWorld(packet.entityId, theEntity);
		
		List<WatchableObject> watchables = packet.getMetadata();
		if(watchables != null) {
			theEntity.getDataWatcher().updateWatchedObjectsFromList(watchables);
		}

	}
	
	public void handleArmoredMobSpawn(Packet90ArmoredMobSpawn packet) {
		double x = (double)packet.xPosition / 32.0D;
		double y = (double)packet.yPosition / 32.0D;
		double z = (double)packet.zPosition / 32.0D;
		float yaw = (float)(packet.yaw * 360) / 256.0F;
		float pitch = (float)(packet.pitch * 360) / 256.0F;

		EntityArmoredMob theEntity = (EntityArmoredMob)EntityList.createEntityByID(packet.type, this.mc.theWorld);
		theEntity.serverPosX = packet.xPosition;
		theEntity.serverPosY = packet.yPosition;
		theEntity.serverPosZ = packet.zPosition;
		theEntity.rotationYawHead = (float)(packet.yawHead * 360) / 256.0F;
		
		// Add armor
		for(int i = 0; i < 5; i ++) {
			theEntity.inventory.setInventorySlotContents(i, packet.inventory[i]);
		}
		
		theEntity.entityId = packet.entityId;
		theEntity.setPositionAndRotation(x, y, z, yaw, pitch);

		this.worldClient.addEntityToWorld(packet.entityId, theEntity);
		
		List<WatchableObject> watchables = packet.getMetadata();
		if(watchables != null) {
			theEntity.getDataWatcher().updateWatchedObjectsFromList(watchables);
		}

	}

	public void handleUpdateTime(Packet4UpdateTime packet4UpdateTime1) {
		this.mc.theWorld.setWorldTime(packet4UpdateTime1.time);
	}

	public void handleSpawnPosition(Packet6SpawnPosition packet6SpawnPosition1) {
		this.mc.thePlayer.setPlayerSpawnCoordinate(new ChunkCoordinates(packet6SpawnPosition1.xPosition,
				packet6SpawnPosition1.yPosition, packet6SpawnPosition1.zPosition));
		this.mc.theWorld.getWorldInfo().setSpawn(packet6SpawnPosition1.xPosition, packet6SpawnPosition1.yPosition,
				packet6SpawnPosition1.zPosition);
	}

	public void handleAttachEntity(Packet39AttachEntity packet39AttachEntity1) {
		Object object2 = this.getEntityByID(packet39AttachEntity1.entityId);
		Entity entity3 = this.getEntityByID(packet39AttachEntity1.vehicleEntityId);
		if (packet39AttachEntity1.entityId == this.mc.thePlayer.entityId) {
			object2 = this.mc.thePlayer;
		}

		if (object2 != null) {
			((Entity) object2).mountEntity(entity3);
		}
	}

	public void handleEntityStatus(Packet38EntityStatus packet38EntityStatus1) {
		Entity entity2 = this.getEntityByID(packet38EntityStatus1.entityId);
		if (entity2 != null) {
			entity2.handleHealthUpdate(packet38EntityStatus1.entityStatus);
		}

	}

	private Entity getEntityByID(int i1) {
		return (Entity) (i1 == this.mc.thePlayer.entityId ? this.mc.thePlayer
				: this.worldClient.getEntityFromLookup(i1));
	}

	public void handleHealth(Packet8UpdateHealth packet8UpdateHealth1) {
		this.mc.thePlayer.setHealth(packet8UpdateHealth1.healthMP);
	}

	public void handleRespawnPacket(Packet9Respawn packet9Respawn1) {
		if (packet9Respawn1.dimension != this.mc.thePlayer.dimension) {
			this.field_1210_g = false;
			this.worldClient = new WorldClient(this, new WorldSettings(0L, 0, false, false, false, false, WorldType.DEFAULT),
					packet9Respawn1.dimension, this.mc.gameSettings);
			this.worldClient.isRemote = true;
			this.mc.changeWorld(this.worldClient);
			this.mc.thePlayer.dimension = packet9Respawn1.dimension;
			this.mc.displayGuiScreen(new GuiDownloadTerrain(this));
		}

		this.mc.respawn(true, packet9Respawn1.dimension);
	}

	public void handleExplosion(Packet60Explosion packet60Explosion1) {
		Explosion explosion2 = new Explosion(this.mc.theWorld, (Entity) null, packet60Explosion1.explosionX,
				packet60Explosion1.explosionY, packet60Explosion1.explosionZ, packet60Explosion1.explosionSize,
				packet60Explosion1.blockID);
		explosion2.destroyedBlockPositions = packet60Explosion1.destroyedBlockPositions;
		explosion2.doEffects(true);
	}

	public void handleOpenWindow(Packet100OpenWindow packet) {
		if (packet.inventoryType == 0) {
			InventoryBasic inventoryBasic2 = new InventoryBasic(packet.windowTitle,
					packet.slotsCount);
			this.mc.thePlayer.displayGUIChest(inventoryBasic2);
			this.mc.thePlayer.craftingInventory.windowId = packet.windowId;
		} else if (packet.inventoryType == 2) {
			TileEntityFurnace tileEntityFurnace3 = new TileEntityFurnace();
			this.mc.thePlayer.displayGUIFurnace(tileEntityFurnace3);
			this.mc.thePlayer.craftingInventory.windowId = packet.windowId;
		} else if (packet.inventoryType == 3) {
			TileEntityDispenser tileEntityDispenser4 = new TileEntityDispenser();
			this.mc.thePlayer.displayGUIDispenser(tileEntityDispenser4);
			this.mc.thePlayer.craftingInventory.windowId = packet.windowId;
		} else if (packet.inventoryType == 1) {
			EntityPlayerSP entityPlayerSP5 = this.mc.thePlayer;
			this.mc.thePlayer.displayWorkbenchGUI(MathHelper.floor_double(entityPlayerSP5.posX),
					MathHelper.floor_double(entityPlayerSP5.posY), MathHelper.floor_double(entityPlayerSP5.posZ));
			this.mc.thePlayer.craftingInventory.windowId = packet.windowId;
		} else if (packet.inventoryType == 6) {
			/*
			EntityPlayerSP entityPlayerSP = this.mc.thePlayer;
			// Jankily reusing existing fields for my purposes
			Currency currency = packet.slotsCount == 0 ? Currency.currencyEmerald : Currency.currencyRuby;
			String traderName = packet.windowTitle;
			this.mc.thePlayer.displayGUITrading(entityPlayerSP.inventory, new NpcTrader(traderName, currency));
			this.mc.thePlayer.craftingInventory.windowId = packet.windowId;
			*/
		}

	}

	public void handleSetSlot(Packet103SetSlot packet103SetSlot1) {
		if (packet103SetSlot1.windowId == -1) {
			this.mc.thePlayer.inventory.setItemStack(packet103SetSlot1.myItemStack);
		} else if (packet103SetSlot1.windowId == 0 && packet103SetSlot1.itemSlot >= 36
				&& packet103SetSlot1.itemSlot < 45) {
			ItemStack itemStack2 = this.mc.thePlayer.inventorySlots.getSlot(packet103SetSlot1.itemSlot).getStack();
			if (packet103SetSlot1.myItemStack != null
					&& (itemStack2 == null || itemStack2.stackSize < packet103SetSlot1.myItemStack.stackSize)) {
				packet103SetSlot1.myItemStack.animationsToGo = 5;
			}

			this.mc.thePlayer.inventorySlots.putStackInSlot(packet103SetSlot1.itemSlot, packet103SetSlot1.myItemStack);
		} else if (packet103SetSlot1.windowId == this.mc.thePlayer.craftingInventory.windowId) {
			this.mc.thePlayer.craftingInventory.putStackInSlot(packet103SetSlot1.itemSlot,
					packet103SetSlot1.myItemStack);
		}

	}

	public void handleTransaction(Packet106Transaction packet106Transaction1) {
		Container container2 = null;
		if (packet106Transaction1.windowId == 0) {
			container2 = this.mc.thePlayer.inventorySlots;
		} else if (packet106Transaction1.windowId == this.mc.thePlayer.craftingInventory.windowId) {
			container2 = this.mc.thePlayer.craftingInventory;
		}

		if (container2 != null) {
			if (packet106Transaction1.packetBoolean) {
				container2.func_20113_a(packet106Transaction1.shortWindowId);
			} else {
				container2.func_20110_b(packet106Transaction1.shortWindowId);
				this.addToSendQueue(new Packet106Transaction(packet106Transaction1.windowId,
						packet106Transaction1.shortWindowId, true));
			}
		}

	}

	public void handleWindowItems(Packet104WindowItems packet104WindowItems1) {
		if (packet104WindowItems1.windowId == 0) {
			this.mc.thePlayer.inventorySlots.putStacksInSlots(packet104WindowItems1.itemStack);
		} else if (packet104WindowItems1.windowId == this.mc.thePlayer.craftingInventory.windowId) {
			this.mc.thePlayer.craftingInventory.putStacksInSlots(packet104WindowItems1.itemStack);
		}

	}

	public void handleUpdateSign(Packet130UpdateSign packet130UpdateSign1) {
		if (this.mc.theWorld.blockExists(packet130UpdateSign1.xPosition, packet130UpdateSign1.yPosition,
				packet130UpdateSign1.zPosition)) {
			TileEntity tileEntity2 = this.mc.theWorld.getBlockTileEntity(packet130UpdateSign1.xPosition,
					packet130UpdateSign1.yPosition, packet130UpdateSign1.zPosition);
			if (tileEntity2 instanceof TileEntitySign) {
				TileEntitySign tileEntitySign3 = (TileEntitySign) tileEntity2;

				for (int i4 = 0; i4 < 4; ++i4) {
					tileEntitySign3.signText[i4] = packet130UpdateSign1.signLines[i4];
				}

				tileEntitySign3.onInventoryChanged();
			}
		}

	}
	
	public void handleUpdateAnimalName(Packet91UpdateAnimalName packet) {
		Entity entity = this.getEntityByID(packet.entityId);
		if(entity == null || !(entity instanceof EntityCreature)) {
			// System.out.println ("Received name " + packet.name + " for non existing creature " + packet.entityId);
		} else {
			((EntityCreature) entity).setName(packet.name);
		}
	}

	public void handleUpdateProgressBar(Packet105UpdateProgressbar packet105UpdateProgressbar1) {
		this.registerPacket(packet105UpdateProgressbar1);
		if (this.mc.thePlayer.craftingInventory != null
				&& this.mc.thePlayer.craftingInventory.windowId == packet105UpdateProgressbar1.windowId) {
			this.mc.thePlayer.craftingInventory.setFurnaceTime(packet105UpdateProgressbar1.progressBar,
					packet105UpdateProgressbar1.progressBarValue);
		}

	}

	public void handlePlayerInventory(Packet5PlayerInventory packet5PlayerInventory1) {
		Entity entity2 = this.getEntityByID(packet5PlayerInventory1.entityID);
		if (entity2 != null) {
			entity2.outfitWithItem(packet5PlayerInventory1.slot, packet5PlayerInventory1.itemID,
					packet5PlayerInventory1.itemDamage);
		}

	}

	public void handleCloseWindow(Packet101CloseWindow packet101CloseWindow1) {
		this.mc.thePlayer.closeScreen();
	}

	public void handleNotePlay(Packet54PlayNoteBlock packet54PlayNoteBlock1) {
		this.mc.theWorld.playNoteAt(packet54PlayNoteBlock1.xLocation, packet54PlayNoteBlock1.yLocation,
				packet54PlayNoteBlock1.zLocation, packet54PlayNoteBlock1.instrumentType, packet54PlayNoteBlock1.pitch);
	}

	public void handleBed(Packet70Bed packet70Bed1) {
		int i2 = packet70Bed1.setRainingAction;
		if (i2 >= 0 && i2 < Packet70Bed.errorMessageArr.length && Packet70Bed.errorMessageArr[i2] != null) {
			this.mc.thePlayer.addChatMessage(Packet70Bed.errorMessageArr[i2]);
		}

		/*
		 * if(i2 == 1) { this.worldClient.getWorldInfo().setRaining(true);
		 * this.worldClient.setRainStrength(1.0F); } else if(i2 == 2) {
		 * this.worldClient.getWorldInfo().setRaining(false);
		 * this.worldClient.setRainStrength(0.0F); }
		 */

		// This is encoded differently to vanilla
		if (i2 == 1) {
			this.worldClient.getWorldInfo().setRaining(packet70Bed1.raining);
			this.worldClient.setRainStrength(packet70Bed1.raining ? 1.0F : 0.0F);
			this.worldClient.getWorldInfo().setSnowing(packet70Bed1.snowing);
			this.worldClient.setSnowingStrength(packet70Bed1.snowing ? 1.0F : 0.0F);
			this.worldClient.getWorldInfo().setThundering(packet70Bed1.thundering);
			this.worldClient.setThunderingStrength(packet70Bed1.thundering ? 1.0F : 0.0F);
		}

	}

	public void handleMapData(Packet131MapData packet131MapData1) {
		if (packet131MapData1.itemID == Item.mapItem.shiftedIndex) {
			ItemMap.getMPMapData(packet131MapData1.uniqueID, this.mc.theWorld).func_28171_a(packet131MapData1.itemData);
		} else {
			System.out.println("Unknown itemid: " + packet131MapData1.uniqueID);
		}

	}

	public void handleDoorChange(Packet61DoorChange packet61DoorChange1) {
		this.mc.theWorld.playAuxSFX(packet61DoorChange1.field_28050_a, packet61DoorChange1.field_28053_c,
				packet61DoorChange1.field_28052_d, packet61DoorChange1.field_28051_e,
				packet61DoorChange1.field_28049_b);
	}

	public void handleStatistic(Packet200Statistic packet200Statistic1) {
		((EntityClientPlayerMP) this.mc.thePlayer).func_27027_b(
				StatList.getOneShotStat(packet200Statistic1.field_27052_a), packet200Statistic1.field_27051_b);
	}

	public void handleUpdateWeather(Packet98UpdateWeather var1) {
		this.worldClient.getWorldInfo().setRaining(var1.raining);
		this.worldClient.getWorldInfo().setSnowing(var1.snowing);
		this.worldClient.getWorldInfo().setThundering(var1.thundering);
	}

	public void handleSetCreative(Packet99SetCreativeMode var1) {
		EntityPlayerSP thePlayer = this.mc.thePlayer;
		thePlayer.isCreative = var1.isCreative;
		if (!thePlayer.isCreative)
			thePlayer.isFlying = false;
	}

	public void handleBadMoonDecide(Packet96BadMoonDecide packet) {
		System.out.println("Got bad moon decide = " + packet.badMoonDecide);
		this.worldClient.badMoonDecide = packet.badMoonDecide;
	}

	public void handleUpdateDayOfTheYear(Packet95UpdateDayOfTheYear packet) {
		System.out.println("Got day of the year = " + packet.dayOfTheYear);
		this.worldClient.performDayOfTheYearUpdate(packet.dayOfTheYear);
	}

	public void handleFreezeLevel(Packet94FreezeLevel packet) {
		this.mc.thePlayer.freezeLevel = packet.freezeLevel;
	}

	public void handleCustomPayload(Packet250CustomPayload par1Packet250CustomPayload) {
		/*
		if ("MC|TrList".equals(par1Packet250CustomPayload.channel)) {
			DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(par1Packet250CustomPayload.data));

			try {
				int windowId = dataInputStream.readInt();
				GuiScreen guiScreen = this.mc.currentScreen;

				if (guiScreen != null && guiScreen instanceof GuiTrading
						&& windowId == this.mc.thePlayer.craftingInventory.windowId) {
					ITrader entityTrader = ((GuiTrading) guiScreen).getEntityTrader();
					TradingRecipeList tradingRecipeList = TradingRecipeList.readRecipesFromStream(dataInputStream);
					entityTrader.setRecipes(tradingRecipeList);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		*/
	}

	public boolean isServerHandler() {
		return false;
	}
	
	public void handleFiniteWorldSettings(Packet93FiniteWorldSettings packet) {
		System.out.println ("Got finite world settings: sizeID = " + packet.sizeID + ", themeID = " + packet.themeID);
		WorldSize.setSizeById(packet.sizeID);
		LevelThemeGlobalSettings.loadThemeById(packet.themeID);
		BiomeGenBase.generateBiomeLookup();
	}

}
