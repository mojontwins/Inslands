package net.minecraft.src;

public class ChunkProviderSky extends ChunkProviderGenerate implements IChunkProvider {
	
	public ChunkProviderSky(World world1, long j2) {
		this(world1, j2, true);
	}
	
	public ChunkProviderSky(World world1, long j2, boolean b) {
		super(world1, j2, b);
	}

	public void generateTerrain(int chunkX, int chunkZ, byte[] blocks, BiomeGenBase[] biomes, double[] temperatures) {
		double noiseScale = 0.25D;
		double yscalingFactor = 0.125D;
		double densityVariationSpeed = 0.125D;
		
		byte quadrantSize = 2;
		
		int cellSize = quadrantSize + 1;
		byte columnSize = 33;
		int cellSize2 = quadrantSize + 1;
		short chunkHeight = 128;
		
		this.terrainNoise = this.initializeNoiseField(this.terrainNoise, chunkX * quadrantSize, 0, chunkZ * quadrantSize, cellSize, columnSize, cellSize2);

		for(int xSection = 0; xSection < quadrantSize; ++xSection) {
			for(int zSection = 0; zSection < quadrantSize; ++zSection) {
				for(int ySection = 0; ySection < 32; ++ySection) {
					
					double noiseA = this.terrainNoise[((xSection + 0) * cellSize2 + zSection + 0) * columnSize + ySection + 0];
					double noiseB = this.terrainNoise[((xSection + 0) * cellSize2 + zSection + 1) * columnSize + ySection + 0];
					double noiseC = this.terrainNoise[((xSection + 1) * cellSize2 + zSection + 0) * columnSize + ySection + 0];
					double noiseD = this.terrainNoise[((xSection + 1) * cellSize2 + zSection + 1) * columnSize + ySection + 0];
					double noiseAinc = (this.terrainNoise[((xSection + 0) * cellSize2 + zSection + 0) * columnSize + ySection + 1] - noiseA) * noiseScale;
					double noiseBinc = (this.terrainNoise[((xSection + 0) * cellSize2 + zSection + 1) * columnSize + ySection + 1] - noiseB) * noiseScale;
					double noiseCinc = (this.terrainNoise[((xSection + 1) * cellSize2 + zSection + 0) * columnSize + ySection + 1] - noiseC) * noiseScale;
					double noiseDinc = (this.terrainNoise[((xSection + 1) * cellSize2 + zSection + 1) * columnSize + ySection + 1] - noiseD) * noiseScale;

					for(int y = 0; y < 4; ++y) {
						
						double curNoiseA = noiseA;
						double curNoiseB = noiseB;
						double curNoiseAinc = (noiseC - noiseA) * yscalingFactor;
						double curNoiseBinc = (noiseD - noiseB) * yscalingFactor;

						for(int x = 0; x < 8; ++x) {
							int indexInBlockArray = (x + (xSection << 3)) << 11 | (0 + (zSection << 3)) << 7 | (ySection << 2) + y;
														
							double density = curNoiseA;
							double densityIncrement = (curNoiseB - curNoiseA) * densityVariationSpeed;

							for(int z = 0; z < 8; ++z) {
								int blockID = 0;
								if(density > 0.0D) {
									blockID = Block.stone.blockID;
								}

								blocks[indexInBlockArray] = (byte)blockID;
								indexInBlockArray += chunkHeight;
								density += densityIncrement;
							}

							curNoiseA += curNoiseAinc;
							curNoiseB += curNoiseBinc;
						}

						noiseA += noiseAinc;
						noiseB += noiseBinc;
						noiseC += noiseCinc;
						noiseD += noiseDinc;
					}
				}
			}
		}

	}

	public void replaceBlocksForBiome(int chunkX, int chunkZ, byte[] blocks, BiomeGenBase[] biomes) {
		double d5 = 8.0D / 256D;
		this.sandNoise = this.noiseGenSandOrGravel.generateNoiseOctaves(this.sandNoise, (double)(chunkX * 16), (double)(chunkZ * 16), 0.0D, 16, 16, 1, d5, d5, 1.0D);
		this.gravelNoise = this.noiseGenSandOrGravel.generateNoiseOctaves(this.gravelNoise, (double)(chunkX * 16), 109.0134D, (double)(chunkZ * 16), 16, 1, 16, d5, 1.0D, d5);
		this.stoneNoise = this.noiseStone.generateNoiseOctaves(this.stoneNoise, (double)(chunkX * 16), (double)(chunkZ * 16), 0.0D, 16, 16, 1, d5 * 2.0D, d5 * 2.0D, d5 * 2.0D);

		int biomeIndex = 0;
		BiomeGenBase biomeGen;

		for(int x = 0; x < 16; ++x) {
			for(int z = 0; z < 16; ++z) {
				biomeGen = biomes[biomeIndex ++];
				
				int noiseIndex = x + (z << 4);
				int i10 = (int)(this.stoneNoise[noiseIndex] / 3.0D + 3.0D + this.rand.nextDouble() * 0.25D);
				int i11 = -1;
				byte topBlock = biomeGen.getTopBlock(this.rand);
				byte fillerBlock = biomeGen.fillerBlock;

				for(int y = 127; y >= 0; --y) {
					int index = x << 11 | z << 7 | y; // (x * 16 + z) * 128 + y
					byte blockID = blocks[index];
					if(blockID == 0) {
						i11 = -1;
					} else if(blockID == Block.stone.blockID) {
						if(i11 == -1) {
							if(i10 <= 0) {
								topBlock = 0;
								fillerBlock = (byte)Block.stone.blockID;
							}

							i11 = i10;
							if(y >= 0) {
								blocks[index] = topBlock;
							} else {
								blocks[index] = fillerBlock;
							}
						} else if(i11 > 0) {
							--i11;
							blocks[index] = fillerBlock;
							if(i11 == 0 && fillerBlock == Block.sand.blockID) {
								i11 = this.rand.nextInt(4);
								fillerBlock = (byte)Block.sandStone.blockID;
							}
						}
					}
				}
			}
		}

	}

	public double extend_center(double d) {
		// Assumes d = 0.0 -> 1.0.
		if(d < 0.25D) return d * 2;
		if(d >= 0.75D) return (d - 0.75D) * 2 + 0.5D;
		return 0.5D;
	}
	
	public void terraform(int chunkX, int chunkZ, Chunk chunk, BiomeGenBase[] biomes) {
		// fade world height to the edges of map. This uses formulae not dissimilar to those found in indev,
		// albeit adapted to work with 3D perlin terrain divided in chunks! 
		
		byte[] blocks = chunk.blocks;
		
		int xx = chunkX << 4;
		for(int x = 0; x < 16; x ++) {
			double dx = Math.abs(( extend_center((double)xx / (double)(WorldSize.width - 1)) - 0.5D) * 2.0D);
			
			int zz = chunkZ << 4;
			for(int z = 0; z < 16; z ++) {
				double dz = Math.abs(( extend_center ((double)zz / (double)(WorldSize.length - 1)) - 0.5D) * 2.0D);
				
				// Get a weighted 2D distance to the center of sorts. This is a cone centered on the whole map area
				double d = Math.sqrt(dx * dx + dz * dz) * 1.2D;
				
				// Get noise
				double noise = this.noiseIslandGen.generateNoise(xx * 0.05D, zz * 0.05D) / 4.0D + 1.0D;
				
				// Weird a bit with those values (noise and d) to get a nice fried agg shape
				double factor = Math.max(Math.min(d, noise), Math.min(dx, dz));
				
				if(factor > 1.0D) factor = 1.0D;
				if(factor < 0.0D) factor = 0.0D;
				
				// Curve a bit
				factor *= factor;
			
				//factor *= 2;				
				
				// Land height map, that's what we are adjusting:
				int height = chunk.getLandSurfaceHeightValue(x, z);
				if(height > 1) {	
					// Adjust by factor
					double normalizedHeight = (double)height;
					normalizedHeight = normalizedHeight * (1.0D - factor) - factor * 10.0D + 5.0D;
					
					// Deepen oceans
					if(normalizedHeight < 0.0D) {
						normalizedHeight -= normalizedHeight * normalizedHeight * 0.2D;
					}
					
					int newHeight = (int)normalizedHeight;
					if(newHeight < 0) newHeight = 0;
					if(newHeight > 127) newHeight = 127;
					
					// Erode / raise
					int columnIndex = x << 11 | z << 7;
					
					if(newHeight < height) {
						for(int y = newHeight + 1; y <= height; y ++) {
							blocks[columnIndex + y] = 0;
						}
					} else if(newHeight > height) {
						for(int y = height + 1; y <= newHeight; y ++) {
							blocks[columnIndex + y] = (byte)Block.stone.blockID;
						}
					}
									
					// write back height
					chunk.setLandSurfaceHeightValue(x, z, newHeight);
				}
				
				zz ++;
			}
			xx ++;
		}
		// 
	}
	
	public Chunk prepareChunk(int i1, int i2) {
		return this.provideChunk(i1, i2);
	}

	private double[] initializeNoiseField(double[] d1, int i2, int i3, int i4, int i5, int i6, int i7) {
		if(d1 == null) {
			d1 = new double[i5 * i6 * i7];
		}

		double d8 = 684.412D;
		double d10 = 684.412D;
		double[] d12 = this.worldObj.getWorldChunkManager().temperature;
		double[] d13 = this.worldObj.getWorldChunkManager().humidity;
		this.noise5 = this.noiseGen5.generateNoiseOctaves(this.noise5, i2, i4, i5, i7, 1.121D, 1.121D, 0.5D);
		this.noise6 = this.noiseGen6.generateNoiseOctaves(this.noise6, i2, i4, i5, i7, 200.0D, 200.0D, 0.5D);
		d8 *= 2.0D; 	// This makes the difference between overworld & sky dimension
		this.noise3 = this.noiseGen3.generateNoiseOctaves(this.noise3, (double)i2, (double)i3, (double)i4, i5, i6, i7, d8 / 80.0D, d10 / 160.0D, d8 / 80.0D);
		this.noise1 = this.noiseGen1.generateNoiseOctaves(this.noise1, (double)i2, (double)i3, (double)i4, i5, i6, i7, d8, d10, d8);
		this.noise2 = this.noiseGen2.generateNoiseOctaves(this.noise2, (double)i2, (double)i3, (double)i4, i5, i6, i7, d8, d10, d8);
		int i14 = 0;
		int i15 = 0;
		int i16 = 16 / i5;

		for(int i17 = 0; i17 < i5; ++i17) {
			int i18 = i17 * i16 + i16 / 2;

			for(int i19 = 0; i19 < i7; ++i19) {
				int i20 = i19 * i16 + i16 / 2;
				double d21 = d12[i18 * 16 + i20];
				double d23 = d13[i18 * 16 + i20] * d21;
				double d25 = 1.0D - d23;
				d25 *= d25;
				d25 *= d25;
				d25 = 1.0D - d25;
				double d27 = (this.noise5[i15] + 256.0D) / 512.0D;
				d27 *= d25;
				if(d27 > 1.0D) {
					d27 = 1.0D;
				}

				double d29 = this.noise6[i15] / 8000.0D;
				if(d29 < 0.0D) {
					d29 = -d29 * 0.3D;
				}

				d29 = d29 * 3.0D - 2.0D;
				if(d29 > 1.0D) {
					d29 = 1.0D;
				}

				d29 /= 8.0D;
				d29 = 0.0D;
				if(d27 < 0.0D) {
					d27 = 0.0D;
				}

				d27 += 0.5D;
				d29 = d29 * (double)i6 / 16.0D;
				++i15;
				double d31 = (double)i6 / 2.0D;

				for(int i33 = 0; i33 < i6; ++i33) {
					double d34 = 0.0D;
					double d36 = ((double)i33 - d31) * 8.0D / d27;
					if(d36 < 0.0D) {
						d36 *= -1.0D;
					}

					double d38 = this.noise1[i14] / 512.0D;
					double d40 = this.noise2[i14] / 512.0D;
					double d42 = (this.noise3[i14] / 10.0D + 1.0D) / 2.0D;
					if(d42 < 0.0D) {
						d34 = d38;
					} else if(d42 > 1.0D) {
						d34 = d40;
					} else {
						d34 = d38 + (d40 - d38) * d42;
					}

					d34 -= 8.0D;
					byte b44 = 32;
					double d45;
					if(i33 > i6 - b44) {
						d45 = (double)((float)(i33 - (i6 - b44)) / ((float)b44 - 1.0F));
						d34 = d34 * (1.0D - d45) + -30.0D * d45;
					}

					b44 = 8;
					if(i33 < b44) {
						d45 = (double)((float)(b44 - i33) / ((float)b44 - 1.0F));
						d34 = d34 * (1.0D - d45) + -30.0D * d45;
					}

					d1[i14] = d34;
					++i14;
				}
			}
		}

		return d1;
	}
	
	public void populateOres(int x0, int z0, BiomeGenBase biomeGen) {
		int i, x, y, z;
		
		for(i = 0; i < biomeGen.coalLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreCoal.blockID, 16)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < biomeGen.glowLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreGlow.blockID, 8)).generate(this.worldObj, this.rand, x, y, z);
		}
				
		for(i = 0; i < 2*biomeGen.ironLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreIron.blockID, 8)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 4*biomeGen.goldLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreGold.blockID, 8)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 6*biomeGen.redstoneLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreRedstone.blockID, 7)).generate(this.worldObj, this.rand, x, y, z);
		}

		for(i = 0; i < 6*biomeGen.diamondLumpAttempts; ++i) {
			x = x0 + this.rand.nextInt(16);
			y = this.rand.nextInt(128);
			z = z0 + this.rand.nextInt(16);
			(new WorldGenMinable(Block.oreDiamond.blockID, 7)).generate(this.worldObj, this.rand, x, y, z);
		}
	}
	
	public void generateMapFeatures(int chunkX, int chunkZ) {
		if (this.mapFeaturesEnabled) {
		}
	}

	public boolean chunkExists(int i1, int i2) {
		return true;
	}
	
	public boolean saveChunks(boolean z1, IProgressUpdate iProgressUpdate2) {
		return true;
	}

	public boolean unload100OldestChunks() {
		return false;
	}

	public boolean canSave() {
		return true;
	}

	public String makeString() {
		return "RandomLevelSource";
	}
}
