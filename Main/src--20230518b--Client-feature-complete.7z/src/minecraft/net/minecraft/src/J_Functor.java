package net.minecraft.src;

interface J_Functor {
	boolean func_27058_a(Object object1);

	Object func_27059_b(Object object1);

	String func_27060_a();
}
