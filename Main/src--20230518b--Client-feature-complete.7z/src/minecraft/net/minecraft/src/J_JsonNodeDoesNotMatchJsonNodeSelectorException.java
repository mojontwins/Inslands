package net.minecraft.src;

public class J_JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -726288864488212032L;

	J_JsonNodeDoesNotMatchJsonNodeSelectorException(String string1) {
		super(string1);
	}
}
