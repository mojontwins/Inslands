package net.minecraft.src;

class WorldBlockPositionType {
	int posX;
	int posY;
	int posZ;
	int acceptCountdown;
	int blockID;
	int metadata;
}
