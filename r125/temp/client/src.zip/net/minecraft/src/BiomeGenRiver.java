package net.minecraft.src;

public class BiomeGenRiver extends BiomeGenBase {
	public BiomeGenRiver(int i1) {
		super(i1);
		this.spawnableCreatureList.clear();
	}
}
