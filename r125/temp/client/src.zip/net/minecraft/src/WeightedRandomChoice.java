package net.minecraft.src;

public class WeightedRandomChoice {
	protected int itemWeight;

	public WeightedRandomChoice(int i1) {
		this.itemWeight = i1;
	}
}
