package net.minecraft.src;

public class MinecraftException extends RuntimeException {
	public MinecraftException(String string1) {
		super(string1);
	}
}
