package net.minecraft.src;

import net.minecraft.client.Minecraft;

import org.lwjgl.opengl.GL11;

public class TileEntityRendererPiston extends TileEntitySpecialRenderer {
	private RenderBlocks blockRenderer;

	public void renderPiston(TileEntityPiston tileEntityPiston1, double d2, double d4, double d6, float f8) {
		Block block9 = Block.blocksList[tileEntityPiston1.getStoredBlockID()];
		if(block9 != null && tileEntityPiston1.getProgress(f8) < 1.0F) {
			Tessellator tessellator10 = Tessellator.instance;
			this.bindTextureByName("/terrain.png");
			RenderHelper.disableStandardItemLighting();
			GL11.glBlendFunc(770, 771);
			GL11.glEnable(3042);
			GL11.glDisable(2884);
			if(Minecraft.isAmbientOcclusionEnabled()) {
				GL11.glShadeModel(7425);
			} else {
				GL11.glShadeModel(7424);
			}

			tessellator10.startDrawingQuads();
			tessellator10.setTranslation((double)((float)d2 - (float)tileEntityPiston1.xCoord + tileEntityPiston1.getOffsetX(f8)), (double)((float)d4 - (float)tileEntityPiston1.yCoord + tileEntityPiston1.getOffsetY(f8)), (double)((float)d6 - (float)tileEntityPiston1.zCoord + tileEntityPiston1.getOffsetZ(f8)));
			tessellator10.setColorOpaque(1, 1, 1);
			if(block9 == Block.pistonExtension && tileEntityPiston1.getProgress(f8) < 0.5F) {
				this.blockRenderer.renderPistonExtensionAllFaces(block9, tileEntityPiston1.xCoord, tileEntityPiston1.yCoord, tileEntityPiston1.zCoord, false);
			} else if(tileEntityPiston1.shouldRenderHead() && !tileEntityPiston1.isExtending()) {
				Block.pistonExtension.setHeadTexture(((BlockPistonBase)block9).getPistonExtensionTexture());
				this.blockRenderer.renderPistonExtensionAllFaces(Block.pistonExtension, tileEntityPiston1.xCoord, tileEntityPiston1.yCoord, tileEntityPiston1.zCoord, tileEntityPiston1.getProgress(f8) < 0.5F);
				Block.pistonExtension.clearHeadTexture();
				tessellator10.setTranslation((double)((float)d2 - (float)tileEntityPiston1.xCoord), (double)((float)d4 - (float)tileEntityPiston1.yCoord), (double)((float)d6 - (float)tileEntityPiston1.zCoord));
				this.blockRenderer.renderPistonBaseAllFaces(block9, tileEntityPiston1.xCoord, tileEntityPiston1.yCoord, tileEntityPiston1.zCoord);
			} else {
				this.blockRenderer.renderBlockAllFaces(block9, tileEntityPiston1.xCoord, tileEntityPiston1.yCoord, tileEntityPiston1.zCoord);
			}

			tessellator10.setTranslation(0.0D, 0.0D, 0.0D);
			tessellator10.draw();
			RenderHelper.enableStandardItemLighting();
		}

	}

	public void cacheSpecialRenderInfo(World world1) {
		this.blockRenderer = new RenderBlocks(world1);
	}

	public void renderTileEntityAt(TileEntity tileEntity1, double d2, double d4, double d6, float f8) {
		this.renderPiston((TileEntityPiston)tileEntity1, d2, d4, d6, f8);
	}
}
