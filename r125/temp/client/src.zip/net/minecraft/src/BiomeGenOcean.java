package net.minecraft.src;

public class BiomeGenOcean extends BiomeGenBase {
	public BiomeGenOcean(int i1) {
		super(i1);
		this.spawnableCreatureList.clear();
	}
}
