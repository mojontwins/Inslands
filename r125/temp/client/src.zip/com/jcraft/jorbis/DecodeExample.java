package com.jcraft.jorbis;

import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;

import java.io.FileInputStream;
import java.io.InputStream;

class DecodeExample {
	static int convsize = 8192;
	static byte[] convbuffer = new byte[convsize];

	public static void main(String[] string0) {
		Object object1 = System.in;
		if(string0.length > 0) {
			try {
				object1 = new FileInputStream(string0[0]);
			} catch (Exception exception28) {
				System.err.println(exception28);
			}
		}

		SyncState syncState2 = new SyncState();
		StreamState streamState3 = new StreamState();
		Page page4 = new Page();
		Packet packet5 = new Packet();
		Info info6 = new Info();
		Comment comment7 = new Comment();
		DspState dspState8 = new DspState();
		Block block9 = new Block(dspState8);
		int i11 = 0;
		syncState2.init();

		while(true) {
			boolean z12 = false;
			int i13 = syncState2.buffer(4096);
			byte[] b10 = syncState2.data;

			try {
				i11 = ((InputStream)object1).read(b10, i13, 4096);
			} catch (Exception exception26) {
				System.err.println(exception26);
				System.exit(-1);
			}

			syncState2.wrote(i11);
			if(syncState2.pageout(page4) != 1) {
				if(i11 < 4096) {
					syncState2.clear();
					System.err.println("Done.");
					return;
				}

				System.err.println("Input does not appear to be an Ogg bitstream.");
				System.exit(1);
			}

			streamState3.init(page4.serialno());
			info6.init();
			comment7.init();
			if(streamState3.pagein(page4) < 0) {
				System.err.println("Error reading first page of Ogg bitstream data.");
				System.exit(1);
			}

			if(streamState3.packetout(packet5) != 1) {
				System.err.println("Error reading initial header packet.");
				System.exit(1);
			}

			if(info6.synthesis_headerin(comment7, packet5) < 0) {
				System.err.println("This Ogg bitstream does not contain Vorbis audio data.");
				System.exit(1);
			}

			int i14;
			for(i14 = 0; i14 < 2; syncState2.wrote(i11)) {
				label156:
				while(true) {
					int i15;
					do {
						if(i14 >= 2) {
							break label156;
						}

						i15 = syncState2.pageout(page4);
						if(i15 == 0) {
							break label156;
						}
					} while(i15 != 1);

					streamState3.pagein(page4);

					while(i14 < 2) {
						i15 = streamState3.packetout(packet5);
						if(i15 == 0) {
							break;
						}

						if(i15 == -1) {
							System.err.println("Corrupt secondary header.  Exiting.");
							System.exit(1);
						}

						info6.synthesis_headerin(comment7, packet5);
						++i14;
					}
				}

				i13 = syncState2.buffer(4096);
				b10 = syncState2.data;

				try {
					i11 = ((InputStream)object1).read(b10, i13, 4096);
				} catch (Exception exception25) {
					System.err.println(exception25);
					System.exit(1);
				}

				if(i11 == 0 && i14 < 2) {
					System.err.println("End of file before finding all Vorbis headers!");
					System.exit(1);
				}
			}

			byte[][] b29 = comment7.user_comments;

			for(int i16 = 0; i16 < b29.length && b29[i16] != null; ++i16) {
				System.err.println(new String(b29[i16], 0, b29[i16].length - 1));
			}

			System.err.println("\nBitstream is " + info6.channels + " channel, " + info6.rate + "Hz");
			System.err.println("Encoded by: " + new String(comment7.vendor, 0, comment7.vendor.length - 1) + "\n");
			convsize = 4096 / info6.channels;
			dspState8.synthesis_init(info6);
			block9.init(dspState8);
			float[][][] f30 = new float[1][][];
			int[] i31 = new int[info6.channels];

			while(!z12) {
				label207:
				while(true) {
					label205:
					while(true) {
						if(z12) {
							break label207;
						}

						int i17 = syncState2.pageout(page4);
						if(i17 == 0) {
							break label207;
						}

						if(i17 == -1) {
							System.err.println("Corrupt or missing data in bitstream; continuing...");
						} else {
							streamState3.pagein(page4);

							while(true) {
								do {
									i17 = streamState3.packetout(packet5);
									if(i17 == 0) {
										if(page4.eos() != 0) {
											z12 = true;
										}
										continue label205;
									}
								} while(i17 == -1);

								if(block9.synthesis(packet5) == 0) {
									dspState8.synthesis_blockin(block9);
								}

								int i18;
								while((i18 = dspState8.synthesis_pcmout(f30, i31)) > 0) {
									float[][] f19 = f30[0];
									int i20 = i18 < convsize ? i18 : convsize;

									for(i14 = 0; i14 < info6.channels; ++i14) {
										int i21 = i14 * 2;
										int i22 = i31[i14];

										for(int i23 = 0; i23 < i20; ++i23) {
											int i24 = (int)((double)f19[i14][i22 + i23] * 32767.0D);
											if(i24 > 32767) {
												i24 = 32767;
											}

											if(i24 < -32768) {
												i24 = -32768;
											}

											if(i24 < 0) {
												i24 |= 32768;
											}

											convbuffer[i21] = (byte)i24;
											convbuffer[i21 + 1] = (byte)(i24 >>> 8);
											i21 += 2 * info6.channels;
										}
									}

									System.out.write(convbuffer, 0, 2 * info6.channels * i20);
									dspState8.synthesis_read(i20);
								}
							}
						}
					}
				}

				if(!z12) {
					i13 = syncState2.buffer(4096);
					b10 = syncState2.data;

					try {
						i11 = ((InputStream)object1).read(b10, i13, 4096);
					} catch (Exception exception27) {
						System.err.println(exception27);
						System.exit(1);
					}

					syncState2.wrote(i11);
					if(i11 == 0) {
						z12 = true;
					}
				}
			}

			streamState3.clear();
			block9.clear();
			dspState8.clear();
			info6.clear();
		}
	}
}
