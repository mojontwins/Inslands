package com.jcraft.jorbis;

class ChainingExample {
	public static void main(String[] string0) {
		VorbisFile vorbisFile1 = null;

		try {
			if(string0.length > 0) {
				vorbisFile1 = new VorbisFile(string0[0]);
			} else {
				vorbisFile1 = new VorbisFile(System.in, (byte[])null, -1);
			}
		} catch (Exception exception5) {
			System.err.println(exception5);
			return;
		}

		if(vorbisFile1.seekable()) {
			System.out.println("Input bitstream contained " + vorbisFile1.streams() + " logical bitstream section(s).");
			System.out.println("Total bitstream playing time: " + vorbisFile1.time_total(-1) + " seconds\n");
		} else {
			System.out.println("Standard input was not seekable.");
			System.out.println("First logical bitstream information:\n");
		}

		for(int i2 = 0; i2 < vorbisFile1.streams(); ++i2) {
			Info info3 = vorbisFile1.getInfo(i2);
			System.out.println("\tlogical bitstream section " + (i2 + 1) + " information:");
			System.out.println("\t\t" + info3.rate + "Hz " + info3.channels + " channels bitrate " + vorbisFile1.bitrate(i2) / 1000 + "kbps serial number=" + vorbisFile1.serialnumber(i2));
			System.out.print("\t\tcompressed length: " + vorbisFile1.raw_total(i2) + " bytes ");
			System.out.println(" play time: " + vorbisFile1.time_total(i2) + "s");
			Comment comment4 = vorbisFile1.getComment(i2);
			System.out.println(comment4);
		}

	}
}
