package com.jcraft.jorbis;

import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

public class VorbisFile {
	static final int CHUNKSIZE = 8500;
	static final int SEEK_SET = 0;
	static final int SEEK_CUR = 1;
	static final int SEEK_END = 2;
	static final int OV_FALSE = -1;
	static final int OV_EOF = -2;
	static final int OV_HOLE = -3;
	static final int OV_EREAD = -128;
	static final int OV_EFAULT = -129;
	static final int OV_EIMPL = -130;
	static final int OV_EINVAL = -131;
	static final int OV_ENOTVORBIS = -132;
	static final int OV_EBADHEADER = -133;
	static final int OV_EVERSION = -134;
	static final int OV_ENOTAUDIO = -135;
	static final int OV_EBADPACKET = -136;
	static final int OV_EBADLINK = -137;
	static final int OV_ENOSEEK = -138;
	InputStream datasource;
	boolean seekable = false;
	long offset;
	long end;
	SyncState oy = new SyncState();
	int links;
	long[] offsets;
	long[] dataoffsets;
	int[] serialnos;
	long[] pcmlengths;
	Info[] vi;
	Comment[] vc;
	long pcm_offset;
	boolean decode_ready = false;
	int current_serialno;
	int current_link;
	float bittrack;
	float samptrack;
	StreamState os = new StreamState();
	DspState vd = new DspState();
	Block vb = new Block(this.vd);

	public VorbisFile(String string1) {
		VorbisFile.SeekableInputStream vorbisFile$SeekableInputStream2 = null;

		try {
			vorbisFile$SeekableInputStream2 = new VorbisFile.SeekableInputStream(string1);
			int i3 = this.open(vorbisFile$SeekableInputStream2, (byte[])null, 0);
			if(i3 == -1) {
				throw new JOrbisException("VorbisFile: open return -1");
			}
		} catch (Exception exception11) {
			throw new JOrbisException("VorbisFile: " + exception11.toString());
		} finally {
			if(vorbisFile$SeekableInputStream2 != null) {
				try {
					vorbisFile$SeekableInputStream2.close();
				} catch (IOException iOException10) {
					iOException10.printStackTrace();
				}
			}

		}

	}

	public VorbisFile(InputStream inputStream1, byte[] b2, int i3) {
		int i4 = this.open(inputStream1, b2, i3);
		if(i4 == -1) {
			;
		}

	}

	private int get_data() {
		int i1 = this.oy.buffer(8500);
		byte[] b2 = this.oy.data;
		boolean z3 = false;

		int i6;
		try {
			i6 = this.datasource.read(b2, i1, 8500);
		} catch (Exception exception5) {
			return -128;
		}

		this.oy.wrote(i6);
		if(i6 == -1) {
			i6 = 0;
		}

		return i6;
	}

	private void seek_helper(long j1) {
		fseek(this.datasource, j1, 0);
		this.offset = j1;
		this.oy.reset();
	}

	private int get_next_page(Page page1, long j2) {
		if(j2 > 0L) {
			j2 += this.offset;
		}

		while(j2 <= 0L || this.offset < j2) {
			int i4 = this.oy.pageseek(page1);
			if(i4 < 0) {
				this.offset -= (long)i4;
			} else {
				int i5;
				if(i4 != 0) {
					i5 = (int)this.offset;
					this.offset += (long)i4;
					return i5;
				}

				if(j2 == 0L) {
					return -1;
				}

				i5 = this.get_data();
				if(i5 == 0) {
					return -2;
				}

				if(i5 < 0) {
					return -128;
				}
			}
		}

		return -1;
	}

	private int get_prev_page(Page page1) {
		long j2 = this.offset;
		int i5 = -1;

		label37:
		do {
			int i4;
			while(i5 == -1) {
				j2 -= 8500L;
				if(j2 < 0L) {
					j2 = 0L;
				}

				this.seek_helper(j2);

				while(this.offset < j2 + 8500L) {
					i4 = this.get_next_page(page1, j2 + 8500L - this.offset);
					if(i4 == -128) {
						return -128;
					}

					if(i4 < 0) {
						continue label37;
					}

					i5 = i4;
				}
			}

			this.seek_helper((long)i5);
			i4 = this.get_next_page(page1, 8500L);
			if(i4 < 0) {
				return -129;
			}

			return i5;
		} while(i5 != -1);

		throw new JOrbisException();
	}

	int bisect_forward_serialno(long j1, long j3, long j5, int i7, int i8) {
		long j9 = j5;
		long j11 = j5;
		Page page13 = new Page();

		int i14;
		while(j3 < j9) {
			long j15;
			if(j9 - j3 < 8500L) {
				j15 = j3;
			} else {
				j15 = (j3 + j9) / 2L;
			}

			this.seek_helper(j15);
			i14 = this.get_next_page(page13, -1L);
			if(i14 == -128) {
				return -128;
			}

			if(i14 >= 0 && page13.serialno() == i7) {
				j3 = (long)(i14 + page13.header_len + page13.body_len);
			} else {
				j9 = j15;
				if(i14 >= 0) {
					j11 = (long)i14;
				}
			}
		}

		this.seek_helper(j11);
		i14 = this.get_next_page(page13, -1L);
		if(i14 == -128) {
			return -128;
		} else {
			if(j3 < j5 && i14 != -1) {
				i14 = this.bisect_forward_serialno(j11, this.offset, j5, page13.serialno(), i8 + 1);
				if(i14 == -128) {
					return -128;
				}
			} else {
				this.links = i8 + 1;
				this.offsets = new long[i8 + 2];
				this.offsets[i8 + 1] = j3;
			}

			this.offsets[i8] = j1;
			return 0;
		}
	}

	int fetch_headers(Info info1, Comment comment2, int[] i3, Page page4) {
		Page page5 = new Page();
		Packet packet6 = new Packet();
		if(page4 == null) {
			int i7 = this.get_next_page(page5, 8500L);
			if(i7 == -128) {
				return -128;
			}

			if(i7 < 0) {
				return -132;
			}

			page4 = page5;
		}

		if(i3 != null) {
			i3[0] = page4.serialno();
		}

		this.os.init(page4.serialno());
		info1.init();
		comment2.init();
		int i8 = 0;

		do {
			if(i8 >= 3) {
				return 0;
			}

			this.os.pagein(page4);

			while(i8 < 3) {
				int i9 = this.os.packetout(packet6);
				if(i9 == 0) {
					break;
				}

				if(i9 == -1) {
					info1.clear();
					comment2.clear();
					this.os.clear();
					return -1;
				}

				if(info1.synthesis_headerin(comment2, packet6) != 0) {
					info1.clear();
					comment2.clear();
					this.os.clear();
					return -1;
				}

				++i8;
			}
		} while(i8 >= 3 || this.get_next_page(page4, 1L) >= 0);

		info1.clear();
		comment2.clear();
		this.os.clear();
		return -1;
	}

	void prefetch_all_headers(Info info1, Comment comment2, int i3) {
		Page page4 = new Page();
		this.vi = new Info[this.links];
		this.vc = new Comment[this.links];
		this.dataoffsets = new long[this.links];
		this.pcmlengths = new long[this.links];
		this.serialnos = new int[this.links];

		label38:
		for(int i6 = 0; i6 < this.links; ++i6) {
			if(info1 != null && comment2 != null && i6 == 0) {
				this.vi[i6] = info1;
				this.vc[i6] = comment2;
				this.dataoffsets[i6] = (long)i3;
			} else {
				this.seek_helper(this.offsets[i6]);
				this.vi[i6] = new Info();
				this.vc[i6] = new Comment();
				if(this.fetch_headers(this.vi[i6], this.vc[i6], (int[])null, (Page)null) == -1) {
					this.dataoffsets[i6] = -1L;
				} else {
					this.dataoffsets[i6] = this.offset;
					this.os.clear();
				}
			}

			long j7 = this.offsets[i6 + 1];
			this.seek_helper(j7);

			do {
				int i5 = this.get_prev_page(page4);
				if(i5 == -1) {
					this.vi[i6].clear();
					this.vc[i6].clear();
					continue label38;
				}
			} while(page4.granulepos() == -1L);

			this.serialnos[i6] = page4.serialno();
			this.pcmlengths[i6] = page4.granulepos();
		}

	}

	private int make_decode_ready() {
		if(this.decode_ready) {
			System.exit(1);
		}

		this.vd.synthesis_init(this.vi[0]);
		this.vb.init(this.vd);
		this.decode_ready = true;
		return 0;
	}

	int open_seekable() {
		Info info1 = new Info();
		Comment comment2 = new Comment();
		Page page8 = new Page();
		int[] i9 = new int[1];
		int i6 = this.fetch_headers(info1, comment2, i9, (Page)null);
		int i3 = i9[0];
		int i7 = (int)this.offset;
		this.os.clear();
		if(i6 == -1) {
			return -1;
		} else if(i6 < 0) {
			return i6;
		} else {
			this.seekable = true;
			fseek(this.datasource, 0L, 2);
			this.offset = ftell(this.datasource);
			long j4 = this.offset;
			j4 = (long)this.get_prev_page(page8);
			if(page8.serialno() != i3) {
				if(this.bisect_forward_serialno(0L, 0L, j4 + 1L, i3, 0) < 0) {
					this.clear();
					return -128;
				}
			} else if(this.bisect_forward_serialno(0L, j4, j4 + 1L, i3, 0) < 0) {
				this.clear();
				return -128;
			}

			this.prefetch_all_headers(info1, comment2, i7);
			return 0;
		}
	}

	int open_nonseekable() {
		this.links = 1;
		this.vi = new Info[this.links];
		this.vi[0] = new Info();
		this.vc = new Comment[this.links];
		this.vc[0] = new Comment();
		int[] i1 = new int[1];
		if(this.fetch_headers(this.vi[0], this.vc[0], i1, (Page)null) == -1) {
			return -1;
		} else {
			this.current_serialno = i1[0];
			this.make_decode_ready();
			return 0;
		}
	}

	void decode_clear() {
		this.os.clear();
		this.vd.clear();
		this.vb.clear();
		this.decode_ready = false;
		this.bittrack = 0.0F;
		this.samptrack = 0.0F;
	}

	int process_packet(int i1) {
		Page page2 = new Page();

		while(true) {
			if(this.decode_ready) {
				Packet packet3 = new Packet();
				int i4 = this.os.packetout(packet3);
				if(i4 > 0) {
					long j5 = packet3.granulepos;
					if(this.vb.synthesis(packet3) == 0) {
						int i7 = this.vd.synthesis_pcmout((float[][][])null, (int[])null);
						this.vd.synthesis_blockin(this.vb);
						this.samptrack += (float)(this.vd.synthesis_pcmout((float[][][])null, (int[])null) - i7);
						this.bittrack += (float)(packet3.bytes * 8);
						if(j5 != -1L && packet3.e_o_s == 0) {
							i7 = this.seekable ? this.current_link : 0;
							int i8 = this.vd.synthesis_pcmout((float[][][])null, (int[])null);
							j5 -= (long)i8;

							for(int i9 = 0; i9 < i7; ++i9) {
								j5 += this.pcmlengths[i9];
							}

							this.pcm_offset = j5;
						}

						return 1;
					}
				}
			}

			if(i1 == 0) {
				return 0;
			}

			if(this.get_next_page(page2, -1L) < 0) {
				return 0;
			}

			this.bittrack += (float)(page2.header_len * 8);
			if(this.decode_ready && this.current_serialno != page2.serialno()) {
				this.decode_clear();
			}

			if(!this.decode_ready) {
				if(!this.seekable) {
					int[] i12 = new int[1];
					int i13 = this.fetch_headers(this.vi[0], this.vc[0], i12, page2);
					this.current_serialno = i12[0];
					if(i13 != 0) {
						return i13;
					}

					++this.current_link;
					boolean z11 = false;
				} else {
					this.current_serialno = page2.serialno();

					int i10;
					for(i10 = 0; i10 < this.links && this.serialnos[i10] != this.current_serialno; ++i10) {
					}

					if(i10 == this.links) {
						return -1;
					}

					this.current_link = i10;
					this.os.init(this.current_serialno);
					this.os.reset();
				}

				this.make_decode_ready();
			}

			this.os.pagein(page2);
		}
	}

	int clear() {
		this.vb.clear();
		this.vd.clear();
		this.os.clear();
		if(this.vi != null && this.links != 0) {
			for(int i1 = 0; i1 < this.links; ++i1) {
				this.vi[i1].clear();
				this.vc[i1].clear();
			}

			this.vi = null;
			this.vc = null;
		}

		if(this.dataoffsets != null) {
			this.dataoffsets = null;
		}

		if(this.pcmlengths != null) {
			this.pcmlengths = null;
		}

		if(this.serialnos != null) {
			this.serialnos = null;
		}

		if(this.offsets != null) {
			this.offsets = null;
		}

		this.oy.clear();
		return 0;
	}

	static int fseek(InputStream inputStream0, long j1, int i3) {
		if(inputStream0 instanceof VorbisFile.SeekableInputStream) {
			VorbisFile.SeekableInputStream vorbisFile$SeekableInputStream4 = (VorbisFile.SeekableInputStream)inputStream0;

			try {
				if(i3 == 0) {
					vorbisFile$SeekableInputStream4.seek(j1);
				} else if(i3 == 2) {
					vorbisFile$SeekableInputStream4.seek(vorbisFile$SeekableInputStream4.getLength() - j1);
				}
			} catch (Exception exception6) {
			}

			return 0;
		} else {
			try {
				if(i3 == 0) {
					inputStream0.reset();
				}

				inputStream0.skip(j1);
				return 0;
			} catch (Exception exception7) {
				return -1;
			}
		}
	}

	static long ftell(InputStream inputStream0) {
		try {
			if(inputStream0 instanceof VorbisFile.SeekableInputStream) {
				VorbisFile.SeekableInputStream vorbisFile$SeekableInputStream1 = (VorbisFile.SeekableInputStream)inputStream0;
				return vorbisFile$SeekableInputStream1.tell();
			}
		} catch (Exception exception2) {
		}

		return 0L;
	}

	int open(InputStream inputStream1, byte[] b2, int i3) {
		return this.open_callbacks(inputStream1, b2, i3);
	}

	int open_callbacks(InputStream inputStream1, byte[] b2, int i3) {
		this.datasource = inputStream1;
		this.oy.init();
		if(b2 != null) {
			int i5 = this.oy.buffer(i3);
			System.arraycopy(b2, 0, this.oy.data, i5, i3);
			this.oy.wrote(i3);
		}

		int i4;
		if(inputStream1 instanceof VorbisFile.SeekableInputStream) {
			i4 = this.open_seekable();
		} else {
			i4 = this.open_nonseekable();
		}

		if(i4 != 0) {
			this.datasource = null;
			this.clear();
		}

		return i4;
	}

	public int streams() {
		return this.links;
	}

	public boolean seekable() {
		return this.seekable;
	}

	public int bitrate(int i1) {
		if(i1 >= this.links) {
			return -1;
		} else if(!this.seekable && i1 != 0) {
			return this.bitrate(0);
		} else if(i1 >= 0) {
			return this.seekable ? (int)Math.rint((double)((float)((this.offsets[i1 + 1] - this.dataoffsets[i1]) * 8L) / this.time_total(i1))) : (this.vi[i1].bitrate_nominal > 0 ? this.vi[i1].bitrate_nominal : (this.vi[i1].bitrate_upper > 0 ? (this.vi[i1].bitrate_lower > 0 ? (this.vi[i1].bitrate_upper + this.vi[i1].bitrate_lower) / 2 : this.vi[i1].bitrate_upper) : -1));
		} else {
			long j2 = 0L;

			for(int i4 = 0; i4 < this.links; ++i4) {
				j2 += (this.offsets[i4 + 1] - this.dataoffsets[i4]) * 8L;
			}

			return (int)Math.rint((double)((float)j2 / this.time_total(-1)));
		}
	}

	public int bitrate_instant() {
		int i1 = this.seekable ? this.current_link : 0;
		if(this.samptrack == 0.0F) {
			return -1;
		} else {
			int i2 = (int)((double)(this.bittrack / this.samptrack * (float)this.vi[i1].rate) + 0.5D);
			this.bittrack = 0.0F;
			this.samptrack = 0.0F;
			return i2;
		}
	}

	public int serialnumber(int i1) {
		return i1 >= this.links ? -1 : (!this.seekable && i1 >= 0 ? this.serialnumber(-1) : (i1 < 0 ? this.current_serialno : this.serialnos[i1]));
	}

	public long raw_total(int i1) {
		if(this.seekable && i1 < this.links) {
			if(i1 >= 0) {
				return this.offsets[i1 + 1] - this.offsets[i1];
			} else {
				long j2 = 0L;

				for(int i4 = 0; i4 < this.links; ++i4) {
					j2 += this.raw_total(i4);
				}

				return j2;
			}
		} else {
			return -1L;
		}
	}

	public long pcm_total(int i1) {
		if(this.seekable && i1 < this.links) {
			if(i1 >= 0) {
				return this.pcmlengths[i1];
			} else {
				long j2 = 0L;

				for(int i4 = 0; i4 < this.links; ++i4) {
					j2 += this.pcm_total(i4);
				}

				return j2;
			}
		} else {
			return -1L;
		}
	}

	public float time_total(int i1) {
		if(this.seekable && i1 < this.links) {
			if(i1 >= 0) {
				return (float)this.pcmlengths[i1] / (float)this.vi[i1].rate;
			} else {
				float f2 = 0.0F;

				for(int i3 = 0; i3 < this.links; ++i3) {
					f2 += this.time_total(i3);
				}

				return f2;
			}
		} else {
			return -1.0F;
		}
	}

	public int raw_seek(int i1) {
		if(!this.seekable) {
			return -1;
		} else if(i1 >= 0 && (long)i1 <= this.offsets[this.links]) {
			this.pcm_offset = -1L;
			this.decode_clear();
			this.seek_helper((long)i1);
			switch(this.process_packet(1)) {
			case -1:
				this.pcm_offset = -1L;
				this.decode_clear();
				return -1;
			case 0:
				this.pcm_offset = this.pcm_total(-1);
				return 0;
			default:
				while(true) {
					switch(this.process_packet(0)) {
					case -1:
						this.pcm_offset = -1L;
						this.decode_clear();
						return -1;
					case 0:
						return 0;
					}
				}
			}
		} else {
			this.pcm_offset = -1L;
			this.decode_clear();
			return -1;
		}
	}

	public int pcm_seek(long j1) {
		boolean z3 = true;
		long j4 = this.pcm_total(-1);
		if(!this.seekable) {
			return -1;
		} else if(j1 >= 0L && j1 <= j4) {
			int i19;
			for(i19 = this.links - 1; i19 >= 0; --i19) {
				j4 -= this.pcmlengths[i19];
				if(j1 >= j4) {
					break;
				}
			}

			long j6 = j1 - j4;
			long j8 = this.offsets[i19 + 1];
			long j10 = this.offsets[i19];
			int i12 = (int)j10;
			Page page13 = new Page();

			while(j10 < j8) {
				long j14;
				if(j8 - j10 < 8500L) {
					j14 = j10;
				} else {
					j14 = (j8 + j10) / 2L;
				}

				this.seek_helper(j14);
				int i16 = this.get_next_page(page13, j8 - j14);
				if(i16 == -1) {
					j8 = j14;
				} else {
					long j17 = page13.granulepos();
					if(j17 < j6) {
						i12 = i16;
						j10 = this.offset;
					} else {
						j8 = j14;
					}
				}
			}

			if(this.raw_seek(i12) != 0) {
				this.pcm_offset = -1L;
				this.decode_clear();
				return -1;
			} else if(this.pcm_offset >= j1) {
				this.pcm_offset = -1L;
				this.decode_clear();
				return -1;
			} else if(j1 > this.pcm_total(-1)) {
				this.pcm_offset = -1L;
				this.decode_clear();
				return -1;
			} else {
				while(this.pcm_offset < j1) {
					int i20 = (int)(j1 - this.pcm_offset);
					float[][][] f7 = new float[1][][];
					int[] i21 = new int[this.getInfo(-1).channels];
					int i9 = this.vd.synthesis_pcmout(f7, i21);
					if(i9 > i20) {
						i9 = i20;
					}

					this.vd.synthesis_read(i9);
					this.pcm_offset += (long)i9;
					if(i9 < i20 && this.process_packet(1) == 0) {
						this.pcm_offset = this.pcm_total(-1);
					}
				}

				return 0;
			}
		} else {
			this.pcm_offset = -1L;
			this.decode_clear();
			return -1;
		}
	}

	int time_seek(float f1) {
		boolean z2 = true;
		long j3 = this.pcm_total(-1);
		float f5 = this.time_total(-1);
		if(!this.seekable) {
			return -1;
		} else if(f1 >= 0.0F && f1 <= f5) {
			int i8;
			for(i8 = this.links - 1; i8 >= 0; --i8) {
				j3 -= this.pcmlengths[i8];
				f5 -= this.time_total(i8);
				if(f1 >= f5) {
					break;
				}
			}

			long j6 = (long)((float)j3 + (f1 - f5) * (float)this.vi[i8].rate);
			return this.pcm_seek(j6);
		} else {
			this.pcm_offset = -1L;
			this.decode_clear();
			return -1;
		}
	}

	public long raw_tell() {
		return this.offset;
	}

	public long pcm_tell() {
		return this.pcm_offset;
	}

	public float time_tell() {
		int i1 = -1;
		long j2 = 0L;
		float f4 = 0.0F;
		if(this.seekable) {
			j2 = this.pcm_total(-1);
			f4 = this.time_total(-1);

			for(i1 = this.links - 1; i1 >= 0; --i1) {
				j2 -= this.pcmlengths[i1];
				f4 -= this.time_total(i1);
				if(this.pcm_offset >= j2) {
					break;
				}
			}
		}

		return f4 + (float)(this.pcm_offset - j2) / (float)this.vi[i1].rate;
	}

	public Info getInfo(int i1) {
		return this.seekable ? (i1 < 0 ? (this.decode_ready ? this.vi[this.current_link] : null) : (i1 >= this.links ? null : this.vi[i1])) : (this.decode_ready ? this.vi[0] : null);
	}

	public Comment getComment(int i1) {
		return this.seekable ? (i1 < 0 ? (this.decode_ready ? this.vc[this.current_link] : null) : (i1 >= this.links ? null : this.vc[i1])) : (this.decode_ready ? this.vc[0] : null);
	}

	int host_is_big_endian() {
		return 1;
	}

	int read(byte[] b1, int i2, int i3, int i4, int i5, int[] i6) {
		int i7 = this.host_is_big_endian();
		int i8 = 0;

		while(true) {
			if(this.decode_ready) {
				float[][][] f10 = new float[1][][];
				int[] i11 = new int[this.getInfo(-1).channels];
				int i12 = this.vd.synthesis_pcmout(f10, i11);
				float[][] f9 = f10[0];
				if(i12 != 0) {
					int i13 = this.getInfo(-1).channels;
					int i14 = i4 * i13;
					if(i12 > i2 / i14) {
						i12 = i2 / i14;
					}

					int i15;
					int i16;
					int i17;
					int i18;
					if(i4 == 1) {
						i16 = i5 != 0 ? 0 : 128;

						for(i17 = 0; i17 < i12; ++i17) {
							for(i18 = 0; i18 < i13; ++i18) {
								i15 = (int)((double)f9[i18][i11[i18] + i17] * 128.0D + 0.5D);
								if(i15 > 127) {
									i15 = 127;
								} else if(i15 < -128) {
									i15 = -128;
								}

								b1[i8++] = (byte)(i15 + i16);
							}
						}
					} else {
						i16 = i5 != 0 ? 0 : 32768;
						if(i7 == i3) {
							int i19;
							int i20;
							if(i5 != 0) {
								for(i17 = 0; i17 < i13; ++i17) {
									i18 = i11[i17];
									i19 = i17;

									for(i20 = 0; i20 < i12; ++i20) {
										i15 = (int)((double)f9[i17][i18 + i20] * 32768.0D + 0.5D);
										if(i15 > 32767) {
											i15 = 32767;
										} else if(i15 < -32768) {
											i15 = -32768;
										}

										b1[i19] = (byte)(i15 >>> 8);
										b1[i19 + 1] = (byte)i15;
										i19 += i13 * 2;
									}
								}
							} else {
								for(i17 = 0; i17 < i13; ++i17) {
									float[] f21 = f9[i17];
									i19 = i17;

									for(i20 = 0; i20 < i12; ++i20) {
										i15 = (int)((double)f21[i20] * 32768.0D + 0.5D);
										if(i15 > 32767) {
											i15 = 32767;
										} else if(i15 < -32768) {
											i15 = -32768;
										}

										b1[i19] = (byte)(i15 + i16 >>> 8);
										b1[i19 + 1] = (byte)(i15 + i16);
										i19 += i13 * 2;
									}
								}
							}
						} else if(i3 != 0) {
							for(i17 = 0; i17 < i12; ++i17) {
								for(i18 = 0; i18 < i13; ++i18) {
									i15 = (int)((double)f9[i18][i17] * 32768.0D + 0.5D);
									if(i15 > 32767) {
										i15 = 32767;
									} else if(i15 < -32768) {
										i15 = -32768;
									}

									i15 += i16;
									b1[i8++] = (byte)(i15 >>> 8);
									b1[i8++] = (byte)i15;
								}
							}
						} else {
							for(i17 = 0; i17 < i12; ++i17) {
								for(i18 = 0; i18 < i13; ++i18) {
									i15 = (int)((double)f9[i18][i17] * 32768.0D + 0.5D);
									if(i15 > 32767) {
										i15 = 32767;
									} else if(i15 < -32768) {
										i15 = -32768;
									}

									i15 += i16;
									b1[i8++] = (byte)i15;
									b1[i8++] = (byte)(i15 >>> 8);
								}
							}
						}
					}

					this.vd.synthesis_read(i12);
					this.pcm_offset += (long)i12;
					if(i6 != null) {
						i6[0] = this.current_link;
					}

					return i12 * i14;
				}
			}

			switch(this.process_packet(1)) {
			case -1:
				return -1;
			case 0:
				return 0;
			}
		}
	}

	public Info[] getInfo() {
		return this.vi;
	}

	public Comment[] getComment() {
		return this.vc;
	}

	public void close() {
		this.datasource.close();
	}

	class SeekableInputStream extends InputStream {
		RandomAccessFile raf = null;
		final String mode = "r";

		SeekableInputStream(String string2) {
			this.raf = new RandomAccessFile(string2, "r");
		}

		public int read() {
			return this.raf.read();
		}

		public int read(byte[] b1) {
			return this.raf.read(b1);
		}

		public int read(byte[] b1, int i2, int i3) {
			return this.raf.read(b1, i2, i3);
		}

		public long skip(long j1) {
			return (long)this.raf.skipBytes((int)j1);
		}

		public long getLength() {
			return this.raf.length();
		}

		public long tell() {
			return this.raf.getFilePointer();
		}

		public int available() {
			return this.raf.length() == this.raf.getFilePointer() ? 0 : 1;
		}

		public void close() {
			this.raf.close();
		}

		public synchronized void mark(int i1) {
		}

		public synchronized void reset() {
		}

		public boolean markSupported() {
			return false;
		}

		public void seek(long j1) {
			this.raf.seek(j1);
		}
	}
}
