package argo.jdom;

public class JsonNodeDoesNotMatchJsonNodeSelectorException extends IllegalArgumentException {
	JsonNodeDoesNotMatchJsonNodeSelectorException(String string1) {
		super(string1);
	}
}
