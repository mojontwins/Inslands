package argo.jdom;

interface JsonListenerToJdomAdapter_NodeContainer {
	void addNode(JsonNodeBuilder jsonNodeBuilder1);

	void addField(JsonFieldBuilder jsonFieldBuilder1);
}
