package net.minecraft.src;

import java.util.ArrayList;

public class EntitySenses {
	EntityLiving entityObj;
	ArrayList canSeeCachePositive = new ArrayList();
	ArrayList canSeeCacheNegative = new ArrayList();

	public EntitySenses(EntityLiving entityLiving1) {
		this.entityObj = entityLiving1;
	}

	public void clearSensingCache() {
		this.canSeeCachePositive.clear();
		this.canSeeCacheNegative.clear();
	}

	public boolean canSee(Entity entity1) {
		if(this.canSeeCachePositive.contains(entity1)) {
			return true;
		} else if(this.canSeeCacheNegative.contains(entity1)) {
			return false;
		} else {
			Profiler.startSection("canSee");
			boolean z2 = this.entityObj.canEntityBeSeen(entity1);
			Profiler.endSection();
			if(z2) {
				this.canSeeCachePositive.add(entity1);
			} else {
				this.canSeeCacheNegative.add(entity1);
			}

			return z2;
		}
	}
}
