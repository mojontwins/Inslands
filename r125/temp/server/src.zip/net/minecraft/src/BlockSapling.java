package net.minecraft.src;

import java.util.Random;

public class BlockSapling extends BlockFlower {
	protected BlockSapling(int i1, int i2) {
		super(i1, i2);
		float f3 = 0.4F;
		this.setBlockBounds(0.5F - f3, 0.0F, 0.5F - f3, 0.5F + f3, f3 * 2.0F, 0.5F + f3);
	}

	public void updateTick(World world1, int i2, int i3, int i4, Random random5) {
		if(!world1.isRemote) {
			super.updateTick(world1, i2, i3, i4, random5);
			if(world1.getBlockLightValue(i2, i3 + 1, i4) >= 9 && random5.nextInt(7) == 0) {
				int i6 = world1.getBlockMetadata(i2, i3, i4);
				if((i6 & 8) == 0) {
					world1.setBlockMetadataWithNotify(i2, i3, i4, i6 | 8);
				} else {
					this.growTree(world1, i2, i3, i4, random5);
				}
			}

		}
	}

	public int getBlockTextureFromSideAndMetadata(int i1, int i2) {
		i2 &= 3;
		return i2 == 1 ? 63 : (i2 == 2 ? 79 : (i2 == 3 ? 30 : super.getBlockTextureFromSideAndMetadata(i1, i2)));
	}

	public void growTree(World world1, int i2, int i3, int i4, Random random5) {
		int i6 = world1.getBlockMetadata(i2, i3, i4) & 3;
		Object object7 = null;
		int i8 = 0;
		int i9 = 0;
		boolean z10 = false;
		if(i6 == 1) {
			object7 = new WorldGenTaiga2(true);
		} else if(i6 == 2) {
			object7 = new WorldGenForest(true);
		} else if(i6 == 3) {
			for(i8 = 0; i8 >= -1; --i8) {
				for(i9 = 0; i9 >= -1; --i9) {
					if(this.func_50010_f(world1, i2 + i8, i3, i4 + i9, 3) && this.func_50010_f(world1, i2 + i8 + 1, i3, i4 + i9, 3) && this.func_50010_f(world1, i2 + i8, i3, i4 + i9 + 1, 3) && this.func_50010_f(world1, i2 + i8 + 1, i3, i4 + i9 + 1, 3)) {
						object7 = new WorldGenHugeTrees(true, 10 + random5.nextInt(20), 3, 3);
						z10 = true;
						break;
					}
				}

				if(object7 != null) {
					break;
				}
			}

			if(object7 == null) {
				i9 = 0;
				i8 = 0;
				object7 = new WorldGenTrees(true, 4 + random5.nextInt(7), 3, 3, false);
			}
		} else {
			object7 = new WorldGenTrees(true);
			if(random5.nextInt(10) == 0) {
				object7 = new WorldGenBigTree(true);
			}
		}

		if(z10) {
			world1.setBlock(i2 + i8, i3, i4 + i9, 0);
			world1.setBlock(i2 + i8 + 1, i3, i4 + i9, 0);
			world1.setBlock(i2 + i8, i3, i4 + i9 + 1, 0);
			world1.setBlock(i2 + i8 + 1, i3, i4 + i9 + 1, 0);
		} else {
			world1.setBlock(i2, i3, i4, 0);
		}

		if(!((WorldGenerator)object7).generate(world1, random5, i2 + i8, i3, i4 + i9)) {
			if(z10) {
				world1.setBlockAndMetadata(i2 + i8, i3, i4 + i9, this.blockID, i6);
				world1.setBlockAndMetadata(i2 + i8 + 1, i3, i4 + i9, this.blockID, i6);
				world1.setBlockAndMetadata(i2 + i8, i3, i4 + i9 + 1, this.blockID, i6);
				world1.setBlockAndMetadata(i2 + i8 + 1, i3, i4 + i9 + 1, this.blockID, i6);
			} else {
				world1.setBlockAndMetadata(i2, i3, i4, this.blockID, i6);
			}
		}

	}

	public boolean func_50010_f(World world1, int i2, int i3, int i4, int i5) {
		return world1.getBlockId(i2, i3, i4) == this.blockID && (world1.getBlockMetadata(i2, i3, i4) & 3) == i5;
	}

	protected int damageDropped(int i1) {
		return i1 & 3;
	}
}
