package net.minecraft.src;

public class BiomeGenSnow extends BiomeGenBase {
	public BiomeGenSnow(int i1) {
		super(i1);
	}
}
