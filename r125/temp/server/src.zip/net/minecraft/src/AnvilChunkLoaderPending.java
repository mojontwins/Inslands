package net.minecraft.src;

class AnvilChunkLoaderPending {
	public final ChunkCoordIntPair field_48581_a;
	public final NBTTagCompound field_48580_b;

	public AnvilChunkLoaderPending(ChunkCoordIntPair chunkCoordIntPair1, NBTTagCompound nBTTagCompound2) {
		this.field_48581_a = chunkCoordIntPair1;
		this.field_48580_b = nBTTagCompound2;
	}
}
