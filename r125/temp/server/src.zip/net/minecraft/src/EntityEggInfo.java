package net.minecraft.src;

public class EntityEggInfo {
	public int spawnedID;
	public int primaryColor;
	public int secondaryColor;

	public EntityEggInfo(int i1, int i2, int i3) {
		this.spawnedID = i1;
		this.primaryColor = i2;
		this.secondaryColor = i3;
	}
}
