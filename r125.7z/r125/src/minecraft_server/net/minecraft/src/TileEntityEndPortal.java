package net.minecraft.src;

public class TileEntityEndPortal extends TileEntity {
}
