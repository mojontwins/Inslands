package net.minecraft.src;

public abstract class EntityAITarget extends EntityAIBase {
	protected EntityLiving taskOwner;
	protected float field_48288_d;
	protected boolean field_48289_e;
	private boolean field_48292_a;
	private int field_48290_b;
	private int field_48286_f;
	private int field_48287_g;

	public EntityAITarget(EntityLiving entityLiving1, float f2, boolean z3) {
		this(entityLiving1, f2, z3, false);
	}

	public EntityAITarget(EntityLiving entityLiving1, float f2, boolean z3, boolean z4) {
		this.field_48290_b = 0;
		this.field_48286_f = 0;
		this.field_48287_g = 0;
		this.taskOwner = entityLiving1;
		this.field_48288_d = f2;
		this.field_48289_e = z3;
		this.field_48292_a = z4;
	}

	public boolean continueExecuting() {
		EntityLiving entityLiving1 = this.taskOwner.getAttackTarget();
		if(entityLiving1 == null) {
			return false;
		} else if(!entityLiving1.isEntityAlive()) {
			return false;
		} else if(this.taskOwner.getDistanceSqToEntity(entityLiving1) > (double)(this.field_48288_d * this.field_48288_d)) {
			return false;
		} else {
			if(this.field_48289_e) {
				if(!this.taskOwner.func_48318_al().canSee(entityLiving1)) {
					if(++this.field_48287_g > 60) {
						return false;
					}
				} else {
					this.field_48287_g = 0;
				}
			}

			return true;
		}
	}

	public void startExecuting() {
		this.field_48290_b = 0;
		this.field_48286_f = 0;
		this.field_48287_g = 0;
	}

	public void resetTask() {
		this.taskOwner.setAttackTarget((EntityLiving)null);
	}

	protected boolean func_48284_a(EntityLiving entityLiving1, boolean z2) {
		if(entityLiving1 == null) {
			return false;
		} else if(entityLiving1 == this.taskOwner) {
			return false;
		} else if(!entityLiving1.isEntityAlive()) {
			return false;
		} else if(entityLiving1.boundingBox.maxY > this.taskOwner.boundingBox.minY && entityLiving1.boundingBox.minY < this.taskOwner.boundingBox.maxY) {
			if(!this.taskOwner.func_48336_a(entityLiving1.getClass())) {
				return false;
			} else {
				if(this.taskOwner instanceof EntityTameable && ((EntityTameable)this.taskOwner).isTamed()) {
					if(entityLiving1 instanceof EntityTameable && ((EntityTameable)entityLiving1).isTamed()) {
						return false;
					}

					if(entityLiving1 == ((EntityTameable)this.taskOwner).getOwner()) {
						return false;
					}
				} else if(entityLiving1 instanceof EntityPlayer && !z2 && ((EntityPlayer)entityLiving1).capabilities.disableDamage) {
					return false;
				}

				if(!this.taskOwner.isWithinHomeDistance(MathHelper.floor_double(entityLiving1.posX), MathHelper.floor_double(entityLiving1.posY), MathHelper.floor_double(entityLiving1.posZ))) {
					return false;
				} else if(this.field_48289_e && !this.taskOwner.func_48318_al().canSee(entityLiving1)) {
					return false;
				} else {
					if(this.field_48292_a) {
						if(--this.field_48286_f <= 0) {
							this.field_48290_b = 0;
						}

						if(this.field_48290_b == 0) {
							this.field_48290_b = this.func_48285_a(entityLiving1) ? 1 : 2;
						}

						if(this.field_48290_b == 2) {
							return false;
						}
					}

					return true;
				}
			}
		} else {
			return false;
		}
	}

	private boolean func_48285_a(EntityLiving entityLiving1) {
		this.field_48286_f = 10 + this.taskOwner.getRNG().nextInt(5);
		PathEntity pathEntity2 = this.taskOwner.getNavigator().func_48661_a(entityLiving1);
		if(pathEntity2 == null) {
			return false;
		} else {
			PathPoint pathPoint3 = pathEntity2.getFinalPathPoint();
			if(pathPoint3 == null) {
				return false;
			} else {
				int i4 = pathPoint3.xCoord - MathHelper.floor_double(entityLiving1.posX);
				int i5 = pathPoint3.zCoord - MathHelper.floor_double(entityLiving1.posZ);
				return (double)(i4 * i4 + i5 * i5) <= 2.25D;
			}
		}
	}
}
