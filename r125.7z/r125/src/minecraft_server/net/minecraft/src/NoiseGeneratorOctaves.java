package net.minecraft.src;

import java.util.Random;

public class NoiseGeneratorOctaves extends NoiseGenerator {
	private NoiseGeneratorPerlin[] generatorCollection;
	private int octaves;

	public NoiseGeneratorOctaves(Random random1, int i2) {
		this.octaves = i2;
		this.generatorCollection = new NoiseGeneratorPerlin[i2];

		for(int i3 = 0; i3 < i2; ++i3) {
			this.generatorCollection[i3] = new NoiseGeneratorPerlin(random1);
		}

	}

	public double[] generateNoiseOctaves(double[] d1, int i2, int i3, int i4, int i5, int i6, int i7, double d8, double d10, double d12) {
		if(d1 == null) {
			d1 = new double[i5 * i6 * i7];
		} else {
			for(int i14 = 0; i14 < d1.length; ++i14) {
				d1[i14] = 0.0D;
			}
		}

		double d27 = 1.0D;

		for(int i16 = 0; i16 < this.octaves; ++i16) {
			double d17 = (double)i2 * d27 * d8;
			double d19 = (double)i3 * d27 * d10;
			double d21 = (double)i4 * d27 * d12;
			long j23 = MathHelper.floor_double_long(d17);
			long j25 = MathHelper.floor_double_long(d21);
			d17 -= (double)j23;
			d21 -= (double)j25;
			j23 %= 16777216L;
			j25 %= 16777216L;
			d17 += (double)j23;
			d21 += (double)j25;
			this.generatorCollection[i16].func_646_a(d1, d17, d19, d21, i5, i6, i7, d8 * d27, d10 * d27, d12 * d27, d27);
			d27 /= 2.0D;
		}

		return d1;
	}

	public double[] generateNoiseOctaves(double[] d1, int i2, int i3, int i4, int i5, double d6, double d8, double d10) {
		return this.generateNoiseOctaves(d1, i2, 10, i3, i4, 1, i5, d6, 1.0D, d8);
	}
}
