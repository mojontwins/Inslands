package net.minecraft.server;

import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.ConsoleCommandHandler;
import net.minecraft.src.ConsoleLogManager;
import net.minecraft.src.ConvertProgressUpdater;
import net.minecraft.src.EntityTracker;
import net.minecraft.src.GlobalVars;
import net.minecraft.src.ICommandListener;
import net.minecraft.src.IProgressUpdate;
import net.minecraft.src.ISaveFormat;
import net.minecraft.src.IUpdatePlayerListBox;
import net.minecraft.src.LevelThemeGlobalSettings;
import net.minecraft.src.LevelThemeSettings;
import net.minecraft.src.NetworkListenThread;
import net.minecraft.src.Packet4UpdateTime;
import net.minecraft.src.Packet95UpdateDayOfTheYear;
import net.minecraft.src.PropertyManager;
import net.minecraft.src.SaveConverterMcRegion;
import net.minecraft.src.SaveOldDir;
import net.minecraft.src.Seasons;
import net.minecraft.src.ServerCommand;
import net.minecraft.src.ServerConfigurationManager;
import net.minecraft.src.ServerGUI;
import net.minecraft.src.StatList;
import net.minecraft.src.ThreadCommandReader;
import net.minecraft.src.ThreadServerApplication;
import net.minecraft.src.ThreadSleepForeverServer;
import net.minecraft.src.Vec3D;
import net.minecraft.src.Version;
import net.minecraft.src.WorldManager;
import net.minecraft.src.WorldServer;
import net.minecraft.src.WorldServerMulti;
import net.minecraft.src.WorldSettings;
import net.minecraft.src.WorldSize;
import net.minecraft.src.WorldType;

public class MinecraftServer implements Runnable, ICommandListener {
	public static Logger logger = Logger.getLogger("Minecraft");
	public static HashMap<String,Integer> s_field_6037_b = new HashMap<String,Integer>();
	public NetworkListenThread networkServer;
	public PropertyManager propertyManagerObj;
	public WorldServer[] worldMngr;
	public ServerConfigurationManager configManager;
	private ConsoleCommandHandler commandHandler;
	private boolean serverRunning = true;
	public boolean serverStopped = false;
	int deathTime = 0;
	public String currentTask;
	public int percentDone;
	private List<IUpdatePlayerListBox> playersOnline = new ArrayList<IUpdatePlayerListBox>();
	private List<ServerCommand> commands = Collections.synchronizedList(new ArrayList<ServerCommand>());
	public EntityTracker[] entityTracker = new EntityTracker[2];
	public boolean onlineMode;
	public boolean spawnPeacefulMobs;
	public boolean pvpOn;
	public boolean allowFlight;

	public MinecraftServer() {
		new ThreadSleepForeverServer(this);
	}

	private boolean startServer() throws UnknownHostException {
		this.commandHandler = new ConsoleCommandHandler(this);
		ThreadCommandReader threadCommandReader1 = new ThreadCommandReader(this);
		threadCommandReader1.setDaemon(true);
		threadCommandReader1.start();
		ConsoleLogManager.init();
		logger.info("Starting minecraft server " + Version.getVersion());
		if(Runtime.getRuntime().maxMemory() / 1024L / 1024L < 512L) {
			logger.warning("**** NOT ENOUGH RAM!");
			logger.warning("To start the server with more ram, launch it as \"java -Xmx1024M -Xms1024M -jar minecraft_server.jar\"");
		}

		logger.info("Loading properties");
		this.propertyManagerObj = new PropertyManager(new File("server.properties"));
		String string2 = this.propertyManagerObj.getStringProperty("server-ip", "");
		this.onlineMode = this.propertyManagerObj.getBooleanProperty("online-mode", true);
		this.spawnPeacefulMobs = this.propertyManagerObj.getBooleanProperty("spawn-animals", true);
		this.pvpOn = this.propertyManagerObj.getBooleanProperty("pvp", true);
		this.allowFlight = this.propertyManagerObj.getBooleanProperty("allow-flight", false);
		
		// Level size
		WorldSize.setSizeByName(this.propertyManagerObj.getStringProperty("world-size", "normal"));
		
		// Level theme
		LevelThemeGlobalSettings.loadThemeById(LevelThemeSettings.findThemeByName(this.propertyManagerObj.getStringProperty("world-theme", "normal")).id);
		
		InetAddress inetAddress3 = null;
		if(string2.length() > 0) {
			inetAddress3 = InetAddress.getByName(string2);
		}

		int i4 = this.propertyManagerObj.getIntProperty("server-port", 25565);
		logger.info("Starting Minecraft server on " + (string2.length() == 0 ? "*" : string2) + ":" + i4);

		try {
			this.networkServer = new NetworkListenThread(this, inetAddress3, i4);
		} catch (IOException iOException13) {
			logger.warning("**** FAILED TO BIND TO PORT!");
			logger.log(Level.WARNING, "The exception was: " + iOException13.toString());
			logger.warning("Perhaps a server is already running on that port?");
			return false;
		}

		if(!this.onlineMode) {
			logger.warning("**** SERVER IS RUNNING IN OFFLINE/INSECURE MODE!");
			logger.warning("The server will make no attempt to authenticate usernames. Beware.");
			logger.warning("While this makes the game possible to play without internet access, it also opens up the ability for hackers to connect with any username they choose.");
			logger.warning("To change this, set \"online-mode\" to \"true\" in the server.settings file.");
		}

		this.configManager = new ServerConfigurationManager(this);
		this.entityTracker[0] = new EntityTracker(this, 0);
		this.entityTracker[1] = new EntityTracker(this, -1);
		long j5 = System.nanoTime();
		String string7 = this.propertyManagerObj.getStringProperty("level-name", "world");
		String string8 = this.propertyManagerObj.getStringProperty("level-seed", "");
		String string9 = this.propertyManagerObj.getStringProperty("level-type", "DEFAULT");
		
		long j9 = (new Random()).nextLong();
		if(string8.length() > 0) {
			try {
				j9 = Long.parseLong(string8);
			} catch (NumberFormatException numberFormatException12) {
				j9 = (long)string8.hashCode();
			}
		}

		WorldType worldType16 = WorldType.parseWorldType(string9);
		if(worldType16 == null) {
			worldType16 = WorldType.DEFAULT;
		}
		
		logger.info("Preparing level \"" + string7 + "\"");
		this.initWorld(new SaveConverterMcRegion(new File(".")), string7, j9, worldType16);
		logger.info("Done (" + (System.nanoTime() - j5) + "ns)! For help, type \"help\" or \"?\"");
		return true;
	}
	
	private void preloadWorld(WorldServer world) {
		int chunksLoaded = 0;
		long prevTime = System.currentTimeMillis();
		for(int x = 0; x < WorldSize.xChunks; x ++) { 
			for(int z = 0 ; z < WorldSize.zChunks; z ++) {
				long curTime = System.currentTimeMillis();
				if(curTime > prevTime + 1000L) {
					prevTime = curTime;
					this.outputPercentRemaining("Preparing spawn area", chunksLoaded * 100 / WorldSize.getTotalChunks());
				}
				chunksLoaded++;
				world.getBlockId(x, 64, z);
				world.chunkProviderServer.prepareChunk(x, z);
			}
		}
	}

	private void initWorld(ISaveFormat saveHandler, String folderName, long seed, WorldType worldType) {
		BiomeGenBase.generateBiomeLookup();
		
		if(saveHandler.isOldMapFormat(folderName)) {
			logger.info("Converting map!");
			saveHandler.converMapToMCRegion(folderName, new ConvertProgressUpdater(this));
		}

		this.worldMngr = new WorldServer[2];
		boolean generateStructures = this.propertyManagerObj.getBooleanProperty("generate-structures", true);
		
		SaveOldDir saveOldDir = new SaveOldDir(new File("."), folderName, true);

		boolean levelsAreOk;
		do {
			levelsAreOk = true;
			WorldSettings worldSettings8 = new WorldSettings(seed, 0, generateStructures, false, false, worldType);
			
			for(int i = 0; i < this.worldMngr.length; ++i) {
				logger.info("** DIM " + ( i == 0 ? 0 : -1));
				GlobalVars.initializeGameFlags();
				
				if(i == 0) {
					this.worldMngr[i] = new WorldServer(this, saveOldDir, folderName, i == 0 ? 0 : -1, worldSettings8);
				} else {
					this.worldMngr[i] = new WorldServerMulti(this, saveOldDir, folderName, i == 0 ? 0 : -1, worldSettings8, this.worldMngr[0]);
				}
				
				WorldServer worldMngr = this.worldMngr[i];				
				
				worldMngr.addWorldAccess(new WorldManager(this, this.worldMngr[i]));
				worldMngr.difficultySetting = this.propertyManagerObj.getBooleanProperty("spawn-monsters", true) ? 1 : 0;
				worldMngr.setAllowedMobSpawns(this.propertyManagerObj.getBooleanProperty("spawn-monsters", true), this.spawnPeacefulMobs);
				this.configManager.setPlayerManager(this.worldMngr);
				
				// Check if valid
				boolean newWorld = worldMngr.isNewWorld;
				if(newWorld) {
					logger.info("Generating new world");
				} else {
					logger.info("Loading existing world");
				}

				// Pregenerate/preload all level
				this.preloadWorld(worldMngr);

				if(newWorld && i == 0) {
					if(worldMngr.findingSpawnPoint) {
						logger.info("Could not find a valid spawn point for dim " + (i == 0 ? 0 : -1) + ". Retrying");
						levelsAreOk = false;
						break;
					} else if(!worldMngr.levelIsValidUponWorldTheme()) {
						logger.info("Generated overworld doesn't meet requirements for selected level theme " + LevelThemeSettings.findThemeById(LevelThemeGlobalSettings.themeID).name + ". Retrying");
						levelsAreOk = false;
						seed = worldMngr.rand.nextLong();
						break;
					}
				}
	
			}
			if(!levelsAreOk) {
				for(int i = 0; i < this.worldMngr.length; i ++) {
					this.worldMngr[i] = null;
				}
				System.gc();
			}
		} while (!levelsAreOk);

		this.clearCurrentTask();
	}

	private void outputPercentRemaining(String string1, int i2) {
		this.currentTask = string1;
		this.percentDone = i2;
		logger.info(string1 + ": " + i2 + "%");
	}

	private void clearCurrentTask() {
		this.currentTask = null;
		this.percentDone = 0;
	}

	private void saveServerWorld() {
		logger.info("Saving chunks");

		for(int i1 = 0; i1 < this.worldMngr.length; ++i1) {
			WorldServer worldServer2 = this.worldMngr[i1];
			worldServer2.saveWorld(true, (IProgressUpdate)null);
			worldServer2.s_func_30006_w();
		}

	}

	private void stopServer() {
		logger.info("Stopping server");
		if(this.configManager != null) {
			this.configManager.savePlayerStates();
		}

		for(int i1 = 0; i1 < this.worldMngr.length; ++i1) {
			WorldServer worldServer2 = this.worldMngr[i1];
			if(worldServer2 != null) {
				this.saveServerWorld();
			}
		}

	}

	public void initiateShutdown() {
		this.serverRunning = false;
	}

	public void run() {
		try {
			if(this.startServer()) {
				long j1 = System.currentTimeMillis();

				for(long j3 = 0L; this.serverRunning; Thread.sleep(1L)) {
					long j5 = System.currentTimeMillis();
					long j7 = j5 - j1;
					if(j7 > 2000L) {
						logger.warning("Can\'t keep up! Did the system time change, or is the server overloaded?");
						j7 = 2000L;
					}

					if(j7 < 0L) {
						logger.warning("Time ran backwards! Did the system time change?");
						j7 = 0L;
					}

					j3 += j7;
					j1 = j5;
					if(this.worldMngr[0].isAllPlayersFullyAsleep()) {
						this.doTick();
						j3 = 0L;
					} else {
						while(j3 > 50L) {
							j3 -= 50L;
							this.doTick();
						}
					}
				}
			} else {
				while(this.serverRunning) {
					this.commandLineParser();

					try {
						Thread.sleep(10L);
					} catch (InterruptedException interruptedException57) {
						interruptedException57.printStackTrace();
					}
				}
			}
		} catch (Throwable throwable58) {
			throwable58.printStackTrace();
			logger.log(Level.SEVERE, "Unexpected exception", throwable58);

			while(this.serverRunning) {
				this.commandLineParser();

				try {
					Thread.sleep(10L);
				} catch (InterruptedException interruptedException56) {
					interruptedException56.printStackTrace();
				}
			}
		} finally {
			try {
				this.stopServer();
				this.serverStopped = true;
			} catch (Throwable throwable54) {
				throwable54.printStackTrace();
			} finally {
				System.exit(0);
			}

		}

	}

	private void doTick() {
		ArrayList<String> arrayList1 = new ArrayList<String>();
		Iterator<String> iterator2 = s_field_6037_b.keySet().iterator();

		while(iterator2.hasNext()) {
			String string3 = (String)iterator2.next();
			int i4 = ((Integer)s_field_6037_b.get(string3)).intValue();
			if(i4 > 0) {
				s_field_6037_b.put(string3, i4 - 1);
			} else {
				arrayList1.add(string3);
			}
		}

		int i6;
		for(i6 = 0; i6 < arrayList1.size(); ++i6) {
			s_field_6037_b.remove(arrayList1.get(i6));
		}

		AxisAlignedBB.clearBoundingBoxPool();
		Vec3D.initialize();
		++this.deathTime;

		for(i6 = 0; i6 < this.worldMngr.length; ++i6) {
			if(i6 == 0 || this.propertyManagerObj.getBooleanProperty("allow-nether", true)) {
				WorldServer worldServer7 = this.worldMngr[i6];
				if(this.deathTime % 20 == 0) {
					this.configManager.sendPacketToAllPlayersInDimension(new Packet4UpdateTime(worldServer7.getWorldTime()), worldServer7.worldProvider.worldType);
				}

				int dayOfTheYear = Seasons.dayOfTheYear;
				worldServer7.tick();
				if (Seasons.dayOfTheYear != dayOfTheYear) {
					this.configManager.sendPacketToAllPlayersInDimension(new Packet95UpdateDayOfTheYear(Seasons.dayOfTheYear), worldServer7.worldProvider.worldType);
				}

				worldServer7.updateEntities();
			}
		}

		this.networkServer.handleNetworkListenThread();
		this.configManager.onTick();

		for(i6 = 0; i6 < this.entityTracker.length; ++i6) {
			this.entityTracker[i6].updateTrackedEntities();
		}

		for(i6 = 0; i6 < this.playersOnline.size(); ++i6) {
			((IUpdatePlayerListBox)this.playersOnline.get(i6)).update();
		}

		try {
			this.commandLineParser();
		} catch (Exception exception5) {
			logger.log(Level.WARNING, "Unexpected exception while parsing console command", exception5);
		}

	}

	public void addCommand(String string1, ICommandListener iCommandListener2) {
		this.commands.add(new ServerCommand(string1, iCommandListener2));
	}

	public void commandLineParser() {
		while(this.commands.size() > 0) {
			ServerCommand serverCommand1 = (ServerCommand)this.commands.remove(0);
			this.commandHandler.handleCommand(serverCommand1);
		}

	}

	public void addToOnlinePlayerList(IUpdatePlayerListBox iUpdatePlayerListBox1) {
		this.playersOnline.add(iUpdatePlayerListBox1);
	}

	public static void main(String[] string0) {
		StatList.preInit();

		try {
			MinecraftServer minecraftServer1 = new MinecraftServer();
			if(!GraphicsEnvironment.isHeadless() && (string0.length <= 0 || !string0[0].equals("nogui"))) {
				ServerGUI.initGui(minecraftServer1);
			}

			(new ThreadServerApplication("Server thread", minecraftServer1)).start();
		} catch (Exception exception2) {
			logger.log(Level.SEVERE, "Failed to start the minecraft server", exception2);
		}

	}

	public File getFile(String string1) {
		return new File(string1);
	}

	public void log(String string1) {
		logger.info(string1);
	}

	public void logWarning(String string1) {
		logger.warning(string1);
	}

	public String getUsername() {
		return "CONSOLE";
	}

	public WorldServer getWorldManager(int i1) {
		return i1 == -1 ? this.worldMngr[1] : this.worldMngr[0];
	}

	public EntityTracker getEntityTracker(int i1) {
		return i1 == -1 ? this.entityTracker[1] : this.entityTracker[0];
	}

	public static boolean isServerRunning(MinecraftServer minecraftServer0) {
		return minecraftServer0.serverRunning;
	}
}
