package net.minecraft.src;

public class Version {
	private static final String version = "InSlands v250707";
	private static final String date = "20250707";
	
	public static String getVersion () { 
		return version;
	}

	public static String getDate() {
		return date;
	}
}
