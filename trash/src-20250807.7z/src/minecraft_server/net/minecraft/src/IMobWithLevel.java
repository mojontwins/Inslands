package net.minecraft.src;

public interface IMobWithLevel {
	public void setLevel(int level);

	public int getMaxLevel();
}
