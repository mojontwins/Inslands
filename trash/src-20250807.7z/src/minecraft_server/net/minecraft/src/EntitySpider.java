package net.minecraft.src;

public class EntitySpider extends EntitySpiderBase implements IMob {

	public EntitySpider(World world1) {
		super(world1);
	}

}
