package com.mojontwins.minecraft.icepalace;

public class PalacePiecePosition {
	public int x, y, z;
	public boolean rotated;
	
	public PalacePiecePosition(int x, int y, int z, boolean rotated) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.rotated = rotated;
	}

}
