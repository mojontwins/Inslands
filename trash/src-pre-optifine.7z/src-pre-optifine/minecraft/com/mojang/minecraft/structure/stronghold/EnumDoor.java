package com.mojang.minecraft.structure.stronghold;

public enum EnumDoor {
	OPENING,
	WOOD_DOOR,
	GRATES,
	IRON_DOOR;
}
