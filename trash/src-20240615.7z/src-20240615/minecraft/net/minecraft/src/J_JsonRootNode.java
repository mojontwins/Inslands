package net.minecraft.src;

public abstract class J_JsonRootNode extends J_JsonNode {
}
