package net.minecraft.src;

public class MinecraftError extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5660431779816150072L;
}
