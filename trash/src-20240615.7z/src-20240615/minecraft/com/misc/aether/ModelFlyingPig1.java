package com.misc.aether;

import net.minecraft.src.ModelQuadruped;

public class ModelFlyingPig1 extends ModelQuadruped {
	public ModelFlyingPig1() {
		super(6, 0.0F);
	}

	public ModelFlyingPig1(float f) {
		super(6, f);
	}
}
