package com.mojontwins.minecraft.icepalace;

import com.chocolatin.betterdungeons.RenderHuman;

import net.minecraft.src.ModelBase;

public class RenderIceBoss extends RenderHuman {

	public RenderIceBoss(ModelBase modelbase, float f) {
		super(modelbase, f);
	}

}
