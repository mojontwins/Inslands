package net.minecraft.src;

public class Facing {
    public static final int faceToSide[] = { 1, 0, 3, 2, 5, 4 };
    public static final int offsetsXForSide[] = { 0, 0, 0, 0, -1, 1 };
    public static final int offsetsYForSide[] = { -1, 1, 0, 0, 0, 0 };
    public static final int offsetsZForSide[] = { 0, 0, -1, 1, 0, 0 };
}
