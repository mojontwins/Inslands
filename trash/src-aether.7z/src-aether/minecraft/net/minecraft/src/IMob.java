package net.minecraft.src;

public interface IMob {
}
