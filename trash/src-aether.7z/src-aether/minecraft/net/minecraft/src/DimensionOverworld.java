package net.minecraft.src;

public class DimensionOverworld extends DimensionBase {
	public DimensionOverworld() {
		super(0, WorldProviderSurface.class, (Class)null);
		this.name = "Overworld";
	}
}
