package net.minecraft.src;

public enum EnumElement {
	Fire,
	Lightning,
	Holy;
}
