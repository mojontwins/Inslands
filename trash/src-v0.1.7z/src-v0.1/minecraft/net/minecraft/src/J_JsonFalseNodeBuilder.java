package net.minecraft.src;

final class J_JsonFalseNodeBuilder implements J_JsonNodeBuilder {
	public J_JsonNode func_27234_b() {
		return J_JsonNodeFactories.func_27314_c();
	}
}
