package net.minecraft.src;

interface J_ThingWithPosition {
	int func_27331_a();

	int func_27330_b();
}
