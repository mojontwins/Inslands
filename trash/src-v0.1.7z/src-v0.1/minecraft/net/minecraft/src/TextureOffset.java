package net.minecraft.src;

public class TextureOffset {
	public final int u;
	public final int v;

	public TextureOffset(int i1, int i2) {
		this.u = i1;
		this.v = i2;
	}
}
