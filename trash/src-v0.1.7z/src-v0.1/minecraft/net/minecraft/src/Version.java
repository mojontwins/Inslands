package net.minecraft.src;

public class Version {
	private static final String version = "InSlands v0.1";
	
	public static String getVersion () { 
		return version;
	}
}
