package net.minecraft.src;

public class ThreadSleepForever extends Thread {
	// Dummy. Stays so the reobfuscator doesn't go nuts!
}
