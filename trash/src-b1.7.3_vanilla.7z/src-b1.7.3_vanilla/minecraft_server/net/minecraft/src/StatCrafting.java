package net.minecraft.src;

public class StatCrafting extends StatBase {
	private final int field_27990_a;

	public StatCrafting(int i1, String string2, int i3) {
		super(i1, string2);
		this.field_27990_a = i3;
	}
}
