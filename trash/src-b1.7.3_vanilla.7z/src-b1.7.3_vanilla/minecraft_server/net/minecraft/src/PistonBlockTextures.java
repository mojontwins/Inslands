package net.minecraft.src;

public class PistonBlockTextures {
	public static final int[] field_31052_a = new int[]{1, 0, 3, 2, 5, 4};
	public static final int[] field_31051_b = new int[]{0, 0, 0, 0, -1, 1};
	public static final int[] field_31054_c = new int[]{-1, 1, 0, 0, 0, 0};
	public static final int[] field_31053_d = new int[]{0, 0, -1, 1, 0, 0};
}
