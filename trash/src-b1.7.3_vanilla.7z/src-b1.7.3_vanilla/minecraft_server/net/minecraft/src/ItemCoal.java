package net.minecraft.src;

public class ItemCoal extends Item {
	public ItemCoal(int i1) {
		super(i1);
		this.setHasSubtypes(true);
		this.setMaxDamage(0);
	}
}
